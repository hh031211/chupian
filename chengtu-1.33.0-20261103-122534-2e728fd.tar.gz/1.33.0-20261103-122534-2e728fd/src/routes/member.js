'use strict';
// 会员中心：套餐、下单支付、订单/点数明细、优惠券、兑换码、邀请记录；支付回调
const db = require('../core/db');
const S = require('../core/settings');
const users = require('../core/users');
const orders = require('../core/orders');
const wx = require('../core/wechat');
const config = require('../core/config');
const { fail } = require('../core/http');
const guard = require('../core/guard');
const { now, str, int, pageArgs, fmtTime, money } = require('../core/util');

function inviteLink(code) {
  const base = (S.get('site').frontend_url || config.siteUrl || '').replace(/\/$/, '');
  return `${base}/?code=${code}`;
}
function maskName(u) {
  const n = String((u && (u.nickname || u.username)) || '用户');
  return n.length <= 1 ? n + '*' : n[0] + '*'.repeat(Math.min(3, n.length - 1)) + (n.length > 2 ? n[n.length - 1] : '');
}

function planView(p) {
  return {
    id: p.id, type: p.type, tag: p.tag, title: p.title, price: p.price, original_price: p.original_price, points: p.points, days: p.days,
    note: p.note, highlight: p.highlight ? 1 : 0, level: p.level || p.type,
  };
}

function couponView(c) {
  return {
    id: c.id, title: c.title, name: c.title, amount: c.amount, threshold_amount: c.threshold_amount,
    cond: c.threshold_amount > 0 ? `满 ${c.threshold_amount} 元可用` : '无门槛', type: 'cash', status: c.status,
    expireAt: fmtTime(c.expiretime).slice(0, 10), expiretime: c.expiretime, expiretime_text: fmtTime(c.expiretime),
    usetime_text: c.usetime ? fmtTime(c.usetime) : '',
  };
}

function expireCoupons(userId) {
  db.run(`UPDATE yd_user_coupon SET status='expired' WHERE user_id=? AND status='valid' AND expiretime<?`, userId, now());
}

module.exports = (route) => {
  route('/member/plans', () => {
    const rows = db.all(`SELECT * FROM yd_plan WHERE status='normal' ORDER BY type, sort, id`);
    const plans = { basic: [], enterprise: [], pack: [] };
    for (const r of rows) (plans[r.type] || (plans[r.type] = [])).push(planView(r));
    return { plans };
  }, { auth: 'optional' });

  route('/member/center', ({ user }) => {
    const bill = users.billUser(user);
    return {
      userinfo: users.userinfo(user),
      level: users.effectiveLevel(user),
      score: bill.score,
      orders: db.val(`SELECT COUNT(*) FROM yd_order WHERE user_id=? AND pay_status='paid'`, user.id),
    };
  });

  route('/member/order', async ({ p, user }) => {
    const plan = db.get(`SELECT * FROM yd_plan WHERE id=? AND status='normal'`, int(p.plan_id));
    if (!plan) fail('套餐不存在或已下架');
    if (plan.type === 'pack' && users.effectiveLevel(user) === 'free') fail('加油包需在会员有效期内购买，请先开通会员');
    let amount = money(plan.price);
    let discount = 0;
    let couponId = 0;
    guard.rl('order:' + user.id, 20, 600, '下单太频繁，请稍后再试');
    if (int(p.coupon_id)) {
      expireCoupons(user.id);
      const c = db.get(`SELECT * FROM yd_user_coupon WHERE id=? AND user_id=? AND status='valid'`, int(p.coupon_id), user.id);
      if (!c) fail('优惠券不可用');
      if (c.threshold_amount > amount) fail('未达到优惠券使用门槛');
      discount = Math.min(c.amount, amount - 0.01);
      amount = money(Math.max(0.01, amount - c.amount));
      couponId = c.id;
    }
    const payType = p.pay_type === 'mppay' ? 'mppay' : 'wxpay';
    const order = orders.createOrder({ user, kind: 'member', plan, amount, points: plan.points, couponId, discount, payType });
    const pay = await orders.createPay(order, user, payType);
    return { order: orders.orderView(order), pay };
  });

  route('/member/status', async ({ p, user }) => {
    let o = db.get('SELECT * FROM yd_order WHERE order_sn=? AND user_id=?', str(p.order_sn), user.id);
    if (!o) fail('订单不存在');
    o = await orders.syncOrder(o);
    return { order: orders.orderView(o), userinfo: users.userinfo(users.getUser(user.id)) };
  });

  route('/member/orders', ({ p, user }) => {
    const { limit, offset, page } = pageArgs(p, 10);
    const total = db.val(`SELECT COUNT(*) FROM yd_order WHERE user_id=? AND kind='member'`, user.id);
    const list = db.all(`SELECT * FROM yd_order WHERE user_id=? AND kind='member' ORDER BY id DESC LIMIT ? OFFSET ?`, user.id, limit, offset).map(orders.orderView);
    return { list, total, page, limit };
  });

  route('/member/logs', ({ p, user }) => {
    const { limit, offset, page } = pageArgs(p, 10);
    const uid = users.billUser(user).id;
    const total = db.val('SELECT COUNT(*) FROM yd_score_log WHERE user_id=?', uid);
    const list = db.all('SELECT * FROM yd_score_log WHERE user_id=? ORDER BY id DESC LIMIT ? OFFSET ?', uid, limit, offset).map((r) => ({
      id: r.id, type: r.type, change: r.change, balance: r.balance, remark: r.remark, createtime: r.createtime, createtime_text: fmtTime(r.createtime),
    }));
    return { list, total, page, limit };
  });

  route('/member/rights', ({ user }) => {
    expireCoupons(user.id);
    const redeems = db.all(`SELECT * FROM yd_redeem_code WHERE used_user_id=? ORDER BY usetime DESC LIMIT 50`, user.id).map((r) => ({
      id: r.id, code: r.code, title: r.title, points: r.points, days: r.days, usetime_text: fmtTime(r.usetime),
    }));
    const claimed = new Set(db.all('SELECT activity_id FROM yd_user_coupon WHERE user_id=?', user.id).map((x) => x.activity_id));
    const activities = db.all(
      `SELECT * FROM yd_coupon_activity WHERE status='normal' AND (starttime=0 OR starttime<=?) AND (endtime=0 OR endtime>=?) ORDER BY id DESC`, now(), now(),
    ).map((a) => ({
      id: a.id, title: a.title, name: a.title, amount: a.amount, cond: a.threshold_amount > 0 ? `满 ${a.threshold_amount} 元可用` : '无门槛',
      threshold_amount: a.threshold_amount, expireAt: a.endtime ? fmtTime(a.endtime).slice(0, 10) : `领取后 ${a.valid_days} 天内有效`,
      claimed: claimed.has(a.id) ? 1 : 0, left: a.total ? Math.max(0, a.total - a.claimed) : -1,
    }));
    const all = db.all('SELECT * FROM yd_user_coupon WHERE user_id=? ORDER BY id DESC', user.id).map(couponView);
    return {
      redeems, activities,
      coupons: { valid: all.filter((c) => c.status === 'valid'), used: all.filter((c) => c.status === 'used'), expired: all.filter((c) => c.status === 'expired') },
    };
  });

  route('/member/coupons', ({ p, user }) => {
    expireCoupons(user.id);
    const amount = Number(p.amount || 0);
    const list = db.all(`SELECT * FROM yd_user_coupon WHERE user_id=? AND status='valid' ORDER BY amount DESC`, user.id)
      .filter((c) => !amount || c.threshold_amount <= amount).map(couponView);
    return { list };
  });

  route('/member/claimcoupon', ({ p, user }) => db.tx(() => {
    const a = db.get(`SELECT * FROM yd_coupon_activity WHERE id=? AND status='normal'`, int(p.activity_id));
    if (!a) fail('活动不存在或已结束');
    if ((a.starttime && a.starttime > now()) || (a.endtime && a.endtime < now())) fail('不在活动时间内');
    if (a.total && a.claimed >= a.total) fail('优惠券已被领完');
    const mine = db.val('SELECT COUNT(*) FROM yd_user_coupon WHERE user_id=? AND activity_id=?', user.id, a.id);
    if (mine >= (a.per_user || 1)) fail('您已领取过该优惠券');
    db.insert('yd_user_coupon', {
      user_id: user.id, activity_id: a.id, title: a.title, amount: a.amount, threshold_amount: a.threshold_amount, status: 'valid',
      expiretime: a.endtime && a.valid_days <= 0 ? a.endtime : now() + (a.valid_days || 30) * 86400, createtime: now(),
    });
    db.run('UPDATE yd_coupon_activity SET claimed=claimed+1 WHERE id=?', a.id);
    return null;
  }));

  route('/member/redeem', ({ p, user }) => {
    const code = str(p.code);
    if (!code) fail('请输入兑换码');
    guard.rl('redeem:' + user.id, 10, 600, '兑换尝试太频繁，请 10 分钟后再试');
    const u = orders.redeem(user, code);
    return { userinfo: users.userinfo(u) };
  });

  // ---------- 邀请记录（邀请好友得点数） ----------
  route('/task/center', ({ p, user }) => {
    const inv = S.get('invite');
    const { limit, offset } = pageArgs(p, 20);
    const rows = db.all('SELECT id, nickname, username, jointime FROM yd_user WHERE parent_user_id=? AND deletetime=0 ORDER BY id DESC LIMIT ? OFFSET ?', user.id, limit, offset);
    const rewarded = db.all(`SELECT ref, change FROM yd_score_log WHERE user_id=? AND ref LIKE 'invite:%'`, user.id);
    const rmap = new Map(rewarded.map((r) => [r.ref, r.change]));
    const total = db.val('SELECT COUNT(*) FROM yd_user WHERE parent_user_id=? AND deletetime=0', user.id) || 0;
    const every = Math.max(1, Number(inv.reward_every || 1));
    return {
      invite_code: user.invite_code,
      invite_link: inviteLink(user.invite_code),
      invited_count: total,
      rewarded_points: rewarded.reduce((a, r) => a + r.change, 0),
      pending_count: total % every,
      reward_points: Number(inv.reward_points || 0),
      reward_every: every,
      invites: rows.map((u) => ({
        id: u.id, nickname: maskName(u), registered_at: fmtTime(u.jointime), status: rmap.has(`invite:${u.id}`) ? 'rewarded' : 'counted',
        points: rmap.get(`invite:${u.id}`) || 0,
      })),
      total,
      beans: users.billUser(user).score,
    };
  });

  // ---------- 支付回调 ----------
  route('/pay/wechat/notify', ({ p, res }) => {
    try {
      const body = p.resource ? p : JSON.parse(p._raw || '{}');
      const data = wx.payDecrypt(body.resource);
      if (data.trade_state === 'SUCCESS') {
        // 实付金额必须和订单金额一致才发货（防止篡改金额的订单被当成全额支付）
        const o = db.get('SELECT amount FROM yd_order WHERE order_sn=?', str(data.out_trade_no));
        const paid = Number(data.amount && data.amount.total);
        if (o && Number.isFinite(paid) && paid < Math.round(o.amount * 100)) throw new Error(`金额不符：订单 ${o.amount} 元，实付 ${paid / 100} 元`);
        orders.fulfill(data.out_trade_no, data.transaction_id || '');
      }
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ code: 'SUCCESS', message: '成功' }));
    } catch (e) {
      console.error('[pay notify]', e.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ code: 'FAIL', message: e.message }));
    }
    return undefined;
  }, { auth: false, raw: true });

  // 模拟支付（仅后台开启“模拟支付”时可用，用于联调测试）
  route('/pay/mock', ({ p, res }) => {
    const pay = S.get('payment');
    const o = db.get('SELECT * FROM yd_order WHERE order_sn=?', str(p.order_sn));
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    if (!pay.mock || !o) { res.end('<h3>模拟支付未开启或订单不存在</h3>'); return undefined; }
    if (p.confirm === '1') {
      orders.fulfill(o.order_sn, 'MOCK' + now(), 'mock');
      res.end('<meta name="viewport" content="width=device-width"><h2 style="font-family:sans-serif;text-align:center;margin-top:30vh">✅ 模拟支付成功</h2>');
      return undefined;
    }
    res.end(`<meta name="viewport" content="width=device-width"><div style="font-family:sans-serif;text-align:center;margin-top:25vh">
      <h3>模拟支付（测试用）</h3><p>${o.title}</p><p style="font-size:28px;color:#e33">¥${o.amount}</p>
      <a href="?order_sn=${o.order_sn}&confirm=1" style="display:inline-block;padding:12px 40px;background:#07c160;color:#fff;border-radius:8px;text-decoration:none">确认支付</a></div>`);
    return undefined;
  }, { auth: false, raw: true });
};
