'use strict';
// 素材库（官方素材，前台只读）：分类、列表（分类 / 搜索 / 排序）、详情、使用计数
const db = require('../core/db');
const gallery = require('../ai/gallery');
const { str, int, pageArgs } = require('../core/util');

const { initials } = require('../core/pinyin-initials');
// 已上架素材的拼音首字母缓存（素材有变动时重算）
let pyCache = { key: '', rows: [] };
function pinyinIds(q) {
  const key = String(db.val(`SELECT COUNT(*) || '-' || COALESCE(MAX(updatetime), 0) FROM yd_gallery WHERE status='online'`) || '');
  if (pyCache.key !== key) {
    pyCache = { key, rows: db.all(`SELECT id, title, tags FROM yd_gallery WHERE status='online'`).map((r) => ({ id: r.id, py: initials(r.title) + ' ' + initials(r.tags) })) };
  }
  return pyCache.rows.filter((r) => r.py.includes(q)).slice(0, 500).map((r) => r.id);
}

module.exports = (route) => {
  route('/gallery/cats', () => {
    const counts = new Map(db.all(`SELECT cat_id, COUNT(*) n FROM yd_gallery WHERE status='online' GROUP BY cat_id`).map((r) => [r.cat_id, r.n]));
    const list = gallery.cats().map((c) => ({ id: c.id, name: c.name, count: counts.get(c.id) || 0 })).filter((c) => c.count > 0);
    return { cats: list, total: db.val(`SELECT COUNT(*) FROM yd_gallery WHERE status='online'`) || 0 };
  }, { auth: false });

  route('/gallery/lists', ({ p }) => {
    const { page, limit, offset } = pageArgs(p, 30, 60);
    const where = [`status='online'`];
    const args = [];
    if (int(p.cat_id)) { where.push('cat_id=?'); args.push(int(p.cat_id)); }
    const q = str(p.q || p.keyword).slice(0, 40);
    const tag = str(p.tag).slice(0, 20);
    if (tag) { where.push('tags LIKE ?'); args.push(`%${JSON.stringify(tag)}%`); }
    // 拼音首字母（kh → 口红、xhs → 小红书）：纯字母的搜索词再按标题 / 标签的首字母匹配
    const py = /^[a-z]{2,12}$/i.test(q) ? pinyinIds(q.toLowerCase()) : [];
    if (q) {
      const parts = []; const pa = [];
      for (const w of q.split(/\s+/).filter(Boolean).slice(0, 5)) { parts.push('(title LIKE ? OR prompt LIKE ? OR tags LIKE ?)'); pa.push(`%${w}%`, `%${w}%`, `%${w}%`); }
      where.push(`((${parts.join(' AND ')})${py.length ? ` OR id IN (${py.map(() => '?').join(',')})` : ''})`); args.push(...pa, ...py);
    }
    const order = p.sort === 'hot' ? 'hot DESC, id DESC' : p.sort === 'new' ? 'id DESC' : gallery.FRONT_ORDER;   // 默认 = 后台「已上架」里排好的顺序
    const total = db.val(`SELECT COUNT(*) FROM yd_gallery WHERE ${where.join(' AND ')}`, ...args) || 0;
    const catMap = new Map(gallery.cats().map((c) => [c.id, c]));
    const items = db.all(`SELECT * FROM yd_gallery WHERE ${where.join(' AND ')} ORDER BY ${order} LIMIT ? OFFSET ?`, ...args, limit, offset).map((g) => gallery.itemView(g, catMap));
    return { items, total, page, limit, more: offset + items.length < total };
  }, { auth: false });

  // 热门标签（素材库的「风格」筛选）：已上架素材里出现最多的标签
  route('/gallery/tags', ({ p }) => {
    const where = [`status='online'`]; const args = [];
    if (int(p.cat_id)) { where.push('cat_id=?'); args.push(int(p.cat_id)); }
    const cnt = new Map();
    for (const r of db.all(`SELECT tags FROM yd_gallery WHERE ${where.join(' AND ')}`, ...args)) {
      let t = []; try { t = JSON.parse(r.tags || '[]'); } catch { t = []; }
      for (const x of new Set((Array.isArray(t) ? t : []).map((v) => String(v).trim()).filter((v) => v && v.length <= 8 && !/[:：]/.test(v)))) cnt.set(x, (cnt.get(x) || 0) + 1);
    }
    return { tags: [...cnt.entries()].filter(([, n]) => n >= 2).sort((a, b) => b[1] - a[1]).slice(0, 16).map(([name, count]) => ({ name, count })) };
  }, { auth: false });

  route('/gallery/one', ({ p }) => {
    const g = db.get(`SELECT * FROM yd_gallery WHERE id=? AND status='online'`, int(p.id));
    return { item: g ? gallery.itemView(g) : null };
  }, { auth: false });

  // 一键同款确认后计一次使用（「最热」排序用）
  route('/gallery/use', ({ p }) => {
    db.run(`UPDATE yd_gallery SET hot=hot+1 WHERE id=? AND status='online'`, int(p.id));
    return null;
  });
};
