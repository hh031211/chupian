'use strict';
// 资料库类接口：上传、我的素材、站点信息、公告、反馈、项目库记录、回收站
const db = require('../core/db');
const S = require('../core/settings');
const storage = require('../core/storage');
const engine = require('../ai/engine');
const { fail } = require('../core/http');
const guard = require('../core/guard');
const { now, str, int, pageArgs, fmtTime, jsonParse } = require('../core/util');

const TRASH_DAYS = 30;
const asIds = (v) => (Array.isArray(v) ? v : v == null || v === '' ? [] : [v]).map((x) => int(x)).filter((x) => x > 0);
const gid = (v) => (v === 'default' || v === 'all' || v == null || v === '' ? 0 : int(v));

module.exports = (route) => {
  // ---------------- 上传 ----------------
  async function handleUpload({ files, p, user }, imageOnly) {
    const f = files.find((x) => x.field === 'file') || files[0];
    if (!f || !f.size) fail('请选择要上传的文件');
    guard.rl('up:' + user.id, 300, 600, '上传太频繁，请稍后再试');
    // 文件类型只看文件内容本身（不信浏览器报的类型）；SVG / 网页 / 脚本一律不收
    const sniffed = storage.sniff(f.buffer) || '';
    if (/svg/.test(sniffed)) fail('不支持 SVG 图片');
    if (imageOnly && !/^image\//.test(sniffed)) fail('只能上传图片文件');
    if (!imageOnly && !/^(image|video)\//.test(sniffed) && sniffed !== 'application/pdf') fail('只能上传图片、视频或 PDF 文件');
    const saved = await storage.saveBuffer(f.buffer, { mimetype: sniffed, category: str(p.category) || (imageOnly ? 'image' : 'file') });
    db.insert('yd_upload', {
      user_id: user ? user.id : 0, url: saved.url, fullurl: saved.fullurl, mimetype: saved.mimetype, filesize: saved.filesize, width: saved.width,
      height: saved.height, category: str(p.category, 30), source: str(p.scene, 30), createtime: now(),
    });
    return { ...saved, name: f.filename };
  }
  route('/upload/image', (c) => handleUpload(c, true));
  route('/upload/file', (c) => handleUpload(c, false));

  // ---------------- 素材库 ----------------
  function materialView(m) {
    return {
      id: m.id, name: m.name, group_id: m.group_id || 'default', category_id: m.category_id, url: m.fullurl || m.url, fullurl: m.fullurl || m.url,
      src: m.fullurl || m.url, mimetype: m.mimetype, filesize: m.filesize, width: m.width, height: m.height, createtime: m.createtime,
    };
  }
  route('/material/lists', ({ p, user }) => {
    const { page, limit, offset } = pageArgs(p, 24, 200);
    const groups = [{ id: 'default', name: '默认分组', isDefault: true }, ...db.all('SELECT id, name FROM yd_material_group WHERE user_id=? ORDER BY id', user.id)];
    const g = gid(p.group_id);
    const where = g ? 'user_id=? AND group_id=?' : 'user_id=?';
    const args = g ? [user.id, g] : [user.id];
    const total = db.val(`SELECT COUNT(*) FROM yd_material WHERE ${where}`, ...args) || 0;
    const materials = db.all(`SELECT * FROM yd_material WHERE ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map(materialView);
    return { groups, materials, page, limit, total, hasMore: offset + materials.length < total };
  });
  route('/material/addgroup', ({ p, user }) => {
    const name = str(p.name, 30);
    if (!name) fail('请输入分组名称');
    if (db.val('SELECT COUNT(*) FROM yd_material_group WHERE user_id=?', user.id) >= 50) fail('分组数量已达上限');
    const id = db.insert('yd_material_group', { user_id: user.id, name, createtime: now() });
    return { group: { id, name } };
  });
  route('/material/renamegroup', ({ p, user }) => {
    const name = str(p.name, 30);
    if (!name) fail('请输入分组名称');
    db.update('yd_material_group', { name }, 'id=? AND user_id=?', int(p.id), user.id);
    return { group: { id: int(p.id), name } };
  });
  route('/material/delgroup', ({ p, user }) => {
    const id = int(p.id);
    db.run('UPDATE yd_material SET group_id=0 WHERE user_id=? AND group_id=?', user.id, id);
    db.run('DELETE FROM yd_material_group WHERE id=? AND user_id=?', id, user.id);
    return null;
  });
  route('/material/add', ({ p, user }) => {
    const url = str(p.fullurl || p.url, 1000);
    if (!url) fail('素材地址为空');
    if (!/^(https?:\/\/|\/uploads\/)/i.test(url)) fail('素材地址不正确');
    if (db.val('SELECT COUNT(*) FROM yd_material WHERE user_id=?', user.id) >= 5000) fail('素材数量已达上限，请清理后再添加');
    const g = gid(p.group_id);
    if (g && !db.get('SELECT id FROM yd_material_group WHERE id=? AND user_id=?', g, user.id)) fail('分组不存在');
    const id = db.insert('yd_material', {
      user_id: user.id, group_id: g, name: str(p.name, 60) || '素材', url, fullurl: url, mimetype: str(p.mimetype, 50) || 'image/jpeg',
      filesize: int(p.filesize), width: int(p.width), height: int(p.height), createtime: now(),
    });
    return { material: materialView(db.get('SELECT * FROM yd_material WHERE id=?', id)) };
  });
  route('/material/move', ({ p, user }) => {
    const ids = asIds(p.ids);
    const g = gid(p.group_id);
    if (!ids.length) fail('请选择素材');
    db.run(`UPDATE yd_material SET group_id=? WHERE user_id=? AND id IN (${ids.map(() => '?').join(',')})`, g, user.id, ...ids);
    return null;
  });
  route('/material/del', ({ p, user }) => {
    const ids = asIds(p.ids);
    if (ids.length) db.run(`DELETE FROM yd_material WHERE user_id=? AND id IN (${ids.map(() => '?').join(',')})`, user.id, ...ids);
    return null;
  });

  // ---------------- 站点信息（新前端读取：页脚、客服、登录方式） ----------------
  route('/site/config', () => {
    const site = S.get('site') || {};
    const reg = S.get('register') || {};
    const hours = String(site.service_time || '周一至周日 上午 9:00-11:30，下午 13:30-18:00');
    return {
      name: site.name || '出片儿',
      company: site.company || site.name || '出片儿',
      icp: site.icp || '',
      email: site.email || '',
      phone: site.phone || '',
      service_time: hours,
      service_hours: hours.replace(/^周\S*\s+/, ''),
      kefu_image: '/brand/kefu.png',
      username_register: reg.username_register !== false,
      login_captcha: !!reg.login_captcha,
      register_captcha: reg.register_captcha !== false,
      password_min: Math.max(8, Number(reg.password_min) || 8),
      gift_points: Number(reg.gift_points || 0), gift_need_mobile: reg.gift_need_mobile !== false,
      human: require('../core/human').publicConfig(),
      thumb_width: site.thumb_width === undefined ? 480 : Number(site.thumb_width) || 0,
      img_hosts: (() => { const c = (S.get('storage') || {}).cos || {}; try { return c.domain ? [new URL(c.domain).origin] : []; } catch { return []; } })(),
    };
  }, { auth: false });

  // 关于我们 / 用户协议 / 隐私政策
  route('/site/legal', ({ p }) => require('../core/legal').legal(String(p.key || '')) || fail('页面不存在'), { auth: false });

  // ---------------- 公告 / 反馈 ----------------
  // 首页创作台：可选的出图 / 视频模型、各清晰度实际扣点（已按模型「最高清晰度」降档）
  route('/site/models', ({ user }) => {
    const relay = S.get('relay') || {};
    const pr = S.get('pricing') || {};
    const image = Object.entries(relay.image_models || {}).filter(([, m]) => m && m.enabled !== false && (m.model || m.ref)).map(([key, m]) => {
      const prices = {}; const actual = {};
      for (const res of ['1K', '2K', '4K']) {
        const sp = engine.capResolution({ kind: 'image', modelKey: key, resolution: res }, { module: 'ai.image', board: 'ai', kind: 'ai' });
        prices[res] = engine.priceOf(sp, user || {});
        actual[res] = sp.resolution;
      }
      return { key, label: m.label || key, desc: m.desc || '', prices, actual };
    });
    const video = Object.entries(relay.video_models || {}).filter(([, m]) => m && m.enabled !== false && (m.model || m.ref)).map(([key, m]) => ({
      key, label: m.label || (key === 'm3' ? '视频（按秒计费）' : '视频'), seconds: Number(m.seconds) || 5,
      price: engine.priceOf({ kind: 'video', modelKey: key, seconds: Number(m.seconds) || 5 }, user || {}), per_second: key === 'm3',
    }));
    return { image, video, max_images: Number(relay.max_ref_images) || 10 };
  }, { auth: 'optional' });
  // 工具封面（后台替换 / AI 生成的），前端优先用
  route('/site/tool_covers', () => ({ covers: S.get('tool_covers') || {} }), { auth: false });
  // 抠图页：今日免费张数（前端插件读取，未登录也能调）
  route('/site/matting', ({ user }) => {
    const q = engine.mattingQuota(user);
    return { enabled: true, ...q, logged_in: !!user };
  }, { auth: 'optional' });

  route('/notice/lists', ({ user }) => {
    const rows = db.all(`SELECT * FROM yd_notice WHERE status='normal' ORDER BY id DESC LIMIT 100`);
    const read = user ? new Set(db.all('SELECT notice_id FROM yd_notice_read WHERE user_id=?', user.id).map((r) => r.notice_id)) : new Set();
    const view = (n) => ({ id: n.id, title: n.title, time: n.time || fmtTime(n.createtime, false), content: n.content || '', is_read: read.has(n.id) ? 1 : 0 });
    return { notice: rows.filter((n) => n.type !== 'log').map(view), log: rows.filter((n) => n.type === 'log').map(view) };
  }, { auth: 'optional' });
  route('/notice/read', ({ p, user }) => {
    const ids = asIds(p.ids || p.id);
    for (const id of ids) db.run('INSERT OR IGNORE INTO yd_notice_read (user_id, notice_id) VALUES (?, ?)', user.id, id);
    return null;
  });
  route('/feedback/submit', ({ p, user, ip }) => {
    guard.rl('fb:' + ip, 10, 3600, '提交太频繁，请稍后再试');
    if (!str(p.content)) fail('请填写反馈内容');
    db.insert('yd_feedback', {
      user_id: user ? user.id : 0, type: str(p.type, 30), product: str(p.product, 60), content: str(p.content, 3000), wechat: str(p.wechat, 60),
      phone: str(p.phone, 30), images: JSON.stringify(Array.isArray(p.images) ? p.images.filter((x) => typeof x === 'string' && /^(https?:\/\/|\/uploads\/)/i.test(x)).map((x) => x.slice(0, 1000)).slice(0, 9) : []), createtime: now(),
    });
    return null;
  }, { auth: 'optional' });

  // ---------------- 作品记录（各板块） ----------------
  const sessTitle = (id) => (id ? (db.get('SELECT title FROM yd_session WHERE id=?', id) || {}).title || '' : '');
  // 同一对话的任务（删除 / 恢复时整段一起）
  const sameSession = (t, deleted) => (t.session_id ? db.all('SELECT * FROM yd_task WHERE session_id=? AND user_id=? AND deleted=?', t.session_id, t.user_id, deleted) : [t]);
  // 没有生成结果的项目（如只在无限画布上传 / 裁剪 / 改字）：用画布上的第一张图当封面
  const canvasCover = (sid) => {
    if (!sid) return '';
    let row = null;
    try { row = db.get('SELECT doc FROM ct_canvas_doc WHERE session_id=?', sid); } catch { return ''; }
    const d = row ? jsonParse(row.doc, {}) : {};
    const img = (d.extra || []).find((x) => x && x.type !== 'text' && x.url);
    return img ? img.url : '';
  };
  function recordView(t) {
    const params = jsonParse(t.params, {});
    const rs = engine.resultsOf(t.id).filter((r) => !r.deleted);
    const images = rs.map((r) => ({ id: r.id, index: r.idx, url: r.status === 'succeeded' ? r.url : '', status: r.status === 'queued' ? 'pending' : r.status, label: r.label, error: r.error, content: r.content || '' }));
    const flat = { ...params };
    for (const k of ['images', 'count', 'items', 'modules', 'units', 'status', 'scene', 'id', 'task_id', 'cover']) delete flat[k];
    return {
      ...flat,
      params,
      input_images: Array.isArray(params.images) ? params.images : [],
      task_id: t.id,
      id: t.id,
      session_id: t.session_id || 0,
      title: sessTitle(t.session_id) || str(params.title) || (t.kind === 'ai' ? str(params.user_prompt || t.prompt).slice(0, 20) : '') || t.scene_name,
      board: t.board,
      scene: t.scene,
      scene_name: t.scene_name,
      module: t.module,
      cover: (images.find((x) => x.url) || {}).url || canvasCover(t.session_id),
      count: images.length,
      images,
      remark: t.remark,
      status: t.status,
      createtime: t.createtime,
      updatetime: t.updatetime,
      resolution: t.resolution,
      model_key: t.model_key,
      ratio: t.ratio,
      aspect_ratio: t.ratio,
      charged_points: t.charged_points,
      user_id: t.user_id,
    };
  }

  route('/:board.records/:action', ({ params, p, user }) => {
    const board = params.board;
    const action = params.action.toLowerCase();
    if (action === 'lists') {
      const { page, limit, offset } = pageArgs(p, 24, 100);
      const owners = [user.id];
      const scene = str(p.scene).replace(/-/g, '_');
      // 「我的作品」默认（没选具体功能）显示全部作品：所有板块 + 一句话作图 / 对话作图，免得用户在别的板块做的图找不到
      const everything = !scene && !int(p.task_id);
      const where = [`user_id IN (${owners.map(() => '?').join(',')})`, 'deleted=0', everything ? `kind IN ('board','batch','exclusive','pro','ai','chatdraw')` : `kind IN ('board','batch','exclusive','pro')`];
      const args = [...owners];
      if (board !== 'all' && !everything) { where.push('board=?'); args.push(board); }
      // 首页对话：一段对话在项目库里只算一个项目（显示最新那次生成）
      if (everything) { where.push('(session_id=0 OR id IN (SELECT MAX(id) FROM yd_task WHERE user_id=? AND deleted=0 AND session_id>0 GROUP BY session_id))'); args.push(user.id); }
      if (scene) { where.push('(scene=? OR scene=?)'); args.push(scene, scene.replace(/_/g, '-')); }
      if (int(p.start)) { where.push('createtime>=?'); args.push(int(p.start)); }
      if (int(p.end)) { where.push('createtime<=?'); args.push(int(p.end)); }
      if (str(p.keyword)) { where.push('(remark LIKE ? OR scene_name LIKE ?)'); args.push(`%${str(p.keyword)}%`, `%${str(p.keyword)}%`); }
      const total = db.val(`SELECT COUNT(*) FROM yd_task WHERE ${where.join(' AND ')}`, ...args) || 0;
      const items = db.all(`SELECT * FROM yd_task WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map(recordView);
      return { items, list: items, total, page, limit };
    }
    if (action === 'del') {
      const ids = asIds(p.ids);
      const ts = now();
      for (const id of ids) {
        const t = engine.getTask(id, user);
        if (t) for (const x of sameSession(t, 0)) db.update('yd_task', { deleted: 1, deleted_at: ts }, 'id=?', x.id);
      }
      return null;
    }
    if (action === 'delimg') {
      const ids = asIds(p.ids);
      for (const id of ids) {
        const r = db.get('SELECT * FROM yd_task_result WHERE id=?', id);
        if (r && engine.getTask(r.task_id, user)) db.update('yd_task_result', { deleted: 1 }, 'id=?', r.id);
      }
      return null;
    }
    if (action === 'remark') {
      const t = engine.getTask(p.id || p.task_id, user);
      if (!t) fail('记录不存在');
      db.update('yd_task', { remark: str(p.remark, 200) }, 'id=?', t.id);
      return null;
    }
    fail('接口不存在', 0, 404);
    return null;
  });

  // ---------------- 回收站：删除的作品保留 30 天，可恢复或彻底删除（一段对话算一项） ----------------
  function purgeOld(uid) {
    db.run('UPDATE yd_task SET deleted=2 WHERE deleted=1 AND deleted_at<? AND user_id=?', now() - TRASH_DAYS * 86400, uid);
  }
  route('/trash/lists', ({ p, user }) => {
    purgeOld(user.id);
    const rows = db.all('SELECT * FROM yd_task WHERE deleted=1 AND user_id=? ORDER BY deleted_at DESC, id DESC LIMIT 2000', user.id);
    const groups = new Map();
    for (const t of rows) {
      const key = t.session_id ? 's' + t.session_id : 't' + t.id;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(t);
    }
    const all = [...groups.values()].map((list) => {
      const t = list[0];
      const rs = list.flatMap((x) => engine.resultsOf(x.id).filter((r) => !r.deleted && r.url));
      const params = jsonParse(t.params, {});
      return {
        task_id: t.id, board: t.kind === 'ai' ? 'ai' : t.board, module: t.module, session_id: t.session_id || 0,
        title: sessTitle(t.session_id) || str(params.title) || (t.kind === 'ai' ? str(params.user_prompt || t.prompt).slice(0, 20) : '') || t.scene_name || '作品',
        scene_name: t.scene_name, cover: rs[0] ? rs[0].url : '', count: rs.length, createtime: t.createtime, deleted_at: t.deleted_at,
        expire_days: Math.max(0, Math.ceil((t.deleted_at + TRASH_DAYS * 86400 - now()) / 86400)),
      };
    });
    const { limit, offset } = pageArgs(p, 60, 200);
    return { items: all.slice(offset, offset + limit), total: all.length, keep_days: TRASH_DAYS };
  });
  function trashTasks(p, user) {
    const ids = asIds(p.ids || (Array.isArray(p.items) ? p.items.map((x) => x && x.task_id) : []));
    const out = [];
    for (const id of ids) {
      const t = engine.getTask(id, user);
      if (t && t.deleted === 1) out.push(...sameSession(t, 1));
    }
    return out;
  }
  route('/trash/restore', ({ p, user }) => {
    for (const t of trashTasks(p, user)) db.update('yd_task', { deleted: 0, deleted_at: 0 }, 'id=?', t.id);
    return null;
  });
  route('/trash/del', ({ p, user }) => {
    for (const t of trashTasks(p, user)) db.update('yd_task', { deleted: 2 }, 'id=?', t.id);
    return null;
  });
  route('/trash/clear', ({ user }) => {
    db.run('UPDATE yd_task SET deleted=2 WHERE deleted=1 AND user_id=?', user.id);
    return null;
  });
};
