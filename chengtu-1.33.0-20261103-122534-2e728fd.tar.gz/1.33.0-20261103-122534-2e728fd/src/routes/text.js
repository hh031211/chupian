'use strict';
// 精准改字 / 图片翻译（画布「文字编辑」）
//   识别：本机 OCR 服务找出每段文字（位置、内容、颜色、粗细）
//   擦除：默认本机 LaMa 擦掉要改的文字（免费）；擦不干净可选「AI 擦除」（中转站生图，扣点），只把擦好的文字区域贴回原图
//   排字：浏览器里用真实字体排新文字（字 100% 正确），字体按用到的字裁成小文件下发
//   翻译：文本模型翻译识别出的文字
const S = require('../core/settings');
const users = require('../core/users');
const storage = require('../core/storage');
const engine = require('../ai/engine');
const llm = require('../ai/llm');
const { runWithFeature } = require('../ai/relay');
const { fail } = require('../core/http');
const { str } = require('../core/util');

const cfg = () => ({ enabled: true, url: 'http://127.0.0.1:8361', ...(S.get('textedit') || {}) });
async function side(path, body, timeout = 120000) {
  const c = cfg();
  if (c.enabled === false) fail('精准改字功能已关闭');
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), timeout);
  let res;
  try {
    res = await fetch(c.url.replace(/\/$/, '') + path, body === undefined ? { signal: ctl.signal } : { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' }, signal: ctl.signal });
  } catch (e) {
    fail(e.name === 'AbortError' ? '改字服务处理超时，请稍后再试' : '精准改字服务没有启动，请联系管理员（服务器执行 tools/setup-textedit.sh 安装）');
  } finally { clearTimeout(t); }
  const j = await res.json().catch(() => ({}));
  if (!res.ok) fail('改字服务出错：' + (j.error || res.status));
  return j;
}
async function status() {
  try { const j = await side('/health', undefined, 3000); return { enabled: true, ocr: !!j.ocr, lama: !!j.lama, fonts: j.fonts || [] }; } catch { return { enabled: false, ocr: false, lama: false, fonts: [] }; }
}
async function imageB64(url) {
  const u = str(url, 2000);
  if (!u) fail('请先选择图片');
  const { buffer } = await storage.fetchBuffer(u, { maxBytes: 40 * 1024 * 1024 });
  return { buffer, b64: buffer.toString('base64') };
}
const cleanBoxes = (list) => (Array.isArray(list) ? list : []).slice(0, 200).map((b) => ({
  cx: Number(b.cx) || 0, cy: Number(b.cy) || 0, w: Math.max(1, Number(b.w) || 0), h: Math.max(1, Number(b.h) || 0), angle: Number(b.angle) || 0,
}));
async function save(b64) {
  const buf = Buffer.from(b64, 'base64');
  const r = await storage.saveBuffer(buf, { mimetype: 'image/png', category: 'edit' });
  return r.fullurl;
}

module.exports = (route) => {
  route('/text/status', () => status());

  route('/text/detect', async ({ p }) => {
    const { b64 } = await imageB64(p.image);
    const r = await side('/ocr', { image: b64 });
    return { width: r.width, height: r.height, items: r.items || [] };
  });

  route('/text/erase', async ({ p, user }) => {
    const boxes = cleanBoxes(p.boxes);
    if (!boxes.length) fail('没有要擦除的文字');
    const { buffer, b64 } = await imageB64(p.image);
    const keep = cleanBoxes(p.keep);   // 旁边不改的文字：擦除时绕开，免得把它们也擦花
    if (p.engine !== 'ai') {
      const r = await side('/inpaint', { image: b64, boxes, keep });
      return { url: await save(r.image), engine: r.engine };
    }
    // AI 擦除：原图 + 红色标记图交给生图模型，只把框里的部分贴回原图
    if (S.get('member').generate_requires_member !== false && users.effectiveLevel(user) === 'free') fail('您当前不是会员，开通会员后即可使用 AI 擦除', 403);
    const mk = str(p.model_key) || 'm1';
    const cost = engine.priceOf({ kind: 'image', modelKey: mk.startsWith('ref:') ? 'm1' : mk, resolution: '2K' }, user);
    users.charge(user, cost, 'AI 擦除文字');
    try {
      const mark = await side('/mark', { image: b64, boxes });
      const prompt = '图1 是原图；图2 是同一张图，上面用半透明红色标出了文字所在的区域。把红色区域里的文字彻底擦掉，用周围的背景（颜色、渐变、纹理、图案、光影）自然补全，像这里从来没有文字一样，不留残影、不留痕迹，也不要写任何新文字。红色区域以外的内容与图1 完全一致，输出里不能出现红色。';
      const outs = await runWithFeature({ module: 'ai.image', board: 'ai', kind: 'ai' }, () => engine.relay().image({
        ...(mk.startsWith('ref:') ? { modelRef: mk.slice(4) } : { modelKey: mk }), prompt, images: [buffer, Buffer.from(mark.image, 'base64')], ratio: '', resolution: '2K', n: 1,
      }));
      let out = outs[0];
      if (!out) throw new Error('模型没有返回图片');
      if (!out.buffer && out.url) out = await storage.fetchBuffer(out.url);
      const comp = await side('/composite', { base: b64, patch: out.buffer.toString('base64'), boxes });
      return { url: await save(comp.image), engine: 'ai', charged_points: cost };
    } catch (e) {
      users.refund(users.billUser(user).id, cost, 'AI 擦除文字失败退回');
      throw e;
    }
  });

  // 画布「AI 智能消除」本机版：按画笔涂抹的区域用 LaMa 擦除（免费、只动涂抹的地方）
  route('/text/inpaint', async ({ p }) => {
    const m = str(p.mask, 30 * 1024 * 1024).replace(/^data:[^,]+,/, '');
    if (!m) fail('先在图上涂抹要消除的区域');
    const { b64 } = await imageB64(p.image);
    const r = await side('/inpaint', { image: b64, boxes: [], mask: m });
    return { url: await save(r.image), engine: r.engine };
  });

  route('/text/translate', async ({ p, user }) => {
    const texts = (Array.isArray(p.texts) ? p.texts : []).map((t) => str(t, 500)).slice(0, 80);
    const lang = str(p.lang, 20) || '英语';
    if (!texts.length) return { texts: [] };
    const cost = Number((S.get('pricing').text || {}).text_translate || 0);
    users.charge(user, cost, '图片文字翻译');
    try {
      const out = await runWithFeature({ text: 'text_translate' }, () => llm.translateTexts(texts, lang));
      return { texts: out, charged_points: cost };
    } catch (e) {
      users.refund(users.billUser(user).id, cost, '图片文字翻译失败退回');
      fail('翻译失败：' + e.message);
    }
    return null;
  });

  route('/text/font', async ({ p }) => {
    const r = await side('/subset', { font: str(p.font, 120), text: str(p.text, 2000), weight: Number(p.weight) || 400 }, 30000);
    return { font: r.font, variable: !!r.variable };
  });
};
