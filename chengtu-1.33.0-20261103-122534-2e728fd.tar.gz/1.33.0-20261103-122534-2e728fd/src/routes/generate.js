'use strict';
// AI 生成相关接口：首页创作台（/ai/image、提示词优化、生成前说明、同款改写）、
// 保留的功能模块（generate / status / regen / 商品套图大纲）
const db = require('../core/db');
const S = require('../core/settings');
const users = require('../core/users');
const engine = require('../ai/engine');
const { runWithFeature } = require('../ai/relay');
const builder = require('../ai/builder');
const modules = require('../ai/modules');
const llm = require('../ai/llm');
const { fail } = require('../core/http');
const { now, str, int, jsonParse } = require('../core/util');

const textCost = (k) => Number((S.get('pricing').text || {})[k] || 0);

async function withTextCharge(user, key, label, fn) {
  const cost = textCost(key);
  if (cost > 0) users.charge(user, cost, label);
  try {
    const r = await runWithFeature({ text: key }, fn);
    return { r, cost };
  } catch (e) {
    if (cost > 0) users.refund(users.billUser(user).id, cost, `${label}失败退回`);
    throw e;
  }
}

// 首页对话：一个对话 = 一个项目（yd_session），同一对话里的每次生成都挂在它下面，项目库点开能回到这段对话
function sessionFor(user, p) {
  const id = int(p.session_id);
  if (id) {
    const s = db.get('SELECT id FROM yd_session WHERE id=? AND user_id=?', id, user.id);
    if (s) { db.update('yd_session', { updatetime: now() }, 'id=?', id); return id; }
  }
  const title = str(p.session_title || p.title, 40) || str(p.user_prompt || p.prompt).replace(/\s+/g, ' ').slice(0, 20) || '新的创作';
  return db.insert('yd_session', { user_id: user.id, title, createtime: now(), updatetime: now() });
}
// 改图时没经过「对话」理解（快速模式 / 理解失败）：补一句保持原图不变，避免模型顺手改掉衣服、背景
const KEEP_REST = '\n只按上面的要求修改；要求之外的内容（人物服装与配饰、帽子发饰、姿势动作、表情、背景、光线、色调、构图、画质）都与参考图保持一致。';

function aiAssistantPrompt(p) {
  const parts = [str(p.prompt) + (p.images && p.images.length && !p.refined && p.mode !== 'set' ? KEEP_REST : '')];
  if (str(p.style)) parts.push(`画面风格：${p.style}`);
  if (str(p.language)) parts.push(`画面中如有文字，使用${p.language}`);
  if (p.mode === 'agent' && p.skill) parts.push(`（技能：${p.skill}）`);
  const st = p.settings && typeof p.settings === 'object' ? Object.entries(p.settings).filter(([, v]) => typeof v === 'string' && v.trim()).map(([k, v]) => `${k}：${v}`).join('；') : '';
  if (st) parts.push(st);
  return parts.filter(Boolean).join('\n');
}

module.exports = (route) => {
  // ================= AI 助手（自由生图） =================
  route('/ai/image', ({ p, user }) => {
    const prompt = str(p.prompt, 4000);
    if (!prompt) fail('请输入描述');
    const count = Math.max(1, Math.min(8, int(p.count, 1)));
    const images = builder.urls(p.images).slice(0, 10);
    const info = { module: 'ai.image', board: 'ai', scene: 'assistant', sceneName: 'AI 助手', kind: 'image' };
    const full = aiAssistantPrompt(p);
    const specs = Array.from({ length: count }, (_, i) => ({
      label: '', kind: 'image', images, ratio: str(p.aspectRatio || p.aspect_ratio) === 'auto' ? '' : str(p.aspectRatio || p.aspect_ratio),
      resolution: str(p.resolution) || '2K', modelKey: str(p.model_key) || 'm1',
      prompt: count > 1 ? `${full}\n（同组第 ${i + 1}/${count} 张，构图可有所变化）` : full,
    }));
    const sessionId = sessionFor(user, p);
    const id = engine.createTask({ user, kind: 'ai', info, params: p, specs, prompt: str(p.user_prompt, 4000) || prompt, sessionId });
    return engine.statusPayload(engine.getTask(id), { onlyDone: true });
  });
  // 打开一个对话（项目库 → 回到生成界面）。老记录没有对话的，按单个任务打开
  route('/ai/session', ({ p, user }) => {
    const s = int(p.id) ? db.get('SELECT * FROM yd_session WHERE id=? AND user_id=?', int(p.id), user.id) : null;
    let tasks = [];
    if (s) tasks = db.all('SELECT * FROM yd_task WHERE session_id=? AND user_id=? AND deleted=0 ORDER BY id', s.id, user.id);
    else if (int(p.task_id)) { const t = engine.getTask(p.task_id, user); if (t && !t.deleted) tasks = t.session_id ? db.all('SELECT * FROM yd_task WHERE session_id=? AND user_id=? AND deleted=0 ORDER BY id', t.session_id, user.id) : [t]; }
    if (!tasks.length) fail('这个项目不存在或已删除');
    const sess = s || (tasks[0].session_id ? db.get('SELECT * FROM yd_session WHERE id=?', tasks[0].session_id) : null);
    const canvas = tasks.some((t) => t.module === 'canvas');
    tasks = tasks.filter((t) => t.module !== 'canvas');   // 无限画布的锚点记录不算一轮对话
    const KEYS = ['user_prompt', 'prompt', 'plan', 'mode', 'turn', 'label', 'images', 'display_images', 'set_info', 'aspectRatio', 'resolution', 'count', 'title', 'duration'];
    return {
      session: { id: sess ? sess.id : 0, title: (sess && sess.title) || '', canvas },
      tasks: tasks.map((t) => {
        const prm = jsonParse(t.params, {});
        const params = {}; for (const k of KEYS) if (prm[k] !== undefined) params[k] = prm[k];
        return { ...engine.statusPayload(t), kind: t.module === 'video.imagetovideo' ? 'video' : 'image', params };
      }),
    };
  });
  route('/ai/status', ({ p, user }) => {
    const t = engine.getTask(p.task_id, user);
    if (!t) fail('任务不存在');
    return engine.statusPayload(t, { onlyDone: true });
  });
  route('/ai/history', ({ p, user }) => {
    const limit = Math.min(100, Math.max(1, int(p.limit, 24)));
    const page = Math.max(1, int(p.page, 1));
    const where = ['user_id=?', `kind='ai'`, 'deleted=0'];
    const args = [user.id];
    if (int(p.start)) { where.push('createtime>=?'); args.push(int(p.start)); }
    if (int(p.end)) { where.push('createtime<=?'); args.push(int(p.end)); }
    const total = db.val(`SELECT COUNT(*) FROM yd_task WHERE ${where.join(' AND ')}`, ...args) || 0;
    const rows = db.all(`SELECT * FROM yd_task WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, (page - 1) * limit);
    const list = rows.map((t) => {
      const rs = engine.resultsOf(t.id).filter((r) => !r.deleted && r.status === 'succeeded');
      const prm = jsonParse(t.params, {});
      return {
        id: t.id, prompt: t.prompt, user_prompt: prm.prompt || t.prompt, thumb: rs[0] ? rs[0].url : '', items: rs.map((r) => ({ id: r.id, index: r.idx, url: r.url })),
        success_count: t.success_count, fail_count: t.fail_count, count: t.count, status: t.status, remark: t.remark, resolution: t.resolution,
        model_key: t.model_key, aspect_ratio: t.ratio, images: prm.images || [], style: prm.style || '', createtime: t.createtime, updatetime: t.updatetime,
        user_id: t.user_id,
      };
    });
    return { list, total, page, limit };
  });
  route('/ai/delete', ({ p, user }) => {
    const t = engine.getTask(p.task_id, user);
    if (t) db.update('yd_task', { deleted: 1, deleted_at: now() }, 'id=?', t.id);
    return null;
  });
  route('/ai/remark', ({ p, user }) => {
    const t = engine.getTask(p.task_id, user);
    if (!t) fail('任务不存在');
    db.update('yd_task', { remark: str(p.remark, 200) }, 'id=?', t.id);
    return null;
  });
  route('/ai/regenimage', ({ p, user }) => engine.regen(user, p.task_id, p.index));

  // ================= 首页创作台：提示词优化 / 生成前说明 =================
  route('/ai/prompt/optimize', async ({ p, user }) => {
    if (!str(p.prompt)) fail('请先输入提示词后再进行优化操作');
    const { r, cost } = await withTextCharge(user, 'prompt_optimize', '提示词优化', () => llm.optimizePrompt(p.prompt, p.images));
    if (!r) fail('优化失败，请重试');
    return { prompt: r, charged_points: cost };
  });
  route('/ai/prompt/adapt', async ({ p, user }) => {
    const images = (Array.isArray(p.images) ? p.images : []).filter((x) => typeof x === 'string' && x).slice(0, 10);
    if (!images.length) fail('请先上传图片');
    if (!str(p.prompt)) fail('模板提示词为空');
    const { r, cost } = await withTextCharge(user, 'prompt_adapt', '同款提示词改写', () => llm.adaptPrompt(p.prompt, images, p.title));
    if (!r) fail('改写失败，请重试');
    return { prompt: r, charged_points: cost };
  });
  // 无限画布（工具箱入口）：新建一个空项目。挂一条「锚点」记录（module=canvas，无结果、不扣点），项目库 / 回收站才能找到它
  route('/ai/session/create', ({ p, user }) => {
    const title = str(p.title, 40) || '无限画布';
    const sid = db.insert('yd_session', { user_id: user.id, title, createtime: now(), updatetime: now() });
    db.insert('yd_task', {
      user_id: user.id, bill_user_id: user.id, kind: 'ai', board: 'ai', module: 'canvas', scene: 'canvas', scene_name: '无限画布',
      params: JSON.stringify({ mode: 'canvas', title }), status: 'succeeded', count: 0, prompt: title, session_id: sid, createtime: now(), updatetime: now(),
    });
    return { id: sid, title };
  });
  // ================= 画布 =================
  // 画布文档：{ pos: {key:{x,y,w}}, hidden: [key], extra: [{id,type:'image'|'text',url|text,x,y,w,h}] }
  route('/ai/canvas/get', ({ p, user }) => {
    const sid = int(p.session_id);
    const s = sid && db.get('SELECT id FROM yd_session WHERE id=? AND user_id=?', sid, user.id);
    if (!s) return { doc: null };
    const row = db.get('SELECT doc FROM ct_canvas_doc WHERE session_id=?', sid);
    return { doc: row ? jsonParse(row.doc, null) : null };
  });
  route('/ai/canvas/save', ({ p, user }) => {
    const sid = int(p.session_id);
    if (!sid || !db.get('SELECT id FROM yd_session WHERE id=? AND user_id=?', sid, user.id)) fail('项目不存在');
    const doc = p.doc && typeof p.doc === 'object' ? p.doc : {};
    const clean = {
      pos: Object.fromEntries(Object.entries(doc.pos || {}).slice(0, 2000).map(([k, v]) => [String(k).slice(0, 80), { x: Number(v && v.x) || 0, y: Number(v && v.y) || 0, ...(v && v.w ? { w: Math.max(40, Math.min(4000, Number(v.w) || 0)) } : {}) }])),
      hidden: (Array.isArray(doc.hidden) ? doc.hidden : []).slice(0, 2000).map((x) => String(x).slice(0, 80)),
      extra: (Array.isArray(doc.extra) ? doc.extra : []).slice(0, 500).map((n) => ({
        id: String(n.id || '').slice(0, 40), type: n.type === 'text' ? 'text' : 'image', url: str(n.url, 1000), text: str(n.text, 4000), label: str(n.label, 40),
        x: Number(n.x) || 0, y: Number(n.y) || 0, w: Math.max(40, Math.min(4000, Number(n.w) || 320)), h: Math.max(20, Math.min(8000, Number(n.h) || 0)) || undefined, from: str(n.from, 80),
      })).filter((n) => n.id && (n.type === 'text' ? n.text : n.url)),
    };
    const json = JSON.stringify(clean);
    if (json.length > 900000) fail('画布内容太多了');
    db.run('INSERT INTO ct_canvas_doc (session_id, user_id, doc, updatetime) VALUES (?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET doc=excluded.doc, updatetime=excluded.updatetime', sid, user.id, json, now());
    return null;
  });
  // 反推提示词：还原画面 / 总结模板
  route('/ai/describe', async ({ p, user }) => {
    const image = str(p.image, 1000);
    if (!image) fail('请先选择图片');
    const mode = p.mode === 'template' ? 'template' : 'restore';
    const { r, cost } = await withTextCharge(user, 'prompt_reverse', mode === 'template' ? '反推提示词·总结模板' : '反推提示词·还原画面', () => llm.reversePrompt(image, mode));
    if (!r) fail('反推失败，请重试');
    return { text: r, charged_points: cost };
  });
  route('/ai/plan', async ({ p }) => {
    if (!str(p.prompt)) return { text: '', prompt: '', title: '' };
    try {
      const r = await runWithFeature({ text: 'prompt_plan' }, () => llm.planEdit(p.prompt, p.images));
      return { text: r.reply, prompt: r.prompt, title: r.title };
    } catch { return { text: '', prompt: '', title: '' }; }
  });

  // ================= 功能模块（通配） =================
  // 支持：/{board}.{func}/generate|status|regen|retry|outline|customset|customset_outline|heroImage|styleanalyze|
  //       supplementfields|aiwritestream|styledescribestream|parse|transfer|check|predict|lists|claim|del|history
  route('/:module/:action', async (ctx) => {
    const { params, p, user, res } = ctx;
    const mod = params.module.toLowerCase();
    const action = params.action.toLowerCase();
    if (!/^[a-z]+\.[a-z0-9_]+$/.test(mod)) fail('接口不存在', 0, 404);
    if (!user) fail('请先登录', 401, 401);

    // ----- 通用：状态 / 重生成 -----
    if (action === 'status') {
      const t = engine.getTask(p.task_id, user);
      if (!t) fail('任务不存在');
      const out = engine.statusPayload(t);
      if (mod.endsWith('pro')) out.errors = out.errors.map((e) => e.error);
      return out;
    }
    if (action === 'regen' || action === 'retry') return engine.regen(user, p.task_id, p.index);
    // 只保留站点在用的功能；其余模块一律下线
    if (!modules.ENABLED.has(mod) && !(mod.endsWith('.records') || mod === 'all.records')) fail('该功能已下线', 0, 404);

    // ----- 大纲 / 分析 -----
    if (action === 'outline') {
      const { r, cost } = await withTextCharge(user, 'outline', '套图规划', () => llm.outlineProductMain(p));
      return { outline: r, charged_points: cost };
    }

    // ----- 生成 -----
    const GEN_ACTIONS = ['generate'];
    if (!GEN_ACTIONS.includes(action)) fail('接口不存在', 0, 404);
    if (!modules.isKnownModule(mod)) fail('未知的功能模块：' + mod, 0, 404);
    if (!modules.ENABLED.has(mod)) fail('该功能已下线', 0, 404);
    const info = modules.resolve(mod, p);
    let type = 'generic';
    let kind = 'board';
    if (mod === 'product.productmain') type = 'modules';
    const specs = builder.compile(info, p, type);
    if (!specs.length) fail('没有可生成的内容');
    const TEXT_KEYS = ['guidance', 'prompt', 'extra', 'user_instruction', 'instruction', 'bg_prompt', 'company_name', 'headline', 'info', 'notes', 'free_desc', 'replace_info'];
    const hasText = TEXT_KEYS.some((k) => typeof p[k] === 'string' && p[k].trim()) || ['items', 'modules', 'units', 'templates', 'products'].some((k) => Array.isArray(p[k]) && p[k].length);
    if (!specs.some((s) => (s.images || []).length) && !hasText) fail('请先上传图片或填写描述');
    const sessionId = p.session_id !== undefined ? sessionFor(user, p) : 0;   // 首页对话里出的视频也算进这段对话
    const id = engine.createTask({ user, kind, info, params: p, specs, prompt: str(p.user_prompt || p.user_instruction || p.extra || p.prompt || '', 500), sessionId });
    const out = engine.statusPayload(engine.getTask(id));
    return out;
  });
};
