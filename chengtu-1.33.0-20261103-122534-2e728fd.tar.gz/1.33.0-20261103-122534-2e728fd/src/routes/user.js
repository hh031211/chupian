'use strict';
// 账号：验证码、登录注册、短信/邮箱、资料、绑定、微信扫码/授权登录
const db = require('../core/db');
const S = require('../core/settings');
const config = require('../core/config');
const users = require('../core/users');
const captcha = require('../core/captcha');
const human = require('../core/human');
const notify = require('../core/notify');
const wx = require('../core/wechat');
const { fail } = require('../core/http');
const guard = require('../core/guard');
const { now, str, int, hashPassword, verifyPassword, randomHex } = require('../core/util');

const MOBILE_RE = /^1\d{10}$/;
const DUMMY = hashPassword(randomHex(8));
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function findByAccount(account) {
  const a = str(account);
  if (!a) return null;
  return db.get('SELECT * FROM yd_user WHERE deletetime=0 AND (username=? OR mobile=? OR email=?) ORDER BY id LIMIT 1', a, a, a.toLowerCase());
}

function ensureActive(u) {
  if (!u) fail('账号不存在');
  if (u.status !== 'normal') fail('账号已被禁用，请联系客服');
  return u;
}

function ipRegisterGuard(ip) {
  const lim = Number(S.get('security').ip_register_limit_per_day || 0);
  if (!lim || !ip) return;
  const c = db.val('SELECT COUNT(*) FROM yd_user WHERE joinip=? AND jointime>?', ip, now() - 86400);
  if (c >= lim) fail('该网络今日注册次数过多，请明天再试');
}

// 防短信轰炸：同一 IP 发过 2 条后要图形验证码（开了阿里云验证码则每次都要）；IP 每小时 / 每天上限；全站每天总量上限
async function smsGuard(p, ip, user = null) {
  const sec = S.get('security') || {};
  if (guard.on()) {
    const cap = Number(sec.sms_daily_cap ?? 300);
    if (cap > 0 && db.val('SELECT COUNT(*) FROM yd_vcode WHERE createtime>?', now() - 86400) >= cap) fail('今日验证码发送量已达上限，请明天再试或用账号密码登录');
  }
  guard.rl('smsday:' + ip, 20, 86400, '该网络今日获取验证码次数过多，请明天再试');
  guard.rl('smshour:' + ip, 8, 3600, '获取验证码太频繁，请稍后再试');
  const needCap = !user && (human.aliyunOn() || guard.seen('sms:' + ip, 3600) >= 2);
  await human.check(p, needCap);
  guard.note('sms:' + ip);
}

module.exports = (route) => {
  route('/captcha/create', ({ ip }) => { guard.rl('cap:' + ip, 60, 600); return captcha.create(); }, { auth: false });

  route('/user/login', async ({ p, ip }) => {
    const reg = S.get('register');
    const acc = str(p.account, 64).toLowerCase();
    guard.rl('login:' + ip, 30, 600, '登录尝试太频繁，请 10 分钟后再试');
    // 防密码爆破：同一账号 / 同一 IP 连续输错 3 次后必须填图形验证码；同一账号 15 分钟内错 10 次锁定
    if (guard.seen('lf:' + acc, 900) >= 10) fail('密码错误次数过多，账号已临时锁定，请 15 分钟后再试，或用手机验证码登录');
    const needCap = reg.login_captcha || guard.seen('lf:' + acc, 900) >= 3 || guard.seen('lfip:' + ip, 900) >= 5;
    if (needCap || p.captcha_verify_param) await human.check(p, needCap);
    const u = findByAccount(p.account);
    if (!u) verifyPassword(String(p.password || ''), DUMMY.hash, DUMMY.salt);   // 账号不存在也算一遍，别人没法靠响应快慢判断账号是否存在
    if (!u || !verifyPassword(p.password, u.password, u.salt)) { guard.note('lf:' + acc); guard.note('lfip:' + ip); fail('账号或密码不正确'); }
    ensureActive(u);
    guard.reset('lf:' + acc);
    return users.loginPayload(u, int(p.keeptime));
  }, { auth: false });

  route('/user/register', async ({ p, ip }) => {
    const reg = S.get('register');
    guard.rl('reg:' + ip, 10, 3600, '注册太频繁，请稍后再试');
    if (reg.username_register === false) fail('暂未开放账号注册，请使用手机号登录');
    await human.check(p, reg.register_captcha !== false || human.aliyunOn());
    const username = str(p.username, 32);
    if (username.length < 3) fail('用户名至少 3 位');
    if (!/^[A-Za-z0-9_]{3,32}$/.test(username)) {
      const bad = [...new Set(username.replace(/[A-Za-z0-9_]/g, '').replace(/\s/g, '空格'))];
      fail(/[一-龥]/.test(username) ? '用户名不能用中文，只能用英文字母、数字和下划线 _' : `用户名不能包含「${bad.slice(0, 3).join(' ')}」，只能用英文字母、数字和下划线 _`);
    }
    if (MOBILE_RE.test(username)) fail('用户名不能是手机号，请使用手机号验证码登录');
    const pwd = String(p.password || '');
    const pmin = Math.max(8, Number(reg.password_min) || 8);
    if (pwd.length < pmin || pwd.length > 32) fail(`密码长度需为 ${pmin}-32 位`);
    if (!/[A-Za-z]/.test(pwd) || !/\d/.test(pwd)) fail('密码需要同时包含字母和数字');
    if (db.get('SELECT id FROM yd_user WHERE username=? AND deletetime=0', username)) fail('用户名已被占用');
    ipRegisterGuard(ip);
    const u = users.createUser({ username, nickname: username, password: pwd }, { inviteCode: p.invite_code, ip });
    return users.loginPayload(u, int(p.keeptime), { is_new: 1 });
  }, { auth: false });

  async function codeLogin({ p, ip }, kind) {
    guard.rl('codelogin:' + ip, 30, 600, '登录尝试太频繁，请 10 分钟后再试');
    const target = kind === 'mobile' ? str(p.mobile) : str(p.email).toLowerCase();
    if (kind === 'mobile' && !MOBILE_RE.test(target)) fail('手机号格式不正确');
    if (kind === 'email' && !EMAIL_RE.test(target)) fail('邮箱格式不正确');
    notify.checkCode(target, kind === 'mobile' ? 'mobilelogin' : 'emaillogin', p.captcha, kind === 'mobile' ? ['mobilelogin', 'register', 'login'] : ['emaillogin', 'register', 'login']);
    let u = db.get(`SELECT * FROM yd_user WHERE ${kind === 'mobile' ? 'mobile' : 'email'}=? AND deletetime=0 ORDER BY id LIMIT 1`, target);
    let isNew = 0;
    if (!u) {
      ipRegisterGuard(ip);
      u = users.createUser(kind === 'mobile' ? { mobile: target, nickname: '用户' + target.slice(-4) } : { email: target, nickname: target.split('@')[0] }, { inviteCode: p.invite_code, ip });
      isNew = 1;
    }
    ensureActive(u);
    return users.loginPayload(u, int(p.keeptime), { is_new: isNew });
  }
  route('/user/mobilelogin', (c) => codeLogin(c, 'mobile'), { auth: false });
  route('/user/emaillogin', (c) => {
    if (!S.get('register').email_login) fail('已关闭邮箱登录，请使用手机号或账号登录');
    return codeLogin(c, 'email');
  }, { auth: false });

  route('/sms/send', async ({ p, ip }) => {
    const mobile = str(p.mobile);
    if (!MOBILE_RE.test(mobile)) fail('手机号格式不正确');
    await smsGuard(p, ip);
    return notify.sendCode(mobile, str(p.event) || 'mobilelogin', 'mobile', ip);
  }, { auth: false });

  route('/ems/send', async ({ p, ip }) => {
    const email = str(p.email).toLowerCase();
    if (!EMAIL_RE.test(email)) fail('邮箱格式不正确');
    await smsGuard(p, ip);
    return notify.sendCode(email, str(p.event) || 'emaillogin', 'email', ip);
  }, { auth: false });

  route('/user/logout', ({ req }) => {
    const t = req.headers.token || String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (t) db.run('DELETE FROM yd_token WHERE token IN (?, ?)', users.tokenKey(t), String(t));
    return null;
  }, { auth: false });

  route('/user/info', ({ user }) => ({ userinfo: users.userinfo(user) }));

  route('/user/profile', ({ p, user }) => {
    const up = {};
    if (p.nickname != null) {
      const n = str(p.nickname, 30);
      if (!n) fail('昵称不能为空');
      up.nickname = n;
    }
    // 登录账号（用户名）注册后不能修改
    if (p.username != null && str(p.username) !== user.username) fail('登录账号注册后不能修改');
    if (p.avatar != null) {
      const a = str(p.avatar, 500);
      if (a && !/^(https?:\/\/|\/uploads\/)/i.test(a)) fail('头像地址不正确');
      up.avatar = a;
    }
    if (Object.keys(up).length) db.update('yd_user', up, 'id=?', user.id);
    return { userinfo: users.userinfo(users.getUser(user.id)) };
  });

  route('/user/sendmobilecode', async ({ p, user, ip }) => {
    const mobile = str(p.mobile);
    if (!MOBILE_RE.test(mobile)) fail('手机号格式不正确');
    const ex = db.get('SELECT id FROM yd_user WHERE mobile=? AND deletetime=0 AND id<>?', mobile, user.id);
    if (ex) fail('该手机号已绑定其他账号');
    await smsGuard(p, ip, user);
    return notify.sendCode(mobile, str(p.event) || 'bind', 'mobile', ip);
  });
  route('/user/bindmobile', ({ p, user }) => {
    const mobile = str(p.mobile);
    if (!MOBILE_RE.test(mobile)) fail('手机号格式不正确');
    notify.checkCode(mobile, str(p.event) || 'bind', p.captcha, ['bind', 'changemobile']);
    if (db.get('SELECT id FROM yd_user WHERE mobile=? AND deletetime=0 AND id<>?', mobile, user.id)) fail('该手机号已绑定其他账号');
    const first = !db.val('SELECT mobile FROM yd_user WHERE id=?', user.id);
    db.update('yd_user', { mobile }, 'id=?', user.id);
    if (first) users.onVerified(user.id, mobile);   // 第一次绑定手机：补发新人赠送 / 给邀请人记邀请
    return { userinfo: users.userinfo(users.getUser(user.id)) };
  });
  route('/user/sendemailcode', async ({ p, user, ip }) => {
    const email = str(p.email).toLowerCase();
    if (!EMAIL_RE.test(email)) fail('邮箱格式不正确');
    if (db.get('SELECT id FROM yd_user WHERE email=? AND deletetime=0 AND id<>?', email, user.id)) fail('该邮箱已绑定其他账号');
    await smsGuard(p, ip, user);
    return notify.sendCode(email, str(p.event) || 'bindemail', 'email', ip);
  });
  route('/user/bindemail', ({ p, user }) => {
    const email = str(p.email).toLowerCase();
    if (!EMAIL_RE.test(email)) fail('邮箱格式不正确');
    notify.checkCode(email, str(p.event) || 'bindemail', p.captcha, ['bindemail', 'bind']);
    if (db.get('SELECT id FROM yd_user WHERE email=? AND deletetime=0 AND id<>?', email, user.id)) fail('该邮箱已绑定其他账号');
    db.update('yd_user', { email }, 'id=?', user.id);
    return { userinfo: users.userinfo(users.getUser(user.id)) };
  });

  route('/user/changepwd', ({ p, user }) => {
    guard.rl('pwd:' + user.id, 10, 600, '操作太频繁，请 10 分钟后再试');
    const np = String(p.new_password || '');
    if (np.length < 8 || np.length > 32) fail('新密码长度需为 8-32 位');
    if (!/[A-Za-z]/.test(np) || !/\d/.test(np)) fail('新密码需要同时包含字母和数字');
    if (user.password && !verifyPassword(p.old_password, user.password, user.salt)) fail('原密码不正确');
    const h = hashPassword(np);
    db.update('yd_user', { password: h.hash, salt: h.salt }, 'id=?', user.id);
    // 改了密码：别的设备上的登录全部失效（防止密码泄露后对方一直登着）
    db.run('DELETE FROM yd_token WHERE user_id=? AND token<>?', user.id, String(user._token || ''));
    return { userinfo: users.userinfo(users.getUser(user.id)) };
  });

  route('/user/delete', ({ p, user }) => {
    if (!str(p.confirm)) fail('请确认注销');
    if (user.enterprise_owner_id === 0 && db.val('SELECT COUNT(*) FROM yd_user WHERE enterprise_owner_id=? AND deletetime=0', user.id) > 0) {
      fail('请先删除企业子账号后再注销');
    }
    db.update('yd_user', {
      deletetime: now(), status: 'hidden', remark: '用户注销：' + str(p.reason, 200),
      mobile: '', email: '', wechat_openid: '', wechat_unionid: '', username: `deleted_${user.id}_${now()}`,
    }, 'id=?', user.id);
    db.run('DELETE FROM yd_token WHERE user_id=?', user.id);
    return null;
  });

  // ---------------- 微信 ----------------
  function newState(mode, extra = {}) {
    const state = randomHex(12);
    db.insert('yd_wechat_state', { state, mode, status: 'pending', createtime: now(), ...extra });
    db.run('DELETE FROM yd_wechat_state WHERE createtime < ?', now() - 86400);
    return state;
  }

  route('/wechat/qrcode', async ({ p, user }) => {
    const mp = S.get('wechat_mp');
    if (!S.get('register').wechat_login || !mp.enabled) fail('已关闭微信登录，请使用手机号或账号登录');
    const mode = p.mode === 'bind' ? 'bind' : 'login';
    if (mode === 'bind' && !user) fail('请先登录', 401, 401);
    const state = newState(mode, { user_id: user ? user.id : 0, invite_code: str(p.invite_code), keeptime: int(p.keeptime) });
    const qr = await wx.mpCreateQrcode(`yd_${state}`, 600);
    return { qr_url: qr, state, expires_in: 600 };
  }, { auth: 'optional' });

  route('/wechat/authorize', ({ p, user }) => {
    const mp = S.get('wechat_mp');
    if (!S.get('register').wechat_login || !mp.enabled) fail('已关闭微信登录，请使用手机号或账号登录');
    const mode = p.mode === 'bind' ? 'bind' : 'login';
    if (mode === 'bind' && !user) fail('请先登录', 401, 401);
    const state = newState(mode, { user_id: user ? user.id : 0, invite_code: str(p.invite_code), keeptime: int(p.keeptime), redirect: str(p.redirect, 500) || '/' });
    const cb = (mp.oauth_redirect_base || config.publicBaseUrl + config.apiPrefix).replace(/\/$/, '') + '/wechat/callback';
    return { auth_url: wx.oauthUrl(cb, state), state };
  }, { auth: 'optional' });

  // 网页授权回调 → 跳回前端 ?wx_state=
  route('/wechat/callback', async ({ p, res }) => {
    const st = db.get('SELECT * FROM yd_wechat_state WHERE state=?', str(p.state));
    const front = S.get('site').frontend_url || config.siteUrl || '/';
    if (!st) { res.writeHead(302, { Location: front }); res.end(); return undefined; }
    try {
      const info = await wx.oauthExchange(str(p.code));
      resolveWechat(st, info);
    } catch (e) {
      db.update('yd_wechat_state', { status: 'failed', msg: e.message }, 'state=?', st.state);
    }
    const target = new URL(st.redirect && st.redirect.startsWith('/') ? front.replace(/\/$/, '') + st.redirect : front);
    target.searchParams.set('wx_state', st.state);
    res.writeHead(302, { Location: target.toString() });
    res.end();
    return undefined;
  }, { auth: false, raw: true });

  // 公众号服务器配置（URL 填 https://你的API域名/ydapi/wechat/notify）
  route('/wechat/notify', async ({ req, res, p }) => {
    if (!wx.mpCheckSignature(p)) { res.writeHead(403); res.end('bad signature'); return undefined; }
    if (req.method === 'GET') { res.writeHead(200, { 'Content-Type': 'text/plain' }); res.end(String(p.echostr || '')); return undefined; }
    const msg = wx.parseXml(String(p._raw || (req.rawBody || '').toString('utf8')));
    let reply = 'success';
    if (msg.MsgType === 'event' && (msg.Event === 'subscribe' || msg.Event === 'SCAN')) {
      const key = String(msg.EventKey || '').replace(/^qrscene_/, '');
      if (key.startsWith('yd_')) {
        const st = db.get('SELECT * FROM yd_wechat_state WHERE state=?', key.slice(3));
        if (st && st.status === 'pending') {
          const info = await wx.mpUserInfo(msg.FromUserName);
          const r = resolveWechat(st, { openid: msg.FromUserName, unionid: info.unionid || '', nickname: info.nickname || '', avatar: info.headimgurl || '' });
          reply = wx.mpReplyText(msg.FromUserName, msg.ToUserName, r.ok ? (st.mode === 'bind' ? '微信绑定成功' : `登录成功，欢迎使用${S.get('site').name}`) : r.msg);
        }
      }
    }
    res.writeHead(200, { 'Content-Type': 'application/xml' });
    res.end(reply);
    return undefined;
  }, { auth: false, raw: true });

  function resolveWechat(st, info) {
    if (st.mode === 'bind') {
      const other = db.get('SELECT id FROM yd_user WHERE wechat_openid=? AND deletetime=0 AND id<>?', info.openid, st.user_id);
      if (other) {
        db.update('yd_wechat_state', { status: 'failed', msg: '该微信已绑定其他账号', openid: info.openid }, 'state=?', st.state);
        return { ok: false, msg: '该微信已绑定其他账号' };
      }
      db.update('yd_user', { wechat_openid: info.openid, wechat_unionid: info.unionid || '', wechat_nickname: info.nickname || '微信用户' }, 'id=?', st.user_id);
      db.update('yd_wechat_state', { status: 'success', openid: info.openid, result_user_id: st.user_id }, 'state=?', st.state);
      return { ok: true };
    }
    let u = db.get('SELECT * FROM yd_user WHERE wechat_openid=? AND deletetime=0', info.openid);
    if (!u && info.unionid) u = db.get('SELECT * FROM yd_user WHERE wechat_unionid=? AND deletetime=0', info.unionid);
    if (!u) {
      u = users.createUser({
        nickname: info.nickname || '微信用户', avatar: info.avatar || '', wechat_openid: info.openid, wechat_unionid: info.unionid || '',
        wechat_nickname: info.nickname || '微信用户',
      }, { inviteCode: st.invite_code });
    }
    if (u.status !== 'normal') {
      db.update('yd_wechat_state', { status: 'failed', msg: '账号已被禁用' }, 'state=?', st.state);
      return { ok: false, msg: '账号已被禁用' };
    }
    db.update('yd_wechat_state', { status: 'success', openid: info.openid, result_user_id: u.id }, 'state=?', st.state);
    return { ok: true };
  }

  route('/wechat/status', ({ p }) => {
    const st = db.get('SELECT * FROM yd_wechat_state WHERE state=?', str(p.state));
    if (!st) return { status: 'expired', msg: '二维码已失效' };
    if (st.status === 'pending') {
      if (now() - st.createtime > 600) return { status: 'expired', msg: '二维码已过期' };
      return { status: 'pending' };
    }
    if (st.status === 'failed') return { status: 'failed', msg: st.msg || '微信授权失败' };
    if (st.status === 'success') {
      if (now() - st.createtime > 1800) return { status: 'expired', msg: '授权已过期，请重新扫码' };
      const u = users.getUser(st.result_user_id);
      if (!u) return { status: 'failed', msg: '账号不存在' };
      if (st.mode === 'bind') return { status: 'success', mode: 'bind', userinfo: users.userinfo(u) };
      db.update('yd_wechat_state', { status: 'used' }, 'state=?', st.state);
      return { status: 'success', mode: 'login', ...users.loginPayload(u, st.keeptime) };
    }
    return { status: 'expired', msg: '授权已使用，请重新扫码' };
  }, { auth: false });

  route('/wechat/unbind', ({ user }) => {
    if (!user.mobile && !user.email && !user.password) fail('请先绑定手机号或设置密码，避免无法登录');
    db.update('yd_user', { wechat_openid: '', wechat_unionid: '', wechat_nickname: '' }, 'id=?', user.id);
    return { userinfo: users.userinfo(users.getUser(user.id)) };
  });
};
