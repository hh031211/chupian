'use strict';
// 缩略图：/uploads/xxx.png?w=480 → 按宽度生成 WebP 小图（只用于列表卡片；原图不动）
//   优先用 vipsthumbnail（libvips-tools，快、省内存），其次 ImageMagick convert；都没有就直接返回原图
//   生成结果缓存在 数据目录/thumbs，同一张图同一宽度只生成一次
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');
const config = require('./config');

const DIR = path.join(path.dirname(config.dbFile), 'thumbs');
const WIDTHS = [240, 320, 480, 640, 960, 1200, 1600, 2048];
const QUALITY = 82;

let tool;   // { bin, args(src, dst, w) } | null
function detect() {
  if (tool !== undefined) return tool;
  const has = (bin) => { try { return spawnSync(bin, ['--version'], { stdio: 'ignore', timeout: 5000 }).status === 0; } catch { return false; } };
  if (has('vipsthumbnail')) tool = { name: 'vips', bin: 'vipsthumbnail', args: (src, dst, w) => [src, '--size', `${w}x`, '-o', `${dst}[Q=${QUALITY},strip]`] };
  else if (has('convert')) tool = { name: 'imagemagick', bin: 'convert', args: (src, dst, w) => [`${src}[0]`, '-auto-orient', '-thumbnail', `${w}x>`, '-strip', '-quality', String(QUALITY), `webp:${dst}`] };
  else tool = null;
  return tool;
}
/** 后台「系统状态」显示用 */
function status() { const t = detect(); return { enabled: !!t, tool: t ? t.name : '' }; }

/** 合法宽度：取不小于请求值的最近一档（防止任意宽度把磁盘写满） */
function widthOf(w) {
  const n = parseInt(w, 10);
  if (!n || n <= 0) return 0;
  return WIDTHS.find((x) => x >= n) || WIDTHS[WIDTHS.length - 1];
}

let running = 0;
const waiting = [];
const pending = new Map();
function slot() { return new Promise((r) => { if (running < 2) { running++; r(); } else waiting.push(r); }); }
function release() { const n = waiting.shift(); if (n) n(); else running--; }

/**
 * @returns {Promise<string|null>} 缩略图文件路径；不需要 / 生成失败时返回 null（调用方回退原图）
 */
async function thumbOf(file, w) {
  const width = widthOf(w);
  if (!width || !/\.(png|jpe?g|webp|gif|bmp)$/i.test(file)) return null;
  const t = detect();
  if (!t) return null;
  let st;
  try { st = fs.statSync(file); } catch { return null; }
  if (st.size < 60 * 1024) return null;   // 本来就很小的图不用缩
  const key = crypto.createHash('md5').update(`${file}|${st.size}|${st.mtimeMs}|${width}|${QUALITY}`).digest('hex');
  const dst = path.join(DIR, key.slice(0, 2), `${key}.webp`);
  if (fs.existsSync(dst)) return dst;
  if (pending.has(dst)) return pending.get(dst);
  const job = (async () => {
    await slot();
    try {
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      const tmp = `${dst}.${process.pid}.tmp.webp`;
      const ok = await new Promise((resolve) => {
        const p = spawn(t.bin, t.args(file, tmp, width), { stdio: 'ignore' });
        const timer = setTimeout(() => { try { p.kill('SIGKILL'); } catch { /* ignore */ } resolve(false); }, 30000);
        p.on('error', () => { clearTimeout(timer); resolve(false); });
        p.on('exit', (code) => { clearTimeout(timer); resolve(code === 0); });
      });
      if (!ok || !fs.existsSync(tmp) || fs.statSync(tmp).size === 0) { try { fs.unlinkSync(tmp); } catch { /* ignore */ } return null; }
      // 缩出来反而更大（原图本来就小 / 是 WebP），就用原图
      if (fs.statSync(tmp).size >= st.size) { fs.unlinkSync(tmp); return null; }
      fs.renameSync(tmp, dst);
      return dst;
    } catch { return null; } finally { release(); pending.delete(dst); }
  })();
  pending.set(dst, job);
  return job;
}

/** 把一张图缩放成 size×size 的 PNG（Logo → 网站图标用）；成功返回 true */
function squarePng(src, dst, size) {
  const t = detect();
  if (!t) return false;
  const args = t.name === 'vips' ? [src, '--size', `${size}x${size}`, '-o', dst] : [`${src}[0]`, '-resize', `${size}x${size}`, '-background', 'none', '-gravity', 'center', '-extent', `${size}x${size}`, `png:${dst}`];
  try { return spawnSync(t.bin, args, { stdio: 'ignore', timeout: 20000 }).status === 0 && fs.existsSync(dst); } catch { return false; }
}

/** 图片有没有透明通道（PNG 颜色类型 4/6 或带 tRNS；WebP VP8X 的 alpha 标记） */
function hasAlpha(buf) {
  if (!buf || buf.length < 32) return false;
  if (buf[0] === 0x89 && buf[1] === 0x50) return buf[25] === 4 || buf[25] === 6 || buf.indexOf('tRNS') > 0 && buf.indexOf('tRNS') < 4096;
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(12, 16).toString() === 'VP8X') return (buf[20] & 0x10) !== 0;
  return false;
}

/**
 * 重新编码一张图：长边超过 max 就等比缩小（max=0 不缩），不透明的存成 JPG（质量 q），透明的保持 PNG。
 * 变小了返回 { buffer, mimetype }，没变小 / 没装工具 / 失败返回 null（调用方继续用原图）。
 */
async function recode(buf, { max = 0, q = 92 } = {}) {
  const t = detect();
  if (!t || !buf || buf.length < 32) return null;
  const isPng = buf[0] === 0x89 && buf[1] === 0x50;
  const isJpg = buf[0] === 0xff && buf[1] === 0xd8;
  const isWebp = buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP';
  if (!isPng && !isJpg && !isWebp) return null;
  const alpha = hasAlpha(buf);
  const tmpDir = path.join(DIR, 'tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const id = crypto.randomBytes(8).toString('hex');
  const src = path.join(tmpDir, `${id}.${isPng ? 'png' : isJpg ? 'jpg' : 'webp'}`);
  const dst = path.join(tmpDir, `${id}.out.${alpha ? 'png' : 'jpg'}`);
  const size = max > 0 ? `${max}x${max}>` : '100000x100000>';
  const args = t.name === 'vips'
    ? [src, '--size', size, '-o', alpha ? `${dst}[compression=6,strip]` : `${dst}[Q=${q},strip,optimize_coding]`]
    : [`${src}[0]`, '-auto-orient', '-resize', size, '-strip', '-quality', String(alpha ? 90 : q), `${alpha ? 'png' : 'jpg'}:${dst}`];
  await slot();
  try {
    fs.writeFileSync(src, buf);
    const ok = await new Promise((resolve) => {
      const p = spawn(t.bin, args, { stdio: 'ignore' });
      const timer = setTimeout(() => { try { p.kill('SIGKILL'); } catch { /* ignore */ } resolve(false); }, 60000);
      p.on('error', () => { clearTimeout(timer); resolve(false); });
      p.on('exit', (code) => { clearTimeout(timer); resolve(code === 0); });
    });
    if (!ok || !fs.existsSync(dst)) return null;
    const out = fs.readFileSync(dst);
    if (!out.length || out.length >= buf.length) return null;
    return { buffer: out, mimetype: alpha ? 'image/png' : 'image/jpeg' };
  } catch { return null; } finally {
    release();
    for (const f of [src, dst]) { try { fs.unlinkSync(f); } catch { /* ignore */ } }
  }
}

/** 生成一张宽 w 的 WebP 缩略图（存 COS 时顺带生成一份，列表直接用，不用每次让数据万象现缩） */
async function webpThumb(buf, w = 960) {
  const t = detect();
  if (!t || !buf || buf.length < 32) return null;
  const tmpDir = path.join(DIR, 'tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const id = crypto.randomBytes(8).toString('hex');
  const src = path.join(tmpDir, `${id}.src`);
  const dst = path.join(tmpDir, `${id}.webp`);
  const args = t.name === 'vips' ? [src, '--size', `${w}x>`, '-o', `${dst}[Q=${QUALITY},strip]`] : [`${src}[0]`, '-auto-orient', '-thumbnail', `${w}x>`, '-strip', '-quality', String(QUALITY), `webp:${dst}`];
  await slot();
  try {
    fs.writeFileSync(src, buf);
    const ok = await new Promise((resolve) => {
      const p = spawn(t.bin, args, { stdio: 'ignore' });
      const timer = setTimeout(() => { try { p.kill('SIGKILL'); } catch { /* ignore */ } resolve(false); }, 30000);
      p.on('error', () => { clearTimeout(timer); resolve(false); });
      p.on('exit', (code) => { clearTimeout(timer); resolve(code === 0); });
    });
    if (!ok || !fs.existsSync(dst)) return null;
    const out = fs.readFileSync(dst);
    return out.length ? out : null;
  } catch { return null; } finally {
    release();
    for (const f of [src, dst]) { try { fs.unlinkSync(f); } catch { /* ignore */ } }
  }
}

module.exports = { squarePng, thumbOf, widthOf, status, recode, hasAlpha, webpThumb, WIDTHS, DIR };
