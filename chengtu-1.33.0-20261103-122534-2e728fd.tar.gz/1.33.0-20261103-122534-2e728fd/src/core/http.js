'use strict';
// 极简 HTTP 框架：路由、JSON/表单/multipart 解析、CORS、统一返回 {code,msg,time,data}
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const config = require('./config');

class ApiError extends Error {
  constructor(msg, code = 0, status = 200, data = null) {
    super(msg);
    this.code = code;
    this.status = status;
    this.data = data;
  }
}
const fail = (msg, code = 0, status = 200, data = null) => { throw new ApiError(msg, code, status, data); };

const MAX_BODY = 60 * 1024 * 1024;

function readBody(req, max = MAX_BODY) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let over = false;
    if (Number(req.headers['content-length'] || 0) > max) { over = true; reject(new ApiError('请求体过大', 0, 413)); }
    req.on('data', (c) => {
      if (over) return;   // 超了：后面的数据直接丢掉（不存内存），等读完再回 413
      size += c.length;
      if (size > max) { over = true; chunks.length = 0; reject(new ApiError('请求体过大', 0, 413)); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function parseMultipart(buf, boundary) {
  const fields = {};
  const files = [];
  const delim = Buffer.from('--' + boundary);
  let pos = buf.indexOf(delim);
  while (pos !== -1) {
    pos += delim.length;
    if (buf[pos] === 45 && buf[pos + 1] === 45) break; // --
    if (buf[pos] === 13) pos += 2;
    const headEnd = buf.indexOf('\r\n\r\n', pos);
    if (headEnd === -1) break;
    const head = buf.slice(pos, headEnd).toString('utf8');
    const next = buf.indexOf(delim, headEnd + 4);
    if (next === -1) break;
    const body = buf.slice(headEnd + 4, next - 2);
    const name = (/name="([^"]*)"/i.exec(head) || [])[1];
    const filename = (/filename="([^"]*)"/i.exec(head) || [])[1];
    const ctype = (/content-type:\s*([^\r\n]+)/i.exec(head) || [])[1];
    if (name != null) {
      if (filename != null) files.push({ field: name, filename, mimetype: (ctype || 'application/octet-stream').trim(), buffer: body, size: body.length });
      else fields[name] = body.toString('utf8');
    }
    pos = next;
  }
  return { fields, files };
}

async function parseRequest(req, maxBody = MAX_BODY) {
  const u = new URL(req.url, 'http://localhost');
  const query = Object.fromEntries(u.searchParams.entries());
  let body = {};
  let files = [];
  if (req.method === 'POST' || req.method === 'PUT') {
    const ct = String(req.headers['content-type'] || '');
    const raw = await readBody(req, maxBody);
    req.rawBody = raw;
    if (/multipart\/form-data/i.test(ct)) {
      const b = (/boundary=(?:"([^"]+)"|([^;]+))/i.exec(ct) || []);
      const r = parseMultipart(raw, b[1] || b[2] || '');
      body = r.fields;
      files = r.files;
    } else if (/application\/x-www-form-urlencoded/i.test(ct)) {
      body = Object.fromEntries(new URLSearchParams(raw.toString('utf8')).entries());
    } else if (raw.length) {
      const text = raw.toString('utf8');
      if (/json/i.test(ct) || /^\s*[\[{]/.test(text)) {
        try { body = JSON.parse(text); } catch { body = {}; }
      } else body = { _raw: text };
    }
  }
  if (!body || typeof body !== 'object' || Array.isArray(body)) body = { _body: body };
  return { pathname: decodeURIComponent(u.pathname), query, body, files };
}

function clientIp(req) {
  if (config.trustProxy) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
    if (req.headers['x-real-ip']) return String(req.headers['x-real-ip']);
  }
  return (req.socket && req.socket.remoteAddress || '').replace(/^::ffff:/, '');
}

// 跨域：只允许本站自己的域名（config.corsOrigins 填了具体域名就用填的；填 "*" 也只放行本站，
// 想真正放开给所有网站请在 corsOrigins 里写 "allow-any"）。前端和接口同域，本来就不需要跨域。
let ownOrigins = null;
function ownList() {
  if (!ownOrigins) {
    ownOrigins = new Set();
    for (const u of [config.publicBaseUrl, config.siteUrl, ...(Array.isArray(config.aliasBaseUrls) ? config.aliasBaseUrls : [])]) { try { if (u) ownOrigins.add(new URL(u).origin); } catch { /* 不是地址 */ } }
  }
  return ownOrigins;
}
function setCors(req, res) {
  const origin = req.headers.origin;
  const allow = config.corsOrigins || ['*'];
  let site = '';
  try { const S = require('./settings'); const s = S.get('site') || {}; site = s.frontend_url ? new URL(s.frontend_url).origin : (s.domain ? `https://${s.domain}` : ''); } catch { /* 没配置 */ }
  const host = String(req.headers.host || '');
  const same = origin && (origin === `https://${host}` || origin === `http://${host}`);
  const ok = origin && (allow.includes('allow-any') || same || ownList().has(origin) || origin === site || allow.filter((x) => x !== '*').includes(origin));
  if (ok) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,token,Authorization,X-Requested-With,admin-token');
  res.setHeader('Access-Control-Max-Age', '86400');
}

// 换了域名 / 上了 HTTPS 后，数据库里以前存的图片地址（如 http://IP/uploads/…）统一换成现在的地址，避免 https 页面加载 http 图片被浏览器拦截
let aliasRe;
function fixUrls(s) {
  if (aliasRe === undefined) {
    const list = (Array.isArray(config.aliasBaseUrls) ? config.aliasBaseUrls : []).map((u) => String(u || '').replace(/\/$/, '')).filter((u) => u && u !== config.publicBaseUrl);
    aliasRe = list.length ? new RegExp(`(${list.map((u) => u.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&')).join('|')})(?=/uploads/)`, 'g') : null;
  }
  return aliasRe ? s.replace(aliasRe, config.publicBaseUrl) : s;
}
function sendJson(res, status, obj) {
  if (res.headersSent) { try { res.end(); } catch {} return; }
  const s = fixUrls(JSON.stringify(obj));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(s);
}
const ok = (res, data = null, msg = 'ok') => sendJson(res, 200, { code: 1, msg, time: String(Math.floor(Date.now() / 1000)), data });

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.mjs': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml',
  '.webmanifest': 'application/manifest+json', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.pdf': 'application/pdf',
  '.zip': 'application/zip',
};

const zlib = require('node:zlib');
const COMPRESSIBLE = /^(text\/|application\/(javascript|json|xml|manifest\+json)|image\/svg)/;
const zcache = new Map();
let zcacheBytes = 0;

// 文本类静态文件：gzip / brotli 压缩并缓存在内存，大幅减少首屏下载量
function compressed(file, st, enc, buf) {
  const key = `${file}|${st.mtimeMs}|${enc}`;
  let out = zcache.get(key);
  if (!out) {
    const raw = buf || fs.readFileSync(file);
    out = enc === 'br'
      ? zlib.brotliCompressSync(raw, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 6, [zlib.constants.BROTLI_PARAM_SIZE_HINT]: raw.length } })
      : zlib.gzipSync(raw, { level: 6 });
    zcache.set(key, out);
    zcacheBytes += out.length;
    if (zcacheBytes > 200 * 1024 * 1024) { zcache.clear(); zcacheBytes = 0; }
  }
  return out;
}

function serveFile(req, res, file, { cache = 'public, max-age=604800', body = null, bodyKey = '', extra = null } = {}) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404); res.end('Not Found'); return; }
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const headers = { 'Content-Type': type, 'Cache-Control': cache, 'Last-Modified': st.mtime.toUTCString(), Vary: 'Accept-Encoding', ...(extra || {}) };
    // ETag：内容没变时返回 304，浏览器直接用缓存，不再重新下载
    const etag = 'W/"' + (body ? require('crypto').createHash('md5').update(String(bodyKey) + '|' + st.mtimeMs + '|' + body.length).digest('hex').slice(0, 16) : `${st.size.toString(36)}-${Math.floor(st.mtimeMs).toString(36)}`) + '"';
    headers.ETag = etag;
    const inm = req.headers['if-none-match'];
    if (inm && inm.split(/\s*,\s*/).includes(etag)) { res.writeHead(304, { ETag: etag, 'Cache-Control': cache, Vary: 'Accept-Encoding' }); res.end(); return; }
    const ae = String(req.headers['accept-encoding'] || '');
    const size = body ? body.length : st.size;
    if (COMPRESSIBLE.test(type) && size > 1024 && !req.headers.range) {
      const enc = /\bbr\b/.test(ae) ? 'br' : /\bgzip\b/.test(ae) ? 'gzip' : '';
      if (enc) {
        const out = compressed(file + (body ? '#transformed' + require('crypto').createHash('md5').update(bodyKey || String(body.length)).digest('hex') : ''), st, enc, body || null);
        res.writeHead(200, { ...headers, 'Content-Encoding': enc, 'Content-Length': out.length });
        res.end(req.method === 'HEAD' ? undefined : out);
        return;
      }
    }
    if (body) {
      res.writeHead(200, { ...headers, 'Content-Length': body.length });
      res.end(req.method === 'HEAD' ? undefined : body);
      return;
    }
    const range = req.headers.range;
    if (range && /^bytes=/.test(range)) {
      const [s, e] = range.replace('bytes=', '').split('-');
      const start = parseInt(s, 10) || 0;
      const end = e ? Math.min(parseInt(e, 10), st.size - 1) : st.size - 1;
      res.writeHead(206, { ...headers, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1 });
      fs.createReadStream(file, { start, end }).pipe(res);
      return;
    }
    res.writeHead(200, { ...headers, 'Content-Length': st.size, 'Accept-Ranges': 'bytes' });
    if (req.method === 'HEAD') { res.end(); return; }
    fs.createReadStream(file).pipe(res);
  });
}

function safeJoin(base, p) {
  const b = path.normalize(base).replace(/[\\/]+$/, '');
  const f = path.normalize(path.join(b, p));
  return f === b || f.startsWith(b + path.sep) ? f : null;   // 只能在 base 目录里面（防 ../ 和同名前缀目录）
}

// ---------------- 频率限制（内存，按 key 计数，窗口内超过 max 次就拒绝）----------------
const hits = new Map();
function hitCount(key, windowSec) {
  const t = Date.now(); const arr = (hits.get(key) || []).filter((x) => t - x < windowSec * 1000);
  hits.set(key, arr);
  return arr;
}
/** 记一次并检查；超过返回 true */
function over(key, max, windowSec) {
  const arr = hitCount(key, windowSec);
  arr.push(Date.now());
  return arr.length > max;
}
/** 只查不记 */
function count(key, windowSec) { return hitCount(key, windowSec).length; }
function mark(key) { const arr = hits.get(key) || []; arr.push(Date.now()); hits.set(key, arr); }
function clearHits(key) { hits.delete(key); }
function limit(key, max, windowSec, msg = '操作太频繁，请稍后再试') {
  if (over(key, max, windowSec)) throw new ApiError(msg, 0, 429);
}
setInterval(() => { const t = Date.now(); for (const [k, arr] of hits) { if (!arr.length || t - arr[arr.length - 1] > 86400e3) hits.delete(k); } }, 600e3).unref();

/** 通用安全响应头 */
function securityHeaders(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  if (String(req.headers['x-forwarded-proto'] || '') === 'https') res.setHeader('Strict-Transport-Security', 'max-age=15552000');
}

// SSE 输出（前端 To() 期望：event: message data: {"delta":"..."} / event: done / event: error）
function sse(res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  const write = (event, data) => {
    try { res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); } catch {}
  };
  return {
    delta: (t) => write('message', { delta: t }),
    done: (d = {}) => { write('done', d); try { res.end(); } catch {} },
    error: (m) => { write('error', { message: m }); try { res.end(); } catch {} },
  };
}

class Router {
  constructor() { this.exact = new Map(); this.patterns = []; }
  // path: '/user/login'；支持 '/:module/generate' 形式的参数
  add(p, handler, opts = {}) {
    if (p.includes(':') || p.includes('*')) {
      const keys = [];
      const escaped = p.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\//g, '\\/');
      const re = new RegExp('^' + escaped.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+?)'; }).replace(/\*/g, '(.*)') + '$', 'i');
      this.patterns.push({ re, keys, handler, opts });
    } else this.exact.set(p.toLowerCase(), { handler, opts });
  }
  match(p) {
    const lower = p.toLowerCase().replace(/\/+$/, '') || '/';
    const e = this.exact.get(lower);
    if (e) return { ...e, params: {} };
    for (const r of this.patterns) {
      const m = r.re.exec(p);
      if (m) {
        const params = {};
        r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
        return { handler: r.handler, opts: r.opts, params };
      }
    }
    return null;
  }
}

module.exports = { ApiError, fail, ok, sendJson, parseRequest, clientIp, setCors, serveFile, safeJoin, sse, Router, MIME, limit, over, count, mark, clearHits, securityHeaders };
