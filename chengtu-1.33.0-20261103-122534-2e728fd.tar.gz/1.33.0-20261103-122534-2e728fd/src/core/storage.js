'use strict';
// 文件存储：本地磁盘（默认）或腾讯云 COS。统一返回 {url, fullurl, mimetype, filesize, width, height}
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('./config');
const S = require('./settings');
const { randomHex } = require('./util');

const EXT_MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', svg: 'image/svg+xml',
  mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', pdf: 'application/pdf', zip: 'application/zip', txt: 'text/plain',
  json: 'application/json', bmp: 'image/bmp', avif: 'image/avif', heic: 'image/heic',
};
const MIME_EXT = Object.fromEntries(Object.entries(EXT_MIME).map(([k, v]) => [v, k]));
MIME_EXT['image/jpeg'] = 'jpg';

function sniff(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  if (buf.slice(0, 3).toString() === 'GIF') return 'image/gif';
  if (buf.slice(4, 8).toString() === 'ftyp') {
    const brand = buf.slice(8, 12).toString();
    if (/avif/.test(brand)) return 'image/avif';
    if (/heic|heix|mif1/.test(brand)) return 'image/heic';
    return 'video/mp4';
  }
  if (buf[0] === 0x1a && buf[1] === 0x45) return 'video/webm';
  if (buf.slice(0, 4).toString() === '%PDF') return 'application/pdf';
  const head = buf.slice(0, 200).toString('utf8').trim();
  if (head.startsWith('<svg') || (head.startsWith('<?xml') && head.includes('<svg'))) return 'image/svg+xml';
  return null;
}

function imageSize(buf) {
  try {
    const t = sniff(buf);
    if (t === 'image/png') return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
    if (t === 'image/gif') return { width: buf.readUInt16LE(6), height: buf.readUInt16LE(8) };
    if (t === 'image/webp') {
      const chunk = buf.slice(12, 16).toString();
      if (chunk === 'VP8 ') return { width: buf.readUInt16LE(26) & 0x3fff, height: buf.readUInt16LE(28) & 0x3fff };
      if (chunk === 'VP8L') {
        const b = buf.readUInt32LE(21);
        return { width: (b & 0x3fff) + 1, height: ((b >> 14) & 0x3fff) + 1 };
      }
      if (chunk === 'VP8X') return { width: 1 + buf.readUIntLE(24, 3), height: 1 + buf.readUIntLE(27, 3) };
    }
    if (t === 'image/jpeg') {
      let i = 2;
      while (i < buf.length) {
        if (buf[i] !== 0xff) { i++; continue; }
        const marker = buf[i + 1];
        const len = buf.readUInt16BE(i + 2);
        if (marker >= 0xc0 && marker <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(marker)) {
          return { height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
        }
        i += 2 + len;
      }
    }
  } catch {}
  return { width: 0, height: 0 };
}

function datePath() {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return `${d.getUTCFullYear()}${String(d.getUTCMonth() + 1).padStart(2, '0')}${String(d.getUTCDate()).padStart(2, '0')}`;
}

// ---------- 腾讯云 COS ----------
function cosHost(c) { return `${c.bucket}.cos.${c.region}.myqcloud.com`; }
/** 图片对外访问的地址前缀（自定义域名优先） */
function cosBase(c) { return String(c.domain || `https://${cosHost(c)}`).replace(/\/$/, ''); }
function cosSign(method, key, host, secretId, secretKey) {
  const start = Math.floor(Date.now() / 1000) - 60;
  const keyTime = `${start};${start + 3600}`;
  const signKey = crypto.createHmac('sha1', secretKey).update(keyTime).digest('hex');
  const httpString = `${method.toLowerCase()}\n${key}\n\nhost=${encodeURIComponent(host)}\n`;
  const strToSign = `sha1\n${keyTime}\n${crypto.createHash('sha1').update(httpString).digest('hex')}\n`;
  const sig = crypto.createHmac('sha1', signKey).update(strToSign).digest('hex');
  return `q-sign-algorithm=sha1&q-ak=${secretId}&q-sign-time=${keyTime}&q-key-time=${keyTime}&q-header-list=host&q-url-param-list=&q-signature=${sig}`;
}

async function cosPut(objKey, buf, mimetype, c = S.get('storage').cos) {
  const host = cosHost(c);
  const key = '/' + objKey.replace(/^\//, '');
  const res = await fetch(`https://${host}${encodeURI(key)}`, {
    method: 'PUT',
    headers: { Authorization: cosSign('put', key, host, c.secret_id, c.secret_key), 'Content-Type': mimetype, 'Content-Length': String(buf.length) },
    body: buf,
  });
  if (!res.ok) throw new Error(`COS 上传失败：HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
  return cosBase(c) + encodeURI(key);
}
async function cosDelete(objKey, c = S.get('storage').cos) {
  const host = cosHost(c);
  const key = '/' + objKey.replace(/^\//, '');
  const res = await fetch(`https://${host}${encodeURI(key)}`, { method: 'DELETE', headers: { Authorization: cosSign('delete', key, host, c.secret_id, c.secret_key) } });
  return res.ok || res.status === 404;
}

// 保存二进制
async function saveBuffer(buf, { mimetype = '', ext = '', category = 'file' } = {}) {
  const sniffed = sniff(buf);
  const mt = sniffed || mimetype || EXT_MIME[ext] || 'application/octet-stream';
  const e = MIME_EXT[mt] || ext || 'bin';
  const safeCat = String(category || 'file').replace(/[^a-z0-9_-]/gi, '').slice(0, 30) || 'file';
  const st0 = S.get('storage');
  // 存到 COS 的图片：顺带生成一张 960 宽的 WebP 小图（文件名带 _t 表示有小图），列表 / 首页直接用它，
  // 不用每次让数据万象现场缩 4K 大图（又慢又占免费额度）
  let tb = null;
  if (st0.driver === 'cos' && st0.cos && st0.cos.bucket && /^image\/(png|jpeg|webp)$/.test(mt) && buf.length > 150 * 1024) {
    tb = await require('./thumbs').webpThumb(buf, 960).catch(() => null);
  }
  const rel = `/uploads/${safeCat}/${datePath()}/${randomHex(12)}${tb ? '_t' : ''}.${e}`;
  const size = mt.startsWith('image/') ? imageSize(buf) : { width: 0, height: 0 };
  const st = S.get('storage');
  let fullurl;
  let url = rel;
  if (st.driver === 'cos' && st.cos && st.cos.bucket) {
    const key = (st.cos.prefix || 'uploads') + rel.replace(/^\/uploads/, '');
    [fullurl] = await Promise.all([cosPut(key, buf, mt), tb ? cosPut(key + '.w960.webp', tb, 'image/webp').catch(() => null) : null]);
    url = fullurl;
  } else {
    const file = path.join(config.uploadDir, rel.replace(/^\/uploads\//, ''));
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, buf);
    fullurl = config.publicBaseUrl + rel;
  }
  return { url, fullurl, relative_url: url, mimetype: mt, filesize: buf.length, width: size.width, height: size.height };
}

function localFileOf(url) {
  const s = String(url || '');
  let p = null;
  if (s.startsWith('/uploads/')) p = s;
  else {
    // 现在的地址，或换域名前的旧地址（config.aliasBaseUrls）
    const base = [config.publicBaseUrl, ...(Array.isArray(config.aliasBaseUrls) ? config.aliasBaseUrls : [])].map((u) => String(u || '').replace(/\/$/, '')).find((u) => u && s.startsWith(u + '/uploads/'));
    if (base) p = s.slice(base.length);
  }
  if (!p) return null;
  const base = path.normalize(config.uploadDir).replace(/[\\/]+$/, '');
  const f = path.normalize(path.join(base, p.split('?')[0].replace(/^\/uploads\//, '')));
  return f.startsWith(base + path.sep) && fs.existsSync(f) ? f : null;
}

// ---------- 防 SSRF：不许借服务器去访问内网 / 本机地址（只放行自己配置的中转站、抠图、存储地址）----------
const dns = require('node:dns').promises;
const net = require('node:net');
function privateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 198 && (b === 18 || b === 19)) || a >= 224;
  }
  const s = ip.toLowerCase();
  if (s.startsWith('::ffff:')) return privateIp(s.slice(7));
  return s === '::' || s === '::1' || /^f[cd]/.test(s) || /^fe[89ab]/.test(s) || s.startsWith('ff');
}
function trustedHosts() {
  const out = new Set();
  const add = (u) => { try { if (u) out.add(new URL(u).host.toLowerCase()); } catch { /* 不是地址 */ } };
  add(config.publicBaseUrl); add(config.siteUrl);
  const relay = S.get('relay') || {};
  for (const ch of relay.channels || []) add(ch && ch.base_url);
  add((S.get('matting') || {}).picwish_base);
  const c = (S.get('storage') || {}).cos || {};
  if (c.bucket && c.region) { add(cosBase(c)); out.add(cosHost(c)); }
  return out;
}
async function assertPublicUrl(u) {
  let url;
  try { url = new URL(u); } catch { throw new Error('图片地址不正确'); }
  if (!/^https?:$/.test(url.protocol)) throw new Error('只支持 http / https 图片地址');
  if (config.allowPrivateFetch || trustedHosts().has(url.host.toLowerCase())) return;
  const host = url.hostname.replace(/^\[|\]$/g, '');
  const ips = net.isIP(host) ? [host] : (await dns.lookup(host, { all: true }).catch(() => [])).map((x) => x.address);
  if (!ips.length) throw new Error('图片地址无法访问');
  if (ips.some(privateIp)) throw new Error('不支持内网地址的图片');
}

// 读取任意图片 URL（本地文件直读；data URI 解码；远程下载）
async function fetchBuffer(url, { timeout = 60000, maxBytes = 40 * 1024 * 1024 } = {}) {
  const s = String(url || '').trim();
  if (!s) throw new Error('图片地址为空');
  if (s.startsWith('data:')) {
    const m = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(s);
    if (!m) throw new Error('data URI 无效');
    return { buffer: m[2] ? Buffer.from(m[3], 'base64') : Buffer.from(decodeURIComponent(m[3])), mimetype: m[1] || 'application/octet-stream' };
  }
  const lf = localFileOf(s);
  if (lf) {
    const buffer = fs.readFileSync(lf);
    return { buffer, mimetype: sniff(buffer) || 'application/octet-stream' };
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  try {
    // 电商图床会校验 Referer / UA，按域名补上
    const headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36', Accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' };
    const host = (() => { try { return new URL(s).hostname; } catch { return ''; } })();
    if (/alicdn\.com|taobaocdn|tbcdn/.test(host)) headers.Referer = 'https://www.taobao.com/';
    else if (/360buyimg\.com|jd\.com/.test(host)) headers.Referer = 'https://item.jd.com/';
    else if (/pddpic|yangkeduo|pinduoduo/.test(host)) headers.Referer = 'https://mobile.yangkeduo.com/';
    else if (/1688|cbu01/.test(host)) headers.Referer = 'https://detail.1688.com/';
    // 手动跟随跳转，每一跳都检查一遍地址（防止用公网地址 302 跳到内网）
    let cur = s; let res;
    for (let hop = 0; ; hop++) {
      await assertPublicUrl(cur);
      res = await fetch(cur, { signal: ctrl.signal, headers, redirect: 'manual' });
      const loc = res.status >= 300 && res.status < 400 ? res.headers.get('location') : '';
      if (!loc) break;
      if (hop >= 4) throw new Error('图片地址跳转次数过多');
      cur = new URL(loc, cur).toString();
    }
    if (!res.ok) throw new Error(`下载失败 HTTP ${res.status}`);
    const len = Number(res.headers.get('content-length') || 0);
    if (len > maxBytes) throw new Error('文件过大');
    const ab = await res.arrayBuffer();
    if (ab.byteLength > maxBytes) throw new Error('文件过大');
    const buffer = Buffer.from(ab);
    return { buffer, mimetype: sniff(buffer) || res.headers.get('content-type') || 'application/octet-stream' };
  } finally { clearTimeout(timer); }
}

async function saveRemote(url, category = 'gen') {
  const { buffer, mimetype } = await fetchBuffer(url, { timeout: 180000, maxBytes: 300 * 1024 * 1024 });
  return saveBuffer(buffer, { mimetype, category });
}

module.exports = { assertPublicUrl, privateIp, cosPut, cosDelete, cosBase, cosHost, saveBuffer, saveRemote, fetchBuffer, localFileOf, sniff, imageSize, EXT_MIME, MIME_EXT };
