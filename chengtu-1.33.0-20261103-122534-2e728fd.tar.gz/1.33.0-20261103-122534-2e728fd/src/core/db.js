'use strict';
// SQLite（Node 内置 node:sqlite）数据层：建表 + 轻量查询助手
const { DatabaseSync } = require('node:sqlite');
const config = require('./config');

const db = new DatabaseSync(config.dbFile);
db.exec('PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL; PRAGMA foreign_keys = OFF; PRAGMA busy_timeout = 5000;');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS yd_user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT DEFAULT '', nickname TEXT DEFAULT '', password TEXT DEFAULT '', salt TEXT DEFAULT '',
  mobile TEXT DEFAULT '', email TEXT DEFAULT '', avatar TEXT DEFAULT '',
  score INTEGER DEFAULT 0, locked_score INTEGER DEFAULT 0,
  member_level TEXT DEFAULT 'free', member_expiretime INTEGER DEFAULT 0,
  is_distributor INTEGER DEFAULT 0, distribution_rate REAL DEFAULT 0, distribution_opentime INTEGER DEFAULT 0,
  enable_video INTEGER DEFAULT 1, video_cost INTEGER DEFAULT 0, video_m3_cost INTEGER DEFAULT 0, concurrency INTEGER DEFAULT 0,
  invite_code TEXT DEFAULT '', parent_user_id INTEGER DEFAULT 0,
  enterprise_owner_id INTEGER DEFAULT 0, sub_remark TEXT DEFAULT '',
  wechat_openid TEXT DEFAULT '', wechat_unionid TEXT DEFAULT '', wechat_nickname TEXT DEFAULT '',
  status TEXT DEFAULT 'normal', remark TEXT DEFAULT '',
  jointime INTEGER DEFAULT 0, joinip TEXT DEFAULT '', logintime INTEGER DEFAULT 0, loginip TEXT DEFAULT '',
  deletetime INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_user_mobile ON yd_user(mobile);
CREATE INDEX IF NOT EXISTS idx_user_email ON yd_user(email);
CREATE INDEX IF NOT EXISTS idx_user_username ON yd_user(username);
CREATE INDEX IF NOT EXISTS idx_user_invite ON yd_user(invite_code);
CREATE INDEX IF NOT EXISTS idx_user_parent ON yd_user(parent_user_id);
CREATE INDEX IF NOT EXISTS idx_user_openid ON yd_user(wechat_openid);

CREATE TABLE IF NOT EXISTS yd_token (
  token TEXT PRIMARY KEY, user_id INTEGER, createtime INTEGER, expiretime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_token_user ON yd_token(user_id);

CREATE TABLE IF NOT EXISTS yd_captcha ( key TEXT PRIMARY KEY, code TEXT, expiretime INTEGER );
CREATE TABLE IF NOT EXISTS yd_vcode (
  id INTEGER PRIMARY KEY AUTOINCREMENT, target TEXT, event TEXT, code TEXT, times INTEGER DEFAULT 0, ip TEXT, createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_vcode ON yd_vcode(target, event);

CREATE TABLE IF NOT EXISTS yd_wechat_state (
  state TEXT PRIMARY KEY, mode TEXT, user_id INTEGER DEFAULT 0, openid TEXT DEFAULT '', unionid TEXT DEFAULT '',
  nickname TEXT DEFAULT '', avatar TEXT DEFAULT '', status TEXT DEFAULT 'pending', msg TEXT DEFAULT '',
  invite_code TEXT DEFAULT '', redirect TEXT DEFAULT '', keeptime INTEGER DEFAULT 0, result_user_id INTEGER DEFAULT 0,
  createtime INTEGER
);

CREATE TABLE IF NOT EXISTS yd_score_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, type TEXT, change INTEGER, balance INTEGER,
  remark TEXT, ref TEXT DEFAULT '', operator_id INTEGER DEFAULT 0, createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_score_user ON yd_score_log(user_id, id);

CREATE TABLE IF NOT EXISTS yd_plan (
  id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, title TEXT, tag TEXT DEFAULT '', price REAL, original_price REAL,
  points INTEGER DEFAULT 0, days INTEGER DEFAULT 0, level TEXT DEFAULT '', note TEXT DEFAULT '', highlight INTEGER DEFAULT 0,
  agent_price REAL DEFAULT 0, redeemable INTEGER DEFAULT 1, sort INTEGER DEFAULT 0, status TEXT DEFAULT 'normal', createtime INTEGER
);

CREATE TABLE IF NOT EXISTS yd_order (
  id INTEGER PRIMARY KEY AUTOINCREMENT, order_sn TEXT UNIQUE, user_id INTEGER, kind TEXT, plan_id INTEGER, title TEXT,
  amount REAL, original_amount REAL DEFAULT 0, discount REAL DEFAULT 0, coupon_id INTEGER DEFAULT 0, points INTEGER DEFAULT 0,
  quantity INTEGER DEFAULT 1, pay_type TEXT, pay_status TEXT DEFAULT 'pending', transaction_id TEXT DEFAULT '',
  paytime INTEGER DEFAULT 0, extra TEXT DEFAULT '', refund_reason TEXT DEFAULT '', createtime INTEGER, updatetime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_order_user ON yd_order(user_id, kind);

CREATE TABLE IF NOT EXISTS yd_coupon_activity (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount REAL, threshold_amount REAL DEFAULT 0, valid_days INTEGER DEFAULT 30,
  total INTEGER DEFAULT 0, claimed INTEGER DEFAULT 0, per_user INTEGER DEFAULT 1, starttime INTEGER DEFAULT 0, endtime INTEGER DEFAULT 0,
  status TEXT DEFAULT 'normal', createtime INTEGER
);
CREATE TABLE IF NOT EXISTS yd_user_coupon (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, activity_id INTEGER, title TEXT, amount REAL, threshold_amount REAL DEFAULT 0,
  status TEXT DEFAULT 'valid', expiretime INTEGER, usetime INTEGER DEFAULT 0, order_sn TEXT DEFAULT '', createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_ucoupon_user ON yd_user_coupon(user_id);

CREATE TABLE IF NOT EXISTS yd_redeem_code (
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, plan_id INTEGER DEFAULT 0, title TEXT, type TEXT DEFAULT 'pack',
  points INTEGER DEFAULT 0, days INTEGER DEFAULT 0, level TEXT DEFAULT '', owner_user_id INTEGER DEFAULT 0, order_sn TEXT DEFAULT '',
  status TEXT DEFAULT 'unused', used_user_id INTEGER DEFAULT 0, usetime INTEGER DEFAULT 0, expiretime INTEGER DEFAULT 0, createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_redeem_owner ON yd_redeem_code(owner_user_id);

CREATE TABLE IF NOT EXISTS yd_notice (
  id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT DEFAULT 'notice', title TEXT, content TEXT, time TEXT, status TEXT DEFAULT 'normal', createtime INTEGER
);
CREATE TABLE IF NOT EXISTS yd_notice_read ( user_id INTEGER, notice_id INTEGER, PRIMARY KEY(user_id, notice_id) );
CREATE TABLE IF NOT EXISTS yd_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, type TEXT, product TEXT, content TEXT, wechat TEXT, phone TEXT, images TEXT,
  status TEXT DEFAULT 'pending', reply TEXT DEFAULT '', createtime INTEGER
);

CREATE TABLE IF NOT EXISTS yd_material_group ( id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, name TEXT, createtime INTEGER );
CREATE TABLE IF NOT EXISTS yd_material (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER DEFAULT 0, group_id INTEGER DEFAULT 0, category_id INTEGER DEFAULT 0,
  name TEXT, url TEXT, fullurl TEXT, mimetype TEXT, filesize INTEGER DEFAULT 0, width INTEGER DEFAULT 0, height INTEGER DEFAULT 0,
  sort INTEGER DEFAULT 0, createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_material_user ON yd_material(user_id, group_id);

CREATE TABLE IF NOT EXISTS yd_upload (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER DEFAULT 0, url TEXT, fullurl TEXT, mimetype TEXT, filesize INTEGER,
  width INTEGER DEFAULT 0, height INTEGER DEFAULT 0, category TEXT DEFAULT '', source TEXT DEFAULT '', createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_upload_user ON yd_upload(user_id, source);

-- 生成任务（所有板块/模块共用）
CREATE TABLE IF NOT EXISTS yd_task (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, bill_user_id INTEGER, kind TEXT, board TEXT, module TEXT, scene TEXT,
  scene_name TEXT DEFAULT '', params TEXT, status TEXT DEFAULT 'queued', count INTEGER DEFAULT 0, success_count INTEGER DEFAULT 0,
  fail_count INTEGER DEFAULT 0, charged_points INTEGER DEFAULT 0, refunded_points INTEGER DEFAULT 0, model_key TEXT DEFAULT '',
  resolution TEXT DEFAULT '', ratio TEXT DEFAULT '', prompt TEXT DEFAULT '', remark TEXT DEFAULT '', session_id INTEGER DEFAULT 0,
  error TEXT DEFAULT '', deleted INTEGER DEFAULT 0, deleted_at INTEGER DEFAULT 0, createtime INTEGER, updatetime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_task_user ON yd_task(user_id, board, deleted, id);
CREATE INDEX IF NOT EXISTS idx_task_status ON yd_task(status);
CREATE INDEX IF NOT EXISTS idx_task_session ON yd_task(session_id);
-- 已验证手机号的被邀请人（邀请奖励按它计数，防机器批量注册刷邀请奖励）
CREATE TABLE IF NOT EXISTS ct_invite_ok ( user_id INTEGER PRIMARY KEY, parent_id INTEGER, createtime INTEGER );
CREATE INDEX IF NOT EXISTS idx_invite_ok_parent ON ct_invite_ok(parent_id);
CREATE TABLE IF NOT EXISTS yd_gallery_cat ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sort INTEGER DEFAULT 0, createtime INTEGER );
CREATE TABLE IF NOT EXISTS yd_gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT DEFAULT '', image TEXT, width INTEGER DEFAULT 0, height INTEGER DEFAULT 0, ratio TEXT DEFAULT '',
  prompt TEXT DEFAULT '', cat_id INTEGER DEFAULT 0, tags TEXT DEFAULT '[]', status TEXT DEFAULT 'draft', source TEXT DEFAULT '', job_id INTEGER DEFAULT 0,
  hot INTEGER DEFAULT 0, sort INTEGER DEFAULT 0, createtime INTEGER, updatetime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_gallery_status ON yd_gallery(status, cat_id, id);
CREATE TABLE IF NOT EXISTS yd_gallery_job (
  id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, title TEXT DEFAULT '', params TEXT DEFAULT '{}', total INTEGER DEFAULT 0, done INTEGER DEFAULT 0,
  failed INTEGER DEFAULT 0, status TEXT DEFAULT 'running', error TEXT DEFAULT '', createtime INTEGER, updatetime INTEGER
);
-- 首页对话的画布（每个对话一张；旧系统数据库里可能有同名的 yd_canvas 表，所以用新名字）：图片位置、隐藏的图、画布上额外添加的图 / 文字（JSON）
CREATE TABLE IF NOT EXISTS ct_canvas_doc ( session_id INTEGER PRIMARY KEY, user_id INTEGER, doc TEXT DEFAULT '{}', updatetime INTEGER );
CREATE TABLE IF NOT EXISTS yd_session (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT DEFAULT '', createtime INTEGER, updatetime INTEGER
);
CREATE TABLE IF NOT EXISTS yd_task_result (
  id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER, idx INTEGER, label TEXT DEFAULT '', kind TEXT DEFAULT 'image',
  spec TEXT, cost INTEGER DEFAULT 0, status TEXT DEFAULT 'queued', url TEXT DEFAULT '', content TEXT DEFAULT '', error TEXT DEFAULT '',
  attempts INTEGER DEFAULT 0, deleted INTEGER DEFAULT 0, refunded INTEGER DEFAULT 0, starttime INTEGER DEFAULT 0,
  createtime INTEGER, updatetime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_result_task ON yd_task_result(task_id, idx);
CREATE INDEX IF NOT EXISTS idx_result_status ON yd_task_result(status, id);

CREATE TABLE IF NOT EXISTS yd_setting ( key TEXT PRIMARY KEY, value TEXT );

CREATE TABLE IF NOT EXISTS yd_admin ( id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, salt TEXT, createtime INTEGER, logintime INTEGER DEFAULT 0 );
CREATE TABLE IF NOT EXISTS yd_admin_token ( token TEXT PRIMARY KEY, admin_id INTEGER, expiretime INTEGER );
CREATE TABLE IF NOT EXISTS yd_ai_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER DEFAULT 0, kind TEXT, model TEXT, ok INTEGER, ms INTEGER, error TEXT DEFAULT '', createtime INTEGER
);
CREATE TABLE IF NOT EXISTS yd_admin_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, username TEXT, action TEXT, detail TEXT DEFAULT '', ip TEXT DEFAULT '', createtime INTEGER
);
CREATE INDEX IF NOT EXISTS idx_admin_log_time ON yd_admin_log(createtime);
`;
db.exec(SCHEMA);
// 增量字段（老库升级）
function addColumn(table, col, def) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(col)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${col} ${def}`);
}
addColumn('yd_admin', 'role', "TEXT DEFAULT 'super'");
addColumn('yd_admin', 'nickname', "TEXT DEFAULT ''");
addColumn('yd_admin', 'status', "TEXT DEFAULT 'normal'");

// ---------- 助手 ----------
function norm(v) {
  if (v === undefined) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  if (v !== null && typeof v === 'object' && !Buffer.isBuffer(v)) return JSON.stringify(v);
  return v;
}
const cache = new Map();
function stmt(sql) {
  let s = cache.get(sql);
  if (!s) { s = db.prepare(sql); cache.set(sql, s); if (cache.size > 500) cache.delete(cache.keys().next().value); }
  return s;
}
const all = (sql, ...p) => stmt(sql).all(...p.map(norm));
const get = (sql, ...p) => stmt(sql).get(...p.map(norm)) || null;
const run = (sql, ...p) => stmt(sql).run(...p.map(norm));
const val = (sql, ...p) => { const r = get(sql, ...p); return r ? Object.values(r)[0] : null; };

function insert(table, obj) {
  const keys = Object.keys(obj);
  const r = run(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(() => '?').join(',')})`, ...keys.map((k) => obj[k]));
  return Number(r.lastInsertRowid);
}
function update(table, obj, where, ...wp) {
  const keys = Object.keys(obj);
  if (!keys.length) return 0;
  const r = run(`UPDATE ${table} SET ${keys.map((k) => `${k}=?`).join(',')} WHERE ${where}`, ...keys.map((k) => obj[k]), ...wp);
  return Number(r.changes);
}
let txDepth = 0;
function tx(fn) {
  if (txDepth > 0) { txDepth++; try { return fn(); } finally { txDepth--; } }
  db.exec('BEGIN IMMEDIATE');
  txDepth = 1;
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; } finally { txDepth = 0; }
}

module.exports = { db, all, get, run, val, insert, update, tx };
