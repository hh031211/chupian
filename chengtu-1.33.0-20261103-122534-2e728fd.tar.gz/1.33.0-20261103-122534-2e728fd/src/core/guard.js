'use strict';
// 防刷：登录爆破、短信轰炸、批量注册、免费 AI 接口被狂刷。
// 计数在内存里（重启清零），按 IP / 账号 / 用户 分别限制。后台「内容安全」可关（security.rate_limit=false，只在测试环境用）。
const S = require('./settings');
const { limit, over, count, mark, clearHits, fail } = require('./http');

const on = () => (S.get('security') || {}).rate_limit !== false;

/** 窗口内超过 max 次就拒绝 */
function rl(key, max, windowSec, msg) { if (on()) limit(key, max, windowSec, msg); }
/** 只记一次不检查（如：登录失败次数） */
function note(key) { if (on()) mark(key); }
function seen(key, windowSec) { return on() ? count(key, windowSec) : 0; }
function reset(key) { clearHits(key); }
function tooMany(key, max, windowSec) { return on() && over(key, max, windowSec); }

// 免费的 AI 文本 / 改字接口：每个用户 10 分钟内的次数上限（防止被刷掉中转站费用、拖慢服务器）
const AI_LIMITS = {
  '/ai/plan': 60, '/ai/describe': 40, '/ai/prompt/optimize': 40, '/ai/prompt/adapt': 40,
  '/text/detect': 40, '/text/inpaint': 40, '/text/erase': 40, '/text/translate': 40, '/text/font': 400,
};
function aiLimit(pathname, user) {
  const max = AI_LIMITS[pathname];
  if (max && user) rl(`ai:${pathname}:${user.id}`, max, 600, '操作太频繁，请稍后再试');
}

module.exports = { on, rl, note, seen, reset, tooMany, aiLimit, fail };
