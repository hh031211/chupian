'use strict';
// 启动配置：config.json（不存在则用 config.example.json 的默认值），环境变量可覆盖关键项
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..', '..');

function load() {
  const exampleFile = path.join(ROOT, 'config.example.json');
  const file = process.env.YD_CONFIG || path.join(ROOT, 'config.json');
  let base = {};
  try { base = JSON.parse(fs.readFileSync(exampleFile, 'utf8')); } catch {}
  let user = {};
  if (fs.existsSync(file)) {
    try { user = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {
      console.error('[config] config.json 解析失败：', e.message);
      process.exit(1);
    }
  }
  const cfg = deepMerge(base, user);
  if (process.env.PORT) cfg.port = Number(process.env.PORT);
  if (process.env.YD_PUBLIC_BASE_URL) cfg.publicBaseUrl = process.env.YD_PUBLIC_BASE_URL;
  if (process.env.YD_DB_FILE) cfg.dbFile = process.env.YD_DB_FILE;
  cfg.root = ROOT;
  cfg.dbFile = path.resolve(ROOT, cfg.dbFile || './data/yuduo.db');
  cfg.uploadDir = path.resolve(ROOT, cfg.uploadDir || './data/uploads');
  if (cfg.frontendDist) cfg.frontendDist = path.resolve(ROOT, cfg.frontendDist);
  cfg.apiPrefix = (cfg.apiPrefix || '').replace(/\/$/, '');
  cfg.publicBaseUrl = String(cfg.publicBaseUrl || '').replace(/\/$/, '');
  fs.mkdirSync(path.dirname(cfg.dbFile), { recursive: true });
  fs.mkdirSync(cfg.uploadDir, { recursive: true });
  return cfg;
}

function deepMerge(a, b) {
  if (Array.isArray(b)) return b.slice();
  if (!b || typeof b !== 'object') return b === undefined ? a : b;
  const out = { ...(a && typeof a === 'object' && !Array.isArray(a) ? a : {}) };
  for (const k of Object.keys(b)) out[k] = deepMerge(out[k], b[k]);
  return out;
}

module.exports = load();
module.exports.deepMerge = deepMerge;
