'use strict';
/**
 * 人机验证（防机器批量注册 / 刷短信 / 撞库）
 *   provider = builtin  图形验证码（本站自己画的 PNG，见 captcha.js）
 *   provider = aliyun   阿里云验证码 2.0：前端按钮点击时做无痕 / 滑块验证，拿到 captchaVerifyParam，
 *                       服务端调 VerifyIntelligentCaptcha 校验（按次计费，约 5 元 / 千次）
 * 阿里云接口异常（超时、5xx）时按官方建议放行，保证正常用户能注册登录；频率限制等其它防护照常生效
 */
const S = require('./settings');
const captcha = require('./captcha');
const { fail } = require('./http');

function aliCfg() {
  const h = (S.get('security') || {}).human || {};
  const a = h.aliyun || {};
  const sms = ((S.get('sms') || {}).aliyun) || {};
  return {
    on: h.provider === 'aliyun' && !!a.prefix && !!a.scene_id,
    prefix: String(a.prefix || '').trim(), scene_id: String(a.scene_id || '').trim(), region: a.region === 'sgp' ? 'sgp' : 'cn',
    access_key_id: a.access_key_id || sms.access_key_id || '', access_key_secret: a.access_key_secret || sms.access_key_secret || '',
  };
}
const aliyunOn = () => aliCfg().on;

/** 给前端的公开配置（不含密钥） */
function publicConfig() {
  const c = aliCfg();
  return c.on ? { provider: 'aliyun', prefix: c.prefix, scene_id: c.scene_id, region: c.region } : { provider: 'builtin' };
}

async function verifyAliyun(param) {
  if (process.env.CT_HUMAN_MOCK === '1') return param === 'mock-pass';   // 只有测试沙箱会设置
  const c = aliCfg();
  if (!c.access_key_id || !c.access_key_secret) { console.warn('[人机验证] 阿里云验证码没有 AccessKey，已放行'); return true; }
  const host = c.region === 'sgp' ? 'captcha.ap-southeast-1.aliyuncs.com' : 'captcha.cn-shanghai.aliyuncs.com';
  try {
    const { status, j } = await require('./notify').aliyunRpc(host, 'VerifyIntelligentCaptcha', {
      Version: '2023-03-05', RegionId: c.region === 'sgp' ? 'ap-southeast-1' : 'cn-shanghai', CaptchaVerifyParam: String(param), SceneId: c.scene_id,
    }, c);
    if (j && j.Result && typeof j.Result.VerifyResult === 'boolean') {
      if (!j.Result.VerifyResult) console.warn('[人机验证] 未通过：', j.Result.VerifyCode || '');
      return j.Result.VerifyResult;
    }
    console.warn('[人机验证] 阿里云返回异常，已放行：', status, j && (j.Code || j.Message));
    return true;
  } catch (e) {
    console.warn('[人机验证] 调用阿里云失败，已放行：', e.message);
    return true;
  }
}

/**
 * 校验一次人机验证
 *   need：这次是否必须验证（如注册总是要；登录输错几次后才要）
 *   阿里云模式：前端传 captcha_verify_param；图形验证码模式：captcha_key + captcha
 */
async function check(p, need) {
  if (aliyunOn()) {
    if (!p.captcha_verify_param) { if (need) fail('请先完成安全验证'); return; }
    if (!(await verifyAliyun(p.captcha_verify_param))) fail('安全验证未通过，请重试');
    return;
  }
  if ((need || p.captcha_key) && !captcha.verify(p.captcha_key, p.captcha)) fail(p.captcha ? '图形验证码不正确，请重新输入' : '请输入图形验证码');
}

module.exports = { publicConfig, check, aliyunOn, verifyAliyun };
