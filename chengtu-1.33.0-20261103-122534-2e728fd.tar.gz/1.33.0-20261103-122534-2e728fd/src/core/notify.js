'use strict';
// 短信（阿里云）与邮件（SMTP）验证码发送 + 校验
const crypto = require('node:crypto');
const net = require('node:net');
const tls = require('node:tls');
const db = require('./db');
const S = require('./settings');
const { now, randomDigits } = require('./util');
const { fail } = require('./http');

function pe(s) {
  return encodeURIComponent(s).replace(/\+/g, '%20').replace(/\*/g, '%2A').replace(/%7E/g, '~');
}

// 阿里云 RPC 接口（签名 V1）
async function aliyunRpc(host, action, extra, c) {
  const params = {
    AccessKeyId: c.access_key_id, Action: action, Format: 'JSON', RegionId: 'cn-hangzhou',
    SignatureMethod: 'HMAC-SHA1', SignatureNonce: crypto.randomUUID(), SignatureVersion: '1.0',
    Timestamp: new Date().toISOString().replace(/\.\d+Z$/, 'Z'), Version: '2017-05-25', ...extra,
  };
  const canon = Object.keys(params).sort().map((k) => `${pe(k)}=${pe(params[k])}`).join('&');
  const sts = `GET&${pe('/')}&${pe(canon)}`;
  const sig = crypto.createHmac('sha1', c.access_key_secret + '&').update(sts).digest('base64');
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const res = await fetch(`https://${host}/?Signature=${pe(sig)}&${canon}`, { signal: ctl.signal });
    return { status: res.status, j: await res.json().catch(() => ({})) };
  } finally { clearTimeout(t); }
}

/**
 * 发短信验证码
 *   provider=aliyun       阿里云「短信服务」：自己的签名 + 模板（需要企业 / 商标资质）
 *   provider=aliyun_pnvs  阿里云「号码认证服务 → 短信认证」：系统赠送的签名 + 模板，个人实名即可，不用执照和备案
 *   验证码都由本站生成、本站校验（10 分钟有效）
 */
async function aliyunSms(mobile, code, cfg = S.get('sms')) {
  const c = cfg.aliyun || {};
  if (!c.access_key_id || !c.access_key_secret) throw new Error('短信未配置 AccessKey');
  if (!c.sign_name || !c.template_code) throw new Error('短信未配置签名或模板 CODE');
  if (cfg.provider === 'aliyun_pnvs') {
    const { status, j } = await aliyunRpc('dypnsapi.aliyuncs.com', 'SendSmsVerifyCode', {
      PhoneNumber: mobile, SignName: c.sign_name, TemplateCode: c.template_code,
      TemplateParam: JSON.stringify({ code, min: '10' }), CodeLength: String(code).length, ValidTime: 600, Interval: 60,
    }, c);
    if (j.Code !== 'OK') throw new Error('短信发送失败：' + (j.Message || j.Code || status));
    return;
  }
  const { status, j } = await aliyunRpc('dysmsapi.aliyuncs.com', 'SendSms', {
    PhoneNumbers: mobile, SignName: c.sign_name, TemplateCode: c.template_code, TemplateParam: JSON.stringify({ code }),
  }, c);
  if (j.Code !== 'OK') throw new Error('短信发送失败：' + (j.Message || j.Code || status));
}

// ---- 极简 SMTP 客户端 ----
function smtpSend({ host, port, secure, user, pass, from, to, subject, html }) {
  return new Promise((resolve, reject) => {
    let sock;
    let buf = '';
    const queue = [];
    let step = 0;
    const timer = setTimeout(() => { try { sock.destroy(); } catch {} reject(new Error('SMTP 超时')); }, 20000);
    const send = (l) => sock.write(l + '\r\n');
    const fromAddr = (/<([^>]+)>/.exec(from) || [null, from])[1];
    const b64 = (s) => Buffer.from(s, 'utf8').toString('base64');
    const msg = [
      `From: ${from}`, `To: ${to}`, `Subject: =?UTF-8?B?${b64(subject)}?=`, 'MIME-Version: 1.0',
      'Content-Type: text/html; charset=UTF-8', 'Content-Transfer-Encoding: base64', `Date: ${new Date().toUTCString()}`, '',
      b64(html).replace(/.{76}/g, '$&\r\n'), '.',
    ].join('\r\n');
    const steps = [
      (c) => c === 220 && send(`EHLO yuduo.local`),
      (c, all) => {
        if (c !== 250) return false;
        if (!secure && /STARTTLS/i.test(all) && !sock.encrypted) { send('STARTTLS'); step = 100; return true; }
        send('AUTH LOGIN'); return true;
      },
      (c) => c === 334 && send(b64(user)),
      (c) => c === 334 && send(b64(pass)),
      (c) => c === 235 && send(`MAIL FROM:<${fromAddr}>`),
      (c) => c === 250 && send(`RCPT TO:<${to}>`),
      (c) => (c === 250 || c === 251) && send('DATA'),
      (c) => c === 354 && sock.write(msg + '\r\n'),
      (c) => { if (c !== 250) return false; send('QUIT'); clearTimeout(timer); resolve(); return true; },
    ];
    const onData = (d) => {
      buf += d.toString();
      const lines = buf.split('\r\n');
      if (!/^\d{3} /m.test(buf)) return;
      const last = lines.filter(Boolean).pop();
      if (!/^\d{3} /.test(last)) return;
      const all = buf;
      buf = '';
      const code = parseInt(last.slice(0, 3), 10);
      if (step === 100) {
        if (code !== 220) { clearTimeout(timer); reject(new Error('STARTTLS 失败')); return; }
        const s2 = tls.connect({ socket: sock, servername: host }, () => { sock = s2; step = 1; send('EHLO yuduo.local'); });
        s2.on('data', onData);
        s2.on('error', (e) => { clearTimeout(timer); reject(e); });
        sock.encrypted = true;
        return;
      }
      const fn = steps[step];
      if (!fn) return;
      const r = fn(code, all);
      if (r === false) { clearTimeout(timer); try { sock.destroy(); } catch {} reject(new Error('SMTP 错误：' + last)); return; }
      if (step !== 100) step++;
    };
    sock = secure ? tls.connect({ host, port, servername: host }) : net.connect({ host, port });
    sock.on('data', onData);
    sock.on('error', (e) => { clearTimeout(timer); reject(e); });
    queue.length = 0;
  });
}

async function sendMail(to, code) {
  const m = S.get('mail');
  if (!m.enabled || !m.host) throw new Error('邮件未配置');
  const site = S.get('site').name;
  await smtpSend({
    host: m.host, port: Number(m.port || 465), secure: m.secure !== false && Number(m.port) !== 587, user: m.user, pass: m.pass,
    from: m.from || m.user, to, subject: `【${site}】${m.subject || '验证码'}`,
    html: `<div style="font-size:14px">您的验证码是 <b style="font-size:20px;color:#2f80ff">${code}</b>，10 分钟内有效。如非本人操作请忽略。</div>`,
  });
}

// 发送验证码：target 手机号/邮箱
async function sendCode(target, event, kind, ip = '') {
  target = String(target || '').trim();
  const last = db.get('SELECT createtime FROM yd_vcode WHERE target=? AND event=? ORDER BY id DESC LIMIT 1', target, event);
  if (last && now() - last.createtime < 60) fail('发送太频繁，请 60 秒后再试');
  const hourCnt = db.val('SELECT COUNT(*) FROM yd_vcode WHERE target=? AND createtime>?', target, now() - 3600);
  if (hourCnt >= 10) fail('发送次数过多，请稍后再试');
  const code = randomDigits(6);
  const cfg = S.get('sms');
  let debugCode = null;
  if (kind === 'mobile') {
    if (cfg.provider === 'aliyun' || cfg.provider === 'aliyun_pnvs') await aliyunSms(target, code);
    else if (cfg.debug) debugCode = code;
    else fail('短信服务未配置，请联系管理员');
  } else {
    const m = S.get('mail');
    if (m.enabled && m.host) await sendMail(target, code);
    else if (cfg.debug) debugCode = code;
    else fail('邮件服务未配置，请联系管理员');
  }
  db.insert('yd_vcode', { target, event, code, times: 0, ip, createtime: now() });
  if (debugCode) console.log(`[验证码-调试模式] ${target} (${event}) => ${debugCode}`);
  return debugCode ? { debug_code: debugCode } : {};
}

function checkCode(target, event, code, events = null) {
  target = String(target || '').trim();
  const evs = events || [event];
  const row = db.get(
    `SELECT * FROM yd_vcode WHERE target=? AND event IN (${evs.map(() => '?').join(',')}) ORDER BY id DESC LIMIT 1`,
    target, ...evs,
  );
  if (!row || now() - row.createtime > 600) fail('验证码已过期，请重新获取');
  if (row.times >= 5) fail('验证码错误次数过多，请重新获取');
  if (String(row.code) !== String(code || '').trim()) {
    db.run('UPDATE yd_vcode SET times=times+1 WHERE id=?', row.id);
    fail('验证码不正确');
  }
  db.run('DELETE FROM yd_vcode WHERE id=?', row.id);
  return true;
}

module.exports = { aliyunRpc, sendCode, checkCode, smtpSend, aliyunSms };
