'use strict';
const crypto = require('node:crypto');

const now = () => Math.floor(Date.now() / 1000);

function pad(n) { return String(n).padStart(2, '0'); }

// 统一按北京时间格式化（服务器时区可能是 UTC）
function fmtTime(ts, withSec = true) {
  const t = Number(ts || 0);
  if (!t) return '';
  const d = new Date((t + 8 * 3600) * 1000);
  const s = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
  return withSec ? `${s}:${pad(d.getUTCSeconds())}` : s;
}
function fmtDate(ts) { return fmtTime(ts).slice(0, 10); }

function dayStart(ts = now()) {
  const d = new Date((ts + 8 * 3600) * 1000);
  return Math.floor(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()) / 1000) - 8 * 3600;
}

function randomHex(bytes = 16) { return crypto.randomBytes(bytes).toString('hex'); }
function randomDigits(len = 6) {
  let s = '';
  for (let i = 0; i < len; i++) s += crypto.randomInt(0, 10);
  return s;
}
function randomCode(len = 8, alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789') {
  let s = '';
  for (let i = 0; i < len; i++) s += alphabet[crypto.randomInt(0, alphabet.length)];
  return s;
}
function orderSn(prefix = '') {
  const d = new Date(Date.now() + 8 * 3600 * 1000);
  return prefix + d.toISOString().replace(/\D/g, '').slice(0, 14) + randomDigits(6);
}

function jsonParse(s, def = null) {
  if (s == null || s === '') return def;
  if (typeof s === 'object') return s;
  try { return JSON.parse(s); } catch { return def; }
}
function toJson(v) { return v == null ? null : JSON.stringify(v); }

function int(v, def = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : def;
}
function num(v, def = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}
function str(v, max = 0) {
  let s = v == null ? '' : String(v);
  s = s.trim();
  return max ? s.slice(0, max) : s;
}
function money(v) { return Math.round(num(v) * 100) / 100; }

function pageArgs(p, defLimit = 20, maxLimit = 200) {
  const page = Math.max(1, int(p.page, 1));
  const limit = Math.min(maxLimit, Math.max(1, int(p.limit || p.pageSize || p.page_size, defLimit)));
  return { page, limit, offset: (page - 1) * limit };
}

function isUrl(s) { return typeof s === 'string' && /^https?:\/\//i.test(s.trim()); }
function uniq(arr) { return [...new Set(arr.filter(Boolean))]; }

function maskPhone(p) { return p ? String(p).replace(/^(\d{3})\d{4}(\d+)$/, '$1****$2') : ''; }

function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }
function md5(s) { return crypto.createHash('md5').update(String(s)).digest('hex'); }

function hashPassword(pwd, salt = randomHex(8)) {
  const h = crypto.scryptSync(String(pwd), salt, 32).toString('hex');
  return { hash: h, salt };
}
function verifyPassword(pwd, hash, salt) {
  if (!hash || !salt) return false;
  const h = crypto.scryptSync(String(pwd), salt, 32).toString('hex');
  const a = Buffer.from(h, 'hex');
  const b = Buffer.from(String(hash), 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = {
  now, fmtTime, fmtDate, dayStart, randomHex, randomDigits, randomCode, orderSn,
  jsonParse, toJson, int, num, str, money, pageArgs, isUrl, uniq, maskPhone,
  sha256, md5, hashPassword, verifyPassword, sleep,
};
