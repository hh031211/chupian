'use strict';
// 用户核心：令牌、登录态、用户信息序列化、点数（豆）账户
const db = require('./db');
const S = require('./settings');
const config = require('./config');
const { now, fmtTime, randomHex, randomCode, hashPassword, sha256 } = require('./util');

// 数据库里只存令牌的哈希：就算数据库文件泄露，也拿不到能直接登录的令牌（老令牌明文存的，继续兼容到过期）
const tokenKey = (t) => 'h:' + sha256(String(t));
const { fail } = require('./http');

const DEFAULT_KEEP = 30 * 86400;

function issueToken(userId, keeptime = 0) {
  const token = randomHex(20);
  const keep = Number(keeptime) > 0 ? Number(keeptime) : DEFAULT_KEEP;
  db.insert('yd_token', { token: tokenKey(token), user_id: userId, createtime: now(), expiretime: now() + keep });
  db.run('DELETE FROM yd_token WHERE expiretime < ?', now());
  return { token, expires_in: keep };
}

function userByToken(token) {
  if (!token) return null;
  const t = db.get('SELECT * FROM yd_token WHERE token IN (?, ?)', tokenKey(token), String(token));
  if (!t || t.expiretime < now()) return null;
  const u = db.get('SELECT * FROM yd_user WHERE id=? AND deletetime=0', t.user_id);
  if (!u || u.status !== 'normal') return null;
  u._token = t.token;
  u._expires = t.expiretime - now();
  return u;
}

function getUser(id) { return db.get('SELECT * FROM yd_user WHERE id=?', id); }

// 扣点账户（历史上企业子账号从主账号扣，子账号功能已下线，现在都是自己）
function billUser(u) { return u; }

function effectiveLevel(u) {
  const src = billUser(u);
  if (!src) return 'free';
  if (src.member_level && src.member_level !== 'free' && Number(src.member_expiretime) > now()) return src.member_level;
  return 'free';
}

function genInviteCode() {
  for (let i = 0; i < 20; i++) {
    const c = randomCode(6);
    if (!db.get('SELECT id FROM yd_user WHERE invite_code=?', c)) return c;
  }
  return randomCode(10);
}

function userinfo(u, tokenInfo = null) {
  if (!u) return null;
  const bill = billUser(u);
  const levels = S.get('member').level_names || {};
  const lv = effectiveLevel(u);
  const pricing = S.get('pricing');
  const info = {
    id: u.id,
    user_id: u.id,
    username: u.username || '',
    nickname: u.nickname || u.username || '',
    mobile: u.mobile || '',
    email: u.email || '',
    avatar: u.avatar || S.get('site').default_avatar || '',
    score: bill.score,
    locked_score: bill.locked_score || 0,
    expiring_score: 0,
    member_level: lv,
    member_level_name: levels[lv] || '普通用户',
    member_expiretime: bill.member_expiretime || 0,
    member_expiretime_text: bill.member_expiretime ? fmtTime(bill.member_expiretime) : '',
    enable_video: u.enable_video ? 1 : 0,
    video_cost: u.video_cost || pricing.video_cost || 40,
    video_m3_cost: u.video_m3_cost || pricing.video_m3_cost || 5,
    invite_code: u.invite_code || '',
    parent_user_id: u.parent_user_id || 0,
    jointime: u.jointime || 0,
    password_set: u.password ? 1 : 0,
    wechat: u.wechat_nickname || (u.wechat_openid ? '已绑定' : ''),
    wechat_openid: u.wechat_openid ? 'bound' : '',
  };
  if (tokenInfo) { info.token = tokenInfo.token; info.expires_in = tokenInfo.expires_in; }
  return info;
}

function loginPayload(u, keeptime, extra = {}) {
  const t = issueToken(u.id, keeptime);
  db.update('yd_user', { logintime: now() }, 'id=?', u.id);
  const fresh = getUser(u.id);
  return { userinfo: userinfo(fresh, t), token: t.token, expires_in: t.expires_in, ...extra };
}

// 新建用户（注册/手机/邮箱/微信）
function createUser(fields, { inviteCode = '', ip = '' } = {}) {
  const reg = S.get('register');
  let parent = 0;
  if (inviteCode) {
    const p = db.get('SELECT id FROM yd_user WHERE invite_code=? AND deletetime=0', String(inviteCode).trim());
    if (p) parent = p.id;
  }
  const row = {
    username: '', nickname: '', password: '', salt: '', mobile: '', email: '', avatar: '',
    score: 0, invite_code: genInviteCode(), parent_user_id: parent, jointime: now(), joinip: ip, status: 'normal',
    ...fields,
  };
  if (row.password && !row.salt) {
    const h = hashPassword(row.password);
    row.password = h.hash;
    row.salt = h.salt;
  }
  const id = db.insert('yd_user', row);
  if (!row.nickname) db.update('yd_user', { nickname: `用户${id}` }, 'id=?', id);
  // 防机器批量注册薅点数：默认要验证过手机号才发新人赠送和邀请奖励（手机号登录注册的立即发，账号注册的绑定手机后发）
  if (!giftNeedsMobile() || row.mobile) onVerified(id, row.mobile);
  return getUser(id);
}

const giftNeedsMobile = () => S.get('register').gift_need_mobile !== false;
/** 新人赠送：每个账号一次；同一个手机号也只送一次（防换绑薅点数） */
function grantSignupGift(userId, mobile = '') {
  const gift = Number(S.get('register').gift_points || 0);
  if (gift <= 0) return;
  if (db.get(`SELECT id FROM yd_score_log WHERE user_id=? AND (ref='reg-gift' OR ref LIKE 'reg-gift:%')`, userId)) return;
  if (mobile && db.get('SELECT id FROM yd_score_log WHERE ref=?', 'reg-gift:' + mobile)) return;
  changeScore(userId, gift, 'recharge', '新用户注册赠送', mobile ? 'reg-gift:' + mobile : 'reg-gift');
}
/** 账号算「真人」了（注册时带手机号，或后来第一次绑定手机号）：发新人赠送 + 给邀请人记一次邀请 */
function onVerified(userId, mobile = '') {
  grantSignupGift(userId, mobile);
  const u = db.get('SELECT parent_user_id FROM yd_user WHERE id=?', userId);
  if (u && u.parent_user_id && !db.get('SELECT user_id FROM ct_invite_ok WHERE user_id=?', userId)) {
    db.run('INSERT OR IGNORE INTO ct_invite_ok (user_id, parent_id, createtime) VALUES (?, ?, ?)', userId, u.parent_user_id, now());
    onInvited(u.parent_user_id, userId);
  }
}

// 邀请奖励：每邀请 reward_every 个（已验证手机号的）好友奖励 reward_points
function onInvited(parentId, newUserId) {
  const inv = S.get('invite');
  const every = Math.max(1, Number(inv.reward_every || 1));
  const pts = Number(inv.reward_points || 0);
  const cnt = Number(db.val('SELECT COUNT(*) FROM ct_invite_ok WHERE parent_id=?', parentId) || 0);
  if (pts > 0 && cnt % every === 0) changeScore(parentId, pts, 'recharge', `邀请奖励（第 ${cnt} 位好友）`, `invite:${newUserId}`);
}

// 点数变动（正数增加，负数扣减）。type: recharge/consume/refund/adjust
function changeScore(userId, change, type, remark, ref = '', operatorId = 0) {
  change = Math.round(Number(change) || 0);
  if (!change) return getUser(userId);
  return db.tx(() => {
    const u = db.get('SELECT id, score FROM yd_user WHERE id=?', userId);
    if (!u) fail('用户不存在');
    const balance = u.score + change;
    if (balance < 0) fail('点数不足，请先充值', 402);
    db.run('UPDATE yd_user SET score=? WHERE id=?', balance, userId);
    db.insert('yd_score_log', { user_id: userId, type, change, balance, remark: remark || '', ref, operator_id: operatorId, createtime: now() });
    return getUser(userId);
  });
}

// 扣点（按账单用户），返回扣除数
function charge(u, points, remark, ref = '') {
  points = Math.max(0, Math.round(Number(points) || 0));
  if (!points) return 0;
  const bill = billUser(u);
  if (bill.score < points) fail(`点数不足：本次需要 ${points} 点，当前余额 ${bill.score} 点`, 402);
  changeScore(bill.id, -points, 'consume', remark, ref);
  return points;
}
function refund(billUserId, points, remark, ref = '') {
  points = Math.max(0, Math.round(Number(points) || 0));
  if (!points) return 0;
  changeScore(billUserId, points, 'refund', remark, ref);
  return points;
}

// 会员开通/续期
function grantMembership(userId, level, days) {
  const u = getUser(userId);
  if (!u || !level || !days) return u;
  const RANK = { free: 0, basic: 1, pro: 2, enterprise: 3 };
  const active = u.member_level && u.member_level !== 'free' && u.member_expiretime > now();
  const cur = active ? u.member_level : 'free';
  let newLevel = level;
  let base = now();
  if (active && (RANK[level] ?? 1) <= (RANK[cur] ?? 1)) {
    // 同级续期；买了更低等级则保留当前高等级并顺延时长
    newLevel = cur;
    base = u.member_expiretime;
  }
  db.update('yd_user', { member_level: newLevel, member_expiretime: base + days * 86400 }, 'id=?', userId);
  return getUser(userId);
}

function concurrencyOf(u) {
  const bill = billUser(u);
  if (bill.concurrency) return bill.concurrency;
  const map = S.get('member').concurrency || {};
  return Number(map[effectiveLevel(u)] || map.free || 2);
}

function publicUrl(p) {
  if (!p) return '';
  if (/^https?:\/\//i.test(p) || p.startsWith('data:')) return p;
  return config.publicBaseUrl + (p.startsWith('/') ? p : '/' + p);
}

module.exports = {
  onVerified,
  tokenKey, issueToken, userByToken, getUser, billUser, effectiveLevel, userinfo, loginPayload, createUser,
  changeScore, charge, refund, grantMembership, concurrencyOf, genInviteCode, publicUrl,
};
