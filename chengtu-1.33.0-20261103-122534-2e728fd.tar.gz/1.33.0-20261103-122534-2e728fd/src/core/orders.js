'use strict';
// 订单：创建支付、支付成功履约（会员 / 加油包）、兑换码
const db = require('./db');
const S = require('./settings');
const config = require('./config');
const users = require('./users');
const wx = require('./wechat');
const { fail } = require('./http');
const { now, orderSn, money, randomCode, fmtTime } = require('./util');

function createOrder({ user, kind, plan, title, amount, points = 0, quantity = 1, couponId = 0, discount = 0, payType, extra = {} }) {
  const sn = orderSn(kind === 'member' ? 'M' : 'R');
  db.insert('yd_order', {
    order_sn: sn, user_id: user.id, kind, plan_id: plan ? plan.id : 0, title: title || (plan && plan.title) || '', amount: money(amount),
    original_amount: money(amount + discount), discount: money(discount), coupon_id: couponId, points, quantity, pay_type: payType || 'wxpay',
    pay_status: 'pending', extra: JSON.stringify(extra), createtime: now(), updatetime: now(),
  });
  return db.get('SELECT * FROM yd_order WHERE order_sn=?', sn);
}

function orderView(o) {
  if (!o) return null;
  return {
    id: o.id, order_sn: o.order_sn, title: o.title, amount: o.amount, points: o.points, pay_type: o.pay_type,
    pay_type_text: { wxpay: '微信扫码', mppay: '微信公众号', wallet: '钱包余额', mock: '模拟支付', admin: '后台开通' }[o.pay_type] || o.pay_type,
    pay_status: o.pay_status, status: o.pay_status,
    status_text: { pending: '待支付', paid: '已支付', closed: '已关闭', refunded: '已退款' }[o.pay_status] || o.pay_status,
    pay_status_text: { pending: '待支付', paid: '已支付', closed: '已关闭', refunded: '已退款' }[o.pay_status] || o.pay_status,
    createtime: o.createtime, createtime_text: fmtTime(o.createtime), paytime: o.paytime, paytime_text: o.paytime ? fmtTime(o.paytime) : '',
    quantity: o.quantity, kind: o.kind,
  };
}

async function createPay(order, user, payType) {
  const pay = S.get('payment');
  const notifyUrl = `${config.publicBaseUrl}${config.apiPrefix}/pay/wechat/notify`;
  const desc = `${S.get('site').name}-${order.title}`;
  if (payType === 'mppay') {
    if (!pay.wechat.enabled) {
      if (pay.mock) return mockPay(order);
      fail('支付暂未开通，请联系客服');
    }
    if (!user.wechat_openid) fail('公众号支付需要先绑定微信，请在个人中心绑定微信，或使用电脑扫码支付');
    return wx.payJsapi({ orderSn: order.order_sn, description: desc, amount: order.amount, openid: user.wechat_openid, notifyUrl });
  }
  if (pay.wechat && pay.wechat.enabled) return wx.payNative({ orderSn: order.order_sn, description: desc, amount: order.amount, notifyUrl });
  if (pay.mock) return mockPay(order);
  fail('支付暂未开通，请联系客服开通');
  return null;
}
function mockPay(order) {
  return { type: 'wxpay', code_url: `${config.publicBaseUrl}${config.apiPrefix}/pay/mock?order_sn=${order.order_sn}`, mock: 1 };
}

// 主动查单（回调没到时轮询兜底）
const lastQuery = new Map();
async function syncOrder(o) {
  if (!o || o.pay_status !== 'pending') return o;
  const pay = S.get('payment');
  if (!pay.wechat || !pay.wechat.enabled || o.pay_type === 'wallet') return o;
  const t = lastQuery.get(o.order_sn) || 0;
  if (Date.now() - t < 4000) return o;
  lastQuery.set(o.order_sn, Date.now());
  try {
    const r = await wx.payQuery(o.order_sn);
    if (r.trade_state === 'SUCCESS') fulfill(o.order_sn, r.transaction_id || '');
  } catch {}
  return db.get('SELECT * FROM yd_order WHERE id=?', o.id);
}

// 支付成功履约（幂等）
function fulfill(sn, transactionId = '', payType = '') {
  return db.tx(() => {
    const o = db.get('SELECT * FROM yd_order WHERE order_sn=?', sn);
    if (!o) fail('订单不存在');
    if (o.pay_status === 'paid') return o;
    db.update('yd_order', { pay_status: 'paid', paytime: now(), transaction_id: transactionId, updatetime: now(), ...(payType ? { pay_type: payType } : {}) }, 'id=?', o.id);
    const plan = db.get('SELECT * FROM yd_plan WHERE id=?', o.plan_id);
    if (o.coupon_id) db.update('yd_user_coupon', { status: 'used', usetime: now(), order_sn: o.order_sn }, 'id=?', o.coupon_id);
    if (o.kind === 'member') {
      if (plan && plan.type !== 'pack' && (plan.days || plan.type)) {
        users.grantMembership(o.user_id, plan.level || plan.type, plan.days || 365);
      }
      if (o.points > 0) users.changeScore(o.user_id, o.points, 'recharge', `购买「${o.title}」`, `order:${o.order_sn}`);
    } else if (o.kind === 'redeem') {
      makeRedeemCodes(plan, o.quantity, o.user_id, o.order_sn);
    }
    return db.get('SELECT * FROM yd_order WHERE id=?', o.id);
  });
}

function makeRedeemCodes(plan, qty, ownerId, sn) {
  const codes = [];
  for (let i = 0; i < Math.max(1, qty); i++) {
    let code;
    do { code = randomCode(12); } while (db.get('SELECT id FROM yd_redeem_code WHERE code=?', code));
    db.insert('yd_redeem_code', {
      code, plan_id: plan ? plan.id : 0, title: plan ? plan.title : '兑换码', type: plan ? plan.type : 'pack', points: plan ? plan.points : 0,
      days: plan ? plan.days : 0, level: plan ? (plan.type === 'pack' ? '' : plan.level || plan.type) : '', owner_user_id: ownerId,
      order_sn: sn || '', status: 'unused', createtime: now(),
    });
    codes.push(code);
  }
  return codes;
}

function redeem(user, code) {
  return db.tx(() => {
    const r = db.get('SELECT * FROM yd_redeem_code WHERE code=?', String(code || '').trim().toUpperCase());
    if (!r) fail('兑换码不存在');
    if (r.status !== 'unused') fail('兑换码已被使用或已失效');
    if (r.expiretime && r.expiretime < now()) fail('兑换码已过期');
    db.update('yd_redeem_code', { status: 'used', used_user_id: user.id, usetime: now() }, 'id=?', r.id);
    if (r.level && r.days) users.grantMembership(user.id, r.level, r.days);
    if (r.points > 0) users.changeScore(user.id, r.points, 'recharge', `兑换码兑换「${r.title}」`, `redeem:${r.code}`);
    return users.getUser(user.id);
  });
}

module.exports = { createOrder, orderView, createPay, syncOrder, fulfill, makeRedeemCodes, redeem };
