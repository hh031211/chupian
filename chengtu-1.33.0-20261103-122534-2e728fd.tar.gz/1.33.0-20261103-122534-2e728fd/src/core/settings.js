'use strict';
// 站点运行配置（存数据库，后台可改）。DEFAULTS 为出厂默认值。
const { all, run } = require('./db');
const { deepMerge } = require('./config');

const DEFAULTS = {
  site: {
    name: '出片儿',
    logo: '/brand/logo.png',
    company: '',        // 运营主体（页脚版权、用户协议），留空用站点名
    icp: '',            // 备案号，香港服务器可留空
    email: '',          // 客服邮箱
    phone: '',          // 客服电话
    domain: '',         // 站点域名（留空取 config.siteUrl）
    title: '',          // 浏览器标签页标题，留空 = “出片儿 - 电商团队一站式AI作图工具”
    service_time: '周一至周日 上午 9:00-11:30，下午 13:30-18:00',
    frontend_url: '',
    mobile_scale: 0.88, // 手机整体显示比例（0.8~1，1 = 不缩小）
    thumb_width: 480,   // 列表卡片缩略图宽度（高清屏自动用 2 倍）；客户觉得糊可调大，0 = 不用缩略图
    default_avatar: '',
    maintenance: false,
  },
  legal: { about: '', terms: '', privacy: '' },   // 关于我们 / 用户协议 / 隐私政策，留空用默认模板（src/core/legal.js）
  register: {
    gift_points: 20,
    gift_need_mobile: true,   // 新人赠送 / 邀请奖励要验证过手机号才发（防机器批量注册薅点数）
    username_register: true,
    login_captcha: false,
    register_captcha: true,   // 账号注册需要图形验证码（防机器批量注册）
    password_min: 8,
    wechat_login: false,   // 微信扫码/授权登录（已从前台移除）
    email_login: false,    // 邮箱验证码登录（已从前台移除）
  },
  invite: {
    reward_points: 20,
    reward_every: 1,
  },
  relay: {
    channels: [
      { id: 'main', name: '主中转站', base_url: 'https://api.example.com', api_key: '', enabled: true, timeout: 300 },
    ],
    image_models: {
      m1: { label: '模型2.0', channel: 'main', model: 'gpt-image-1', mode: 'openai', size_strategy: 'openai', quality: 'high', extra: {} },
      m2: { label: '模型2.5', channel: 'main', model: 'gpt-image-1', mode: 'openai', size_strategy: 'openai', quality: 'high', extra: {} },
    },
    chat_model: { channel: 'main', model: 'gpt-4o-mini', temperature: 0.7, extra: {} },
    vision_model: { channel: 'main', model: 'gpt-4o', temperature: 0.4, extra: {} },
    video_models: {
      m1: { channel: 'main', model: 'sora-2', mode: 'openai-video', seconds: 8, extra: {} },
      m3: { channel: 'main', model: 'sora-2', mode: 'openai-video', seconds: 5, extra: {} },
    },
    save_remote: true,
    max_ref_images: 10,
    retry: 1,
    retry_task: 0,
    image_timeout: 300,
  },
  pricing: {
    image: { m1: { '1K': 3, '2K': 4, '4K': 5 }, m2: { '1K': 4, '2K': 5, '4K': 6 } },
    video_cost: 40,
    video_m3_cost: 5,
    matting: null,     // 抠图「自动」模式每张点数；null = 跟前端显示的模型价格一致（如 1K=3）
    matting_local: 0,  // 用户选「本地极速抠图」每张点数（0 = 免费）
    matting_ai: 3,     // 用户选「AI 精细抠图」每张点数
    matting_ai_mode: 'resolution', // AI 精细计价：resolution = 按出图模型 + 实际清晰度（同出图价）；fixed = 固定 matting_ai 点
    text: {
      outline: 0, prompt_optimize: 0, prompt_adapt: 0, prompt_reverse: 0, text_translate: 0,
    },
    refund_failed: true,
  },
  member: {
    level_names: { free: '普通用户', basic: '基础会员', pro: '高级会员', enterprise: '企业版' },
    concurrency: { free: 2, basic: 2, pro: 4, enterprise: 8 },
    generate_requires_member: true,
  },
  payment: {
    mock: false,
    wechat: {
      enabled: false, appid: '', mchid: '', serial_no: '', private_key: '', apiv3_key: '', notify_url: '', platform_cert: '',
    },
  },
  sms: {
    provider: 'none',
    aliyun: { access_key_id: '', access_key_secret: '', sign_name: '', template_code: '' },
    // 调试模式：不发短信，验证码直接返回给前端（仅限测试环境！正式环境开启等于任何人都能登录任意手机号）
    debug: false,
  },
  mail: {
    enabled: false, host: '', port: 465, secure: true, user: '', pass: '', from: '', subject: '验证码',
  },
  wechat_mp: {
    enabled: false, appid: '', secret: '', token: '', oauth_redirect_base: '',
  },
  // 图库搜图（后台素材库「从图库搜图」，只当参考生成新图）：Unsplash Access Key、Pexels API Key
  stock: { unsplash_key: '', pexels_key: '' },
  // 精准改字服务（tools/textedit/server.py，本机 Python 进程，tools/setup-textedit.sh 安装）
  textedit: { enabled: true, url: 'http://127.0.0.1:8361' },
  storage: {
    driver: 'local',
    save_jpeg: false,   // 出图存为高质量 JPG（不透明的图；分辨率不变，体积约 PNG 的 1/4）
    cos: { secret_id: '', secret_key: '', bucket: '', region: '', domain: '', prefix: 'uploads' },
  },
  matting: {
    engine: 'picwish',           // 抠图引擎：佐糖接口
    picwish_key: '',             // 佐糖 X-API-KEY（https://picwish.cn/my-account?subRoute=api-key）
    picwish_base: 'https://techsz.aoscdn.com',
    picwish_timeout: 90,         // 佐糖单张最长等待秒数
    free_daily: 10,              // 每个用户每天免费抠图张数（0 = 不免费）
    over_action: 'charge',       // 超出免费张数后：charge = 按 over_price 扣点；block = 当天不能再抠
    over_price: 3,               // 超出后每张扣点（AI 抠图、智能抠图）
    over_price_idphoto: '',      // 证件照超出后每张扣点（留空 = 同上）
    require_member: false,       // 抠图是否要求会员（默认否：所有登录用户都能用免费张数）
  },
  // 工具封面：后台替换 / AI 生成的封面 { slug: 图片地址 }，没有的用前端自带的默认图
  tool_covers: {},
  // 工具封面的出图设置（后台「工具封面」页顶部可改）
  cover_gen: { model_key: 'm2', resolution: '4K', ratio: '1:1', edit_model_key: 'm2', edit_resolution: '4K' },
  security: {
    ip_register_limit_per_day: 20,
    rate_limit: true,      // 防刷：登录爆破、短信轰炸、免费接口狂刷（只在测试环境关闭）
    sms_daily_cap: 300,    // 全站每天最多发多少条短信验证码（防短信轰炸刷光短信费），0 = 不限
    banned_words: [],      // 违禁词：提示词/描述里出现则拒绝生成
    ip_blacklist: [],      // IP 黑名单：支持完整 IP 或前缀（如 1.2.3.）
    // 人机验证：builtin = 图形验证码；aliyun = 阿里云验证码 2.0（填 prefix + 场景 ID；AccessKey 留空则用短信的）
    human: { provider: 'builtin', aliyun: { prefix: '', scene_id: '', region: 'cn', access_key_id: '', access_key_secret: '' } },
  },
};

let cache = null;

function load() {
  const rows = all('SELECT key, value FROM yd_setting');
  const stored = {};
  for (const r of rows) {
    try { stored[r.key] = JSON.parse(r.value); } catch {}
  }
  cache = deepMerge(DEFAULTS, stored);
  return cache;
}

function get(group) {
  if (!cache) load();
  return group ? cache[group] : cache;
}

function set(group, value) {
  run('INSERT INTO yd_setting (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', group, JSON.stringify(value));
  load();
}

module.exports = { DEFAULTS, get, set, load };

// ---------------- 密钥脱敏：后台读设置时只显示「已设置·末 4 位」，保存时原样提交的掩码自动换回原值 ----------------
//   这样即使后台页面被人看到 / 截图 / 只读账号，也拿不到完整的 Key
const SECRET_KEYS = new Set(['api_key', 'secret_key', 'access_key_secret', 'private_key', 'apiv3_key', 'platform_cert', 'pass', 'secret', 'token', 'picwish_key', 'unsplash_key', 'pexels_key']);
const MASK = '********';
const isMask = (v) => typeof v === 'string' && v.startsWith(MASK);
const maskOf = (v) => `${MASK}${String(v).slice(-4)}`;
function maskSecrets(v, key = '') {
  if (Array.isArray(v)) return v.map((x) => maskSecrets(x));
  if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, maskSecrets(x, k)]));
  if (SECRET_KEYS.has(key) && typeof v === 'string' && v) return maskOf(v);
  return v;
}
/** incoming 里还是掩码的字段，换回 stored 里对应的原值（数组按 id 对应，没有 id 按位置） */
function unmaskSecrets(incoming, stored, key = '') {
  if (isMask(incoming)) return SECRET_KEYS.has(key) && typeof stored === 'string' && maskOf(stored) === incoming ? stored : '';
  if (Array.isArray(incoming)) {
    const old = Array.isArray(stored) ? stored : [];
    return incoming.map((x, i) => unmaskSecrets(x, x && typeof x === 'object' && x.id != null ? old.find((o) => o && o.id === x.id) : old[i]));
  }
  if (incoming && typeof incoming === 'object') {
    const old = stored && typeof stored === 'object' ? stored : {};
    // 中转站这类「地址 + Key」：地址改了就不能沿用旧 Key（防止把真 Key 发到别人填的地址）
    const moved = old.base_url !== undefined && incoming.base_url !== undefined && String(old.base_url) !== String(incoming.base_url);
    return Object.fromEntries(Object.entries(incoming).map(([k, x]) => [k, moved && isMask(x) ? '' : unmaskSecrets(x, old[k], k)]));
  }
  return incoming;
}
module.exports.maskSecrets = maskSecrets;
module.exports.unmaskSecrets = unmaskSecrets;
module.exports.isMask = isMask;
