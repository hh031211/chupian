'use strict';
// 微信：公众号（扫码关注登录 / 网页授权）+ 微信支付 V3（Native 扫码 / JSAPI 公众号内）
const crypto = require('node:crypto');
const S = require('./settings');
const { randomHex } = require('./util');

// ---------------- 公众号 ----------------
let tokenCache = { token: '', exp: 0 };
async function mpAccessToken() {
  const c = S.get('wechat_mp');
  if (!c.appid || !c.secret) throw new Error('未配置公众号 AppID/Secret');
  if (tokenCache.token && tokenCache.exp > Date.now() && tokenCache.appid === c.appid) return tokenCache.token;
  const r = await fetch(`https://api.weixin.qq.com/cgi-bin/stable_token`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ grant_type: 'client_credential', appid: c.appid, secret: c.secret }),
  });
  const j = await r.json();
  if (!j.access_token) throw new Error('获取公众号 access_token 失败：' + (j.errmsg || JSON.stringify(j)));
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in - 300) * 1000, appid: c.appid };
  return j.access_token;
}

async function mpCreateQrcode(sceneStr, expire = 600) {
  const at = await mpAccessToken();
  const r = await fetch(`https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=${at}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ expire_seconds: expire, action_name: 'QR_STR_SCENE', action_info: { scene: { scene_str: sceneStr } } }),
  });
  const j = await r.json();
  if (!j.ticket) throw new Error('生成公众号二维码失败：' + (j.errmsg || JSON.stringify(j)));
  return `https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=${encodeURIComponent(j.ticket)}`;
}

async function mpUserInfo(openid) {
  try {
    const at = await mpAccessToken();
    const r = await fetch(`https://api.weixin.qq.com/cgi-bin/user/info?access_token=${at}&openid=${openid}&lang=zh_CN`);
    return await r.json();
  } catch { return {}; }
}

function mpCheckSignature({ signature, timestamp, nonce }) {
  const token = S.get('wechat_mp').token || '';
  const s = [token, timestamp, nonce].sort().join('');
  return crypto.createHash('sha1').update(s).digest('hex') === signature;
}

function parseXml(xml) {
  const out = {};
  const re = /<(\w+)>(?:<!\[CDATA\[([\s\S]*?)\]\]>|([^<]*))<\/\1>/g;
  let m;
  while ((m = re.exec(xml))) out[m[1]] = m[2] != null ? m[2] : m[3];
  return out;
}

function mpReplyText(to, from, content) {
  return `<xml><ToUserName><![CDATA[${to}]]></ToUserName><FromUserName><![CDATA[${from}]]></FromUserName><CreateTime>${Math.floor(Date.now() / 1000)}</CreateTime><MsgType><![CDATA[text]]></MsgType><Content><![CDATA[${content}]]></Content></xml>`;
}

function oauthUrl(redirectUri, state) {
  const c = S.get('wechat_mp');
  return `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${c.appid}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=snsapi_userinfo&state=${state}#wechat_redirect`;
}

async function oauthExchange(code) {
  const c = S.get('wechat_mp');
  const r = await fetch(`https://api.weixin.qq.com/sns/oauth2/access_token?appid=${c.appid}&secret=${c.secret}&code=${code}&grant_type=authorization_code`);
  const j = await r.json();
  if (!j.openid) throw new Error('微信授权失败：' + (j.errmsg || ''));
  let info = {};
  try {
    const r2 = await fetch(`https://api.weixin.qq.com/sns/userinfo?access_token=${j.access_token}&openid=${j.openid}&lang=zh_CN`);
    info = await r2.json();
  } catch {}
  return { openid: j.openid, unionid: j.unionid || info.unionid || '', nickname: info.nickname || '', avatar: info.headimgurl || '' };
}

// ---------------- 微信支付 V3 ----------------
function payCfg() {
  const c = S.get('payment').wechat || {};
  if (!c.enabled || !c.mchid || !c.private_key || !c.serial_no) throw new Error('微信支付未配置');
  return c;
}
function payAuth(method, urlPath, body, c) {
  const ts = Math.floor(Date.now() / 1000).toString();
  const nonce = randomHex(16);
  const msg = `${method}\n${urlPath}\n${ts}\n${nonce}\n${body}\n`;
  const sig = crypto.createSign('RSA-SHA256').update(msg).sign(c.private_key, 'base64');
  return `WECHATPAY2-SHA256-RSA2048 mchid="${c.mchid}",nonce_str="${nonce}",signature="${sig}",timestamp="${ts}",serial_no="${c.serial_no}"`;
}
async function payRequest(method, urlPath, payload) {
  const c = payCfg();
  const body = payload ? JSON.stringify(payload) : '';
  const r = await fetch('https://api.mch.weixin.qq.com' + urlPath, {
    method,
    headers: { Authorization: payAuth(method, urlPath, body, c), 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': 'yuduo-server' },
    body: body || undefined,
  });
  const text = await r.text();
  let j = {};
  try { j = text ? JSON.parse(text) : {}; } catch {}
  if (r.status >= 300) throw new Error('微信支付接口错误：' + (j.message || text || r.status));
  return j;
}

async function payNative({ orderSn, description, amount, notifyUrl }) {
  const c = payCfg();
  const j = await payRequest('POST', '/v3/pay/transactions/native', {
    appid: c.appid, mchid: c.mchid, description: description.slice(0, 120), out_trade_no: orderSn,
    notify_url: c.notify_url || notifyUrl, amount: { total: Math.round(amount * 100), currency: 'CNY' },
  });
  return { type: 'wxpay', code_url: j.code_url };
}

async function payJsapi({ orderSn, description, amount, openid, notifyUrl }) {
  const c = payCfg();
  const j = await payRequest('POST', '/v3/pay/transactions/jsapi', {
    appid: c.appid, mchid: c.mchid, description: description.slice(0, 120), out_trade_no: orderSn,
    notify_url: c.notify_url || notifyUrl, amount: { total: Math.round(amount * 100), currency: 'CNY' }, payer: { openid },
  });
  const ts = Math.floor(Date.now() / 1000).toString();
  const nonce = randomHex(16);
  const pkg = `prepay_id=${j.prepay_id}`;
  const paySign = crypto.createSign('RSA-SHA256').update(`${c.appid}\n${ts}\n${nonce}\n${pkg}\n`).sign(c.private_key, 'base64');
  return { type: 'mppay', jsapi: { appId: c.appid, timeStamp: ts, nonceStr: nonce, package: pkg, signType: 'RSA', paySign } };
}

async function payQuery(orderSn) {
  const c = payCfg();
  return payRequest('GET', `/v3/pay/transactions/out-trade-no/${orderSn}?mchid=${c.mchid}`);
}

// 回调解密（AES-256-GCM，APIv3 密钥）。能成功解密即证明来源可信。
function payDecrypt(resource) {
  const c = payCfg();
  const key = Buffer.from(c.apiv3_key, 'utf8');
  const data = Buffer.from(resource.ciphertext, 'base64');
  const tag = data.slice(data.length - 16);
  const enc = data.slice(0, data.length - 16);
  const d = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(resource.nonce, 'utf8'));
  d.setAuthTag(tag);
  if (resource.associated_data) d.setAAD(Buffer.from(resource.associated_data, 'utf8'));
  return JSON.parse(Buffer.concat([d.update(enc), d.final()]).toString('utf8'));
}

module.exports = {
  mpAccessToken, mpCreateQrcode, mpUserInfo, mpCheckSignature, parseXml, mpReplyText, oauthUrl, oauthExchange,
  payNative, payJsapi, payQuery, payDecrypt,
};
