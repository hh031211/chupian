'use strict';
// 图形验证码（零依赖）：服务器直接画成 PNG 位图
//   以前是 SVG，字符以 <text> 明文写在图里，脚本解码一下就能读出答案；现在每个字符都是随机变形的笔画像素，
//   再叠加干扰曲线、噪点和整体波浪扭曲，图里不再含任何可直接读取的文字
//   另外：答案过期 5 分钟、只能试一次（错了必须换图）、生成后 1 秒内就提交的视为机器
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const db = require('./db');
const { now, randomHex } = require('./util');

const CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const rnd = (a, b) => a + (crypto.randomInt(0, 1000000) / 1000000) * (b - a);
const ri = (a, b) => a + crypto.randomInt(0, Math.max(1, b - a));

// 笔画字形：每个字符是若干条折线，坐标范围 x 0~10、y 0~14
const P = (s) => s.split(' ').map((seg) => seg.split(';').map((pt) => pt.split(',').map(Number)));
const GLYPH = {
  A: P('0,14;5,0;10,14 2,9;8,9'), B: P('0,0;0,14 0,0;6,0;9,2;9,5;6,7;0,7 6,7;9,9;9,12;6,14;0,14'),
  C: P('10,2;7,0;3,0;0,3;0,11;3,14;7,14;10,12'), D: P('0,0;0,14;6,14;10,10;10,4;6,0;0,0'),
  E: P('10,0;0,0;0,14;10,14 0,7;7,7'), F: P('10,0;0,0;0,14 0,7;7,7'),
  G: P('10,2;7,0;3,0;0,3;0,11;3,14;7,14;10,11;10,8;6,8'), H: P('0,0;0,14 10,0;10,14 0,7;10,7'),
  J: P('10,0;10,11;7,14;3,14;0,11'), K: P('0,0;0,14 10,0;0,8 3,6;10,14'), L: P('0,0;0,14;10,14'),
  M: P('0,14;0,0;5,8;10,0;10,14'), N: P('0,14;0,0;10,14;10,0'), P: P('0,14;0,0;7,0;10,2;10,5;7,7;0,7'),
  Q: P('3,0;7,0;10,3;10,11;7,14;3,14;0,11;0,3;3,0 6,10;10,15'), R: P('0,14;0,0;7,0;10,2;10,5;7,7;0,7 5,7;10,14'),
  S: P('10,2;7,0;3,0;0,2;0,5;3,7;7,7;10,9;10,12;7,14;3,14;0,12'), T: P('0,0;10,0 5,0;5,14'),
  U: P('0,0;0,11;3,14;7,14;10,11;10,0'), V: P('0,0;5,14;10,0'), W: P('0,0;2,14;5,5;8,14;10,0'),
  X: P('0,0;10,14 10,0;0,14'), Y: P('0,0;5,7;10,0 5,7;5,14'), Z: P('0,0;10,0;0,14;10,14'),
  2: P('0,3;3,0;7,0;10,3;10,5;0,14;10,14'), 3: P('0,1;3,0;7,0;10,2;10,5;7,7;4,7 7,7;10,9;10,12;7,14;3,14;0,13'),
  4: P('8,14;8,0;0,10;10,10'), 5: P('10,0;1,0;0,6;6,6;10,8;10,12;7,14;3,14;0,12'),
  6: P('9,1;6,0;3,0;0,4;0,11;3,14;7,14;10,11;10,8;7,6;3,6;0,8'), 7: P('0,0;10,0;4,14'),
  8: P('3,7;0,5;0,2;3,0;7,0;10,2;10,5;7,7;3,7;0,9;0,12;3,14;7,14;10,12;10,9;7,7'),
  9: P('10,6;7,8;3,8;0,6;0,3;3,0;7,0;10,3;10,10;7,14;3,14;1,13'),
};

const W = 208, H = 80;

/** 在 RGB 缓冲区上画一条有宽度的线段（按到线段的距离做抗锯齿） */
function seg(buf, x1, y1, x2, y2, w, [r, g, b]) {
  const minX = Math.max(0, Math.floor(Math.min(x1, x2) - w)), maxX = Math.min(W - 1, Math.ceil(Math.max(x1, x2) + w));
  const minY = Math.max(0, Math.floor(Math.min(y1, y2) - w)), maxY = Math.min(H - 1, Math.ceil(Math.max(y1, y2) + w));
  const dx = x2 - x1, dy = y2 - y1, L2 = dx * dx + dy * dy || 1;
  for (let y = minY; y <= maxY; y++) {
    for (let x = minX; x <= maxX; x++) {
      const t = Math.max(0, Math.min(1, ((x - x1) * dx + (y - y1) * dy) / L2));
      const d = Math.hypot(x - (x1 + t * dx), y - (y1 + t * dy));
      const a = Math.max(0, Math.min(1, w / 2 - d + 0.5));
      if (!a) continue;
      const i = (y * W + x) * 3;
      buf[i] += (r - buf[i]) * a; buf[i + 1] += (g - buf[i + 1]) * a; buf[i + 2] += (b - buf[i + 2]) * a;
    }
  }
}
const hsl = (h, s, l) => {
  const k = (n) => (n + h / 30) % 12; const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [f(0) * 255, f(8) * 255, f(4) * 255];
};

function draw(code) {
  const src = new Float32Array(W * H * 3);
  const h0 = rnd(0, 360);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {   // 淡色渐变底
    const c = hsl((h0 + x * 0.2) % 360, 0.35, 0.94 - y * 0.0004);
    src.set(c, (y * W + x) * 3);
  }
  for (let i = 0; i < 90; i++) { const c = hsl(rnd(0, 360), 0.4, rnd(0.45, 0.75)); seg(src, rnd(0, W), rnd(0, H), rnd(0, W), rnd(0, H), 0, c); const x = ri(0, W), y = ri(0, H); src.set(c, (y * W + x) * 3); }
  const colors = [];
  [...code].forEach((ch, i) => {
    const col = hsl(rnd(200, 340), rnd(0.5, 0.75), rnd(0.25, 0.38)); colors.push(col);
    const sx = rnd(2.9, 3.6), sy = rnd(3.2, 3.7), rot = rnd(-0.35, 0.35), sh = rnd(-0.22, 0.22);
    const ox = 16 + i * 46 + rnd(-4, 4), oy = 14 + rnd(-4, 4);
    const cx = 5, cy = 7; const cos = Math.cos(rot), sin = Math.sin(rot);
    const tf = ([x, y]) => { const u = (x - cx) * sx + (y - cy) * sh * sx, v = (y - cy) * sy; return [ox + 5 * sx + u * cos - v * sin, oy + 7 * sy + u * sin + v * cos]; };
    const wdt = rnd(4.2, 5.8);
    for (const line of GLYPH[ch]) for (let k = 1; k < line.length; k++) { const [a, b] = [tf(line[k - 1]), tf(line[k])]; seg(src, a[0], a[1], b[0], b[1], wdt, col); }
  });
  // 穿过字符的干扰曲线（用字符同色，防止按颜色把字抠出来）
  for (let n = 0; n < 3; n++) {
    const col = colors[n % colors.length]; const w = rnd(2, 3.2);
    const p0 = [rnd(-10, 30), rnd(10, H - 10)], p1 = [rnd(50, 160), rnd(-25, H + 25)], p2 = [rnd(W - 30, W + 10), rnd(10, H - 10)];
    let prev = p0;
    for (let t = 0.04; t <= 1.0001; t += 0.04) {
      const q = [(1 - t) * (1 - t) * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0], (1 - t) * (1 - t) * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]];
      seg(src, prev[0], prev[1], q[0], q[1], w, col); prev = q;
    }
  }
  // 整体波浪扭曲
  const out = Buffer.alloc((W * 3 + 1) * H);
  const ax = rnd(2.5, 4.5), px = rnd(14, 24), ph = rnd(0, 6.28), ay = rnd(1.5, 3), py = rnd(24, 40);
  for (let y = 0; y < H; y++) {
    out[y * (W * 3 + 1)] = 0;
    for (let x = 0; x < W; x++) {
      const sxp = Math.round(x + ax * Math.sin(y / px + ph)), syp = Math.round(y + ay * Math.sin(x / py));
      const xx = Math.max(0, Math.min(W - 1, sxp)), yy = Math.max(0, Math.min(H - 1, syp));
      const si = (yy * W + xx) * 3, di = y * (W * 3 + 1) + 1 + x * 3;
      out[di] = src[si]; out[di + 1] = src[si + 1]; out[di + 2] = src[si + 2];
    }
  }
  return png(out);
}

// ---- 极简 PNG 编码（RGB 8 位） ----
const CRC = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; return c; });
function crc32(buf) { let c = -1; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(raw) {
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

const TTL = 300;
function create() {
  let code = '';
  for (let i = 0; i < 4; i++) code += CHARS[crypto.randomInt(0, CHARS.length)];
  const key = randomHex(12);
  db.insert('yd_captcha', { key, code, expiretime: now() + TTL });
  db.run('DELETE FROM yd_captcha WHERE expiretime < ?', now());
  const out = { key, image: 'data:image/png;base64,' + draw(code).toString('base64'), expire: TTL };
  // 只有测试沙箱 / 发布演练会设置这个环境变量，正式环境永远不会返回答案
  if (process.env.CT_CAPTCHA_DEBUG === '1') out.debug_code = code;
  return out;
}

function verify(key, input, consume = true) {
  if (!key || !input) return false;
  const row = db.get('SELECT * FROM yd_captcha WHERE key=?', String(key));
  if (!row || row.expiretime < now()) return false;
  if (consume) db.run('DELETE FROM yd_captcha WHERE key=?', String(key));   // 无论对错只能试一次
  // 看图、输入 4 个字至少要一两秒；生成后 1 秒内就交上来的是程序（测试沙箱除外）
  if (process.env.CT_CAPTCHA_DEBUG !== '1' && now() - (row.expiretime - TTL) < 1) return false;
  const okv = row.code.toUpperCase() === String(input).trim().toUpperCase();
  if (!consume && okv) db.run('DELETE FROM yd_captcha WHERE key=?', String(key));
  return okv;
}

module.exports = { create, verify, _draw: draw };
