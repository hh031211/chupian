'use strict';
// 首次启动初始化：管理员、默认套餐、公告
const db = require('./db');
const config = require('./config');
const { now, hashPassword } = require('./util');

function seed() {
  if (!db.get('SELECT id FROM yd_admin LIMIT 1')) {
    const a = config.admin || {};
    const h = hashPassword(a.initPassword || 'admin123456');
    db.insert('yd_admin', { username: a.initUsername || 'admin', password: h.hash, salt: h.salt, createtime: now() });
    console.log(`[seed] 已创建管理员账号：${a.initUsername || 'admin'} / ${a.initPassword || 'admin123456'}（请登录后台立即修改密码）`);
  }
  if (!db.get('SELECT id FROM yd_plan LIMIT 1')) {
    const t = now();
    const plans = [
      ['basic', '月度会员', '', 39, 59, 300, 30, 'basic', '适合轻度使用', 0, 29, 1],
      ['basic', '季度会员', '热卖', 99, 177, 1000, 90, 'basic', '平均每月 33 元', 1, 79, 2],
      ['basic', '年度会员', '最划算', 299, 708, 4500, 365, 'basic', '赠送点数最多', 0, 239, 3],
      ['enterprise', '企业版·季度', '', 699, 999, 6000, 90, 'enterprise', '高并发出图，点数更多', 0, 559, 1],
      ['enterprise', '企业版·年度', '推荐', 1999, 3996, 30000, 365, 'enterprise', '企业级管理和数据查看', 1, 1599, 2],
      ['pack', '加油包 200 点', '', 29, 39, 200, 0, '', '永久有效', 0, 23, 1],
      ['pack', '加油包 800 点', '超值', 99, 156, 800, 0, '', '永久有效', 1, 79, 2],
      ['pack', '加油包 2000 点', '', 229, 390, 2000, 0, '', '永久有效', 0, 183, 3],
    ];
    for (const [type, title, tag, price, op, points, days, level, note, hl, agent, sort] of plans) {
      db.insert('yd_plan', { type, title, tag, price, original_price: op, points, days, level, note, highlight: hl, agent_price: agent, redeemable: 1, sort, status: 'normal', createtime: t });
    }
  }
  // 子账号功能已下线：老库里企业版套餐说明不再提子账号
  db.run(`UPDATE yd_plan SET note='高并发出图，点数更多' WHERE note LIKE '%子账号%'`);
  if (!db.get('SELECT id FROM yd_notice LIMIT 1')) {
    db.insert('yd_notice', { type: 'notice', title: '欢迎使用', content: '新用户注册即送体验点数。\n遇到问题可在「个人中心 - 意见反馈」联系我们。', time: new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 16).replace('T', ' '), status: 'normal', createtime: now() });
  }
}

module.exports = { seed };
