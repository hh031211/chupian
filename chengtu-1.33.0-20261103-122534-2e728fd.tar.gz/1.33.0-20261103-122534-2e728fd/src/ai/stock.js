'use strict';
// 免费可商用图库搜索（后台素材库用）：Unsplash、Pexels
//   只在后台当参考：选中的图 → 识图写提示词 → 存为「参考素材」（前台不显示）→ 生成同类 / AI 改图出全新的图
//   Key 在后台「素材库 → 从图库搜图」里填（settings.stock）
const S = require('../core/settings');

const str = (v) => (v == null ? '' : String(v).trim());
async function getJson(url, headers) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const res = await fetch(url, { headers, signal: ctl.signal });
    const j = await res.json().catch(() => ({}));
    if (res.status === 401 || res.status === 403) throw new Error('图库 Key 无效或没有权限，请检查后重新填写');
    if (res.status === 429) throw new Error('图库接口调用太频繁（免费额度每小时有限），稍后再试');
    if (!res.ok) throw new Error(`图库接口错误 HTTP ${res.status}`);
    return j;
  } finally { clearTimeout(t); }
}

const SOURCES = {
  unsplash: {
    name: 'Unsplash',
    key: () => str((S.get('stock') || {}).unsplash_key),
    async search(q, page, key) {
      const j = await getJson(`https://api.unsplash.com/search/photos?query=${encodeURIComponent(q)}&page=${page}&per_page=30&content_filter=high`, { Authorization: `Client-ID ${key}`, 'Accept-Version': 'v1' });
      return {
        total: Number(j.total) || 0,
        items: (j.results || []).map((x) => ({
          source: 'unsplash', id: String(x.id), thumb: x.urls && x.urls.small, full: x.urls && x.urls.regular, width: x.width, height: x.height,
          title: str(x.alt_description || x.description).slice(0, 40), author: x.user ? str(x.user.name) : '', link: x.links ? x.links.html : '',
          track: x.links ? x.links.download_location : '',
        })).filter((x) => x.thumb && x.full),
      };
    },
  },
  pexels: {
    name: 'Pexels',
    key: () => str((S.get('stock') || {}).pexels_key),
    async search(q, page, key) {
      const j = await getJson(`https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&page=${page}&per_page=30`, { Authorization: key });
      return {
        total: Number(j.total_results) || 0,
        items: (j.photos || []).map((x) => ({
          source: 'pexels', id: String(x.id), thumb: x.src && (x.src.medium || x.src.small), full: x.src && (x.src.large2x || x.src.large), width: x.width, height: x.height,
          title: str(x.alt).slice(0, 40), author: str(x.photographer), link: str(x.url), track: '',
        })).filter((x) => x.thumb && x.full),
      };
    },
  },
};

async function search(source, q, page = 1) {
  const s = SOURCES[source];
  if (!s) throw new Error('未知图库');
  const key = s.key();
  if (!key) return { need_key: true, items: [], total: 0 };
  const kw = str(q).slice(0, 60);
  if (!kw) throw new Error('请输入关键词');
  const r = await s.search(kw, Math.max(1, Math.min(100, parseInt(page, 10) || 1)), key);
  return { ...r, need_key: false };
}

/** Unsplash 要求：使用（下载）图片时上报一次 download_location */
function track(item) {
  if (!item || item.source !== 'unsplash' || !/^https:\/\/api\.unsplash\.com\//.test(str(item.track))) return;
  const key = SOURCES.unsplash.key();
  if (key) fetch(item.track, { headers: { Authorization: `Client-ID ${key}` } }).catch(() => {});
}

module.exports = { search, track, SOURCES };
