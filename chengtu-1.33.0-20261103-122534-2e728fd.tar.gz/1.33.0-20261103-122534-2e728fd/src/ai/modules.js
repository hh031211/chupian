'use strict';
// 功能模块注册表：前端 scene ↔ 后端控制器（如 change_bg ↔ product.changebg），板块、名称、描述
const MAP = require('./module_map.json');
const META = require('./scene_meta.json');

const SCENE_MODULES = MAP.scene_modules; // scene -> module
const PRO_MODULES = MAP.pro_modules; // pro tool -> module
const MODULE_SCENE = {};
for (const [scene, mod] of Object.entries(SCENE_MODULES)) if (!MODULE_SCENE[mod]) MODULE_SCENE[mod] = scene;
for (const [scene, mod] of Object.entries(PRO_MODULES)) MODULE_SCENE[mod] = scene + '_pro';

// 前端没有放进 Cc 映射、但单独调用的控制器
const EXTRA = {
  'product.productmain': 'product_main',
  'product.detailpage': 'detail_page',
  'product.sku': 'sku',
  'product.hostbatch': 'product_main',
  'batch.image': 'batch',
  'model.exclusive': 'exclusive_model',
};
for (const [m, s] of Object.entries(EXTRA)) if (!MODULE_SCENE[m]) MODULE_SCENE[m] = s;

const BOARDS = ['product', 'video', 'model', 'pod', 'derive', 'crossborder', 'marketing', 'design', 'material', 'toolbox', 'batch'];

// 一张输入图出一组结果（多图上传时逐张处理）
const PER_IMAGE = new Set([
  'toolbox.cutout', 'toolbox.upscale', 'toolbox.removewatermark', 'toolbox.losslessresize', 'toolbox.limbfix', 'toolbox.clothesfix',
  'toolbox.shoesfix', 'pod.smartcutout', 'toolbox.cutoutpro', 'toolbox.upscalepro', 'toolbox.watermarkpro', 'toolbox.eliminatepro',
  'toolbox.outpaintpro', 'model.modeldeai', 'product.wrinkleremove', 'product.fabricrestore', 'product.coveredit',
  'product.productretouchpro', 'product.productlightstudio',
]);

// 各模块默认任务说明（前端已经拼好了大部分 guidance，这里是兜底/补充）
const DEFAULT_TASK = {
  product: '你是资深电商摄影与修图师。请基于提供的商品图完成以下电商出图任务，严格保持商品本体（形状、结构、颜色、材质、图案、文字、logo）与原图一致，不得改款、不得增删部件。',
  model: '你是资深服装电商模特摄影师。请完成以下模特图任务：服装款式、颜色、图案、面料细节必须与提供的服装图完全一致；人物自然真实、比例正确、手脚完整。',
  marketing: '你是资深电商视觉设计师。请完成以下营销设计任务，画面构图专业、文字排版清晰易读（文字使用指定语言，不要出现乱码），商品保持原貌。',
  material: '你是电商详情页设计师。请完成以下素材设计任务，信息层级清晰，排版规整，商品保持原貌。',
  toolbox: '你是专业图像处理师。请按要求精确处理图片，未要求修改的部分保持不变。',
  pod: '你是 POD（按需印刷）设计师。请完成以下印花/图案相关任务，图案清晰、边缘干净、适合印刷。',
  derive: '你是服装设计师。请完成以下款式衍生/改款任务，输出真实可生产的服装款式图。',
  crossborder: '你是跨境电商视觉专家。请完成以下面向海外平台的出图任务，符合目标平台规范，文案使用目标语言。',
  video: '生成一段电商短视频。',
  design: '你是平面设计师。请完成以下设计任务，版式专业、文字清晰。',
  batch: '你是资深电商视觉设计师。请完成以下批量出图任务，保持商品原貌。',
};

function sceneOfModule(module) {
  if (MODULE_SCENE[module]) return MODULE_SCENE[module];
  const part = String(module).split('.')[1] || module;
  return part;
}

function metaOf(scene) {
  const s = String(scene || '').replace(/-/g, '_');
  return META[s] || META[s.replace(/_pro$/, '')] || null;
}

function resolve(module, params = {}) {
  const mod = String(module || '').trim();
  const [boardRaw] = mod.split('.');
  const board = BOARDS.includes(boardRaw) ? boardRaw : 'product';
  let scene = sceneOfModule(mod);
  if (mod === 'batch.image' && params.scene) scene = String(params.scene);
  const meta = metaOf(scene) || {};
  const SPECIAL = { sku: '商品SKU图', batch: '批量出图', exclusive_model: '专属模特', product_main: '商品套图', detail_page: '电商详情页' };
  if (!meta.name && SPECIAL[scene]) meta.name = SPECIAL[scene];
  if (mod === 'batch.image') meta.name = '批量出图';
  const isVideo = board === 'video';
  return {
    module: mod,
    board,
    scene,
    sceneName: meta.name || scene,
    desc: meta.desc || '',
    kind: isVideo ? 'video' : 'image',
    perImage: PER_IMAGE.has(mod),
    defaultTask: DEFAULT_TASK[board] || DEFAULT_TASK.product,
  };
}

function isKnownModule(mod) {
  if (!/^[a-z]+\.[a-z0-9_]+$/i.test(mod)) return false;
  const b = mod.split('.')[0];
  return BOARDS.includes(b) || ['ecom', 'material'].includes(b);
}

function sceneName(scene) { const m = metaOf(scene); return (m && m.name) || scene; }

const BOARD_NAMES = { product: '商品图', model: '模特图', marketing: '营销图', material: '物料设计', toolbox: '图片工具', pod: '图片 POD', derive: '款式衍生', crossborder: '跨境电商', design: '平面设计', video: '视频', batch: '批量出图' };
/** 后台「功能 → 模型」用：全部前台功能按板块分组 */
function listFeatures() {
  const groups = {};
  for (const mod of Object.keys(MODULE_SCENE)) {
    if (!ENABLED.has(mod)) continue;
    const info = resolve(mod);
    if (!groups[info.board]) groups[info.board] = { board: info.board, name: BOARD_NAMES[info.board] || info.board, kind: info.kind, items: [] };
    groups[info.board].items.push({ key: mod, name: info.sceneName, desc: info.desc || '' });
  }
  const order = ['product', 'model', 'marketing', 'material', 'toolbox', 'pod', 'derive', 'crossborder', 'design', 'batch', 'video'];
  return order.filter((b) => groups[b]).map((b) => groups[b]);
}

// 站点保留的功能（其余已下线，接口直接拒绝）：模特换装、AI 抠图、商品换背景、商品套图、证件照、商品图合成 / 主图拼图、图生视频（首页）
const ENABLED = new Set(['model.humantryon', 'toolbox.cutout', 'product.changebg', 'product.productmain', 'toolbox.idphoto', 'product.composite', 'product.maincollage', 'video.imagetovideo']);

module.exports = { ENABLED, listFeatures, BOARD_NAMES, sceneOfModule, SCENE_MODULES, PRO_MODULES, MODULE_SCENE, BOARDS, resolve, isKnownModule, sceneName, metaOf };
