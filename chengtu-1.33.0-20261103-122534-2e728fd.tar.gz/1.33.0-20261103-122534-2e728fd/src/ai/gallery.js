'use strict';
// 素材库（官方素材）：后台三种来源
//   1. 批量生成：填主题 + 数量 → 文本模型想出不重复的画面（标题 / 分类 / 提示词）→ 生图模型逐张出图 → 待审核，站长挑好的上架
//   2. 上传识图：站长上传图片 → 识图模型写出提示词、标题，按需自动归类 → 直接上架
//   3. 识图生成同类：在 2 的基础上，再按这张图想出 N 个同类画面并出图 → 待审核
//   4. 图库参考：后台搜 Unsplash / Pexels，选中的图识图后存为「参考素材」（状态 ref，前台不显示）
//      → 选中后「AI 改图」（以原图为参考按要求重画）或「生成同类」（按提示词想新画面，全新出图）→ 待审核
// 前台素材库只展示已上架的；每一张都带提示词，可「一键同款」
const db = require('../core/db');
const storage = require('../core/storage');
const engine = require('./engine');
const llm = require('./llm');
const { runWithFeature } = require('./relay');
const { now, jsonParse } = require('../core/util');

const str = (v, n = 0) => { const s = v == null ? '' : String(v).trim(); return n ? s.slice(0, n) : s; };
const DEFAULT_CATS = ['商品主图', '场景图', '模特穿搭', '营销海报', '节日活动', '小红书风格', '美妆个护', '食品饮料', '家居生活', '数码电器'];

function seedCats() {
  if (db.get('SELECT id FROM yd_gallery_cat LIMIT 1')) return;
  DEFAULT_CATS.forEach((name, i) => db.insert('yd_gallery_cat', { name, sort: i, createtime: now() }));
}
const cats = () => db.all('SELECT * FROM yd_gallery_cat ORDER BY sort, id');
/** 分类名 → id；没有就新建（识图给出的新分类） */
function catIdOf(name, create = true) {
  const n = str(name, 20);
  if (!n) return 0;
  const c = db.get('SELECT id FROM yd_gallery_cat WHERE name=?', n);
  if (c) return c.id;
  if (!create) return 0;
  return db.insert('yd_gallery_cat', { name: n, sort: 100 + (db.val('SELECT COUNT(*) FROM yd_gallery_cat') || 0), createtime: now() });
}
const ratioOf = (w, h) => {
  if (!w || !h) return '';
  const r = w / h;
  const STD = [['1:1', 1], ['3:4', 0.75], ['4:3', 1.333], ['2:3', 0.667], ['3:2', 1.5], ['9:16', 0.5625], ['16:9', 1.778], ['4:5', 0.8], ['5:4', 1.25], ['21:9', 2.333], ['1:2', 0.5]];
  return STD.reduce((a, b) => (Math.abs(b[1] - r) < Math.abs(a[1] - r) ? b : a))[0];
};

function itemView(g, catMap) {
  const c = catMap ? catMap.get(g.cat_id) : db.get('SELECT name FROM yd_gallery_cat WHERE id=?', g.cat_id);
  return {
    id: g.id, title: g.title, image: g.image, prompt: g.prompt, ratio: g.ratio || ratioOf(g.width, g.height) || '3:4', width: g.width, height: g.height,
    cat_id: g.cat_id, category: c ? c.name : '', tags: jsonParse(g.tags, []), status: g.status, source: g.source, hot: g.hot, job_id: g.job_id,
    createtime: g.createtime,
  };
}

function addItem({ title, image, width = 0, height = 0, prompt, catId = 0, tags = [], status = 'draft', source = '', jobId = 0 }) {
  return db.insert('yd_gallery', {
    title: str(title, 40) || '素材', image, width, height, ratio: ratioOf(width, height), prompt: str(prompt, 4000), cat_id: catId || 0,
    tags: JSON.stringify(tags || []), status, source, job_id: jobId, hot: 0, sort: 0, createtime: now(), updatetime: now(),
  });
}

// ---------------- 后台任务（进程内排队，同时最多跑 2 张图） ----------------
const RUNNING = new Set();
function newJob(kind, title, params, total) {
  return db.insert('yd_gallery_job', { kind, title: str(title, 80), params: JSON.stringify(params || {}), total, done: 0, failed: 0, status: 'running', error: '', createtime: now(), updatetime: now() });
}
function jobTick(id, { done = 0, failed = 0, total, error } = {}) {
  db.run('UPDATE yd_gallery_job SET done=done+?, failed=failed+?, updatetime=? WHERE id=?', done, failed, now(), id);
  if (total !== undefined) db.update('yd_gallery_job', { total }, 'id=?', id);
  if (error) db.update('yd_gallery_job', { error: str(error, 300) }, 'id=?', id);
}
function jobEnd(id, error = '') {
  const j = db.get('SELECT * FROM yd_gallery_job WHERE id=?', id);
  const status = error ? 'failed' : j && j.failed && !j.done ? 'failed' : 'done';
  db.update('yd_gallery_job', { status, updatetime: now(), ...(error ? { error: str(error, 300) } : {}) }, 'id=?', id);
  RUNNING.delete(id);
}
async function pool(list, n, fn) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, list.length) }, async () => { while (i < list.length) { const k = i++; await fn(list[k], k); } }));
}

async function drawOne(idea, o) {
  const outs = await runWithFeature({ module: 'gallery', kind: 'gallery' }, () => engine.relay().image({
    ...(String(o.model_key || '').startsWith('ref:') ? { modelRef: String(o.model_key).slice(4) } : { modelKey: o.model_key || 'm1' }), prompt: idea.drawPrompt || idea.prompt, ratio: o.ratio || '3:4', resolution: o.resolution || '2K', n: 1,
    images: idea.refs && idea.refs.length ? idea.refs : o.refs && o.refs.length ? o.refs : undefined,
  }));
  let out = outs[0];
  if (!out) throw new Error('模型没有返回图片');
  if (!out.buffer && out.url) out = await storage.fetchBuffer(out.url);
  return storage.saveBuffer(out.buffer, { mimetype: out.mimetype || storage.sniff(out.buffer) || 'image/png', category: 'gallery' });
}
async function drawIdeas(jobId, ideas, o, fixedCat) {
  await pool(ideas, 2, async (idea) => {
    try {
      const saved = await drawOne(idea, o);
      addItem({ title: idea.title, image: saved.fullurl, width: saved.width, height: saved.height, prompt: idea.prompt, catId: fixedCat || catIdOf(idea.category), tags: idea.tags, status: 'draft', source: o.source, jobId });
      jobTick(jobId, { done: 1 });
    } catch (e) { jobTick(jobId, { failed: 1, error: engine.cleanError(e) }); }
  });
}

/** 1. 批量生成 */
function startGenerate(o) {
  const count = Math.max(1, Math.min(50, parseInt(o.count, 10) || 1));
  const theme = str(o.theme, 200);
  if (!theme) throw new Error('请填写主题');
  const fixedCat = parseInt(o.cat_id, 10) || 0;
  const id = newJob('generate', `批量生成：${theme}`, { ...o, count }, count);
  RUNNING.add(id);
  (async () => {
    try {
      const names = fixedCat ? [] : cats().map((c) => c.name);
      let ideas = [];
      for (let tries = 0; ideas.length < count && tries < 3; tries++) {
        const more = await runWithFeature({ text: 'gallery' }, () => llm.galleryIdeas(theme, count - ideas.length, names, o.ratio));
        ideas = ideas.concat(more);
      }
      if (!ideas.length) throw new Error('文本模型没有给出画面方案');
      jobTick(id, { total: ideas.length });
      await drawIdeas(id, ideas.slice(0, count), { ...o, source: 'generate' }, fixedCat);
      jobEnd(id);
    } catch (e) { jobEnd(id, engine.cleanError(e)); }
  })();
  return id;
}

/** 2 / 3. 上传识图（similar > 0 时再按每张图生成同类） */
function startUpload(o) {
  const images = (Array.isArray(o.images) ? o.images : []).map((x) => str(x, 1000)).filter(Boolean).slice(0, 50);
  if (!images.length) throw new Error('请先上传图片');
  const similar = Math.max(0, Math.min(20, parseInt(o.similar, 10) || 0));
  const fixedCat = o.auto_cat ? 0 : parseInt(o.cat_id, 10) || 0;
  const online = o.publish === undefined ? true : !!o.publish;
  // 识图生成同类：原图只当参考（存为「参考素材」，前台不显示），进度只算新生成的图
  const id = newJob(similar ? 'similar' : 'upload', similar ? `识图生成同类：${images.length} 张 × ${similar}` : `上传识图：${images.length} 张`, { ...o, images }, images.length * (similar || 1));
  RUNNING.add(id);
  (async () => {
    const names = cats().map((c) => c.name);
    await pool(images, 2, async (url) => {
      let desc = null;
      let w = 0; let h = 0;
      try {
        desc = await runWithFeature({ text: 'gallery' }, () => llm.describeImage(url, names));
        if (!desc.prompt) throw new Error('识图没有返回提示词');
        try { const b = await storage.fetchBuffer(url); ({ width: w, height: h } = storage.imageSize(b.buffer)); } catch { /* 尺寸未知 */ }
        addItem({ title: desc.title, image: url, width: w, height: h, prompt: desc.prompt, catId: fixedCat || catIdOf(desc.category), tags: desc.tags, status: similar ? 'ref' : online ? 'online' : 'draft', source: 'upload', jobId: id });
        if (!similar) jobTick(id, { done: 1 });
        if (fixedCat) desc.category = (db.get('SELECT name FROM yd_gallery_cat WHERE id=?', fixedCat) || {}).name || desc.category;
      } catch (e) {
        jobTick(id, { failed: similar || 1, error: engine.cleanError(e) });
        return;
      }
      if (!similar) return;
      try {
        const ideas = await runWithFeature({ text: 'gallery' }, () => llm.similarIdeas(desc, similar));
        if (ideas.length < similar) jobTick(id, { failed: similar - ideas.length });
        await drawIdeas(id, ideas, { ...o, ratio: o.ratio || ratioOf(w, h) || '3:4', source: 'similar' }, fixedCat || catIdOf(desc.category));
      } catch (e) { jobTick(id, { failed: similar, error: engine.cleanError(e) }); }
    });
    jobEnd(id);
  })();
  return id;
}

// ---------------- 4. 图库参考（Unsplash / Pexels） ----------------
/**
 * 选中的图库图片 → 识图写提示词 → 存为参考素材（status=ref，前台不显示）；similar>0 时每张再生成同类新图（进待审核）
 */
function importStock(o) {
  const stock = require('./stock');
  const list = (Array.isArray(o.items) ? o.items : []).filter((x) => x && /^https?:\/\//.test(str(x.full))).slice(0, 60);
  if (!list.length) throw new Error('请先选择图片');
  const similar = Math.max(0, Math.min(10, parseInt(o.similar, 10) || 0));
  const fixedCat = parseInt(o.cat_id, 10) || 0;
  const id = newJob(similar ? 'similar' : 'upload', `图库参考：${list.length} 张${similar ? ` × 同类 ${similar}` : ''}`, { ...o, items: list.map((x) => ({ source: x.source, id: x.id })) }, list.length * (1 + similar));
  RUNNING.add(id);
  (async () => {
    const names = cats().map((c) => c.name);
    await pool(list, 2, async (x) => {
      let desc;
      const url = str(x.full);
      try {
        stock.track(x);
        desc = await runWithFeature({ text: 'gallery' }, () => llm.describeImage(url, names));
        if (!desc.prompt) throw new Error('识图没有返回提示词');
        const catId = fixedCat || catIdOf(desc.category);
        if (!db.get('SELECT id FROM yd_gallery WHERE image=?', url)) {
          addItem({ title: desc.title || str(x.title), image: url, width: parseInt(x.width, 10) || 0, height: parseInt(x.height, 10) || 0, prompt: desc.prompt, catId, tags: [...(desc.tags || []), x.author ? `摄影：${str(x.author)}` : ''].filter(Boolean), status: 'ref', source: str(x.source) || 'stock', jobId: id });
        }
        jobTick(id, { done: 1 });
        if (!similar) return;
        if (fixedCat) desc.category = (db.get('SELECT name FROM yd_gallery_cat WHERE id=?', fixedCat) || {}).name || desc.category;
        const ideas = await runWithFeature({ text: 'gallery' }, () => llm.similarIdeas(desc, similar));
        if (ideas.length < similar) jobTick(id, { failed: similar - ideas.length });
        await drawIdeas(id, ideas, { ...o, ratio: o.ratio || ratioOf(parseInt(x.width, 10), parseInt(x.height, 10)) || '3:4', refs: undefined, source: 'similar' }, catId);
      } catch (e) { jobTick(id, { failed: (desc ? 0 : 1) + similar, error: engine.cleanError(e) }); }
    });
    jobEnd(id);
  })();
  return id;
}

/** 以前导入的旧模板素材（cos.huotu333.cn，source=legacy）已弃用：启动时清掉（用它们生成的新图保留） */
function purgeLegacy() {
  // 1.21 之前「识图生成同类」把上传的原图也放进了待审核：改成参考素材
  try { db.run(`UPDATE yd_gallery SET status='ref' WHERE source='upload' AND status='draft' AND job_id IN (SELECT id FROM yd_gallery_job WHERE kind='similar')`); } catch { /* ignore */ }
  try { const n = db.val(`SELECT COUNT(*) FROM yd_gallery WHERE source='legacy'`); if (n) { db.run(`DELETE FROM yd_gallery WHERE source='legacy'`); console.log(`[素材库] 已清除旧模板素材 ${n} 张`); } } catch { /* ignore */ }
}

/**
 * 选中的素材 → 生成全新的图（进待审核）
 *   mode=edit     AI 改图：以原图为参考，按要求重新画（per 张）
 *   mode=similar  生成同类：按原图提示词想 per 个不同的新画面，不带原图、全新出图
 */
function startRemix(o) {
  const ids = (Array.isArray(o.ids) ? o.ids : []).map((x) => parseInt(x, 10)).filter(Boolean).slice(0, 100);
  const items = ids.map((id) => db.get('SELECT * FROM yd_gallery WHERE id=?', id)).filter((g) => g && g.image);
  if (!items.length) throw new Error('请先选择素材');
  const per = Math.max(1, Math.min(10, parseInt(o.per, 10) || 1));
  const mode = o.mode === 'similar' ? 'similar' : 'edit';
  const instruction = str(o.instruction, 500);
  const id = newJob(mode === 'edit' ? 'remix' : 'similar', `${mode === 'edit' ? 'AI 改图' : '生成同类'}：${items.length} 张 × ${per}${instruction ? `（${instruction.slice(0, 30)}）` : ''}`, { ...o, ids }, items.length * per);
  RUNNING.add(id);
  (async () => {
    await pool(items, 2, async (g) => {
      const ratio = o.ratio || g.ratio || ratioOf(g.width, g.height) || '3:4';
      try {
        let ideas;
        if (mode === 'edit') {
          const drawPrompt = `以参考图为基础重新创作一张全新的高质量成品图：保留它的主题、用途和大致版式，画面重新绘制，构图、细节和质感都要比参考图更好，不要直接照抄参考图。${instruction ? `\n修改要求：${instruction}` : '\n要求：画面更高级、更干净，光影和质感更好，文字清晰不乱码。'}\n画面说明：${g.prompt}`;
          ideas = Array.from({ length: per }, () => ({ title: g.title, tags: jsonParse(g.tags, []), prompt: instruction ? `${g.prompt}\n${instruction}` : g.prompt, drawPrompt, refs: [g.image] }));
        } else {
          const cat = db.get('SELECT name FROM yd_gallery_cat WHERE id=?', g.cat_id);
          ideas = await runWithFeature({ text: 'gallery' }, () => llm.similarIdeas({ title: g.title, category: cat ? cat.name : '', prompt: instruction ? `${g.prompt}\n额外要求：${instruction}` : g.prompt }, per));
          if (ideas.length < per) jobTick(id, { failed: per - ideas.length });
        }
        await drawIdeas(id, ideas, { ...o, ratio, refs: undefined, source: mode === 'edit' ? 'remix' : 'similar' }, g.cat_id);
      } catch (e) { jobTick(id, { failed: per, error: engine.cleanError(e) }); }
    });
    jobEnd(id);
  })();
  return id;
}

/**
 * 5. 电商提示词包（src/data/prompt-pack-ecom.js）：按写好的提示词逐条出效果图 → 待审核
 *   已导入过的条目（source=pack:<id>）在列表里标出来，默认不重复导入
 */
function packList() {
  const { PACK } = require('../data/prompt-pack-ecom');
  const used = new Map(db.all(`SELECT source, COUNT(*) n FROM yd_gallery WHERE source LIKE 'pack:%' GROUP BY source`).map((r) => [r.source.slice(5), r.n]));
  return PACK.map((x) => ({ id: x.id, title: x.title, category: x.category, ratio: x.ratio, tags: x.tags, prompt: x.prompt, imported: used.get(x.id) || 0 }));
}
function startPack(o) {
  const { PACK } = require('../data/prompt-pack-ecom');
  const want = new Set((Array.isArray(o.ids) ? o.ids : []).map((x) => str(x, 20)));
  const list = PACK.filter((x) => want.has(x.id));
  if (!list.length) throw new Error('请至少选择一条提示词');
  const per = Math.max(1, Math.min(4, parseInt(o.per, 10) || 1));
  const id = newJob('pack', `电商提示词包：${list.length} 条${per > 1 ? ` × ${per}` : ''}`, { ids: list.map((x) => x.id), per, model_key: o.model_key, resolution: o.resolution }, list.length * per);
  RUNNING.add(id);
  (async () => {
    const jobs = list.flatMap((x) => Array.from({ length: per }, () => x));
    await pool(jobs, 2, async (x) => {
      try {
        const saved = await drawOne({ prompt: x.prompt }, { ...o, ratio: x.ratio, refs: undefined });
        addItem({ title: x.title, image: saved.fullurl, width: saved.width, height: saved.height, prompt: x.prompt, catId: catIdOf(x.category), tags: x.tags, status: 'draft', source: `pack:${x.id}`, jobId: id });
        jobTick(id, { done: 1 });
      } catch (e) { jobTick(id, { failed: 1, error: engine.cleanError(e) }); }
    });
    jobEnd(id);
  })();
  return id;
}

// ---------------- 前台顺序（首页灵感发现 / 素材库「推荐」） ----------------
//   sort 越大越靠前；同 sort 再按热度、新旧。后台调过一次顺序后，所有已上架素材都有明确的 sort
const FRONT_ORDER = 'sort DESC, hot DESC, id DESC';
const frontOrder = () => db.all(`SELECT id FROM yd_gallery WHERE status='online' ORDER BY ${FRONT_ORDER}`).map((r) => r.id);
function writeOrder(order) {
  const n = order.length;
  db.tx(() => order.forEach((id, i) => db.run('UPDATE yd_gallery SET sort=? WHERE id=?', n - i, id)));
}
/** 调整顺序：action = top | bottom | up | down | to（pos 从 1 开始）；返回调整后的位置 */
function reorder(ids, action, pos = 0) {
  const order = frontOrder();
  const set = new Set(ids.filter((id) => order.includes(id)));
  if (!set.size) throw new Error('只有「已上架」的素材才能调整前台顺序');
  const moving = order.filter((id) => set.has(id));
  const rest = order.filter((id) => !set.has(id));
  let next;
  if (action === 'top') next = [...moving, ...rest];
  else if (action === 'bottom') next = [...rest, ...moving];
  else if (action === 'to') { const k = Math.max(0, Math.min(rest.length, (pos || 1) - 1)); next = [...rest.slice(0, k), ...moving, ...rest.slice(k)]; }
  else if (action === 'up' || action === 'down') {
    next = order.slice();
    const list = action === 'up' ? moving : moving.slice().reverse();
    for (const id of list) {
      const i = next.indexOf(id); const j = action === 'up' ? i - 1 : i + 1;
      if (j < 0 || j >= next.length || set.has(next[j])) continue;
      [next[i], next[j]] = [next[j], next[i]];
    }
  } else throw new Error('未知操作');
  writeOrder(next);
  return Object.fromEntries(moving.map((id) => [id, next.indexOf(id) + 1]));
}
/** 新上架的素材排到最前面（之后可在后台再调） */
function placeNew(ids) {
  const max = Math.max(0, Number(db.val(`SELECT MAX(sort) FROM yd_gallery WHERE status='online' AND id NOT IN (${ids.map(() => '?').join(',')})`, ...ids) || 0));
  db.tx(() => ids.forEach((id, i) => db.run('UPDATE yd_gallery SET sort=? WHERE id=?', max + ids.length - i, id)));
}

/** 服务重启时，上次没跑完的任务标记为中断 */
function markInterrupted() {
  db.run(`UPDATE yd_gallery_job SET status='failed', error='服务重启，任务中断（已生成的保留）' WHERE status='running'`);
}

module.exports = { seedCats, cats, catIdOf, itemView, addItem, startGenerate, startUpload, startRemix, importStock, packList, startPack, FRONT_ORDER, frontOrder, reorder, placeNew, purgeLegacy, markInterrupted, RUNNING, ratioOf };
