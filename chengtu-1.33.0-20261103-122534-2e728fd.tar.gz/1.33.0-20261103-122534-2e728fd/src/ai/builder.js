'use strict';
// 把前端提交的表单参数编译成“出图单元”：每个单元 = 一张结果图 {label, prompt, images, ratio, resolution, kind}
// 前端已拼好大部分 guidance / prompt，这里负责：拆分张数、给每张分配参考图、合并提示词与参数说明

const MAX_UNITS = 60;
const IMG_EXT = /\.(png|jpe?g|webp|gif|bmp|avif|heic)(\?|#|$)/i;

const isUrl = (s) => typeof s === 'string' && /^(https?:\/\/|data:image\/|\/uploads\/)/i.test(s.trim());
const urlOf = (v) => {
  if (!v) return '';
  if (typeof v === 'string') return isUrl(v) ? v.trim() : '';
  if (typeof v === 'object') return urlOf(v.url || v.src || v.fullurl || v.image || v.image_url || v.ref_url || v.bg_ref || v.path || '');
  return '';
};
const urls = (v) => {
  if (!v) return [];
  if (typeof v === 'string' && /^\s*\[/.test(v)) { try { v = JSON.parse(v); } catch {} }
  const arr = Array.isArray(v) ? v : [v];
  return arr.map(urlOf).filter(Boolean);
};
const uniq = (arr) => [...new Set(arr.filter(Boolean))];
const str = (v) => (v == null ? '' : typeof v === 'string' ? v.trim() : typeof v === 'number' ? String(v) : '');
const clampInt = (v, lo, hi, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };

// 主图（商品/人像等）
function primaryImages(p) {
  const list = [...urls(p.images)];
  if (!list.length) list.push(...urls(p.origin_images), ...urls(p.image), ...urls(p.source_url));
  return uniq(list);
}
// 其它参考图（背景/模特/款式/模板等）
function refImages(p) {
  const out = [];
  for (const k of [
    'products', 'refs', 'reference_images', 'bg_ref', 'bg_refs', 'reference_url', 'reference_urls', 'model_image', 'model_url',
    'model_ref', 'detail_ref', 'ref_urls', 'font_ref_urls', 'styleRef', 'style_ref', 'template', 'templates', 'extraRefs',
    'extra_images', 'pose_ref', 'pose_image', 'scene_ref', 'fabric', 'fabric_image', 'garment_image', 'face_image', 'logo',
    'mark_url', 'masks', 'mask',
  ]) {
    if (p[k] == null) continue;
    if (k === 'templates' && Array.isArray(p[k])) { p[k].forEach((t) => out.push(urlOf(t))); continue; }
    out.push(...urls(p[k]));
  }
  return uniq(out);
}

const LABEL_NAMES = {
  type_label: '类型', mode_label: '模式', inspire_label: '灵感风格', scope_label: '范围', bgcolor_label: '底色', garment_label: '款式',
  output_label: '输出', style_label: '风格', view_label: '视角', ztc_type_label: '构图', source_label: '来源', place_label: '位置',
  fit_label: '贴合', model_label: '模特', product_kind_label: '品类', reference_name: '参考风格', bg_label: '背景', light_label: '布光',
  frame_label: '构图', size_label: '尺寸', industry_label: '行业', platform_label: '平台', layout_label: '版式', display_label: '展示方式',
  face_basis_label: '人脸依据', look_label: '造型', repair_label: '修复', product_label: '商品', variant_label: '变体类型',
  aesthetic_label: '美学', output_layout_label: '裂变维度', edge_label: '边缘', crop_label: '裁切',
};
const TEXT_FIELDS = [
  ['headline', '主标题'], ['sub', '副标题'], ['promo', '促销信息'], ['tag', '标签'], ['price_value', '价格'], ['company_name', '品牌/公司名'],
  ['slogan', '标语'], ['name', '商品名称'], ['product_name', '商品名称'], ['brand', '品牌'], ['replace_info', '替换内容'],
  ['custom_item', '自定义单品'], ['board_title', '看板标题'], ['free_desc', '自由描述'], ['size_px', '像素尺寸'], ['bg_color', '背景色'],
  ['compare_l', '左标题'], ['compare_r', '右标题'], ['festival', '节日'], ['category', '类目'],
];

function settingsText(s) {
  if (!s || typeof s !== 'object') return '';
  const parts = [];
  const add = (k, label) => { const v = str(s[k]); if (v) parts.push(`${label}：${v}`); };
  add('language', '画面文字语言'); add('country', '目标市场'); add('platform', '投放平台'); add('themeColor', '主题色');
  add('theme_color', '主题色'); add('font', '字体风格'); add('people', '人物设定'); add('extra', '补充');
  return parts.join('；');
}

function formFieldsText(p, skip) {
  let ff = p.form_fields;
  if (typeof ff === 'string') { try { ff = JSON.parse(ff); } catch { ff = null; } }
  if (!Array.isArray(ff)) return '';
  return ff
    .filter((f) => f && f.value != null && String(f.value).trim() && !String(f.key || '').startsWith('_') && !skip.has(String(f.key)))
    .map((f) => `${f.label || f.key}：${String(f.value).slice(0, 200)}`)
    .slice(0, 30)
    .join('；');
}

function styleText(v) {
  if (!v) return '';
  if (typeof v === 'string') return v.trim();
  if (Array.isArray(v)) return v.map(styleText).filter(Boolean).join('；');
  if (typeof v === 'object') return [v.name, v.desc, v.prompt].map(str).filter(Boolean).join('：');
  return '';
}

/** 合成单张图的完整提示词 */
function buildPrompt(info, p, u = {}) {
  const L = [];
  const seen = new Set();
  const push = (title, text, max = 4000) => {
    const t = str(text).slice(0, max);
    if (!t || seen.has(t)) return;
    seen.add(t);
    L.push(title ? `【${title}】${t}` : t);
  };
  push('任务', `${info.sceneName || info.scene}${info.desc ? '：' + info.desc : ''}`);
  push('', info.defaultTask);
  // 图片角色
  const roles = Array.isArray(u.image_roles) && u.image_roles.length ? u.image_roles : Array.isArray(p.image_roles) ? p.image_roles : [];
  const imgs = u.images || [];
  if (roles.length) {
    push('图片说明', roles.filter((r) => r && (r.index || r.label)).map((r) => `第${r.index}张：${r.label || r.role || ''}`).join('；'));
  } else if (imgs.length > 1 && u.roleHint) push('图片说明', u.roleHint);
  else if (imgs.length > 1) push('图片说明', `共 ${imgs.length} 张参考图，第1张为主体（商品/人物）原图，其余为参考图，只借鉴其指定要素。`);
  if (u.label) push('本张主题', u.label, 200);
  push('本张要求', u.prompt);
  push('执行要求', p.guidance);
  push('多视角要求', p.views_guidance);
  if (p.prompt && p.prompt !== p.guidance) push('画面描述', p.prompt);
  push('用户要求', p.user_instruction || p.instruction || p.user_prompt);
  push('背景', p.bg_prompt);
  push('灵感', p.inspire_prompt);
  push('风格', styleText(p.style) || styleText(p.styles));
  push('商品信息', p.info, 3000);
  push('补充说明', p.extra);
  push('备注', p.notes, 2000);
  if (p.avoid) push('规避内容', p.avoid);
  // 选项标签
  const skip = new Set();
  const opts = [];
  for (const [k, name] of Object.entries(LABEL_NAMES)) {
    const v = str(p[k]);
    if (v) { opts.push(`${name}：${v}`); skip.add(k); }
  }
  for (const [k, name] of TEXT_FIELDS) {
    if (u.skipName && k === 'name') continue;
    const v = str(p[k]);
    if (v) { opts.push(`${name}：${v}`); skip.add(k); }
  }
  if (opts.length) push('参数', opts.join('；'));
  const ff = formFieldsText(p, skip);
  if (ff) push('表单', ff, 1500);
  const st = settingsText(p.settings);
  if (st) push('投放设置', st);
  if (u.variant && u.variantTotal > 1) push('', `这是同组第 ${u.variant}/${u.variantTotal} 张：在严格遵守以上要求的前提下，构图/角度/姿态与同组其它张有所区别。`);
  push('', '只输出一张完整的成品图片，不要拼接多图（除非任务明确要求拼图/宫格），不要在画面中出现任何说明文字、水印或标注（除非任务要求排版文案）。');
  return L.join('\n');
}

function expandCount(baseUnits, count, max = MAX_UNITS) {
  const out = [];
  const c = Math.max(1, count);
  for (const u of baseUnits) {
    for (let k = 1; k <= c; k++) {
      out.push({ ...u, variant: k, variantTotal: c, label: c > 1 && u.label ? `${u.label}${baseUnits.length > 1 ? ` ${k}/${c}` : ''}` : u.label });
      if (out.length >= max) return out;
    }
  }
  return out;
}

// ---------------- 各类编译器 ----------------

/** 通用：product.* / model.* / marketing.* / material.* / toolbox.* / pod.* / derive.* / crossborder.* / design.* / video.* */
function compileGeneric(info, p) {
  const prim = primaryImages(p);
  const refs = refImages(p);
  const items = Array.isArray(p.items) ? p.items.filter((x) => x && typeof x === 'object') : [];
  const count = clampInt(p.count, 1, MAX_UNITS, 1);
  const ratio = str(p.ratio || p.aspectRatio || p.aspect_ratio);
  const base = [];
  const mod = info.module;

  // 职业照 / 艺术写真：count 已是总张数，items 为风格
  if (mod === 'toolbox.proportrait' || mod === 'toolbox.artportrait') {
    const n = Math.max(1, count);
    for (let i = 0; i < n && items.length; i++) {
      const it = items[i % items.length];
      const imgs = uniq([prim[0], urlOf(it.ref_url)]);
      base.push({ label: it.label || '', prompt: it.prompt || '', images: imgs, variant: Math.floor(i / items.length) + 1, variantTotal: Math.ceil(n / items.length) });
    }
    if (base.length) return base.map((u) => finalize(info, p, u, ratio));
  }

  // 模特换装：每张模特图 × 同一件（套）衣服 → 一张结果
  if (mod === 'model.humantryon') {
    const garments = uniq([...urls(p.garment_images), ...urls(p.garment_image)]);
    const part = str(p.part_label) || '衣服';
    const models = prim.length ? prim : [''];
    models.forEach((mi, i) => base.push({
      images: uniq([mi, ...garments]),
      label: models.length > 1 ? `模特${i + 1}` : '换装',
      prompt: `把第1张模特图中模特身上的${part}，换成后面服装图里的${part}。只替换${part}，其它一律不变。`,
      roleHint: `第1张为模特图：人物的脸、发型、肤色、身材、姿势、手势、背景、光线、构图，以及没有要求替换的其它衣物、鞋子、配饰全部保持不变。后面${garments.length > 1 ? `${garments.length}张` : '1张'}为要换上的服装（白底 / 平铺 / 挂拍商品图）：款式、版型、颜色、图案、印花、面料质感、长度、口袋、纽扣、拉链等细节必须与服装图完全一致，按模特的身材和姿势自然穿着，有真实的褶皱和光影，不要出现原来那件${part}的任何残留。`,
    }));
    return expandCount(base, count).map((u) => finalize(info, p, u, ratio));
  }

  // 换背景：商品 × 背景
  if (mod === 'product.changebg') {
    const bgs = uniq([...urls(p.bg_refs), ...urls(p.bg_ref)]);
    const products = prim.length ? prim : [''];
    const pair = p.pair_mode === 'pair';
    if (bgs.length && pair) products.forEach((pi, i) => base.push({ images: uniq([pi, bgs[i % bgs.length]]), label: products.length > 1 ? `换背景${i + 1}` : '换背景' }));
    else if (bgs.length) products.forEach((pi, i) => bgs.forEach((b, j) => base.push({ images: uniq([pi, b]), label: `商品${i + 1}·背景${j + 1}` })));
    else products.forEach((pi, i) => base.push({ images: uniq([pi]), label: products.length > 1 ? `换背景${i + 1}` : '换背景' }));
    base.forEach((u) => { u.roleHint = '第1张为商品原图（整件锁死，只换背景），第2张为背景参考（只借环境）。'; });
    return expandCount(base, count).map((u) => finalize(info, p, u, ratio));
  }

  const unitCount = clampInt(p.unit_count, 0, MAX_UNITS, 0);
  if (items.length) {
    items.forEach((it, i) => {
      let imgs;
      if (Number.isInteger(it.image_index) && prim[it.image_index]) imgs = [prim[it.image_index]];
      else imgs = [...prim];
      const extra = urlOf(it.ref_url) || urlOf(it.bg_ref) || urlOf(it.image);
      if (extra) imgs.push(extra);
      if (!Number.isInteger(it.image_index)) imgs.push(...refs);
      base.push({ label: it.label || it.name || '', prompt: it.prompt || (it.label ? `本张输出：${it.label}` : ''), images: uniq(imgs) });
    });
    // unit_count 大于 items（如 SKU 变体按图片数倍增）时，循环补齐
    if (unitCount > base.length) {
      const extra = [];
      for (let i = base.length; i < unitCount; i++) extra.push({ ...base[i % base.length] });
      base.push(...extra);
    }
  } else if (unitCount > 1) {
    for (let i = 0; i < unitCount; i++) {
      const imgs = prim.length >= unitCount ? [prim[i]] : prim.length > 1 && unitCount % prim.length === 0 ? [prim[i % prim.length]] : [...prim];
      base.push({ label: '', images: uniq([...imgs, ...refs]) });
    }
  } else if (info.perImage && prim.length > 1) {
    prim.forEach((pi, i) => base.push({ label: `图${i + 1}`, images: uniq([pi, ...refs]) }));
  } else {
    base.push({ label: '', images: uniq([...prim, ...refs]) });
  }
  // 变体（如 SKU 变体：每张一个规格值）
  if (Array.isArray(p.variants) && p.variants.length && base.length === 1) {
    const total = Math.max(count, 1);
    const out = [];
    for (let i = 0; i < total; i++) out.push({ ...base[0], label: p.variants[i] || `变体${i + 1}`, prompt: `本张变体：${p.variants[i] || '自行设计一个不同的同类属性值'}` });
    return out.map((u) => finalize(info, p, u, ratio));
  }
  return expandCount(base, count).map((u) => finalize(info, p, u, ratio));
}

function finalize(info, p, u, ratio) {
  const kind = u.kind || info.kind;
  const spec = {
    label: u.label || '',
    images: (u.images || []).filter(Boolean),
    ratio: str(u.ratio) || ratio || '',
    resolution: str(u.resolution || p.resolution) || '2K',
    modelKey: str(p.model_key) || 'm1',
    kind,
    prompt: '',
  };
  spec.prompt = kind === 'video' ? buildVideoPrompt(info, p, u) : buildPrompt(info, p, { ...u, images: spec.images });
  if (kind === 'video') {
    spec.seconds = clampInt(p.duration || p.seconds, 2, 30, 0) || undefined;
    spec.image = spec.images[0] || '';
  }
  if (p.mask || p.masks) spec.mask = urls(p.mask)[0] || urls(p.masks)[0] || '';
  return spec;
}

function buildVideoPrompt(info, p, u) {
  const parts = [];
  if (u.prompt) parts.push(u.prompt);
  for (const k of ['prompt', 'guidance', 'motion', 'action', 'camera', 'script', 'user_instruction', 'extra', 'notes']) {
    const v = str(p[k]);
    if (v && !parts.includes(v)) parts.push(v);
  }
  if (!parts.length) parts.push(`${info.sceneName}：根据参考图生成一段自然流畅的电商展示短视频，主体保持与参考图一致。`);
  const st = settingsText(p.settings);
  if (st) parts.push(st);
  return parts.join('\n');
}

/** 详情页 / 商品套图：modules[] 每个模块一张 */
function compileModules(info, p) {
  const prim = primaryImages(p);
  const refs = uniq([...urls(p.extraRefs), ...urls(p.styleRef)]);
  const mods = Array.isArray(p.modules) ? p.modules.filter(Boolean) : [];
  const globalRatio = str(p.aspectRatio || p.ratio);
  const base = mods.map((m) => {
    const lines = [];
    if (m.prompt) lines.push(m.prompt);
    else {
      if (m.name) lines.push(`本张模块：${m.name}`);
      if (m.suggestion) lines.push(`画面规划：${m.suggestion}`);
      if (m.copy) lines.push(`画面文案（需排版进图中，文字准确无乱码）：${m.copy}`);
      if (m.frame_share) lines.push(`商品画面占比：${m.frame_share}`);
    }
    if (m.extra) lines.push(`补充：${m.extra}`);
    const imgs = uniq([...prim, urlOf(m.image), ...refs]);
    return { label: m.name || m.value || '', prompt: lines.join('\n'), images: imgs, ratio: str(m.aspectRatio || m.ratio) || globalRatio, skipName: true };
  });
  if (!base.length) base.push({ label: info.sceneName, images: uniq([...prim, ...refs]) });
  return base.slice(0, MAX_UNITS).map((u) => finalize(info, p, u, globalRatio));
}

/** 自定义套图 / 批量：units[] */
function compileUnitList(info, p) {
  const prim = primaryImages(p);
  const refs = uniq([...urls(p.extraRefs), ...urls(p.styleRef)]);
  const list = Array.isArray(p.units) ? p.units.filter(Boolean) : [];
  const base = list.map((x) => {
    const own = urls(x.images);
    const lines = [];
    if (x.prompt) lines.push(x.prompt);
    if (x.desc) lines.push(x.desc);
    if (x.copy) lines.push(`画面文案（需排版进图中）：${x.copy}`);
    if (x.extra) lines.push(`补充：${x.extra}`);
    if (x.meta && typeof x.meta === 'object') {
      const meta = Object.entries(x.meta).filter(([, v]) => typeof v === 'string' && v.trim() && !isUrl(v)).map(([k, v]) => `${k}：${v}`).join('；');
      if (meta) lines.push(meta);
    }
    return {
      label: x.label || x.name || '',
      prompt: lines.join('\n'),
      images: uniq([...(own.length ? own : prim), urlOf(x.image), ...refs]),
      ratio: str(x.ratio),
      resolution: str(x.resolution),
      skipName: true,
    };
  });
  return base.slice(0, MAX_UNITS).map((u) => finalize(info, p, u, str(p.ratio || p.aspectRatio)));
}

/** 商品主图（模板复刻）：templates × count */
function compileHero(info, p) {
  const prods = primaryImages(p);
  const tpls = Array.isArray(p.templates) ? p.templates.filter((t) => urlOf(t)) : [];
  const count = clampInt(p.count, 1, 10, 1);
  const extraRefs = urls(p.extraRefs);
  const pair = p.match_mode === 'pair';
  const base = [];
  tpls.forEach((t, i) => {
    const product = pair ? [prods[i] || prods[0]] : prods;
    const ex = Array.isArray(t.extra_images) ? t.extra_images.map(urlOf) : [];
    base.push({
      label: t.title || `主图${i + 1}`,
      images: uniq([...product, urlOf(t), ...ex, ...extraRefs]),
      ratio: str(t.ratio),
      roleHint: `前 ${product.length} 张为商品原图（保持商品完全一致），之后 1 张为版式模板（只借鉴版式布局、文字排布与配色，不要照搬模板中的商品）${ex.length || extraRefs.length ? '，其余为补充参考' : ''}。`,
      prompt: `参照模板图的版式布局，为本商品制作电商主图。${p.price_show ? `画面中展示价格：${str(p.price_value)}。` : ''}`,
    });
  });
  if (!base.length) base.push({ label: '主图', images: uniq([...prods, ...extraRefs]) });
  return expandCount(base, count).map((u) => finalize(info, p, u, str(p.ratio || p.aspectRatio)));
}

/** SKU 图：products[] 每个一张，带模板图 */
function compileSku(info, p) {
  const tpl = urlOf(p.template);
  const shots = urls(p.shots);
  const list = Array.isArray(p.products) ? p.products.filter(Boolean) : [];
  const base = list.map((x, i) => ({
    label: x.label || `SKU ${i + 1}`,
    prompt: [x.prompt, p.mark_name ? `在图中标注规格名称：${x.label}` : '', p.consistency ? `系列一致性：${p.consistency}` : ''].filter(Boolean).join('\n'),
    images: uniq([...urls(x.images).length ? urls(x.images) : [urlOf(x.src)], tpl, ...(x.collage ? [] : shots.slice(0, 2))]),
    image_roles: Array.isArray(x.image_roles) ? x.image_roles : undefined,
    roleHint: tpl ? '最后一张为 SKU 模板图（只借鉴版式与风格），其余为本款商品实拍图（保持商品一致）。' : '',
  }));
  return base.slice(0, MAX_UNITS).map((u) => finalize(info, p, u, str(p.ratio)));
}

/** 爆款复刻：refs[] 每张参考出一张（count 倍） */
function compileReplica(info, p) {
  const prods = urls(p.products);
  const refs = urls(p.refs);
  const outline = Array.isArray(p.outline) ? p.outline : [];
  const count = clampInt(p.count, 1, 10, 1);
  const base = (refs.length ? refs : ['']).map((r, i) => {
    const o = outline[i] || {};
    return {
      label: o.name || `复刻${i + 1}`,
      prompt: [o.suggestion, o.copy ? `画面文案：${o.copy}` : '', `复刻程度：${str(p.level) || '高'}`].filter(Boolean).join('\n'),
      images: uniq([...prods, r]),
      roleHint: `前 ${prods.length} 张为本店商品图（必须保持一致），最后 1 张为要复刻的爆款参考图（复刻构图、场景、光影与排版，替换为本店商品）。`,
    };
  });
  return expandCount(base, count).map((u) => finalize(info, p, u, str(p.ratio)));
}

// 抠图类：走本地模型 / AI 抠图引擎（见 matting.js）
const MATTING_MODULES = { 'toolbox.cutout': '', 'pod.smartcutout': '', 'toolbox.idphoto': '', 'toolbox.cutoutpro': '', 'product.whitebg': '' };
function isMatting(info, p) {
  return Object.prototype.hasOwnProperty.call(MATTING_MODULES, info.module) || str(p.engine) === 'matting';
}
function compileMatting(info, p) {
  const prim = primaryImages(p);
  const list = prim.length ? prim : refImages(p).slice(0, 1);
  const isId = info.module === 'toolbox.idphoto';
  const isWhite = info.module === 'product.whitebg';   // 商品白底图：抠图后铺纯白底
  return list.slice(0, MAX_UNITS).map((u, i) => ({
    kind: 'image',
    engine: 'matting',
    label: list.length > 1 ? `图${i + 1}` : (isId ? '证件照' : isWhite ? '白底图' : '抠图'),
    prompt: str(p.guidance) || str(p.prompt) || '抠图',
    images: [u],
    bg: isId || isWhite ? (str(p.bg_color) || '#ffffff') : (/^#?[0-9a-f]{3,6}$/i.test(str(p.bg_color)) && str(p.output) !== 'png' ? str(p.bg_color) : ''),
    size: isId ? str(p.size_px) : '',
    ptype: isId ? 'person' : isWhite ? 'object' : '',   // 佐糖前景类型
  }));
}

function compile(info, p, type = 'generic') {
  if (isMatting(info, p)) return compileMatting(info, p);
  if (type === 'modules') return compileModules(info, p);
  if (type === 'units') return compileUnitList(info, p);
  if (type === 'hero') return compileHero(info, p);
  if (type === 'sku') return compileSku(info, p);
  if (info.module === 'product.hotreplica' && (p.refs || p.products)) return compileReplica(info, p);
  if (Array.isArray(p.modules) && p.modules.length && !p.items) return compileModules(info, p);
  if (Array.isArray(p.units) && p.units.length && !p.items) return compileUnitList(info, p);
  return compileGeneric(info, p);
}

module.exports = { compile, isMatting, buildPrompt, primaryImages, refImages, urls, urlOf, isUrl };
