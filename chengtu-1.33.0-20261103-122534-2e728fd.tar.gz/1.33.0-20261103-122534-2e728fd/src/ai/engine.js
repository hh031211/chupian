'use strict';
// 生成任务引擎：建任务（计费）→ 队列（并发控制）→ 调中转站 → 存图 → 汇总状态/失败退点
const db = require('../core/db');
const S = require('../core/settings');
const config = require('../core/config');
const users = require('../core/users');
const storage = require('../core/storage');
const thumbs = require('../core/thumbs');
const { now, jsonParse } = require('../core/util');
const { fail } = require('../core/http');
const { RelayClient, runWithFeature } = require('./relay');
const matting = require('./matting');

function relay() {
  return new RelayClient(S.get('relay'), {
    log: (e) => {
      try { db.insert('yd_ai_log', { kind: e.kind, model: e.model, ok: e.ok ? 1 : 0, ms: e.ms, error: (e.error || '').slice(0, 500), createtime: now() }); } catch {}
    },
  });
}

// ---------------- 清晰度上限 ----------------
// 模型库里可给生图模型设「最高清晰度」（中转站不支持 4K 等）。用户选得更高时自动降到上限生成，并按实际清晰度计价。
const RES_ORDER = ['1K', '2K', '4K'];
function modelMaxResolution(rl, m) {
  if (!m) return '';
  const meta = ((rl.cfg && rl.cfg.model_meta) || {})[`${m.channel}::${m.model}`] || {};
  return String(m.max_resolution || meta.max_resolution || '').toUpperCase();
}
function capResolution(spec, ctx = {}) {
  if (!spec || spec.kind === 'video' || spec.kind === 'text' || !spec.resolution) return spec;
  let max = '';
  try {
    const rl = relay();
    max = runWithFeature(ctx, () => modelMaxResolution(rl, rl.imageModel(spec.modelKey || 'm1')));
  } catch { return spec; }
  const want = String(spec.resolution).toUpperCase();
  if (max && RES_ORDER.includes(want) && RES_ORDER.indexOf(want) > RES_ORDER.indexOf(max)) {
    spec.requested_resolution = want;
    spec.resolution = max;
  }
  return spec;
}

// ---------------- 计价 ----------------
function priceOf(spec, user) {
  const pr = S.get('pricing');
  if (spec.kind === 'video') {
    if (spec.modelKey === 'm3') return (Number(user.video_m3_cost) || pr.video_m3_cost || 5) * (Number(spec.seconds) || 5);
    return Number(user.video_cost) || pr.video_cost || 40;
  }
  if (spec.kind === 'text') return Number(spec.cost || 0);
  if (spec.cost != null) return Number(spec.cost);
  if (spec.engine === 'matting') return Number(spec.cost || 0);   // 抠图按每日免费张数计价，见 mattingCosts
  // 每个前台模型单独定价（后台「功能 → 模型」里填）；没填的按模型2.0（m1）
  const img = pr.image || {};
  const table = { ...{ '1K': 3, '2K': 4, '4K': 5 }, ...(img.m1 || {}), ...(img[spec.modelKey] || {}) };
  const res = String(spec.resolution || '2K').toUpperCase();
  return Number(table[res] ?? table['2K'] ?? 4);
}

// ---------------- 抠图：每人每天免费张数 ----------------
const MATTING_MODULES = ['toolbox.cutout', 'pod.smartcutout', 'toolbox.idphoto', 'toolbox.cutoutpro', 'product.whitebg'];
function dayStart() { return now() - ((now() + 8 * 3600) % 86400); }
/** 今天已用掉的免费抠图张数（失败的不算） */
function mattingUsedToday(userId) {
  return Number(db.val(
    `SELECT COUNT(*) FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id
     WHERE t.user_id=? AND r.createtime>=? AND r.status<>'failed' AND r.spec LIKE '%"free":1%'`, userId, dayStart(),
  ) || 0);
}
function mattingQuota(user) {
  const c = S.get('matting') || {};
  const free = Math.max(0, Number(c.free_daily ?? 10) || 0);
  const used = user && user.id ? mattingUsedToday(user.id) : 0;
  const base = Math.max(0, Number(c.over_price ?? 3) || 0);
  const own = (k) => (c[k] === undefined || c[k] === null || c[k] === '' || !Number.isFinite(Number(c[k])) ? base : Math.max(0, Number(c[k])));
  return {
    free, used, remaining: Math.max(0, free - used), over_action: c.over_action === 'block' ? 'block' : 'charge', over_price: base,
    over_prices: { 'id-photo': own('over_price_idphoto'), 'white-bg': own('over_price_whitebg') },
  };
}
/** 给本次的抠图规格逐张定价：免费张数以内 0 点，超出按后台设置扣点或拒绝 */
// 各功能免费用完后的单独价格（留空 = 用通用的 over_price）
const OVER_KEYS = { 'toolbox.idphoto': 'over_price_idphoto', 'product.whitebg': 'over_price_whitebg' };
function mattingCosts(specs, user, module) {
  const list = specs.filter((s) => s.engine === 'matting');
  if (!list.length) return;
  const q = mattingQuota(user);
  const own = (S.get('matting') || {})[OVER_KEYS[module]];
  if (own !== undefined && own !== null && own !== '' && Number.isFinite(Number(own))) q.over_price = Math.max(0, Number(own));
  let left = q.remaining;
  for (const s of list) {
    if (left > 0) { s.cost = 0; s.free = 1; left--; continue; }
    if (q.over_action === 'block') fail(`今天的 ${q.free} 张免费抠图已用完，明天再来吧`);
    s.cost = q.over_price; s.free = 0;
  }
}

// ---------------- 内容安全：违禁词 ----------------
function checkBanned(...parts) {
  const words = ((S.get('security') || {}).banned_words || []).map((w) => String(w).trim()).filter(Boolean);
  if (!words.length) return;
  const text = parts.map((x) => (typeof x === 'string' ? x : JSON.stringify(x || '', (k, v) => (typeof v === 'string' && /^(data:|https?:)/.test(v) ? '' : v)))).join('\n').toLowerCase();
  const hit = words.find((w) => text.includes(w.toLowerCase()));
  if (hit) fail(`内容包含违禁词「${hit}」，请修改后重试`);
}

// ---------------- 建任务 ----------------
/**
 * @param {object} o
 * @param {object} o.user     当前用户行
 * @param {string} o.kind     board | ai | chatdraw | batch | pro | exclusive
 * @param {object} o.info     modules.resolve() 的结果
 * @param {object} o.params   前端原始参数（存档，用于记录/复刻）
 * @param {Array}  o.specs    builder.compile() 产出的单元
 */
function createTask({ user, kind = 'board', info, params = {}, specs, sessionId = 0, prompt = '' }) {
  if (!specs || !specs.length) fail('没有可生成的内容，请检查上传的图片和选项');
  if (kind !== 'ai' && kind !== 'chatdraw' && specs.some((s) => s.kind !== 'text' && !s.prompt)) fail('提示词为空');
  if (S.get('site').maintenance) fail('系统维护中，请稍后再试');
  if (JSON.stringify(params || {}).length > 300 * 1024) fail('请求内容太多了，请精简后再试');
  checkBanned(prompt, params, specs);
  const mattingOnly = specs.every((s) => s.engine === 'matting') && (S.get('matting') || {}).require_member !== true;   // 抠图默认非会员也能用
  if (!mattingOnly && S.get('member').generate_requires_member !== false && users.effectiveLevel(user) === 'free') {
    fail('您当前不是会员，开通会员后即可创作', 403);
  }
  const bill = users.billUser(user);
  for (const sp of specs) capResolution(sp, { module: info.module, board: info.board, kind });
  mattingCosts(specs, user, info.module);
  const costs = specs.map((s) => priceOf(s, user));
  const total = costs.reduce((a, b) => a + b, 0);
  const first = specs[0] || {};
  const ts = now();
  const taskId = db.tx(() => {
    const id = db.insert('yd_task', {
      user_id: user.id, bill_user_id: bill.id, kind, board: info.board, module: info.module, scene: info.scene, scene_name: info.sceneName,
      params: JSON.stringify(params || {}), status: 'queued', count: specs.length, charged_points: total,
      model_key: first.modelKey || '', resolution: first.resolution || '', ratio: first.ratio || '', prompt: String(prompt || '').slice(0, 4000),
      session_id: sessionId, createtime: ts, updatetime: ts,
    });
    specs.forEach((s, i) => {
      db.insert('yd_task_result', {
        task_id: id, idx: i + 1, label: s.label || '', kind: s.kind || 'image', spec: JSON.stringify(s), cost: costs[i],
        status: 'queued', createtime: ts, updatetime: ts,
      });
    });
    if (total > 0) users.charge(user, total, `${info.sceneName || info.scene} · ${specs.length} 张`, `task:${id}`);
    return id;
  });
  kick();
  return taskId;
}

function getTask(id, user = null) {
  const t = db.get('SELECT * FROM yd_task WHERE id=?', Number(id) || 0);
  if (!t) return null;
  if (user && !canSee(user, t)) return null;
  return t;
}
function canSee(user, t) { return t.user_id === user.id; }
function resultsOf(taskId) {
  return db.all('SELECT * FROM yd_task_result WHERE task_id=? ORDER BY idx', taskId);
}

function serializeResult(r, t) {
  return {
    id: r.id,
    index: r.idx,
    task_id: t ? t.id : r.task_id,
    label: r.label,
    status: r.status,
    url: r.status === 'succeeded' ? r.url : '',
    content: r.content || '',
    text: r.content || '',
    kind: r.kind === 'image' ? '' : r.kind,
    error: r.error || '',
    attempts: r.attempts || 1,
    deleted: r.deleted || 0,
  };
}

function taskBrief(t) {
  return {
    id: t.id, task_id: t.id, status: t.status, count: t.count, success_count: t.success_count, fail_count: t.fail_count,
    charged_points: t.charged_points, refunded_points: t.refunded_points, model_key: t.model_key, resolution: t.resolution,
    aspect_ratio: t.ratio, ratio: t.ratio, scene: t.scene, scene_name: t.scene_name, board: t.board, session_id: t.session_id,
    prompt: t.prompt, remark: t.remark, createtime: t.createtime, updatetime: t.updatetime, error: t.error,
  };
}

/** 任务状态返回：{task, results, errors} */
function statusPayload(t, { onlyDone = false } = {}) {
  const rs = resultsOf(t.id).filter((r) => !r.deleted);
  const results = (onlyDone ? rs.filter((r) => r.status === 'succeeded') : rs).map((r) => serializeResult(r, t));
  const errors = rs.filter((r) => r.status === 'failed').map((r) => ({ index: r.idx, id: r.id, task_id: t.id, error: r.error || '生成失败' }));
  const p = jsonParse(t.params, {});
  return { task: { ...taskBrief(t), images: Array.isArray(p.images) ? p.images : [], style: p.style || '' }, results, errors };
}

// ---------------- 重新生成 ----------------
function regen(user, taskId, index) {
  const t = getTask(taskId, user);
  if (!t) fail('任务不存在');
  const r = db.get('SELECT * FROM yd_task_result WHERE task_id=? AND idx=?', t.id, Number(index) || 0);
  if (!r) fail('找不到这张图');
  if (r.status === 'queued' || r.status === 'running') fail('这张图正在生成中');
  const spec = jsonParse(r.spec, {});
  const cost = priceOf(spec, user);
  db.tx(() => {
    if (cost > 0) users.charge(user, cost, `重新生成 · ${t.scene_name || t.scene}`, `task:${t.id}:${r.idx}`);
    db.update('yd_task_result', { status: 'queued', url: '', content: '', error: '', attempts: 0, refunded: 0, cost, updatetime: now() }, 'id=?', r.id);
    db.run('UPDATE yd_task SET status=?, charged_points=charged_points+?, updatetime=? WHERE id=?', 'running', cost, now(), t.id);
  });
  kick();
  return { task: taskBrief(getTask(t.id)), result: serializeResult(db.get('SELECT * FROM yd_task_result WHERE id=?', r.id), t), charged_points: cost };
}

// ---------------- 汇总 ----------------
const finishHooks = [];
function onTaskFinished(fn) { finishHooks.push(fn); }

function refreshTask(taskId) {
  const t = db.get('SELECT * FROM yd_task WHERE id=?', taskId);
  if (!t) return null;
  const rs = resultsOf(taskId);
  const live = rs.filter((r) => !r.deleted);
  const ok = live.filter((r) => r.status === 'succeeded').length;
  const bad = live.filter((r) => r.status === 'failed').length;
  const running = live.some((r) => r.status === 'running');
  const queued = live.some((r) => r.status === 'queued');
  let status = t.status;
  if (running || (queued && (ok || bad))) status = 'running';
  else if (queued) status = 'queued';
  else if (ok && bad) status = 'partial';
  else if (ok) status = 'succeeded';
  else status = 'failed';
  let refunded = 0;
  if (!running && !queued && S.get('pricing').refund_failed !== false) {
    for (const r of rs.filter((x) => x.status === 'failed' && !x.refunded && x.cost > 0)) {
      try {
        users.refund(t.bill_user_id || t.user_id, r.cost, `生成失败退回 · ${t.scene_name || t.scene}`, `task:${t.id}:${r.idx}`);
        db.update('yd_task_result', { refunded: 1 }, 'id=?', r.id);
        refunded += r.cost;
      } catch (e) { console.error('[engine] 退点失败', e.message); }
    }
  }
  const firstErr = (live.find((r) => r.status === 'failed') || {}).error || '';
  db.run(
    'UPDATE yd_task SET status=?, success_count=?, fail_count=?, refunded_points=refunded_points+?, error=?, updatetime=? WHERE id=?',
    status, ok, bad, refunded, firstErr.slice(0, 500), now(), taskId,
  );
  const fresh = db.get('SELECT * FROM yd_task WHERE id=?', taskId);
  if (!running && !queued && t.status !== status) for (const h of finishHooks) { try { h(fresh); } catch (e) { console.error(e); } }
  return fresh;
}

// ---------------- 执行器 ----------------
const runningByBill = new Map();
let runningTotal = 0;
let ticking = false;
let timer = null;

function cleanError(e) {
  let m = String((e && e.message) || e || '生成失败');
  m = m.replace(/sk-[A-Za-z0-9]{8,}/g, 'sk-***').replace(/Bearer\s+\S+/g, 'Bearer ***');
  if (/content.?policy|safety|moderation|审核|sensitive|blocked/i.test(m)) return '内容未通过安全审核，请调整图片或描述后重试';
  if (/insufficient|quota|余额|balance/i.test(m)) return '生成服务额度不足，请联系管理员';
  return m.slice(0, 300);
}

// 出图保存：后台开了「出图存为高质量 JPG」时，不透明的图转成 JPG（质量 95，分辨率不变，体积约为 PNG 的 1/4），上传 COS 和用户下载都快很多
async function compactOutput(buf, mimetype) {
  if ((S.get('storage') || {}).save_jpeg !== true || !/^image\/(png|webp)/.test(String(mimetype || storage.sniff(buf) || ''))) return { buffer: buf, mimetype };
  const r = await thumbs.recode(buf, { max: 0, q: 95 }).catch(() => null);
  return r || { buffer: buf, mimetype };
}
async function saveOutput(out, category) {
  if (out.buffer) { const o = await compactOutput(out.buffer, out.mimetype); return (await storage.saveBuffer(o.buffer, { mimetype: o.mimetype, category })).fullurl; }
  if (out.url) {
    if (S.get('relay').save_remote === false) return out.url;
    try {
      const f = await storage.fetchBuffer(out.url, { timeout: 180000, maxBytes: 300 * 1024 * 1024 });
      const o = /^image\//.test(f.mimetype) ? await compactOutput(f.buffer, f.mimetype) : f;
      return (await storage.saveBuffer(o.buffer, { mimetype: o.mimetype, category })).fullurl;
    } catch { return out.url; }
  }
  throw new Error('没有可保存的输出');
}

// 发给 AI 模型的参考图：长边超过 2560 或大于 1.2MB 的先缩一下再发（模型本来就会缩小参考图，出图效果不变；
// 服务器上行带宽小，一张 4K PNG 十几 MB 要传好几秒，缩完通常不到 1MB）
const MODEL_MAX = 2560;
async function forModel(img) {
  if (!img || !img.buffer || !/^image\//.test(String(img.mimetype || ''))) return img;
  const { width, height } = storage.imageSize(img.buffer);
  if (img.buffer.length <= 1.2 * 1024 * 1024 && Math.max(width, height) <= MODEL_MAX) return img;
  const r = await thumbs.recode(img.buffer, { max: MODEL_MAX, q: 92 }).catch(() => null);
  return r || img;
}

async function loadImages(list, { shrink = true } = {}) {
  const out = [];
  for (const u of list || []) {
    if (!u) continue;
    try { const img = await storage.fetchBuffer(u); out.push(shrink ? await forModel(img) : img); } catch (e) {
      if (!out.length) throw new Error('参考图读取失败：' + e.message);
    }
  }
  return out;
}

async function runSpec(spec, category = 'gen') {
  const rl = relay();
  if (spec.kind === 'text') {
    const text = await rl.chat({ system: spec.system, prompt: spec.prompt, images: (await loadImages(spec.images)).map((b) => b) });
    return { content: text };
  }
  if (spec.kind === 'video') {
    const img = spec.image || (spec.images || [])[0];
    const v = await rl.video({ modelKey: spec.modelKey, prompt: spec.prompt, image: img ? (await loadImages([img]))[0] : null, seconds: spec.seconds, ratio: spec.ratio });
    return { url: await saveOutput(v, 'video') };
  }
  if (spec.engine === 'matting') {
    const src = (await loadImages(spec.images.slice(0, 1), { shrink: false }))[0];   // 抠图要原分辨率
    if (!src) throw new Error('请先上传图片');
    const r = await matting.cutout(src, { bg: spec.bg || '', size: matting.parseSize(spec.size), type: spec.ptype || '' });
    return { url: (await storage.saveBuffer(r.buffer, { mimetype: r.mimetype, category })).fullurl, engine: r.engine, confidence: r.confidence };
  }
  const imgs = await loadImages(spec.images, { shrink: !spec.mask });   // 有蒙版的局部重绘：图和蒙版必须同尺寸，不缩
  let ratio = spec.ratio;
  // “原图/自动/跟随”比例：按第一张参考图的宽高推算，避免竖图被出成横图
  if (!/\d+\s*[:：]\s*\d+/.test(String(ratio || '')) && imgs[0]) {
    const { width, height } = storage.imageSize(imgs[0].buffer);
    if (width && height) {
      const g = (a, b) => (b ? g(b, a % b) : a);
      const d = g(width, height);
      ratio = `${width / d}:${height / d}`;
      if (width / d > 50) ratio = `${Math.round((width / height) * 100)}:100`;
    }
  }
  const outs = await rl.image({
    modelKey: spec.modelKey, prompt: spec.prompt, images: imgs, ratio, resolution: spec.resolution,
    mask: spec.mask ? (await loadImages([spec.mask], { shrink: false }))[0] : undefined, n: 1,
  });
  const actual = outs[0] && outs[0].buffer ? tierOf(storage.imageSize(outs[0].buffer)) : '';
  return { url: await saveOutput(outs[0], category), actual };
}

// 中转站实际出图的清晰度（按长边）：1K ≈1024，2K ≈1536~2048，4K ≈3000+
function tierOf(sz) {
  const long = Math.max(Number(sz && sz.width) || 0, Number(sz && sz.height) || 0);
  if (long < 700) return '';   // 异常小图不据此计价
  return long >= 2600 ? '4K' : long >= 1280 ? '2K' : '1K';
}
// 中转站实际出的图低于用户选的清晰度（模型不支持 4K 又没在后台设上限时会这样）：按实际清晰度计价，退回差价
function refundResolutionGap(r, spec, actual) {
  try {
    const want = String(spec.resolution || '').toUpperCase();
    if (!actual || !(r.cost > 0) || RES_ORDER.indexOf(actual) < 0 || RES_ORDER.indexOf(actual) >= RES_ORDER.indexOf(want)) return;
    const t = db.get('SELECT id, user_id, bill_user_id, scene, scene_name FROM yd_task WHERE id=?', r.task_id);
    const fair = priceOf({ ...spec, resolution: actual }, {});
    const diff = Number(r.cost) - Number(fair);
    if (!t || !(diff > 0)) return;
    users.refund(t.bill_user_id || t.user_id, diff, `实际出图 ${actual}（所选 ${want}）退差价 · ${t.scene_name || t.scene}`, `task:${t.id}:${r.idx}:res`);
    db.update('yd_task_result', { cost: fair }, 'id=?', r.id);
    db.run('UPDATE yd_task SET refunded_points=refunded_points+? WHERE id=?', diff, t.id);
    console.log(`[engine] task ${t.id}#${r.idx} 所选 ${want}，中转站实际出 ${actual}，退差价 ${diff} 点`);
  } catch (e) { console.error('[engine] 退差价失败', e.message); }
}

async function processResult(r) {
  const spec = jsonParse(r.spec, {});
  const t = db.get('SELECT board, module, kind FROM yd_task WHERE id=?', r.task_id) || {};
  try {
    const out = await runWithFeature({ module: t.module, board: t.board, kind: t.kind }, () => runSpec(spec, t.board || 'gen'));
    db.update('yd_task_result', { status: 'succeeded', url: out.url || '', content: out.content || '', error: '', updatetime: now() }, 'id=?', r.id);
    refundResolutionGap(r, spec, out.actual);
  } catch (e) {
    const retry = Number(S.get('relay').retry_task ?? 0);
    const attempts = (r.attempts || 0) + 1;
    if (attempts <= retry) db.update('yd_task_result', { status: 'queued', attempts, error: cleanError(e), updatetime: now() }, 'id=?', r.id);
    else db.update('yd_task_result', { status: 'failed', attempts, error: cleanError(e), updatetime: now() }, 'id=?', r.id);
    console.warn(`[engine] task ${r.task_id}#${r.idx} 失败：`, e.message);
  }
  refreshTask(r.task_id);
}

function limitOf(billUserId) {
  const u = users.getUser(billUserId);
  return u ? users.concurrencyOf(u) : 2;
}

async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    const globalMax = Number((config.worker || {}).globalConcurrency || 8);
    if (runningTotal >= globalMax) return;
    const rows = db.all(
      `SELECT r.*, t.bill_user_id FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id
       WHERE r.status='queued' AND r.deleted=0 AND t.deleted=0 ORDER BY r.id LIMIT 100`,
    );
    const jobs = rows.map((r) => ({ bill: r.bill_user_id, row: r, id: r.id }));
    const limits = new Map();
    for (const j of jobs) {
      if (runningTotal >= globalMax) break;
      if (!limits.has(j.bill)) limits.set(j.bill, limitOf(j.bill));
      const cur = runningByBill.get(j.bill) || 0;
      if (cur >= limits.get(j.bill)) continue;
      // 抢占
      const changed = db.run(`UPDATE yd_task_result SET status='running', starttime=?, updatetime=? WHERE id=? AND status='queued'`, now(), now(), j.id).changes;
      if (!changed) continue;
      db.run(`UPDATE yd_task SET status='running', updatetime=? WHERE id=? AND status='queued'`, now(), j.row.task_id);
      runningByBill.set(j.bill, cur + 1);
      runningTotal++;
      const p = processResult(j.row);
      p.catch((e) => console.error('[engine]', e)).finally(() => {
        runningByBill.set(j.bill, Math.max(0, (runningByBill.get(j.bill) || 1) - 1));
        runningTotal = Math.max(0, runningTotal - 1);
        setImmediate(kick);
      });
    }
  } catch (e) {
    console.error('[engine] tick error', e);
  } finally { ticking = false; }
}

function kick() { setImmediate(() => { tick(); }); }

function start() {
  // 进程重启：把中断的任务重新排队
  db.run(`UPDATE yd_task_result SET status='queued' WHERE status='running'`);
  if ((config.worker || {}).enabled === false) return;
  timer = setInterval(tick, Number((config.worker || {}).tickMs || 1000));
  kick();
}
function stop() { if (timer) clearInterval(timer); }

module.exports = {
  relay, priceOf, mattingQuota, capResolution, modelMaxResolution, createTask, getTask, canSee, resultsOf, serializeResult, taskBrief, statusPayload, regen, refreshTask,
  onTaskFinished, start, stop, kick, runSpec, cleanError, loadImages, saveOutput, checkBanned,
};
