'use strict';
// 抠图：只用佐糖抠图接口（后台 系统设置 → 抠图 填 Key）。
//   纯色底（白底 / 证件照底色）直接让佐糖出 JPG；证件照尺寸裁切在前端完成。
const S = require('../core/settings');
const storage = require('../core/storage');

function cfg() {
  return S.get('matting') || {};
}

// ---------------- 佐糖 ----------------
class MattingError extends Error {}

async function picwishCutout(buffer, o = {}) {
  const c = cfg();
  const key = String(c.picwish_key || '').trim();
  if (!key) throw new MattingError('未配置佐糖 API Key（后台 系统设置 → 抠图）');
  const base = String(c.picwish_base || 'https://techsz.aoscdn.com').replace(/\/+$/, '');
  const deadline = Date.now() + (Number(c.picwish_timeout) || 90) * 1000;
  const call = async (url, init) => {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), Math.max(5000, Math.min(60000, deadline - Date.now())));
    try {
      const r = await fetch(url, { ...init, headers: { 'X-API-KEY': key, ...(init && init.headers) }, signal: ctl.signal });
      let j = null;
      try { j = await r.json(); } catch { /* 非 JSON */ }
      if (!j) throw new MattingError(`佐糖接口返回异常（HTTP ${r.status}）`);
      if (Number(j.status) !== 200) throw new MattingError(`佐糖接口错误（${j.status}）：${j.message || ''}`.trim());
      return j.data || {};
    } catch (e) {
      if (e.name === 'AbortError') throw new MattingError('佐糖接口超时');
      throw e;
    } finally { clearTimeout(t); }
  };
  const fd = new FormData();
  fd.append('sync', '0');
  fd.append('image_file', new Blob([buffer], { type: storage.sniff(buffer) || 'image/png' }), 'image.' + ((storage.sniff(buffer) || 'image/png').split('/')[1] || 'png'));
  if (o.type || c.picwish_type) fd.append('type', String(o.type || c.picwish_type));
  fd.append('return_type', '1');
  // 只换纯色底、不裁尺寸时让佐糖直接出带底色的 JPG（不需要本地引擎）
  const solid = o.bg && /^#?[0-9a-f]{3}([0-9a-f]{3})?$/i.test(String(o.bg));   // 纯色底直接让佐糖出（证件照裁尺寸在后面可选做）
  if (solid) {
    let hex = String(o.bg).replace('#', '');
    if (hex.length === 3) hex = hex.split('').map((x) => x + x).join('');
    fd.append('format', 'jpg');
    fd.append('bg_color', hex.toLowerCase());
  } else fd.append('format', 'png');
  const started = Date.now();
  const { task_id: id } = await call(`${base}/api/tasks/visual/segmentation`, { method: 'POST', body: fd });
  if (!id) throw new MattingError('佐糖接口没有返回任务号');
  for (;;) {
    if (Date.now() > deadline) throw new MattingError('佐糖抠图超时');
    await new Promise((r) => setTimeout(r, 1000));
    const d = await call(`${base}/api/tasks/visual/segmentation/${encodeURIComponent(id)}`, { method: 'GET' });
    const st = Number(d.state);
    if (st === 1 && d.image) {
      const out = await storage.fetchBuffer(d.image, { timeout: 60000 });
      return { buffer: out.buffer, mimetype: solid ? 'image/jpeg' : 'image/png', engine: 'picwish', ms: Date.now() - started, confidence: 1, done: true };
    }
    if (st < 0) throw new MattingError(`佐糖抠图失败（状态 ${st}）`);
  }
}

/**
 * 抠图主入口
 * @param {object} img { buffer, mimetype }
 * @param {object} o { bg, type }
 */
async function cutout(img, o = {}) {
  return picwishCutout(img.buffer, o);
}

/** 解析证件照尺寸 "295x413" / "295×413px" / [295,413] */
function parseSize(v) {
  if (Array.isArray(v) && v.length >= 2) return [Number(v[0]), Number(v[1])].every((n) => n > 0) ? [Number(v[0]), Number(v[1])] : null;
  const m = String(v || '').match(/(\d{2,5})\s*[x×*X]\s*(\d{2,5})/);
  return m ? [Number(m[1]), Number(m[2])] : null;
}

/** 后台「抠图」页状态：只看佐糖 Key 是否已填 */
async function localStatus() {
  const k = String(cfg().picwish_key || '').trim();
  return { ok: !!k, engine: 'picwish', error: k ? '' : '未配置佐糖 API Key', model: 'picwish' };
}

module.exports = { cutout, picwishCutout, localStatus, parseSize, MattingError };
