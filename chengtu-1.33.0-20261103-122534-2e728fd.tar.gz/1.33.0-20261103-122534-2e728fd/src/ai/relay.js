'use strict';
/**
 * 中转站（OpenAI 兼容 API）调用封装 —— 生图 / 改图 / 多图融合 / 对话文本 / 识图 / 流式输出 / 视频
 *
 * 可独立使用（不依赖本项目其它文件，Node >= 18 自带 fetch/FormData/Blob 即可）：
 *
 *   const { RelayClient } = require('./relay');
 *   const relay = new RelayClient({
 *     channels: [{ id: 'main', base_url: 'https://你的中转站域名', api_key: 'sk-xxx', timeout: 300 }],
 *     image_models: { m1: { channel: 'main', model: 'gpt-image-1', mode: 'openai', size_strategy: 'openai', quality: 'high' } },
 *     chat_model:   { channel: 'main', model: 'gpt-4o-mini' },
 *     vision_model: { channel: 'main', model: 'gpt-4o' },
 *     video_models: { m1: { channel: 'main', model: 'sora-2', mode: 'openai-video', seconds: 8 } },
 *   });
 *   // 文生图
 *   const imgs = await relay.image({ modelKey: 'm1', prompt: '一只橘猫坐在窗台', ratio: '3:4', resolution: '2K' });
 *   // 改图（传入参考图：URL / Buffer / data URI 均可）
 *   const edited = await relay.image({ modelKey: 'm1', prompt: '把背景换成海边', images: ['https://.../a.png'] });
 *   // imgs[0] => { buffer, mimetype } 或 { url }
 *   // 对话 / 识图 / 流式
 *   const text = await relay.chat({ prompt: '写一句文案', images: ['https://.../a.png'], onDelta: (t) => process.stdout.write(t) });
 *
 * 支持的生图协议（mode）：
 *   - 'openai'  ：/v1/images/generations（文生图）与 /v1/images/edits（带参考图，multipart，image[] 多图）—— gpt-image-1 / gpt-image-2 / dall-e 等
 *   - 'chat'    ：/v1/chat/completions，返回内容里带图片（data URI / 图片链接 / message.images）—— 多数中转站的 gemini-2.5-flash-image、nano-banana、
 *                 gpt-4o-image、doubao-seedream 等“对话出图”模型
 *   - 'gemini'  ：/v1beta/models/{model}:generateContent 原生 Gemini 协议（inline_data）
 * 视频协议：
 *   - 'openai-video'：/v1/videos（Sora 2 风格：创建 → 轮询 → /content 下载）
 *   - 'chat-video'  ：/v1/chat/completions，从返回文本中提取 mp4 链接（部分中转站的 veo / kling / 即梦 视频模型）
 */

const DEFAULT_TIMEOUT = 300;

class RelayError extends Error {
  constructor(message, status = 0, body = '') {
    super(message);
    this.status = status;
    this.body = body;
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function sniffMime(buf) {
  if (!buf || buf.length < 12) return 'application/octet-stream';
  if (buf[0] === 0x89 && buf[1] === 0x50) return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8) return 'image/jpeg';
  if (buf.slice(0, 4).toString() === 'RIFF' && buf.slice(8, 12).toString() === 'WEBP') return 'image/webp';
  if (buf.slice(0, 3).toString() === 'GIF') return 'image/gif';
  if (buf.slice(4, 8).toString() === 'ftyp') return 'video/mp4';
  return 'application/octet-stream';
}
const EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'video/mp4': 'mp4' };

/** 比例 + 分辨率 → 尺寸字符串 */
function computeSize(ratio, resolution, strategy = 'openai') {
  const m = /^(\d+(?:\.\d+)?)\s*[:：xX×]\s*(\d+(?:\.\d+)?)$/.exec(String(ratio || '').trim());
  if (strategy === 'none') return null;
  if (!m) return strategy === 'openai' ? 'auto' : null;
  const rw = Number(m[1]);
  const rh = Number(m[2]);
  const r = rw / rh;
  if (strategy === 'openai') {
    if (r > 1.2) return '1536x1024';
    if (r < 0.83) return '1024x1536';
    return '1024x1024';
  }
  // pixels：按分辨率长边计算精确尺寸（16 的倍数）
  const long = { '1K': 1024, '2K': 2048, '4K': 3840 }[String(resolution || '1K').toUpperCase()] || 1024;
  let w, h;
  if (r >= 1) { w = long; h = Math.round(long / r); } else { h = long; w = Math.round(long * r); }
  // 4K 总像素上限 3840×2160（gpt-image-2 等的限制）：方图 4K = 2880×2880
  const MAXPX = 3840 * 2160;
  if (w * h > MAXPX) { const k = Math.sqrt(MAXPX / (w * h)); w = Math.floor(w * k); h = Math.floor(h * k); }
  const r16 = (x) => Math.max(256, Math.floor(x / 16) * 16);
  return `${r16(w)}x${r16(h)}`;
}

/** 把多种格式的图片输入统一成 { buffer, mimetype } */
async function toImageBuffer(input, fetchTimeout = 60000) {
  if (!input) throw new RelayError('参考图为空');
  if (Buffer.isBuffer(input)) return { buffer: input, mimetype: sniffMime(input) };
  if (typeof input === 'object' && input.buffer) return { buffer: input.buffer, mimetype: input.mimetype || sniffMime(input.buffer) };
  const s = String(input).trim();
  if (s.startsWith('data:')) {
    const m = /^data:([^;,]+)?;base64,(.*)$/s.exec(s);
    if (!m) throw new RelayError('data URI 格式错误');
    const buffer = Buffer.from(m[2], 'base64');
    return { buffer, mimetype: m[1] || sniffMime(buffer) };
  }
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), fetchTimeout);
  try {
    const res = await fetch(s, { signal: ctrl.signal, headers: { 'User-Agent': 'Mozilla/5.0 (compatible; RelayClient/1.0)' } });
    if (!res.ok) throw new RelayError(`参考图下载失败 HTTP ${res.status}：${s.slice(0, 120)}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    return { buffer, mimetype: sniffMime(buffer) !== 'application/octet-stream' ? sniffMime(buffer) : (res.headers.get('content-type') || 'image/png') };
  } finally { clearTimeout(t); }
}
const toDataUri = ({ buffer, mimetype }) => `data:${mimetype || 'image/png'};base64,${buffer.toString('base64')}`;

/** 从 chat 返回内容里提取图片（data URI / markdown 图片 / 裸链接 / message.images） */
function extractImagesFromChat(json) {
  const out = [];
  const choice = (json.choices || [])[0] || {};
  const msg = choice.message || choice.delta || {};
  const push = (u) => {
    if (!u) return;
    if (u.startsWith('data:')) {
      const m = /^data:([^;,]+)?;base64,(.*)$/s.exec(u);
      if (m) out.push({ buffer: Buffer.from(m[2], 'base64'), mimetype: m[1] || 'image/png' });
    } else out.push({ url: u });
  };
  for (const im of msg.images || []) push((im.image_url && im.image_url.url) || im.url || im.b64_json && `data:image/png;base64,${im.b64_json}`);
  const content = msg.content;
  const parts = Array.isArray(content) ? content : [{ type: 'text', text: content || '' }];
  for (const p of parts) {
    if (!p) continue;
    if (p.type === 'image_url' && p.image_url) push(p.image_url.url);
    if (p.type === 'image' && (p.image_url || p.url)) push((p.image_url && p.image_url.url) || p.url);
    if (p.inline_data || p.inlineData) {
      const d = p.inline_data || p.inlineData;
      out.push({ buffer: Buffer.from(d.data, 'base64'), mimetype: d.mime_type || d.mimeType || 'image/png' });
    }
    const text = typeof p === 'string' ? p : p.text || '';
    if (text) {
      const re = /(data:image\/[a-z+]+;base64,[A-Za-z0-9+/=]+)|!\[[^\]]*\]\((https?:\/\/[^)\s]+)\)|(https?:\/\/[^\s"'<>)]+\.(?:png|jpe?g|webp|gif)(?:\?[^\s"'<>)]*)?)/gi;
      let m;
      while ((m = re.exec(text))) push(m[1] || m[2] || m[3]);
    }
  }
  // 去重
  const seen = new Set();
  return out.filter((x) => {
    const k = x.url || (x.buffer && x.buffer.length + ':' + x.buffer.slice(0, 32).toString('hex'));
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

// ---------------- 功能 → 模型 路由 ----------------
// 当前请求属于哪个前台功能（engine / 文本接口在调用前设置），用于按功能选择模型
const { AsyncLocalStorage } = require('node:async_hooks');
const featureCtx = new AsyncLocalStorage();
/** @param {{module?:string, board?:string, kind?:string, text?:string}} f */
function runWithFeature(f, fn) { return featureCtx.run({ ...(featureCtx.getStore() || {}), ...f }, fn); }

/** 根据模型名自动判断类型与调用方式 */
function guessModel(name) {
  const n = String(name || '').toLowerCase();
  if (/sora|veo|kling|hailuo|seedance|vidu|runway|pika|luma|wan.*(t2v|i2v)|video/.test(n)) {
    return { type: 'video', mode: /sora/.test(n) ? 'openai-video' : 'chat-video' };
  }
  if (/gpt-image|dall-e|dalle/.test(n)) return { type: 'image', mode: 'openai', size_strategy: 'openai' };
  if (/grok.*imag|imagine|hunyuan.*image|hy.*image|wanx|wan2.*image|seededit|image-\d|-image\b|image$/.test(n) && !/vision|understand/.test(n)) return { type: 'image', mode: 'openai', size_strategy: 'pixels' };
  if (/flux|imagen|recraft|ideogram|qwen-image|kolors|sd3|stable-diffusion|sdxl|hidream|cogview/.test(n)) return { type: 'image', mode: 'openai', size_strategy: 'pixels' };
  if (/gemini.*image|image-preview|nano-?banana/.test(n)) return { type: 'image', mode: 'chat', size_strategy: 'none', caps: ['image', 'text', 'vision'] };   // 多模态：能出图，也能对话、看图
  if (/seedream|jimeng|doubao.*image|midjourney|mj_|banana/.test(n)) return { type: 'image', mode: 'chat', size_strategy: 'none' };
  if (/embedding|whisper|tts|audio|moderation|rerank/.test(n)) return { type: 'other', mode: '' };
  if (/gpt-4o|gpt-4\.1|gpt-5|chatgpt|claude|gemini|qwen.*vl|qvq|glm-4v|glm-4\.5v|vision|doubao.*(vision|seed)|o3|o4|grok-4|llava|pixtral/.test(n)) return { type: 'vision', mode: 'chat', caps: ['text', 'vision'] };
  return { type: 'text', mode: 'chat' };
}
/**
 * 模型能做什么：后台「模型库」可多选 生图 / 文字 / 识图 / 视频（meta.caps）。
 * 老配置只有单个 type：image / video / text / vision（vision = 文字 + 识图）/ other
 */
function capsOf(meta = {}) {
  if (Array.isArray(meta.caps)) return meta.caps.filter((c) => ['image', 'text', 'vision', 'video'].includes(c));
  const t = meta.type;
  if (t === 'image') return ['image'];
  if (t === 'video') return ['video'];
  if (t === 'vision') return ['text', 'vision'];
  if (t === 'other') return [];
  return ['text'];
}
/** type：image / video / text（文字或识图都算）/ vision */
function canDo(meta, type) {
  const c = capsOf(meta);
  if (type === 'text') return c.includes('text') || c.includes('vision');
  return c.includes(type);
}
const parseRef = (ref) => { const s = String(ref || ''); const i = s.indexOf('::'); return i > 0 ? { channel: s.slice(0, i), model: s.slice(i + 2) } : null; };

class RelayClient {
  /**
   * @param {object} cfg  见文件头示例；与后台「中转站设置」JSON 同结构
   * @param {object} [hooks] { log(entry) } 可选：每次调用结束回调（耗时/成功/错误），用于记录日志
   */
  constructor(cfg = {}, hooks = {}) {
    this.cfg = cfg;
    this.hooks = hooks;
  }

  channel(id) {
    const list = (this.cfg.channels || []).filter((c) => c && c.enabled !== false);
    const ch = list.find((c) => c.id === id) || list[0];
    if (!ch || !ch.base_url) throw new RelayError('未配置可用的中转站通道（base_url / api_key）');
    return ch;
  }

  _url(ch, p) {
    let base = String(ch.base_url).replace(/\/+$/, '');
    if (/\/v1$/.test(base) && p.startsWith('/v1')) base = base.slice(0, -3);
    return base + p;
  }

  async _fetch(ch, p, { method = 'POST', json, form, timeout, headers = {}, raw = false } = {}) {
    const ctrl = new AbortController();
    const ms = (timeout || ch.timeout || DEFAULT_TIMEOUT) * 1000;
    const timer = setTimeout(() => ctrl.abort(), ms);
    const h = { Authorization: `Bearer ${ch.api_key}`, ...headers };
    if (ch.headers && typeof ch.headers === 'object') Object.assign(h, ch.headers);
    let body;
    if (json !== undefined) { h['Content-Type'] = 'application/json'; body = JSON.stringify(json); }
    if (form) body = form;
    try {
      const res = await fetch(this._url(ch, p), { method, headers: h, body, signal: ctrl.signal });
      if (raw) return res;
      const text = await res.text();
      let data = null;
      try { data = text ? JSON.parse(text) : {}; } catch { data = null; }
      if (!res.ok) {
        const msg = (data && (data.error && (data.error.message || data.error) || data.message || data.msg)) || text.slice(0, 300) || `HTTP ${res.status}`;
        throw new RelayError(`中转站返回错误（${res.status}）：${typeof msg === 'string' ? msg : JSON.stringify(msg)}`, res.status, text);
      }
      if (data === null) throw new RelayError('中转站返回的不是 JSON：' + text.slice(0, 200), res.status, text);
      if (data.error && !data.data && !data.choices && !data.candidates) {
        throw new RelayError('中转站错误：' + (data.error.message || JSON.stringify(data.error)), res.status, text);
      }
      return data;
    } catch (e) {
      if (e.name === 'AbortError') throw new RelayError(`请求中转站超时（${ms / 1000}s）`);
      if (e instanceof RelayError) throw e;
      throw new RelayError('连接中转站失败：' + (e.cause && e.cause.message || e.message));
    } finally { clearTimeout(timer); }
  }

  async _withRetry(fn, retry = this.cfg.retry ?? 1) {
    let lastErr;
    for (let i = 0; i <= retry; i++) {
      try { return await fn(i); } catch (e) {
        lastErr = e;
        // 4xx（参数/余额/内容审核）不重试
        if (e.status && e.status >= 400 && e.status < 500 && e.status !== 429) break;
        if (i < retry) await sleep(1500 * (i + 1));
      }
    }
    throw lastErr;
  }

  _log(entry) { try { this.hooks.log && this.hooks.log(entry); } catch {} }

  /** "通道::模型" → 完整模型配置（类型/调用方式取自模型库，未设置则按名称自动判断） */
  modelFromRef(ref) {
    const r = parseRef(typeof ref === 'object' && ref ? ref.ref : ref);
    if (!r) return null;
    const saved = (this.cfg.model_meta || {})[`${r.channel}::${r.model}`] || {};
    const g = guessModel(r.model);
    if (saved.type && !saved.caps) delete g.caps;   // 后台设过类型的老配置：按设过的类型算用途，不用名字猜的
    const meta = { ...g, ...saved };
    return { channel: r.channel, model: r.model, ...meta, extra: meta.extra || {} };
  }

  /**
   * 备用模型接力：主模型失败（中转站故障、超时、余额不足、Key 失效、没返回结果等）时，
   * 依次换用模型库里设置的「备用模型」重试，最多 3 层。内容审核类失败不切换。
   */
  async _withFallback(m, type, run, canSwitch = () => true) {
    const tried = new Set();
    let cur = m;
    let lastErr;
    for (let hop = 0; hop < 4 && cur; hop++) {
      const ref = `${cur.channel}::${cur.model}`;
      tried.add(ref);
      try {
        const r = await run(cur);
        return r;
      } catch (e) {
        lastErr = e;
        if (this.cfg.fallback_enabled === false || !canSwitch() || !RelayClient.canFallback(e)) throw e;
        const next = this.fallbackOf(ref, type, tried);
        if (!next) throw e;
        this._log({ kind: type === 'text' ? 'chat' : type, model: cur.model, ok: false, ms: 0, error: `主模型失败，切换备用 ${next.model}：${String(e.message).slice(0, 200)}` });
        cur = next;
      }
    }
    throw lastErr;
  }

  /** 模型库里给这个模型设置的备用模型（类型需一致、不能循环） */
  fallbackOf(ref, type, tried) {
    const fb = ((this.cfg.model_meta || {})[ref] || {}).fallback;
    if (!fb || tried.has(fb)) return null;
    const m = this.modelFromRef(fb);
    if (!m) return null;
    if (!canDo(m, type)) return null;
    const ch = (this.cfg.channels || []).find((c) => c.id === m.channel);
    if (!ch || ch.enabled === false || !ch.base_url) return this.fallbackOf(fb, type, new Set([...tried, fb]));
    return m;
  }

  static canFallback(e) {
    const msg = String((e && e.message) || e || '');
    if (/提示词为空|参考图读取失败|未配置/.test(msg)) return false;
    if (/content.?policy|safety|moderation|审核|sensitive|blocked|违规|inappropriate|not allowed/i.test(msg)) return false;
    return true;
  }

  /** 档位配置（m1/m2、文本、识图、视频）如果是从模型库选的（带 ref），用模型库里的最新设置 */
  slot(m) {
    if (m && m.ref) { const r = this.modelFromRef(m.ref); if (r) return { ...r, ...(m.quality ? { quality: m.quality } : {}), label: m.label }; }
    return m;
  }

  /** 当前功能是否单独指定了模型：模块 → 板块 → 任务类型 */
  featureModel(type) {
    const f = featureCtx.getStore();
    const map = this.cfg.feature_models || {};
    if (!f) return null;
    const keys = type === 'text' ? [f.text && 'text:' + f.text] : [f.module, f.board && 'board:' + f.board, f.kind && 'kind:' + f.kind];
    for (const k of keys) {
      if (!k || !map[k]) continue;
      const m = this.modelFromRef(map[k]);
      if (m && canDo(m, type)) return m;
    }
    return null;
  }

  imageModel(modelKey) {
    const map = this.cfg.image_models || {};
    const pick = map[modelKey] && map[modelKey].enabled !== false && (map[modelKey].model || map[modelKey].ref) ? map[modelKey] : null;   // 前台关掉 / 没配模型的档位退回 m1
    // 用户在前台明确选了第一个以外的模型：以用户选的为准；选默认（m1）时，后台给功能单独指定的模型优先
    if (!(pick && modelKey !== 'm1')) { const fm = this.featureModel('image'); if (fm) return fm; }
    const m = this.slot(pick || map.m1 || Object.values(map)[0]);
    if (!m || !m.model) throw new RelayError(`未配置生图模型（${modelKey}）`);
    return m;
  }

  /**
   * 生图 / 改图
   * @param {object} o
   * @param {string} o.prompt          提示词
   * @param {Array}  [o.images]        参考图（URL / Buffer / data URI），有图则走“改图/图生图”
   * @param {*}      [o.mask]          蒙版（openai 模式：透明区域为待修改区域）
   * @param {string} [o.modelKey]      m1 / m2 …（对应 image_models 的 key）
   * @param {string} [o.ratio]         '3:4' '1:1' '16:9' 'auto'
   * @param {string} [o.resolution]    '1K' '2K' '4K'
   * @param {number} [o.n]             张数（openai 模式一次请求多张；其它模式循环）
   * @returns {Promise<Array<{buffer?:Buffer,mimetype?:string,url?:string}>>}
   */
  async image(o = {}) {
    const m = (o.modelRef && this.modelFromRef(o.modelRef)) || this.imageModel(o.modelKey);
    return this._withFallback(m, 'image', (mm) => this._imageOnce(mm, o));
  }

  async _imageOnce(m, o) {
    // 模型设置了「最高清晰度」时降档（备用模型的上限可能更低）
    const max = String(m.max_resolution || ((this.cfg.model_meta || {})[`${m.channel}::${m.model}`] || {}).max_resolution || '').toUpperCase();
    const ORDER = ['1K', '2K', '4K'];
    const want = String(o.resolution || '').toUpperCase();
    if (max && ORDER.includes(want) && ORDER.indexOf(want) > ORDER.indexOf(max)) o = { ...o, resolution: max };
    const ch = this.channel(m.channel);
    const started = Date.now();
    const mode = m.mode || 'openai';
    const n = Math.max(1, Math.min(10, Number(o.n) || 1));
    const refs = [];
    for (const im of (o.images || []).slice(0, Number(this.cfg.max_ref_images) || 10)) refs.push(await toImageBuffer(im));
    let prompt = String(o.prompt || '').trim();
    if (!prompt) throw new RelayError('提示词为空');
    const strategy = m.size_strategy || 'openai';
    let size = computeSize(o.ratio, o.resolution, strategy);
    // gpt-image-2 及以后支持任意尺寸：选 2K / 4K 时传真实像素，不再固定 1024（gpt-image-1 / dall-e 仍用三档）
    let legacySize = null;
    if (strategy === 'openai' && /^(2K|4K)$/i.test(String(o.resolution || '')) && !/gpt-image-1|dall-?e/i.test(m.model)) {
      const px = computeSize(o.ratio, o.resolution, 'pixels');
      if (px) { legacySize = size; size = px; }
    }
    if (o.ratio && o.ratio !== 'auto' && /\d/.test(o.ratio) && m.ratio_hint !== false) {
      prompt += `\n\n[输出画面比例：${o.ratio}${o.resolution ? `，清晰度 ${o.resolution}` : ''}]`;
    }
    try {
      let result;
      if (mode === 'chat') result = await this._imageViaChat(ch, m, prompt, refs, n, o);
      else if (mode === 'gemini') result = await this._imageViaGemini(ch, m, prompt, refs, n, o);
      else {
        try { result = await this._imageViaOpenAI(ch, m, prompt, refs, n, size, o); } catch (e) {
          // 中转站不认这个尺寸：退回 1024 三档再试一次
          if (!legacySize || !/size|尺寸|分辨率|resolution|invalid|参数|unsupported|not supported/i.test(String(e.message))) throw e;
          this._log({ kind: 'image', model: m.model, ok: false, ms: Date.now() - started, error: `不支持 ${size}，改用 ${legacySize}：${String(e.message).slice(0, 160)}` });
          result = await this._imageViaOpenAI(ch, m, prompt, refs, n, legacySize, o);
        }
      }
      if (!result.length) throw new RelayError('中转站未返回图片（可能触发了内容审核，或模型不支持出图）');
      this._log({ kind: 'image', model: m.model, ok: true, ms: Date.now() - started });
      return result;
    } catch (e) {
      this._log({ kind: 'image', model: m.model, ok: false, ms: Date.now() - started, error: e.message });
      throw e;
    }
  }

  async _imageViaOpenAI(ch, m, prompt, refs, n, size, o) {
    const extra = { ...(m.extra || {}), ...(o.extra || {}) };
    const timeout = Number(this.cfg.image_timeout) || ch.timeout;
    const parse = (data) => (data.data || []).map((d) => {
      if (d.b64_json) { const buffer = Buffer.from(d.b64_json, 'base64'); return { buffer, mimetype: sniffMime(buffer) }; }
      if (d.url) {
        if (d.url.startsWith('data:')) { const b = Buffer.from(d.url.split(',')[1] || '', 'base64'); return { buffer: b, mimetype: sniffMime(b) }; }
        return { url: d.url };
      }
      return null;
    }).filter(Boolean);
    if (!refs.length) {
      const body = { model: m.model, prompt, n, ...extra };
      if (size) body.size = size;
      if (m.quality) body.quality = m.quality;
      if (m.response_format) body.response_format = m.response_format;
      if (m.output_format) body.output_format = m.output_format;
      return this._withRetry(async () => parse(await this._fetch(ch, '/v1/images/generations', { json: body, timeout })));
    }
    return this._withRetry(async () => {
      const form = new FormData();
      form.append('model', m.model);
      form.append('prompt', prompt);
      form.append('n', String(n));
      if (size) form.append('size', size);
      if (m.quality) form.append('quality', m.quality);
      if (m.response_format) form.append('response_format', m.response_format);
      if (m.output_format) form.append('output_format', m.output_format);
      for (const [k, v] of Object.entries(extra)) form.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
      const field = m.edit_image_field || (refs.length > 1 ? 'image[]' : 'image');
      refs.forEach((r, i) => form.append(field, new Blob([r.buffer], { type: r.mimetype }), `image_${i + 1}.${EXT[r.mimetype] || 'png'}`));
      if (o.mask) {
        const mk = await toImageBuffer(o.mask);
        form.append('mask', new Blob([mk.buffer], { type: mk.mimetype }), 'mask.png');
      }
      return parse(await this._fetch(ch, '/v1/images/edits', { form, timeout }));
    });
  }

  async _imageViaChat(ch, m, prompt, refs, n, o) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const content = [{ type: 'text', text: prompt }];
      for (const r of refs) content.push({ type: 'image_url', image_url: { url: toDataUri(r) } });
      const body = { model: m.model, messages: [{ role: 'user', content }], stream: false, ...(m.extra || {}) };
      if (m.modalities !== false) body.modalities = body.modalities || ['image', 'text'];
      if (o.ratio && m.send_aspect_ratio) body.image_config = { aspect_ratio: o.ratio, image_size: o.resolution };
      const data = await this._withRetry(() => this._fetch(ch, '/v1/chat/completions', { json: body, timeout: Number(this.cfg.image_timeout) || ch.timeout }));
      const imgs = extractImagesFromChat(data);
      if (!imgs.length) {
        const txt = (((data.choices || [])[0] || {}).message || {}).content;
        throw new RelayError('模型没有返回图片：' + String(typeof txt === 'string' ? txt : JSON.stringify(txt || '')).slice(0, 200));
      }
      out.push(imgs[0]);
    }
    return out;
  }

  async _imageViaGemini(ch, m, prompt, refs, n, o) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const parts = [{ text: prompt }];
      for (const r of refs) parts.push({ inline_data: { mime_type: r.mimetype, data: r.buffer.toString('base64') } });
      const gen = { responseModalities: ['TEXT', 'IMAGE'] };
      if (o.ratio && /\d/.test(o.ratio)) gen.imageConfig = { aspectRatio: o.ratio, ...(o.resolution ? { imageSize: String(o.resolution).toUpperCase() } : {}) };
      const body = { contents: [{ role: 'user', parts }], generationConfig: gen, ...(m.extra || {}) };
      const data = await this._withRetry(() => this._fetch(ch, `/v1beta/models/${m.model}:generateContent`, {
        json: body, headers: { 'x-goog-api-key': ch.api_key }, timeout: Number(this.cfg.image_timeout) || ch.timeout,
      }));
      const cand = (data.candidates || [])[0] || {};
      const ps = (cand.content && cand.content.parts) || [];
      const img = ps.find((p) => p.inlineData || p.inline_data);
      if (!img) throw new RelayError('Gemini 没有返回图片：' + (ps.map((p) => p.text).join(' ').slice(0, 200) || cand.finishReason || ''));
      const d = img.inlineData || img.inline_data;
      out.push({ buffer: Buffer.from(d.data, 'base64'), mimetype: d.mimeType || d.mime_type || 'image/png' });
    }
    return out;
  }

  /**
   * 对话 / 识图 / 流式文本
   * @param {object} o
   * @param {string} [o.system]   系统提示
   * @param {string} [o.prompt]   用户内容（也可直接传 messages）
   * @param {Array}  [o.images]   识图时附带的图片
   * @param {Array}  [o.messages] 自定义完整 messages（优先）
   * @param {boolean}[o.json]     要求返回 JSON（会加 response_format，并在结果里自动解析）
   * @param {Function}[o.onDelta] 传了即走流式，每段增量文本回调
   * @param {'chat'|'vision'} [o.which] 选择 chat_model 或 vision_model；带图默认 vision
   * @returns {Promise<string>} 完整文本（json=true 时可用 RelayClient.parseJson 解析）
   */
  async chat(o = {}) {
    const which = o.which || ((o.images && o.images.length) ? 'vision' : 'chat');
    const m = (o.modelRef && this.modelFromRef(o.modelRef)) || this.featureModel('text') || this.slot((which === 'vision' && this.cfg.vision_model && (this.cfg.vision_model.model || this.cfg.vision_model.ref) ? this.cfg.vision_model : this.cfg.chat_model)) || {};
    if (!m.model) throw new RelayError('未配置对话模型');
    if (o._noFallback) return this._chatOnce(m, o);
    let streamed = false;
    const wrapped = typeof o.onDelta === 'function' ? { ...o, onDelta: (t) => { streamed = true; o.onDelta(t); } } : o;
    return this._withFallback(m, 'text', (mm) => this._chatOnce(mm, wrapped), () => !streamed);
  }

  async _chatOnce(m, o) {
    const ch = this.channel(m.channel);
    let messages = o.messages;
    if (!messages) {
      messages = [];
      if (o.system) messages.push({ role: 'system', content: o.system });
      if (o.images && o.images.length) {
        const content = [{ type: 'text', text: o.prompt || '' }];
        for (const im of o.images.slice(0, 10)) {
          const b = await toImageBuffer(im).catch(() => null);
          if (b) content.push({ type: 'image_url', image_url: { url: toDataUri(b) } });
        }
        messages.push({ role: 'user', content });
      } else messages.push({ role: 'user', content: o.prompt || '' });
    }
    const body = { model: m.model, messages, temperature: o.temperature ?? m.temperature ?? 0.7, ...(m.extra || {}) };
    if (o.maxTokens) body.max_tokens = o.maxTokens;
    if (o.json && m.json_mode !== false) body.response_format = { type: 'json_object' };
    const started = Date.now();
    try {
      let text;
      if (typeof o.onDelta === 'function') text = await this._chatStream(ch, body, o.onDelta, o.timeout);
      else {
        const data = await this._withRetry(() => this._fetch(ch, '/v1/chat/completions', { json: { ...body, stream: false }, timeout: o.timeout }));
        const msg = ((data.choices || [])[0] || {}).message || {};
        text = typeof msg.content === 'string' ? msg.content : (msg.content || []).map((p) => p.text || '').join('');
      }
      this._log({ kind: 'chat', model: m.model, ok: true, ms: Date.now() - started });
      return text || '';
    } catch (e) {
      // 模型不支持 response_format 时自动降级重试一次
      if (o.json && body.response_format && /response_format|json_object/i.test(e.message || '')) {
        return this._chatOnce(m, { ...o, json: false, _noJson: true });
      }
      this._log({ kind: 'chat', model: m.model, ok: false, ms: Date.now() - started, error: e.message });
      throw e;
    }
  }

  async _chatStream(ch, body, onDelta, timeout) {
    const res = await this._fetch(ch, '/v1/chat/completions', { json: { ...body, stream: true }, timeout, raw: true });
    if (!res.ok) {
      const t = await res.text();
      throw new RelayError(`中转站返回错误（${res.status}）：${t.slice(0, 300)}`, res.status, t);
    }
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      const data = await res.json();
      const msg = ((data.choices || [])[0] || {}).message || {};
      const text = typeof msg.content === 'string' ? msg.content : '';
      if (text) onDelta(text);
      return text;
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder('utf-8');
    let buf = '';
    let full = '';
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n')) !== -1) {
        const line = buf.slice(0, idx).trim();
        buf = buf.slice(idx + 1);
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (payload === '[DONE]') continue;
        try {
          const j = JSON.parse(payload);
          const d = ((j.choices || [])[0] || {}).delta || {};
          const t = typeof d.content === 'string' ? d.content : '';
          if (t) { full += t; onDelta(t); }
        } catch {}
      }
    }
    return full;
  }

  /**
   * 视频生成
   * @param {object} o { modelKey, prompt, image(首帧/参考图), seconds, ratio, resolution, onProgress }
   * @returns {Promise<{buffer?:Buffer, mimetype?:string, url?:string}>}
   */
  async video(o = {}) {
    const map = this.cfg.video_models || {};
    const m = this.featureModel('video') || this.slot(map[o.modelKey] || map.m1 || Object.values(map)[0]);
    if (!m || !m.model) throw new RelayError('未配置视频模型');
    return this._withFallback(m, 'video', (mm) => this._videoOnce(mm, o));
  }

  async _videoOnce(m, o) {
    const ch = this.channel(m.channel);
    const started = Date.now();
    try {
      let r;
      if (m.mode === 'chat-video') r = await this._videoViaChat(ch, m, o);
      else r = await this._videoViaOpenAI(ch, m, o);
      this._log({ kind: 'video', model: m.model, ok: true, ms: Date.now() - started });
      return r;
    } catch (e) {
      this._log({ kind: 'video', model: m.model, ok: false, ms: Date.now() - started, error: e.message });
      throw e;
    }
  }

  async _videoViaOpenAI(ch, m, o) {
    const form = new FormData();
    form.append('model', m.model);
    form.append('prompt', String(o.prompt || ''));
    form.append('seconds', String(o.seconds || m.seconds || 8));
    const ratio = String(o.ratio || '');
    const size = m.size || (/^9:16|3:4|2:3/.test(ratio) ? '720x1280' : /^16:9|4:3|3:2/.test(ratio) ? '1280x720' : '720x1280');
    form.append('size', size);
    for (const [k, v] of Object.entries(m.extra || {})) form.append(k, String(v));
    if (o.image) {
      const b = await toImageBuffer(o.image);
      form.append('input_reference', new Blob([b.buffer], { type: b.mimetype }), `ref.${EXT[b.mimetype] || 'png'}`);
    }
    const job = await this._fetch(ch, '/v1/videos', { form, timeout: 120 });
    const id = job.id || job.task_id || (job.data && job.data.id);
    if (!id) throw new RelayError('视频任务创建失败：' + JSON.stringify(job).slice(0, 200));
    const deadline = Date.now() + (Number(m.max_wait) || 1200) * 1000;
    let info = job;
    while (Date.now() < deadline) {
      await sleep(Number(m.poll_interval || 8) * 1000);
      info = await this._fetch(ch, `/v1/videos/${id}`, { method: 'GET', timeout: 60 }).catch((e) => ({ status: 'polling_error', error: { message: e.message } }));
      const st = String(info.status || '').toLowerCase();
      if (typeof o.onProgress === 'function') o.onProgress(info.progress || 0, st);
      if (['completed', 'succeeded', 'success'].includes(st)) break;
      if (['failed', 'error', 'cancelled', 'canceled'].includes(st)) throw new RelayError('视频生成失败：' + ((info.error && info.error.message) || st));
    }
    const direct = info.video_url || info.url || (info.data && info.data.url) || (info.output && info.output.url);
    if (direct) return { url: direct };
    const res = await this._fetch(ch, `/v1/videos/${id}/content`, { method: 'GET', raw: true, timeout: 300 });
    if (!res.ok) throw new RelayError(`下载视频失败 HTTP ${res.status}`);
    const buffer = Buffer.from(await res.arrayBuffer());
    return { buffer, mimetype: 'video/mp4' };
  }

  async _videoViaChat(ch, m, o) {
    const content = [{ type: 'text', text: String(o.prompt || '') }];
    if (o.image) { const b = await toImageBuffer(o.image); content.push({ type: 'image_url', image_url: { url: toDataUri(b) } }); }
    const data = await this._fetch(ch, '/v1/chat/completions', {
      json: { model: m.model, messages: [{ role: 'user', content }], stream: false, ...(m.extra || {}) },
      timeout: Number(m.max_wait) || 1200,
    });
    const msg = ((data.choices || [])[0] || {}).message || {};
    const text = typeof msg.content === 'string' ? msg.content : JSON.stringify(msg.content || '');
    const mm = /(https?:\/\/[^\s"'<>)]+\.(?:mp4|mov|webm)(?:\?[^\s"'<>)]*)?)/i.exec(text) || /(https?:\/\/[^\s"'<>)]+)/i.exec(text);
    if (!mm) throw new RelayError('模型没有返回视频链接：' + text.slice(0, 200));
    return { url: mm[1] };
  }

  /** 列出中转站可用模型（后台“测试连接”用） */
  async listModels(channelId) {
    return (await this.listModelsDetailed(channelId)).map((x) => x.id);
  }

  /**
   * 拉取模型列表（含类型提示）。
   * 部分中转站（如 wokey）的 /v1/models 默认只返回文本模型，需加 ?output_modalities=image|video|all 才列出生图 / 视频模型，
   * 这里会依次尝试并合并结果。返回 [{ id, hint: 'image'|'video'|'text'|'' }]
   */
  async listModelsDetailed(channelId) {
    const ch = this.channel(channelId);
    const map = new Map();
    const hintOf = (x, q) => {
      const mods = [].concat(x.output_modalities || x.outputModalities || x.modalities || (x.architecture && x.architecture.output_modalities) || []).map(String);
      const t = String(x.type || x.model_type || x.task || x.category || x.endpoint_type || '').toLowerCase();
      if (mods.includes('video') || /video/.test(t)) return 'video';
      if (mods.includes('image') || /image/.test(t)) return 'image';
      if (q === 'image' || q === 'video') return q;
      if (mods.includes('text') || /chat|text|llm/.test(t)) return 'text';
      return '';
    };
    const add = (data, q) => {
      for (const x of (data && (data.data || data.models)) || []) {
        const id = typeof x === 'string' ? x : x.id || x.name;
        if (!id) continue;
        const h = typeof x === 'string' ? (q === 'image' || q === 'video' ? q : '') : hintOf(x, q);
        const old = map.get(id);
        if (!old) map.set(id, { id, hint: h });
        else if (!old.hint || (old.hint === 'text' && (h === 'image' || h === 'video'))) old.hint = h || old.hint;
      }
    };
    let firstErr = null;
    const ids = (d) => new Set(((d && (d.data || d.models)) || []).map((x) => (typeof x === 'string' ? x : x.id || x.name)).filter(Boolean));
    let base = null;
    try { base = await this._fetch(ch, '/v1/models', { method: 'GET', timeout: 30 }); add(base, ''); } catch (e) { firstErr = e; }
    const baseIds = ids(base);
    for (const q of ['all', 'image', 'video']) {
      let d;
      try { d = await this._fetch(ch, `/v1/models?output_modalities=${q}`, { method: 'GET', timeout: 30 }); } catch { continue; }
      const got = ids(d);
      // 中转站不认识这个参数时会原样返回全部模型：这种结果只合并、不当作类型依据
      const filtered = q !== 'all' && got.size > 0 && [...got].some((id) => !baseIds.has(id)) && ![...baseIds].every((id) => got.has(id));
      add(d, filtered ? q : '');
    }
    if (!map.size && firstErr) throw firstErr;
    return [...map.values()];
  }

  /** 宽松 JSON 解析：去掉 ```json 包裹，截取第一个 { … } / [ … ] */
  static parseJson(text) {
    if (text == null) return null;
    if (typeof text === 'object') return text;
    let s = String(text).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    try { return JSON.parse(s); } catch {}
    const a = s.indexOf('{'); const b = s.lastIndexOf('}');
    const c = s.indexOf('['); const d = s.lastIndexOf(']');
    const cand = [];
    if (a >= 0 && b > a) cand.push(s.slice(a, b + 1));
    if (c >= 0 && d > c) cand.push(s.slice(c, d + 1));
    for (const x of cand) { try { return JSON.parse(x); } catch {} }
    return null;
  }
}

module.exports = { RelayClient, RelayError, runWithFeature, guessModel, capsOf, canDo, featureCtx, computeSize, toImageBuffer, extractImagesFromChat, sniffMime };
