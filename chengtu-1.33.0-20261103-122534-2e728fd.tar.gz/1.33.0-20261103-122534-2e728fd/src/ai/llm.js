'use strict';
// 文本/识图类 AI 能力：套图大纲、风格分析、补充字段、投前检测、点击率预测、文案、流式帮写
const { RelayClient } = require('./relay');
const engine = require('./engine');

const parseJson = RelayClient.parseJson;
const str = (v) => (v == null ? '' : String(v).trim());
const langOf = (p) => str(p && p.settings && p.settings.language) || '中文';

async function loadImgs(list, max = 6) {
  const urls = (Array.isArray(list) ? list : [list]).map((x) => (typeof x === 'string' ? x : x && (x.url || x.src))).filter(Boolean).slice(0, max);
  return engine.loadImages(urls).catch(() => []);
}

async function askJson({ system, prompt, images = [] }) {
  const rl = engine.relay();
  const text = await rl.chat({ system, prompt, images, json: true, which: images.length ? 'vision' : 'chat', temperature: 0.6 });
  const j = parseJson(text);
  if (!j) throw new Error('AI 返回内容无法解析，请重试');
  return j;
}

function arr(j, ...keys) {
  if (Array.isArray(j)) return j;
  for (const k of keys) if (j && Array.isArray(j[k])) return j[k];
  if (j && j.data) return arr(j.data, ...keys);
  return [];
}

const OUTLINE_SYS = `你是资深电商视觉策划，同时具备商业摄影、版式设计和投放经验。根据商品图和商品信息，为电商套图逐张规划画面。
要求：
1. 每一张都能在商品图中指认同一件商品，商品的外观、颜色、材质、包装文字保持不变；
2. 画面互不重复：机位、背景、信息密度一眼可辨；第一张优先是干净、突出商品的主图；
3. suggestion 按「商品位置与占比 → 场景与道具 → 构图机位 → 光线 → 背景与色调」写成具体可执行的画面描述；不要写「高级感」「氛围感」这类空泛的词，要写清楚光从哪个方向来、台面是什么材质、旁边放什么道具；
4. copy 写放进画面的短文案：主标题不超过 10 个字，卖点每条不超过 6 个字、最多 3 条；不需要文案时留空；不夸大，不用「最」「第一」「国家级」等广告法禁用词。
只输出 JSON。`;

/** 商品套图：规划每张图 */
async function outlineProductMain(p) {
  const count = Math.max(1, Math.min(30, parseInt(p.count, 10) || 4));
  const images = await loadImgs(p.images);
  const styles = Array.isArray(p.styles) ? p.styles : [];
  const rec = Array.isArray(p.recommended_types) ? p.recommended_types.map((x) => (typeof x === 'string' ? x : x.name || x.id)).join('、') : '';
  const fallbackNames = ['白底主图', '场景主图', '卖点图', '细节图', '多角度图', '使用场景图', '尺寸图', '包装/配件图'];
  const fallback = () => Array.from({ length: count }, (_, i) => ({
    value: `slot${i + 1}`, name: fallbackNames[i % fallbackNames.length], desc: '', suggestion: `${fallbackNames[i % fallbackNames.length]}：突出商品主体，构图与其它张区分。`, copy: '', ratio: str(p.aspectRatio) || '1:1',
  }));
  try {
    const j = await askJson({
      system: OUTLINE_SYS,
      prompt: [
        `需要规划 ${count} 张商品主图套图。画面比例 ${str(p.aspectRatio) || '1:1'}，画面文字语言：${langOf(p)}。`,
        rec ? `优先覆盖这些出图类型：${rec}` : '',
        p.style ? `整体风格：${typeof p.style === 'string' ? p.style : JSON.stringify(p.style)}` : '',
        styles.length ? `风格方案：${styles.map((s) => s.name + (s.desc ? `（${s.desc}）` : '')).join('；')}` : '',
        p.info ? `商品信息：\n${String(p.info).slice(0, 6000)}` : '',
        `输出格式：{"outline":[{"value":"英文短标识","name":"图型名称","desc":"一句话说明","suggestion":"画面规划","copy":"画面文案"}]}，outline 必须正好 ${count} 条。`,
      ].filter(Boolean).join('\n\n'),
      images,
    });
    const out = arr(j, 'outline', 'list').slice(0, count).map((o, i) => ({
      value: str(o.value || o.key) || `slot${i + 1}`, name: str(o.name || o.label) || `图${i + 1}`, desc: str(o.desc),
      suggestion: str(o.suggestion || o.brief || o.desc), copy: str(o.copy), ratio: str(o.ratio) || str(p.aspectRatio) || '1:1',
    }));
    while (out.length && out.length < count) out.push({ ...out[out.length % Math.max(1, out.length)], value: `slot${out.length + 1}` });
    return out.length ? out : fallback();
  } catch (e) {
    console.warn('[llm] 套图大纲失败，使用兜底：', e.message);
    return fallback();
  }
}

/** 首页创作台「AI 优化提示词」 */
async function optimizePrompt(text, images = []) {
  const imgs = await loadImgs(images, 4);
  const rl = engine.relay();
  const out = await rl.chat({
    system: '你是 AI 修图/生图提示词专家。把用户的一句话改写成更清晰、可执行的中文出图指令：保留原意和所有具体要求，不要添加用户没提的改动；有参考图且是修改图片时，写明只改用户要求的部分、其余内容保持原图不变；新生成画面时补充主体、构图、光线、风格等必要细节；有多张参考图时用「图1」「图2」指代。只输出改写后的提示词，不要解释，不超过 150 字。',
    prompt: `用户原话：${str(text)}${imgs.length ? `\n（共 ${imgs.length} 张参考图）` : ''}`,
    images: imgs, which: imgs.length ? 'vision' : 'chat', temperature: 0.5,
  });
  return str(out).replace(/^["“「]|["”」]$/g, '');
}

/**
 * 画布「反推提示词」
 *   restore：写出能复现这张图的详细提示词（还原画面）
 *   template：总结成可以套用的模板提示词，可替换的部分用【主体】【场景】【文案】这类占位
 */
async function reversePrompt(image, mode = 'restore') {
  const imgs = await loadImgs([image], 1);
  if (!imgs.length) throw new Error('图片读取失败');
  const sys = mode === 'template'
    ? '你是 AI 作图提示词专家。看懂这张图的风格、构图、光线、配色、质感和排版，把它总结成一段可以反复套用的中文模板提示词：保留风格、构图、光线、色调、镜头、质感这些「怎么拍 / 怎么排」的描述，把具体内容换成占位符，例如【主体】【商品】【场景】【主标题】【副标题】【主体动作/局部特征】。150~260 字。只输出模板提示词本身，不要解释。'
    : '你是 AI 作图提示词专家。仔细看这张图，写出能让 AI 生图模型复现同款画面的中文提示词：画面类型与用途、主体（人物 / 商品的外观、颜色、材质、动作表情）、场景与道具、构图与机位景别、光线、配色、风格与质感、画面里的文字（照原样写出，写明位置和字体感觉）。150~300 字，一段话。只输出提示词本身，不要解释。';
  const out = await engine.relay().chat({ system: sys, prompt: '请根据这张图输出提示词。', images: imgs, which: 'vision', temperature: 0.4 });
  return str(out).replace(/^["“「]|["”」]$/g, '');
}

/** 精准改字：把图片上识别出的多段文字翻译成目标语言（电商用语，长度尽量接近原文，方便排回原位置） */
async function translateTexts(texts, lang) {
  const list = (texts || []).map((t) => str(t)).slice(0, 80);
  if (!list.length) return [];
  const j = await askJson({
    system: `你是电商本地化翻译。把图片上的多段文字翻译成${lang}：地道、简洁、符合电商表达；数字、价格、单位、型号保持原样；品牌名和 Logo 文字不翻译；译文尽量和原文差不多长（要排回图片原来的位置）。只输出 JSON。`,
    prompt: `原文（按顺序）：\n${list.map((t, i) => `${i + 1}. ${t}`).join('\n')}\n\n输出格式：{"items":["译文1","译文2",...]}，items 数量必须和原文一样（${list.length} 个），顺序一致。`,
  });
  const out = arr(j, 'items', 'list').map((x) => str(typeof x === 'string' ? x : x && (x.text || x.translation)));
  return list.map((t, i) => out[i] || t);
}

const PLAN_SYS = `你是 AI 修图 / 作图助手。先看懂用户的一句话要求和参考图，再输出 JSON：{"reply":"","prompt":"","title":""}
reply：用 1~2 句中文告诉用户你准备怎么做——先说要改什么、改成什么，再说哪些保持不变。只复述用户明确提出的修改，绝不擅自增加用户没提的改动（比如换衣服、换发型、改颜色、加道具、改背景）。语气自然，不客套，不超过 70 字。
prompt：交给生图模型的中文指令。
  · 有参考图并且用户是要修改这张图：写成「在参考图的基础上……」的精确编辑指令。先只写用户要求的改动；再逐项写出必须与原图保持一致的内容——把图里看得到的东西具体写出来：人物的服装（款式、颜色）、外套、帽子 / 发饰、配饰、姿势与动作、表情、背景与道具、光线、色调、构图与取景、画面比例、清晰度与拍摄质感。要求本身必然带来的连带变化可以有，除此之外一律不变。
  · 有多张参考图：用「图1」「图2」按顺序指代，写清每张图的用途。
  · 没有参考图或用户要新画一张：把需求写成清晰具体的画面描述（主体、场景、构图、光线、风格），不要堆砌形容词。
title：这次创作的短标题，4~12 个字，不带标点，比如「小女孩改为小男孩」「海边木栈道背景」。
只输出 JSON。`;

/** 首页「对话」模式：理解需求 → 回复说明 + 给模型的精确指令 + 项目标题 */
async function planEdit(text, images = []) {
  const imgs = await loadImgs(images, 6);
  const rl = engine.relay();
  const out = await rl.chat({
    system: PLAN_SYS,
    prompt: `用户的要求：${str(text)}${imgs.length ? `\n（附 ${imgs.length} 张参考图，按顺序为 图1～图${imgs.length}）` : '\n（没有参考图）'}`,
    images: imgs, which: imgs.length ? 'vision' : 'chat', json: true, temperature: 0.3,
  });
  const j = parseJson(out) || {};
  return { reply: str(j.reply), prompt: str(j.prompt), title: str(j.title).replace(/[，。！？、；：,.!?;:"“”「」]/g, '').slice(0, 16) };
}

/** 素材库「一键同款」：看懂用户上传的图，把模板原提示词改写成适合这些图的提示词 */
async function adaptPrompt(base, images = [], title = '') {
  const imgs = await loadImgs(images, 6);
  if (!imgs.length) throw new Error('请先上传图片');
  const rl = engine.relay();
  const out = await rl.chat({
    system: '你是电商视觉提示词专家。用户想用自己的图片做出与模板同款风格的成品图。请先看懂用户每张图里的主体（商品/人物/场景及其颜色、材质、文字），再改写模板提示词：保留模板的版式、构图、配色、光影、字体风格与画面比例；把模板里的虚构商品、品牌、文字和道具替换成用户图片里的真实内容；多张图时用「图1」「图2」…按顺序指代并说明各自用途；要求保持用户商品的外观、颜色、logo 与结构不变。只输出改写后的完整中文提示词，不要解释，不超过 400 字。',
    prompt: `模板名称：${str(title) || '电商模板'}\n模板原提示词：${str(base)}\n\n用户上传了 ${imgs.length} 张图片（按顺序为 图1～图${imgs.length}）。`,
    images: imgs, which: 'vision', temperature: 0.5,
  });
  return str(out).replace(/^["“「]|["”」]$/g, '');
}

/** 后台素材库：按主题想出 n 个互不重复的画面，每个给标题、提示词、分类 */
async function galleryIdeas(theme, count, cats = [], ratio = '') {
  const n = Math.max(1, Math.min(50, parseInt(count, 10) || 1));
  const j = await askJson({
    system: '你是电商视觉创意总监，为 AI 出图素材库策划素材。每个素材都是一张可以直接用 AI 生成的成品图（商品主图、海报、场景图、模特图等），画面彼此明显不同（主体、场景、构图、配色不重复）。prompt 用中文写清主体、场景、构图、光线、配色、风格、画面文字（如有，写明具体文字内容），120~260 字，能直接交给生图模型。只输出 JSON。',
    prompt: [
      `主题：${str(theme)}`,
      `数量：${n} 个`,
      ratio ? `画面比例：${ratio}` : '',
      cats.length ? `素材分类（category 必须从中选一个最合适的）：${cats.join('、')}` : '',
      `输出格式：{"items":[{"title":"8~14 字标题","category":"分类","tags":["标签"],"prompt":"提示词"}]}，items 必须正好 ${n} 个。`,
    ].filter(Boolean).join('\n'),
  });
  return arr(j, 'items', 'list').slice(0, n).map((x) => ({ title: str(x.title).slice(0, 30), category: str(x.category), tags: (Array.isArray(x.tags) ? x.tags : []).map(str).filter(Boolean).slice(0, 6), prompt: str(x.prompt) })).filter((x) => x.prompt);
}

/** 后台素材库：推荐「批量生成」的主题（商品 + 风格 / 场景），优先补素材少的分类 */
async function galleryThemes({ cats = [], hint = '', count = 12 } = {}) {
  const n = Math.max(4, Math.min(20, parseInt(count, 10) || 12));
  const j = await askJson({
    system: '你是电商 AI 作图网站的内容运营。网站用户是淘宝、拼多多、抖音、小红书、亚马逊等平台的中小卖家。请为素材库推荐「批量生成」的主题：每个主题 = 具体商品 + 风格 / 场景 / 用途，6~16 字，例如「口红 小红书风 粉色系」「男士T恤 白底电商主图」「中秋月饼礼盒 节日海报」。覆盖不同品类（服装、美妆、食品、数码、家居、母婴、鞋包、节日营销等），彼此不重复，选卖家最常用、最容易出好图的。只输出 JSON。',
    prompt: [
      cats.length ? `素材库现有分类及数量（优先给数量少的分类补主题）：${cats.map((c) => `${c.name}${c.count != null ? ` ${c.count} 张` : ''}`).join('、')}` : '',
      hint ? `运营想要的方向：${hint}（围绕它给主题）` : '',
      `输出格式：{"items":[{"theme":"主题","category":"最合适的分类"}]}，items 正好 ${n} 个。`,
    ].filter(Boolean).join('\n'),
  });
  return arr(j, 'items', 'list').map((x) => ({ theme: str(typeof x === 'string' ? x : x.theme).slice(0, 30), category: str(x && x.category).slice(0, 20) })).filter((x) => x.theme).slice(0, n);
}

/** 后台素材库：看图 → 标题、分类、标签，以及能复现这张图的提示词 */
async function describeImage(image, cats = []) {
  const imgs = await loadImgs([image], 1);
  if (!imgs.length) throw new Error('图片读取失败');
  const j = await askJson({
    system: '你是电商视觉提示词专家。仔细看这张图，写出能让 AI 生图模型复现同款画面的中文提示词：主体（商品 / 人物的外观、颜色、材质）、场景与道具、构图与机位、光线、配色、风格、画面里的文字（照原样写出）。150~280 字。再给它起标题、选分类、打标签。只输出 JSON。',
    prompt: `${cats.length ? `可选分类（category 从中选一个最合适的；都不合适就写一个新的 2~6 字分类名）：${cats.join('、')}\n` : ''}输出格式：{"title":"8~14 字标题","category":"分类","tags":["标签"],"prompt":"提示词"}`,
    images: imgs,
  });
  return { title: str(j.title).slice(0, 30), category: str(j.category).slice(0, 20), tags: (Array.isArray(j.tags) ? j.tags : []).map(str).filter(Boolean).slice(0, 6), prompt: str(j.prompt) };
}

/** 后台素材库：基于一张图的描述，写 n 个同类但不重复的新画面提示词 */
async function similarIdeas(desc, count) {
  const n = Math.max(1, Math.min(20, parseInt(count, 10) || 1));
  const j = await askJson({
    system: '你是电商视觉创意总监。基于给定的参考画面，策划同一类型、同一风格档次、但内容不重复的新画面（换商品细节 / 场景 / 构图 / 配色 / 文案之一或几项），每个都能直接交给 AI 生图。prompt 用中文，120~260 字。只输出 JSON。',
    prompt: `参考画面：${str(desc.title)}（分类：${str(desc.category)}）\n参考提示词：${str(desc.prompt)}\n\n输出格式：{"items":[{"title":"8~14 字标题","tags":["标签"],"prompt":"提示词"}]}，items 必须正好 ${n} 个。`,
  });
  return arr(j, 'items', 'list').slice(0, n).map((x) => ({ title: str(x.title).slice(0, 30), category: str(desc.category), tags: (Array.isArray(x.tags) ? x.tags : []).map(str).filter(Boolean).slice(0, 6), prompt: str(x.prompt) })).filter((x) => x.prompt);
}

module.exports = { translateTexts, reversePrompt, optimizePrompt, planEdit, adaptPrompt, outlineProductMain, galleryIdeas, galleryThemes, describeImage, similarIdeas, loadImgs };
