'use strict';
// 出片儿 后端入口
const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const config = require('./core/config');
require('./core/db');
const S = require('./core/settings');
const users = require('./core/users');
const { seed } = require('./core/seed');
const { Router, ApiError, parseRequest, clientIp, setCors, sendJson, ok, serveFile, safeJoin, securityHeaders } = require('./core/http');
const guard = require('./core/guard');
const engine = require('./ai/engine');
const thumbs = require('./core/thumbs');

seed();
require('./ai/gallery').seedCats();
// 品牌改名（橙图 → 出片儿）：数据库里前台能看到的文字（公告、套餐、优惠券、素材分类 / 标题、各项设置）统一换成新名字
{
  const db = require('./core/db');
  const cols = { yd_notice: ['title', 'content'], yd_plan: ['title', 'tag', 'note'], yd_coupon_activity: ['title'], yd_user_coupon: ['title'], yd_gallery_cat: ['name'], yd_gallery: ['title', 'prompt'], yd_setting: ['value'] };
  let n = 0;
  for (const [t, cs] of Object.entries(cols)) for (const c of cs) { try { n += db.run(`UPDATE ${t} SET ${c}=REPLACE(${c}, '橙图', '出片儿') WHERE ${c} LIKE '%橙图%'`).changes || 0; } catch { /* 老库没有这张表 / 这一列 */ } }
  if (n) { S.load(); console.log(`[改名] 已把 ${n} 处「橙图」改成「出片儿」`); }
}
// 品牌改名（橙图 → 出片儿）：后台没改过名字的，跟着换成新名字
{ const site = S.get('site') || {}; if (!site.name || site.name === '橙图' || /橙图/.test(site.title || '')) S.set('site', { ...site, name: !site.name || site.name === '橙图' ? '出片儿' : site.name, title: String(site.title || '').replace(/橙图/g, '出片儿') }); }
require('./ai/gallery').markInterrupted();
require('./ai/gallery').purgeLegacy();
S.load();

const api = new Router();
const route = (p, handler, opts = {}) => api.add(p, handler, opts);
// 注册顺序：精确路由优先，其次通配（records 在 module 通配之前）
require('./routes/user')(route);
require('./routes/member')(route);
require('./routes/library')(route);
require('./routes/gallery')(route);
require('./routes/text')(route);
require('./routes/generate')(route);

const admin = require('./admin/api');

function tokenOf(req, query) {
  const h = req.headers.token || req.headers['x-token'] || '';
  if (h) return String(h);
  const auth = String(req.headers.authorization || '');
  if (/^Bearer\s+/i.test(auth)) return auth.replace(/^Bearer\s+/i, '');
  return query.token && query.token.length > 30 ? String(query.token) : '';
}

async function handleApi(req, res, pathname) {
  const m = api.match(pathname);
  if (!m) return sendJson(res, 404, { code: 0, msg: '接口不存在：' + pathname, time: String(Math.floor(Date.now() / 1000)), data: null });
  let parsed;
  // 不用登录的接口（登录、验证码、反馈…）只收小请求，最多 256KB，防止被人用超大请求撑爆内存
  const small = m.opts && (m.opts.auth === false || m.opts.auth === 'optional') && !m.opts.raw;
  try { parsed = await parseRequest(req, small ? 256 * 1024 : undefined); } catch (e) { return sendJson(res, e.status || 400, { code: 0, msg: e.message, data: null }); }
  const p = { ...parsed.query, ...parsed.body };
  const opts = m.opts || {};
  const ctx = { req, res, p, files: parsed.files, ip: clientIp(req), params: m.params, user: null };
  // 单个 IP 5 分钟内最多 3000 次接口请求（正常使用远远到不了；防脚本狂刷）
  if (guard.tooMany('api:' + ctx.ip, 3000, 300)) return sendJson(res, 429, { code: 0, msg: '请求太频繁，请稍后再试', time: String(Math.floor(Date.now() / 1000)), data: null });
  const black = (S.get('security') || {}).ip_blacklist || [];
  if (Array.isArray(black) && black.some((b) => b && (ctx.ip === b || (b.endsWith('.') || b.endsWith('*')) && ctx.ip.startsWith(b.replace(/\*$/, ''))))) {
    return sendJson(res, 403, { code: 0, msg: '访问受限，请联系客服', time: String(Math.floor(Date.now() / 1000)), data: null });
  }
  try {
    if (opts.auth !== false || opts.auth === 'optional') {
      const tk = tokenOf(req, parsed.query);
      const tu = tk ? users.userByToken(tk) : null;
      ctx.user = tu ? { ...(users.getUser(tu.id) || tu), _token: tu._token } : null;
    }
    if (opts.auth === undefined || opts.auth === true) {
      if (!ctx.user) return sendJson(res, 401, { code: 401, msg: '请先登录', time: String(Math.floor(Date.now() / 1000)), data: null });
    }
    guard.aiLimit(pathname, ctx.user);
    const data = await m.handler(ctx);
    if (opts.raw || res.headersSent || res.writableEnded) return undefined;
    return ok(res, data === undefined ? null : data);
  } catch (e) {
    if (res.headersSent) { try { res.end(); } catch {} return undefined; }
    if (e instanceof ApiError) return sendJson(res, e.status || 200, { code: e.code, msg: e.message, time: String(Math.floor(Date.now() / 1000)), data: e.data });
    console.error('[api]', pathname, e);
    return sendJson(res, 500, { code: 0, msg: '服务器开小差了，请稍后再试', time: String(Math.floor(Date.now() / 1000)), data: null });   // 具体错误只写日志，不暴露给外部
  }
}

const PUBLIC = path.join(config.root, 'public');

// 前端首页（所有页面地址都返回它），把 __CT_xxx__ 占位符换成后台「站点信息」的值
let indexCache = { mtime: 0, html: '' };
function frontendIndex() {
  const file = path.join(config.frontendDist, 'index.html');
  const st = fs.statSync(file);
  if (!indexCache.html || indexCache.mtime !== st.mtimeMs) indexCache = { mtime: st.mtimeMs, html: fs.readFileSync(file, 'utf8') };
  let out = indexCache.html;
  for (const [k, v] of Object.entries(siteTokens())) out = out.split(k).join(String(v).replace(/[<>"]/g, ''));
  return Buffer.from(out.replace('</head>', bootHead() + '</head>'));
}

// 首屏提速：把「站点信息」和首页第一屏素材直接放进页面里（省掉两次接口往返），
//   并提前和图片域名（COS）建立连接，第一张素材图不用再等 DNS + TLS 握手。缓存 30 秒。
let bootCache = { t: 0, html: '', ver: '' };
const settingsSeen = new WeakMap(); let settingsN = 0;
function settingsVer() { const all = S.get(); if (!settingsSeen.has(all)) settingsSeen.set(all, ++settingsN); return settingsSeen.get(all); }
function bootHead() {
  // 素材上下架 / 后台调顺序后立刻生效（ver 变了就重算），否则 30 秒内复用
  let ver = '';
  try { ver = String(require('./core/db').val(`SELECT COUNT(*) || '-' || COALESCE(SUM(sort), 0) || '-' || COALESCE(MAX(updatetime), 0) FROM yd_gallery WHERE status='online'`) || ''); } catch { ver = ''; }
  ver += '|' + settingsVer();   // 后台改了设置（如开关人机验证）也立刻生效
  if (Date.now() - bootCache.t < 30000 && ver === bootCache.ver) return bootCache.html;
  let html = '';
  try {
    const call = (p, args) => { const m = api.match(p); return m ? m.handler({ p: args || {}, user: null }) : null; };
    const site = call('/site/config');
    let cats = null;
    try { const c = call('/gallery/cats'); if (c && !(c instanceof Promise)) cats = c.cats; } catch {}
    let models = null;
    try { const m = call('/site/models'); if (m && !(m instanceof Promise)) models = m; } catch {}
    let feed = null;
    try { const d = call('/gallery/lists', { page: 1, limit: 24, sort: 'default' }); if (d && !(d instanceof Promise)) feed = { items: d.items, more: d.more }; } catch {}
    const hosts = new Set((site && site.img_hosts) || []);
    const cos = (S.get('storage') || {}).cos || {};
    if (cos.bucket && cos.region) hosts.add(`https://${cos.bucket}.cos.${cos.region}.myqcloud.com`);
    for (const it of (feed && feed.items) || []) { try { const o = new URL(it.image).origin; if (/^https:/.test(o)) hosts.add(o); } catch {} }
    try { hosts.delete(new URL(config.siteUrl || config.publicBaseUrl).origin); } catch {}
    html = '<link rel="preload" as="image" href="/brand/logo-sm.webp" fetchpriority="high">\n' + [...hosts].slice(0, 3).map((h) => `<link rel="preconnect" href="${h.replace(/[<>"]/g, '')}">\n`).join('')
      + `<script type="application/json" id="ct-boot">${JSON.stringify({ t: Date.now(), site, feed, models, cats }).replace(/</g, '\\u003c')}</script>\n`;
  } catch (e) { html = ''; }
  bootCache = { t: Date.now(), html, ver };
  return html;
}

// 内容安全策略（CSP）：页面只允许运行本站的脚本 + 首页里那两段内联脚本（按内容哈希放行）。
// 就算哪天有人想办法把脚本塞进页面，浏览器也会拒绝执行，盗不走用户的登录状态。
function indexCsp(buf) {
  const html = buf.toString('utf8');
  const hashes = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => `'sha256-${require('crypto').createHash('sha256').update(m[1]).digest('base64')}'`);
  // 开了阿里云验证码：放行它的脚本 / 样式 / 字体 / 内嵌框架
  const ali = require('./core/human').aliyunOn() ? ' https://o.alicdn.com https://g.alicdn.com https://*.alicdn.com' : '';
  return [
    "default-src 'self'",
    `script-src 'self' ${hashes.join(' ')}${ali}`,
    `style-src 'self' 'unsafe-inline'${ali}`,
    "img-src 'self' data: blob: https:",
    "media-src 'self' data: blob: https:",
    `font-src 'self' data: blob:${ali}`,
    ...(ali ? [`frame-src 'self'${ali} https://*.aliyun.com https://*.aliyuncs.com`] : []),
    "connect-src 'self' data: blob: https:",
    "worker-src 'self' blob:",
    "manifest-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'self'",
  ].join('; ');
}
function sendIndex(req, res) {
  const body = frontendIndex();
  // bodyKey 用内容哈希：页面内容一变（站点信息、首屏数据），ETag 和压缩缓存都跟着变
  return serveFile(req, res, path.join(config.frontendDist, 'index.html'), { cache: 'no-cache', body, bodyKey: require('crypto').createHash('sha1').update(body).digest('hex'), extra: { 'Content-Security-Policy': indexCsp(body) } });
}

// 小尺寸 Logo（256 宽 WebP，几 KB）：顶栏 / 首页大 Logo 用它，首屏不再等 80KB 的原图；后台换 Logo 后自动重新生成
let logoSm = { key: '', buf: null };
async function sendLogoSm(req, res) {
  const over = path.join(BRAND_DATA, 'logo.png');
  const src = fs.existsSync(over) ? over : path.join(PUBLIC, 'brand', 'logo.png');
  let key = '';
  try { key = src + '|' + fs.statSync(src).mtimeMs; } catch { res.writeHead(404); res.end(); return; }
  if (logoSm.key !== key) {
    let buf = null;
    try { buf = await thumbs.webpThumb(fs.readFileSync(src), 256); } catch { buf = null; }
    logoSm = { key, buf };
  }
  const cache = 'public, max-age=600, stale-while-revalidate=604800';
  if (!logoSm.buf) return serveFile(req, res, src, { cache });
  return serveFile(req, res, src, { cache, body: logoSm.buf, bodyKey: key, extra: { 'Content-Type': 'image/webp' } });
}

// 前端里的 __CT_xxx__ 占位符（公司名/备案号/联系方式/域名）→ 后台「站点信息」的值
const tokCache = new Map();
let tokVer = '';
function siteTokens() {
  const site = S.get('site') || {};
  let domain = site.domain || '';
  if (!domain) { try { domain = new URL(config.siteUrl || config.publicBaseUrl).host; } catch {} }
  return {
    __CT_COMPANY__: site.company || site.name || '出片儿',
    __CT_ICP__: site.icp || '',
    __CT_EMAIL__: site.email || '',
    __CT_PHONE__: site.phone || '',
    __CT_DOMAIN__: domain,
    __CT_SERVICE__: site.service_time || '周一至周日 上午 9:00-11:30，下午 13:30-18:00',
    __CT_HOURS__: (site.service_time || '周一至周日 上午 9:00-11:30，下午 13:30-18:00').replace(/^周\S*\s+/, ''),
    __CT_MSCALE__: String(site.mobile_scale === undefined || site.mobile_scale === '' ? 0.88 : Number(site.mobile_scale) || 1),
    __CT_TITLE__: site.title || `${site.name || '出片儿'} - 电商团队一站式AI作图工具`,
  };
}
function tokenized(file) {
  if (!/\.(js|html)$/.test(file)) return null;
  let st;
  try { st = fs.statSync(file); } catch { return null; }
  const t = siteTokens();
  const ver = JSON.stringify(t);
  if (ver !== tokVer) { tokCache.clear(); tokVer = ver; }
  const c = tokCache.get(file);
  if (c && c.mtime === st.mtimeMs) return c.buf;
  let buf = null;
  const raw = fs.readFileSync(file, 'utf8');
  if (raw.includes('__CT_')) {
    let out = raw;
    for (const [k, v] of Object.entries(t)) out = out.split(k).join(String(v).replace(/[\\"'`]/g, ''));
    buf = Buffer.from(out);
  }
  tokCache.set(file, { mtime: st.mtimeMs, buf });
  return buf;
}

// 健康检查：发布脚本据此确认新版本已正常启动；测试环境带上沙箱标识，测试脚本据此确认不是生产环境
const PKG_VERSION = require('../package.json').version;
function health() {
  let web = null;
  try { web = JSON.parse(fs.readFileSync(path.join(config.frontendDist, 'build-info.json'), 'utf8')); } catch {}
  const out = { status: 'ok', time: Date.now(), version: PKG_VERSION, release: process.env.CT_RELEASE || '', web: web && { build: web.build, app: web.app && web.app.version } };
  if (config.testSandbox) out.sandbox = config.testSandbox;
  return out;
}

// 品牌资源：data/brand 里有同名文件（后台上传的客服码、Logo）优先
const BRAND_DATA = path.join(path.dirname(path.resolve(config.root, config.dbFile || './data/yuduo.db')), 'brand');

const server = http.createServer(async (req, res) => {
  setCors(req, res);
  securityHeaders(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  let pathname = '/';
  try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch {}

  if (pathname.startsWith('/uploads/')) {
    const f = safeJoin(config.uploadDir, pathname.replace(/^\/uploads\//, ''));
    if (!f) return sendJson(res, 404, { code: 0, msg: 'Not Found' });
    // ?w=480：列表卡片用的缩略图（WebP），生成失败 / 没装缩图工具时返回原图
    const w = (/[?&]w=(\d+)/.exec(req.url || '') || [])[1];
    if (w && fs.existsSync(f)) {
      const t = await thumbs.thumbOf(f, w).catch(() => null);
      if (t) return serveFile(req, res, t, { cache: 'public, max-age=2592000, immutable' });
      return serveFile(req, res, f, { cache: 'public, max-age=86400' });   // 没缩成：给原图，短缓存（以后装了工具能换成小图）
    }
    // 不是图片 / 视频的上传文件一律当附件下载，浏览器不会把它当网页打开（防止有人上传网页脚本冒充本站）
    const media = /\.(png|jpe?g|webp|gif|avif|bmp|mp4|webm|mov)$/i.test(f);
    return serveFile(req, res, f, { cache: 'public, max-age=2592000, immutable', extra: media ? null : { 'Content-Disposition': 'attachment', 'Content-Security-Policy': "default-src 'none'; sandbox" } });
  }
  if (pathname === '/favicon.ico') pathname = '/brand/favicon-64.png';
  if (pathname === '/brand/logo-sm.webp') return sendLogoSm(req, res);
  if (pathname.startsWith('/brand/')) {
    const name = pathname.slice(7);
    const over = safeJoin(BRAND_DATA, name);
    if (over && fs.existsSync(over) && fs.statSync(over).isFile()) return serveFile(req, res, over, { cache: 'no-cache' });
    const pub = safeJoin(path.join(PUBLIC, 'brand'), name);
    if (pub && fs.existsSync(pub) && (!config.frontendDist || !fs.existsSync(safeJoin(config.frontendDist, pathname) || ''))) return serveFile(req, res, pub, { cache: 'no-cache' });
  }
  if (pathname === '/avatar-default.svg') return serveFile(req, res, path.join(PUBLIC, 'avatar-default.svg'));
  if (pathname === '/speed') return serveFile(req, res, path.join(PUBLIC, 'speed.html'), { cache: 'no-cache' });   // 测速页（手机打开截图给开发者）
  const adminPath = (config.admin && config.admin.path) || '/admin';
  if (pathname === adminPath || pathname.startsWith(adminPath + '/')) {
    if (pathname.startsWith(adminPath + '/api/')) return admin.handle(req, res, pathname.slice((adminPath + '/api').length));
    if (!admin.ipAllowed(clientIp(req))) return sendJson(res, 404, { code: 0, msg: 'Not Found' });
    return serveFile(req, res, path.join(PUBLIC, 'admin', 'index.html'), { cache: 'no-cache' });
  }
  const prefix = config.apiPrefix;
  if (prefix && (pathname === prefix || pathname.startsWith(prefix + '/'))) return handleApi(req, res, pathname.slice(prefix.length) || '/');
  if (!prefix || (!config.frontendDist && api.match(pathname))) return handleApi(req, res, pathname);
  if (pathname === '/health') return ok(res, health());

  // 托管前端（版本化发布目录 releases/<版本>/web，见 tools/release.js）：文件直接返回，其余页面地址都返回 index.html
  if (config.frontendDist && fs.existsSync(config.frontendDist)) {
    const f = safeJoin(config.frontendDist, pathname);
    if (pathname === '/index.html') return sendIndex(req, res);
    if (f && fs.existsSync(f) && fs.statSync(f).isFile()) {
      const isHtml = /\.html$/.test(f) || /sw\.js$|version\.json$/.test(f);
      const tk = tokenized(f);
      if (tk) return serveFile(req, res, f, { cache: isHtml ? 'no-cache' : 'public, max-age=3600, stale-while-revalidate=604800', body: tk, bodyKey: tokVer });
      if (pathname.startsWith('/brand/')) return serveFile(req, res, f, { cache: 'no-cache' });
      // 只有带内容哈希的构建产物才长期缓存
      const hashed = /^\/app\/assets\//.test(pathname);
      return serveFile(req, res, f, { cache: isHtml ? 'no-cache' : hashed ? 'public, max-age=31536000, immutable' : 'public, max-age=3600' });
    }
    if (!/\.\w{2,5}$/.test(pathname)) return sendIndex(req, res);
  }
  return sendJson(res, 404, { code: 0, msg: 'Not Found' });
});

server.requestTimeout = 15 * 60 * 1000;   // 单个请求最长 15 分钟（防慢速攻击一直占着连接）
server.headersTimeout = 65000;
server.keepAliveTimeout = 61000;

server.listen(config.port, config.host, () => {
  console.log(`\n✅ 出片儿后端已启动  http://${config.host}:${config.port}`);
  console.log(`   接口前缀：${config.apiPrefix || '(无)'}    对外地址：${config.publicBaseUrl || '(未配置 publicBaseUrl)'}`);
  console.log(`   管理后台：http://${config.host === '0.0.0.0' ? '127.0.0.1' : config.host}:${config.port}${(config.admin && config.admin.path) || '/admin'}`);
  if (config.frontendDist) console.log(`   前端托管：${config.frontendDist}`);
  engine.start();
  // 预热：提前压缩首页和主要脚本，第一个访客不用等
  if (config.frontendDist) setTimeout(async () => {
    try {
      const dir = path.join(config.frontendDist, 'assets');
      const files = fs.readdirSync(dir).filter((f) => /\.(js|css)$/.test(f)).map((f) => ({ f, size: fs.statSync(path.join(dir, f)).size })).filter((x) => x.size > 30000 && !/^(de|en|es|fr|id|ja|ko|ms|pt|zh-TW|th|vi|ru|ar|it)-/.test(x.f)).sort((a, b) => b.size - a.size).slice(0, 25);
      const host = `http://127.0.0.1:${config.port}`;
      const t0 = Date.now();
      for (const enc of ['br', 'gzip']) {
        await fetch(host + '/', { headers: { 'Accept-Encoding': enc } }).then((r) => r.arrayBuffer()).catch(() => {});
        for (const x of files) await fetch(`${host}/assets/${x.f}`, { headers: { 'Accept-Encoding': enc } }).then((r) => r.arrayBuffer()).catch(() => {});
      }
      console.log(`   预压缩完成：${files.length} 个文件，${((Date.now() - t0) / 1000).toFixed(1)}s`);
    } catch (e) { console.warn('[warmup]', e.message); }
  }, 1500).unref();
});

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e));
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { engine.stop(); server.close(); process.exit(0); });

module.exports = server;
