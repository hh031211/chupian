'use strict';
const crypto = require('crypto');
// 管理后台 API（/admin/api/*，请求头 admin-token）
const db = require('../core/db');
const S = require('../core/settings');
const users = require('../core/users');
const orders = require('../core/orders');
const storage = require('../core/storage');
const engine = require('../ai/engine');
const { RelayClient } = require('../ai/relay');
const { Router, ApiError, fail, parseRequest, sendJson, ok, clientIp } = require('../core/http');
const { now, str, int, num, pageArgs, fmtTime, jsonParse, randomHex, hashPassword, verifyPassword, money } = require('../core/util');

const r = new Router();
const route = (p, h, o = {}) => r.add(p, h, o);

function adminByToken(t) {
  if (!t) return null;
  const row = db.get('SELECT * FROM yd_admin_token WHERE token IN (?, ?)', users.tokenKey(t), String(t));
  if (!row || row.expiretime < now()) return null;
  return db.get(`SELECT id, username, nickname, role FROM yd_admin WHERE id=? AND (status IS NULL OR status='normal')`, row.admin_id);
}

// ---------------- 登录 ----------------
const loginFails = new Map();
route('/login', ({ p, ip }) => {
  const f = loginFails.get(ip) || { n: 0, t: 0 };
  if (f.n >= 8 && Date.now() - f.t < 15 * 60e3) fail('登录失败次数过多，请 15 分钟后再试');
  // 同一个管理员账号：不管从多少个 IP 来试，30 分钟内错 10 次就锁住（防分布式猜密码）
  const uname = str(p.username, 64);
  const uf = loginFails.get('u:' + uname) || { n: 0, t: 0 };
  if (uf.n >= 10 && Date.now() - uf.t < 30 * 60e3) fail('该账号登录失败次数过多，已锁定 30 分钟');
  const a = db.get(`SELECT * FROM yd_admin WHERE username=? AND (status IS NULL OR status='normal')`, uname);
  if (!a || !verifyPassword(p.password, a.password, a.salt)) {
    loginFails.set(ip, { n: Date.now() - f.t > 15 * 60e3 ? 1 : f.n + 1, t: Date.now() });
    loginFails.set('u:' + uname, { n: Date.now() - uf.t > 30 * 60e3 ? 1 : uf.n + 1, t: Date.now() });
    try { db.insert('yd_admin_log', { admin_id: a ? a.id : 0, username: uname.slice(0, 40), action: '后台登录失败', detail: '', ip, createtime: now() }); } catch {}
    fail('账号或密码错误');
  }
  loginFails.delete(ip); loginFails.delete('u:' + uname);
  const token = randomHex(24);
  db.insert('yd_admin_token', { token: users.tokenKey(token), admin_id: a.id, expiretime: now() + 7 * 86400 });
  db.update('yd_admin', { logintime: now() }, 'id=?', a.id);
  try { db.insert('yd_admin_log', { admin_id: a.id, username: a.username, action: '登录后台', detail: '', ip, createtime: now() }); } catch {}
  return { token, username: a.username, role: a.role || 'super' };
}, { auth: false });
route('/logout', ({ req }) => { const t = String(req.headers['admin-token'] || ''); db.run('DELETE FROM yd_admin_token WHERE token IN (?, ?)', users.tokenKey(t), t); return null; });
route('/me', ({ admin }) => admin);
route('/password', ({ p, admin }) => {
  const a = db.get('SELECT * FROM yd_admin WHERE id=?', admin.id);
  if (!verifyPassword(p.old_password, a.password, a.salt)) fail('原密码错误');
  const np = String(p.new_password || '');
  if (np.length < 10 || !/[A-Za-z]/.test(np) || !/\d/.test(np)) fail('新密码至少 10 位，并且要同时包含字母和数字');
  const h = hashPassword(p.new_password);
  db.update('yd_admin', { password: h.hash, salt: h.salt }, 'id=?', a.id);
  return null;
});

// ---------------- 安全检查（概览页顶部红色提醒）----------------
const weakCache = new Map();
function securityWarnings() {
  const w = [];
  const config = require('../core/config');
  for (const a of db.all(`SELECT username, password, salt FROM yd_admin WHERE status IS NULL OR status='normal'`)) {
    const key = a.password + a.salt;   // 密码没变就不用重新算（scrypt 比较慢）
    if (!weakCache.has(key)) weakCache.set(key, ['admin123456', '123456', 'admin', 'admin123', '12345678', String((config.admin || {}).initPassword || '')].some((x) => x && verifyPassword(x, a.password, a.salt)));
    if (weakCache.get(key)) w.push(`管理员「${a.username}」还在用默认 / 过于简单的密码，请立即在右上角修改密码（至少 12 位，字母 + 数字 + 符号）`);
  }
  const pay = S.get('payment') || {};
  if (pay.mock) w.push('「模拟支付」是开着的：任何人都能不付钱开会员、充点数！正式运营请到「支付配置」关闭');
  const sms = S.get('sms') || {};
  if (sms.debug && !/aliyun/.test(String(sms.provider || ''))) w.push('短信「调试模式」是开着的：验证码会直接返回给浏览器，任何人都能登录任意手机号！请到「短信与邮件」关闭');
  if ((S.get('security') || {}).rate_limit === false) w.push('防刷限制（登录 / 短信 / 免费接口频率限制）被关闭了，请到「内容安全」打开');
  if (config.host && !/^(127\.0\.0\.1|localhost|::1)$/.test(config.host) && config.trustProxy) w.push(`网站程序监听在 ${config.host}，又信任代理头：别人可以绕过 Caddy 直接访问 ${config.port} 端口并伪造 IP。请在 config.json 里把 host 改成 127.0.0.1`);
  return w;
}

// ---------------- 概览 ----------------
route('/dashboard', () => {
  const today = now() - ((now() + 8 * 3600) % 86400);
  return {
    security_warnings: securityWarnings(),
    users: db.val('SELECT COUNT(*) FROM yd_user WHERE deletetime=0'),
    users_today: db.val('SELECT COUNT(*) FROM yd_user WHERE jointime>=? AND deletetime=0', today),
    revenue: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE pay_status='paid' AND pay_type NOT IN ('admin','mock')`)),
    revenue_today: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE pay_status='paid' AND paytime>=? AND pay_type NOT IN ('admin','mock')`, today)),
    tasks_today: db.val('SELECT COUNT(*) FROM yd_task WHERE createtime>=?', today),
    images_today: db.val(`SELECT COUNT(*) FROM yd_task_result WHERE status='succeeded' AND updatetime>=?`, today),
    queue: db.val(`SELECT COUNT(*) FROM yd_task_result WHERE status IN ('queued','running')`),
    failed_today: db.val(`SELECT COUNT(*) FROM yd_task_result WHERE status='failed' AND updatetime>=?`, today),
    points_consumed_today: Math.max(0, -(db.val(`SELECT COALESCE(SUM(change),0) FROM yd_score_log WHERE type IN ('consume','refund') AND createtime>=?`, today) || 0)),
    feedback_pending: db.val(`SELECT COUNT(*) FROM yd_feedback WHERE status='pending'`),
    library_draft: db.val(`SELECT COUNT(*) FROM yd_gallery WHERE status='draft'`),
    ai_errors: db.all('SELECT kind, model, error, createtime FROM yd_ai_log WHERE ok=0 ORDER BY id DESC LIMIT 10').map((x) => ({ ...x, time: fmtTime(x.createtime) })),
  };
});

// ---------------- 用户 ----------------
route('/users', ({ p }) => {
  const { limit, offset } = pageArgs(p, 20);
  const where = ['deletetime=0'];
  const args = [];
  const kw = str(p.keyword);
  if (kw) { where.push('(id=? OR username LIKE ? OR nickname LIKE ? OR mobile LIKE ? OR email LIKE ? OR invite_code=?)'); args.push(int(kw), `%${kw}%`, `%${kw}%`, `%${kw}%`, `%${kw}%`, kw); }
  if (p.level) { where.push('member_level=? AND member_expiretime>?'); args.push(p.level, now()); }
  const total = db.val(`SELECT COUNT(*) FROM yd_user WHERE ${where.join(' AND ')}`, ...args);
  const list = db.all(`SELECT * FROM yd_user WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((u) => ({
    id: u.id, username: u.username, nickname: u.nickname, mobile: u.mobile, email: u.email, score: u.score, member_level: users.effectiveLevel(u),
    member_expiretime: u.member_expiretime ? fmtTime(u.member_expiretime) : '',
    parent_user_id: u.parent_user_id, status: u.status, wechat: u.wechat_openid ? '已绑定' : '',
    jointime: fmtTime(u.jointime), logintime: u.logintime ? fmtTime(u.logintime) : '', invite_code: u.invite_code, enable_video: u.enable_video,
    concurrency: u.concurrency, video_cost: u.video_cost, remark: u.remark,
  }));
  return { list, total };
});
route('/user/save', ({ p }) => {
  const u = users.getUser(int(p.id));
  if (!u) fail('用户不存在');
  const up = {};
  for (const k of ['nickname', 'mobile', 'email', 'status', 'remark', 'member_level']) if (p[k] !== undefined) up[k] = str(p[k]);
  for (const k of ['enable_video', 'concurrency', 'video_cost', 'video_m3_cost', 'parent_user_id']) if (p[k] !== undefined && p[k] !== '') up[k] = int(p[k]);
  if (p.member_expiretime !== undefined) {
    const t = str(p.member_expiretime);
    up.member_expiretime = !t ? 0 : /^\d+$/.test(t) ? int(t) : Math.floor(new Date(t.replace(' ', 'T') + (t.length <= 10 ? 'T23:59:59' : '') + '+08:00').getTime() / 1000) || 0;
  }
  if (p.password) { const h = hashPassword(p.password); up.password = h.hash; up.salt = h.salt; }
  if ((up.status && up.status !== 'normal') || up.password) db.run('DELETE FROM yd_token WHERE user_id=?', u.id);   // 禁用或重置密码：踢掉所有登录
  db.update('yd_user', up, 'id=?', u.id);
  return null;
});
route('/user/score', ({ p, admin }) => {
  const change = int(p.change);
  if (!change) fail('请输入调整数量');
  users.changeScore(int(p.id), change, 'adjust', str(p.remark) || '后台调整', '', admin.id);
  return { score: users.getUser(int(p.id)).score };
});
route('/user/grant', ({ p }) => {
  const days = int(p.days);
  if (!days || !p.level) fail('请选择等级和天数');
  users.grantMembership(int(p.id), str(p.level), days);
  return null;
});
route('/user/logs', ({ p }) => {
  const { limit, offset } = pageArgs(p, 20);
  return {
    list: db.all('SELECT * FROM yd_score_log WHERE user_id=? ORDER BY id DESC LIMIT ? OFFSET ?', int(p.id), limit, offset).map((x) => ({ ...x, time: fmtTime(x.createtime) })),
    total: db.val('SELECT COUNT(*) FROM yd_score_log WHERE user_id=?', int(p.id)),
  };
});
route('/user/login_as', ({ p }) => {
  const u = users.getUser(int(p.id));
  if (!u) fail('用户不存在');
  return users.issueToken(u.id, 3600 * 2);
});

// ---------------- 订单 ----------------
route('/orders', ({ p }) => {
  const { limit, offset } = pageArgs(p, 20);
  const where = ['1=1'];
  const args = [];
  if (p.kind) { where.push('kind=?'); args.push(p.kind); }
  if (p.pay_status) { where.push('pay_status=?'); args.push(p.pay_status); }
  if (str(p.keyword)) { where.push('(order_sn LIKE ? OR user_id=?)'); args.push(`%${str(p.keyword)}%`, int(p.keyword)); }
  if (p.start) { where.push('createtime>=?'); args.push(Math.floor(new Date(p.start + 'T00:00:00+08:00') / 1000)); }
  if (p.end) { where.push('createtime<?'); args.push(Math.floor(new Date(p.end + 'T00:00:00+08:00') / 1000) + 86400); }
  return {
    sum: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE ${where.join(' AND ')} AND pay_status='paid'`, ...args)),
    list: db.all(`SELECT * FROM yd_order WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((o) => ({ ...orders.orderView(o), user_id: o.user_id, discount: o.discount, transaction_id: o.transaction_id })),
    total: db.val(`SELECT COUNT(*) FROM yd_order WHERE ${where.join(' AND ')}`, ...args),
  };
});
route('/order/paid', ({ p }) => { orders.fulfill(str(p.order_sn), 'ADMIN' + now(), 'admin'); return null; });
route('/order/close', ({ p }) => { db.update('yd_order', { pay_status: 'closed', updatetime: now() }, `order_sn=? AND pay_status='pending'`, str(p.order_sn)); return null; });
route('/order/create', ({ p, admin }) => {
  // 后台直接为用户开通套餐（线下收款）
  const u = users.getUser(int(p.user_id));
  const plan = db.get('SELECT * FROM yd_plan WHERE id=?', int(p.plan_id));
  if (!u || !plan) fail('用户或套餐不存在');
  const o = orders.createOrder({ user: u, kind: 'member', plan, amount: num(p.amount, plan.price), points: plan.points, payType: 'admin', extra: { admin: admin.id } });
  orders.fulfill(o.order_sn, 'ADMIN' + now(), 'admin');
  return null;
});

// ---------------- 通用 CRUD ----------------
const CRUD = {
  plans: { table: 'yd_plan', order: 'type, sort, id', fields: ['type', 'title', 'tag', 'price', 'original_price', 'points', 'days', 'level', 'note', 'highlight', 'agent_price', 'redeemable', 'sort', 'status'] },
  coupons: { table: 'yd_coupon_activity', order: 'id DESC', fields: ['title', 'amount', 'threshold_amount', 'valid_days', 'total', 'per_user', 'starttime', 'endtime', 'status'] },
  notices: { table: 'yd_notice', order: 'id DESC', fields: ['type', 'title', 'content', 'time', 'status'] },
  feedback: { table: 'yd_feedback', order: 'id DESC', fields: ['status', 'reply'] },
};
route('/crud/:name/:action', ({ params, p }) => {
  const c = CRUD[params.name];
  if (!c) fail('未知资源');
  const pk = c.pk || 'id';
  if (params.action === 'list') {
    const { limit, offset } = pageArgs(p, 50, 500);
    const where = [c.where || '1=1'];
    const args = [];
    if (p.catalog && c.fields.includes('catalog')) { where.push('catalog=?'); args.push(p.catalog); }
    if (p.category_id && c.fields.includes('category_id')) { where.push('category_id=?'); args.push(int(p.category_id)); }
    return {
      list: db.all(`SELECT * FROM ${c.table} WHERE ${where.join(' AND ')} ORDER BY ${c.order} LIMIT ? OFFSET ?`, ...args, limit, offset),
      total: db.val(`SELECT COUNT(*) FROM ${c.table} WHERE ${where.join(' AND ')}`, ...args),
    };
  }
  if (params.action === 'save') {
    const row = {};
    for (const f of c.fields) if (p[f] !== undefined) row[f] = typeof p[f] === 'object' && p[f] !== null ? JSON.stringify(p[f]) : p[f];
    const id = p[pk];
    if (id) { db.update(c.table, row, `${pk}=?`, id); return { id }; }
    if (c.fields.includes('status') && row.status === undefined) row.status = 'normal';
    if (['yd_plan', 'yd_coupon_activity', 'yd_notice'].includes(c.table)) row.createtime = now();
    return { id: db.insert(c.table, row) };
  }
  if (params.action === 'del') {
    const ids = (Array.isArray(p.ids) ? p.ids : [p[pk] || p.id]).filter((x) => x !== undefined && x !== null && x !== '');
    for (const id of ids) db.run(`DELETE FROM ${c.table} WHERE ${pk}=?${c.where ? ' AND ' + c.where : ''}`, id);
    return null;
  }
  fail('未知操作');
  return null;
});

// ---------------- 兑换码 ----------------
route('/redeem/list', ({ p }) => {
  const { limit, offset } = pageArgs(p, 50);
  const where = ['1=1'];
  const args = [];
  if (p.status) { where.push('status=?'); args.push(p.status); }
  if (str(p.keyword)) { where.push('(code LIKE ? OR owner_user_id=? OR used_user_id=?)'); args.push(`%${str(p.keyword)}%`, int(p.keyword), int(p.keyword)); }
  return {
    list: db.all(`SELECT * FROM yd_redeem_code WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((x) => ({ ...x, createtime: fmtTime(x.createtime), usetime: x.usetime ? fmtTime(x.usetime) : '' })),
    total: db.val(`SELECT COUNT(*) FROM yd_redeem_code WHERE ${where.join(' AND ')}`, ...args),
  };
});
route('/redeem/generate', ({ p }) => {
  const count = Math.max(1, Math.min(1000, int(p.count, 1)));
  let plan = p.plan_id ? db.get('SELECT * FROM yd_plan WHERE id=?', int(p.plan_id)) : null;
  if (!plan) plan = { id: 0, title: str(p.title) || `${int(p.points)} 点兑换码`, type: 'pack', points: int(p.points), days: int(p.days), level: str(p.level) };
  return { codes: orders.makeRedeemCodes(plan, count, int(p.owner_user_id), 'ADMIN') };
});
route('/redeem/disable', ({ p }) => { db.update('yd_redeem_code', { status: 'disabled' }, `id=? AND status='unused'`, int(p.id)); return null; });

// ---------------- 任务 ----------------
route('/tasks', ({ p }) => {
  const { limit, offset } = pageArgs(p, 20);
  const where = ['1=1'];
  const args = [];
  if (p.status) { where.push('status=?'); args.push(p.status); }
  if (p.user_id) { where.push('user_id=?'); args.push(int(p.user_id)); }
  if (p.board) { where.push('board=?'); args.push(p.board); }
  return {
    list: db.all(`SELECT id,user_id,kind,board,module,scene,scene_name,status,count,success_count,fail_count,charged_points,refunded_points,model_key,resolution,error,createtime FROM yd_task WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((t) => ({ ...t, createtime: fmtTime(t.createtime) })),
    total: db.val(`SELECT COUNT(*) FROM yd_task WHERE ${where.join(' AND ')}`, ...args),
  };
});
route('/task/detail', ({ p }) => {
  const t = db.get('SELECT * FROM yd_task WHERE id=?', int(p.id));
  if (!t) fail('任务不存在');
  return { task: { ...t, params: jsonParse(t.params, {}) }, results: engine.resultsOf(t.id).map((x) => ({ ...x, spec: jsonParse(x.spec, {}) })) };
});
route('/task/retry', ({ p }) => {
  const t = db.get('SELECT * FROM yd_task WHERE id=?', int(p.id));
  if (!t) fail('任务不存在');
  db.run(`UPDATE yd_task_result SET status='queued', error='', attempts=0 WHERE task_id=? AND status='failed' AND refunded=0`, t.id);
  db.update('yd_task', { status: 'running' }, 'id=?', t.id);
  engine.kick();
  return null;
});
route('/ai/logs', ({ p }) => {
  const { limit, offset } = pageArgs(p, 50);
  return { list: db.all('SELECT * FROM yd_ai_log ORDER BY id DESC LIMIT ? OFFSET ?', limit, offset).map((x) => ({ ...x, time: fmtTime(x.createtime) })), total: db.val('SELECT COUNT(*) FROM yd_ai_log') };
});

// ---------------- 设置 ----------------
route('/settings', () => ({ settings: S.maskSecrets(S.get()), defaults: S.DEFAULTS }));
route('/settings/save', ({ p }) => {
  const group = str(p.group);
  if (!S.DEFAULTS[group]) fail('未知配置分组');
  const value = typeof p.value === 'string' ? jsonParse(p.value, null) : p.value;
  if (!value || typeof value !== 'object') fail('配置内容需为 JSON 对象');
  S.set(group, S.unmaskSecrets(value, S.get(group)));
  return null;
});

// ---------------- 中转站测试 ----------------
route('/relay/models', async ({ p }) => {
  const rl = new RelayClient(S.get('relay'));
  return { models: await rl.listModels(str(p.channel) || undefined) };
});
route('/relay/test_chat', async ({ p }) => {
  const rl = engine.relay();
  const t0 = Date.now();
  const text = await rl.chat({ prompt: str(p.prompt) || '用一句话介绍你自己', which: p.which === 'vision' ? 'vision' : 'chat' });
  return { text, ms: Date.now() - t0 };
});
route('/relay/test_image', async ({ p }) => {
  const rl = engine.relay();
  const t0 = Date.now();
  const imgs = p.image ? [await storage.fetchBuffer(str(p.image))] : [];
  const out = await rl.image({ modelKey: str(p.model_key) || 'm1', prompt: str(p.prompt) || '一只坐在窗台上的橘猫，电商产品摄影风格', images: imgs, ratio: str(p.ratio) || '1:1', resolution: '1K' });
  const url = await engine.saveOutput(out[0], 'test');
  return { url, ms: Date.now() - t0 };
});

// ---------- 优惠券：发放 / 领取记录 ----------
route('/coupon/grant', ({ p }) => {
  const a = db.get('SELECT * FROM yd_coupon_activity WHERE id=?', int(p.activity_id));
  if (!a) fail('优惠券活动不存在');
  let ids = (Array.isArray(p.user_ids) ? p.user_ids : String(p.user_ids || '').split(/[\s,，]+/)).map((x) => int(x)).filter(Boolean);
  if (p.all_members) ids = db.all(`SELECT id FROM yd_user WHERE deletetime=0 AND member_level<>'free' AND member_expiretime>?`, now()).map((x) => x.id);
  if (p.all_users) ids = db.all('SELECT id FROM yd_user WHERE deletetime=0').map((x) => x.id);
  if (!ids.length) fail('请填写用户ID');
  let n = 0;
  db.tx(() => {
    for (const uid of [...new Set(ids)]) {
      if (!users.getUser(uid)) continue;
      db.insert('yd_user_coupon', {
        user_id: uid, activity_id: a.id, title: a.title, amount: a.amount, threshold_amount: a.threshold_amount, status: 'valid',
        expiretime: now() + (a.valid_days || 30) * 86400, createtime: now(),
      });
      n++;
    }
    db.run('UPDATE yd_coupon_activity SET claimed=claimed+? WHERE id=?', n, a.id);
  });
  return { count: n };
});
route('/coupon/records', ({ p }) => {
  const { limit, offset } = pageArgs(p, 30);
  const where = ['1=1']; const args = [];
  if (int(p.activity_id)) { where.push('c.activity_id=?'); args.push(int(p.activity_id)); }
  if (p.status) { where.push('c.status=?'); args.push(p.status); }
  if (int(p.user_id)) { where.push('c.user_id=?'); args.push(int(p.user_id)); }
  const sql = `FROM yd_user_coupon c LEFT JOIN yd_user u ON u.id=c.user_id WHERE ${where.join(' AND ')}`;
  return {
    list: db.all(`SELECT c.*, u.nickname, u.username, u.mobile ${sql} ORDER BY c.id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((x) => ({
      ...x, createtime: fmtTime(x.createtime), expiretime: fmtTime(x.expiretime), usetime: x.usetime ? fmtTime(x.usetime) : '',
      status: x.status === 'valid' && x.expiretime < now() ? 'expired' : x.status,
    })),
    total: db.val(`SELECT COUNT(*) ${sql}`, ...args),
    stats: db.all(`SELECT status, COUNT(*) n FROM yd_user_coupon c WHERE ${where.join(' AND ')} GROUP BY status`, ...args),
  };
});
route('/redeem/export', ({ p }) => {
  const where = p.status ? 'WHERE status=?' : '';
  const rows = db.all(`SELECT * FROM yd_redeem_code ${where} ORDER BY id DESC LIMIT 100000`, ...(p.status ? [p.status] : [])).map((x) => ({ ...x, createtime: fmtTime(x.createtime), usetime: x.usetime ? fmtTime(x.usetime) : '' }));
  return { filename: `redeem-${fmtTime(now()).slice(0, 10)}.csv`, content: csv(rows, [['code', '兑换码'], ['title', '内容'], ['points', '点数'], ['days', '会员天数'], ['level', '等级'], ['status', '状态'], ['owner_user_id', '归属代理'], ['used_user_id', '使用者'], ['usetime', '使用时间'], ['createtime', '生成时间']]) };
});

// ---------- 全局搜索 ----------
route('/search', ({ p }) => {
  const q = str(p.q);
  if (!q) return { users: [], orders: [] };
  const like = `%${q}%`;
  return {
    users: db.all('SELECT id, username, nickname, mobile, email, member_level, member_expiretime, score FROM yd_user WHERE deletetime=0 AND (id=? OR username LIKE ? OR nickname LIKE ? OR mobile LIKE ? OR email LIKE ? OR invite_code=?) ORDER BY id DESC LIMIT 8', int(q), like, like, like, like, q)
      .map((u) => ({ ...u, member_level: users.effectiveLevel(u) })),
    orders: db.all('SELECT order_sn, user_id, title, amount, pay_status FROM yd_order WHERE order_sn LIKE ? ORDER BY id DESC LIMIT 5', like),
    tasks: /^\d+$/.test(q) ? db.all('SELECT id, user_id, scene_name, status FROM yd_task WHERE id=?', int(q)) : [],
  };
});

// ---------- 财务报表 ----------
route('/stats/finance', ({ p }) => {
  const s = p.start ? Math.floor(new Date(p.start + 'T00:00:00+08:00') / 1000) : dayStart(now()) - 29 * DAY;
  const e = p.end ? Math.floor(new Date(p.end + 'T00:00:00+08:00') / 1000) + DAY : dayStart(now()) + DAY;
  const W = `pay_status='paid' AND paytime>=? AND paytime<? AND pay_type NOT IN ('admin','mock')`;
  const days = [];
  const m = new Map(db.all(`SELECT ((paytime + 28800) / 86400) d, SUM(amount) v, COUNT(*) n FROM yd_order WHERE ${W} GROUP BY d`, s, e).map((r) => [r.d, r]));
  for (let t = s; t < e && days.length < 400; t += DAY) { const r = m.get(Math.floor((t + 28800) / DAY)) || {}; days.push({ date: fmtTime(t).slice(0, 10), amount: money(r.v || 0), orders: r.n || 0 }); }
  return {
    total: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE ${W}`, s, e)),
    orders: db.val(`SELECT COUNT(*) FROM yd_order WHERE ${W}`, s, e),
    payers: db.val(`SELECT COUNT(DISTINCT user_id) FROM yd_order WHERE ${W}`, s, e),
    refunded: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE pay_status='refunded' AND updatetime>=? AND updatetime<?`, s, e)),
    offline: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE pay_status='paid' AND paytime>=? AND paytime<? AND pay_type='admin'`, s, e)),
    by_product: db.all(`SELECT title, kind, COUNT(*) n, SUM(amount) amount FROM yd_order WHERE ${W} GROUP BY title ORDER BY amount DESC LIMIT 20`, s, e).map((x) => ({ ...x, amount: money(x.amount) })),
    by_kind: db.all(`SELECT kind, COUNT(*) n, SUM(amount) amount FROM yd_order WHERE ${W} GROUP BY kind`, s, e).map((x) => ({ ...x, amount: money(x.amount) })),
    days,
  };
});

// ---------- 全站点数流水 ----------
route('/score/logs', ({ p }) => {
  const { limit, offset } = pageArgs(p, 30);
  const where = ['1=1']; const args = [];
  if (int(p.user_id)) { where.push('l.user_id=?'); args.push(int(p.user_id)); }
  if (p.type) { where.push('l.type=?'); args.push(p.type); }
  if (p.start) { where.push('l.createtime>=?'); args.push(Math.floor(new Date(p.start + 'T00:00:00+08:00') / 1000)); }
  if (p.end) { where.push('l.createtime<?'); args.push(Math.floor(new Date(p.end + 'T00:00:00+08:00') / 1000) + DAY); }
  const sql = `FROM yd_score_log l LEFT JOIN yd_user u ON u.id=l.user_id WHERE ${where.join(' AND ')}`;
  return {
    list: db.all(`SELECT l.*, u.nickname, u.username ${sql} ORDER BY l.id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((x) => ({ ...x, time: fmtTime(x.createtime) })),
    total: db.val(`SELECT COUNT(*) ${sql}`, ...args),
    sum_in: db.val(`SELECT COALESCE(SUM(l.change),0) ${sql} AND l.change>0`, ...args),
    sum_out: db.val(`SELECT COALESCE(SUM(l.change),0) ${sql} AND l.change<0`, ...args),
    types: db.all('SELECT DISTINCT type FROM yd_score_log').map((x) => x.type),
  };
});

// ---------- 功能 → 模型 ----------
const { guessModel, capsOf } = require('../ai/relay');
const modules = require('../ai/modules');
const TEXT_FEATURES = [
  { key: 'text:prompt_plan', name: '首页对话：理解需求', desc: '对话模式先说明怎么改，并写出给生图模型的精确指令（带图时需要识图模型）' },
  { key: 'text:prompt_optimize', name: '优化提示词', desc: '首页输入框的魔法棒' },
  { key: 'text:text_translate', name: '画布·图片翻译', desc: '精准改字里的「全部翻译」：翻译图上识别出的文字' },
  { key: 'text:prompt_reverse', name: '画布·反推提示词', desc: '画布里选中图片 →「反推提示词」（还原画面 / 总结模板），需要识图模型' },
  { key: 'text:prompt_adapt', name: '一键同款改写', desc: '素材库一键同款：看懂用户的图，改写模板提示词（需要识图模型）' },
  { key: 'text:outline', name: '商品套图规划', desc: '商品套图工具的「AI 规划套图」' },
  { key: 'text:gallery', name: '素材库生成 / 识图', desc: '后台素材库：批量想画面、识图写提示词（识图需要识图模型）' },
];
const SPECIAL_FEATURES = [
  { key: 'kind:ai', name: '首页创作', desc: '首页对话 / 快速 / 电商套图出图' },
  { key: 'gallery', name: '素材库批量出图', desc: '后台素材库「批量生成」「生成同类」用的生图模型' },
];
// 发一条测试短信（用当前保存的短信配置）
route('/sms/test', async ({ p }) => {
  const mobile = String(p.mobile || '').trim();
  if (!/^1\d{10}$/.test(mobile)) fail('请填写正确的手机号');
  const cfg = S.get('sms') || {};
  if (cfg.provider !== 'aliyun' && cfg.provider !== 'aliyun_pnvs') fail('请先选择短信服务商并保存');
  try { await require('../core/notify').aliyunSms(mobile, String(Math.floor(100000 + Math.random() * 900000)), cfg); } catch (e) { fail(e.message); }
  return { ok: true };
});
// 腾讯云 COS 连通性测试：上传一张小图 → 公网读取 → 数据万象缩略图 → 跨域 → 删除
route('/storage/test', async () => {
  const c = (S.get('storage') || {}).cos || {};
  const miss = [['SecretId', c.secret_id], ['SecretKey', c.secret_key], ['Bucket', c.bucket], ['地域', c.region]].filter((x) => !x[1]).map((x) => x[0]);
  if (miss.length) fail(`请先填写并保存：${miss.join('、')}`);
  const steps = [];
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAFklEQVR4nGP4X+VKEmIY1TCqYfhqAADVFb4Q0aSh3gAAAABJRU5ErkJggg==', 'base64');
  const key = `${(c.prefix || 'uploads').replace(/^\/|\/$/g, '')}/_test/ct-${Date.now()}.png`;
  let url = '';
  try { url = await storage.cosPut(key, png, 'image/png', c); steps.push({ name: '上传', ok: true, msg: url }); } catch (e) {
    steps.push({ name: '上传', ok: false, msg: `${e.message}。检查：SecretId / SecretKey 是否正确、子用户是否有 QcloudCOSDataFullControl 权限、桶名是否带数字后缀、地域是否填对（香港 ap-hongkong）` });
    return { ok: false, steps };
  }
  const get = async (u, headers = {}) => { const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000); try { return await fetch(u, { headers, signal: ctl.signal }); } finally { clearTimeout(t); } };
  try { const r = await get(url); steps.push({ name: '公开读取', ok: r.ok, msg: r.ok ? '用户能直接打开图片' : `HTTP ${r.status}：存储桶「访问权限」要设为「公有读私有写」` }); } catch (e) { steps.push({ name: '公开读取', ok: false, msg: e.message }); }
  try {
    const r = await get(url + '?imageMogr2/thumbnail/8x/format/webp');
    const ok = r.ok && /webp/.test(r.headers.get('content-type') || '');
    steps.push({ name: '数据万象（列表小图）', ok, warn: !ok, msg: ok ? '小图生成正常' : '没生效：到数据万象控制台开通并「绑定存储桶」。不开也能用，只是列表会加载原图、比较慢' });
  } catch (e) { steps.push({ name: '数据万象（列表小图）', ok: false, warn: true, msg: e.message }); }
  try {
    const site = S.get('site') || {};
    const origin = site.frontend_url ? new URL(site.frontend_url).origin : (site.domain ? 'https://' + site.domain : '');
    if (origin) {
      const r = await get(url, { Origin: origin });
      const a = r.headers.get('access-control-allow-origin') || '';
      const ok = a === '*' || a === origin;
      steps.push({ name: '跨域（CORS）', ok, warn: !ok, msg: ok ? `${origin} 可以跨域读取` : `没配置：存储桶「安全管理 → 跨域访问 CORS」添加来源 ${origin}，方法 GET、HEAD，Allow-Headers 填 *。影响证件照等需要在页面里处理图片的工具` });
    }
  } catch (e) { steps.push({ name: '跨域（CORS）', ok: false, warn: true, msg: e.message }); }
  try { steps.push({ name: '删除测试图', ok: await storage.cosDelete(key, c), msg: '' }); } catch (e) { steps.push({ name: '删除测试图', ok: false, warn: true, msg: e.message }); }
  return { ok: steps.every((x) => x.ok || x.warn), steps };
});
route('/relay/features', () => ({ text: TEXT_FEATURES, special: SPECIAL_FEATURES, groups: modules.listFeatures() }));
route('/relay/fetch_models', async ({ p }) => {
  const relay = { ...S.get('relay') };
  if (p.channel_config) relay.channels = [S.unmaskSecrets(p.channel_config, (relay.channels || []).find((c) => c && c.id === p.channel_config.id))];
  const rl = new RelayClient(relay);
  const id = p.channel_config ? p.channel_config.id : str(p.channel);
  const list = await rl.listModelsDetailed(id || undefined);
  return {
    models: list.sort((a, b) => a.id.localeCompare(b.id)).map(({ id: m, hint }) => {
      const g = guessModel(m);
      // 中转站明确标了生图 / 视频的，以中转站为准
      if (hint === 'image' && g.type !== 'image') return { model: m, type: 'image', mode: 'openai', size_strategy: 'pixels' };
      if (hint === 'video' && g.type !== 'video') return { model: m, type: 'video', mode: /sora/i.test(m) ? 'openai-video' : 'chat-video' };
      return { model: m, ...g };
    }),
  };
});
route('/relay/test_model', async ({ p }) => {
  const rl = engine.relay();
  const ref = str(p.ref);
  const m = rl.modelFromRef(ref);
  if (!m) fail('请选择模型');
  const t0 = Date.now();
  const caps = capsOf(m);
  const want = str(p.cap) || (caps.includes('image') ? 'image' : caps.includes('video') ? 'video' : 'text');
  if (want === 'image') {
    const out = await rl.image({ modelRef: ref, prompt: str(p.prompt) || '一只坐在窗台上的橘猫，电商产品摄影风格，干净背景', ratio: '1:1', resolution: '1K' });
    return { type: 'image', url: await engine.saveOutput(out[0], 'test'), ms: Date.now() - t0 };
  }
  if (want === 'video') fail('视频模型测试较慢且费用高，请在前台直接试用');
  const text = await rl.chat({ modelRef: ref, prompt: str(p.prompt) || '用一句话介绍你自己，并说明你是哪个模型' });
  return { type: 'text', text, ms: Date.now() - t0 };
});

// ---------------- 上传（后台素材/图片） ----------------
route('/upload', async ({ files, p }) => {
  const f = files[0];
  if (!f) fail('请选择文件');
  return storage.saveBuffer(f.buffer, { mimetype: f.mimetype, category: str(p.category) || 'admin' });
});

// =====================================================================
// 扩展：统计趋势、用户详情/批量、导出、作品审核、站点品牌、抠图、管理员、系统
// =====================================================================
const fs = require('fs');
const path = require('path');
const config = require('../core/config');
const matting = require('../ai/matting');
const DAY = 86400;
const dayStart = (t) => t - ((t + 8 * 3600) % DAY);
const csv = (rows, cols) => '﻿' + [cols.map((c) => c[1]).join(','), ...rows.map((r) => cols.map((c) => {
  const v = String(r[c[0]] ?? '').replace(/"/g, '""');
  return /[",\n]/.test(v) ? `"${v}"` : v;
}).join(','))].join('\n');

// ---------- 趋势 ----------
route('/stats/trend', ({ p }) => {
  const days = Math.max(7, Math.min(90, int(p.days, 30)));
  const end = dayStart(now()) + DAY;
  const start = end - days * DAY;
  const bucket = (sql, ...a) => {
    const m = new Map();
    for (const r of db.all(sql, start, ...a)) m.set(r.d, r.v);
    return m;
  };
  const D = `((%s + 28800) / 86400)`;
  const q = (col) => D.replace('%s', col);
  const users_ = bucket(`SELECT ${q('jointime')} d, COUNT(*) v FROM yd_user WHERE jointime>=? AND deletetime=0 GROUP BY d`);
  const revenue = bucket(`SELECT ${q('paytime')} d, SUM(amount) v FROM yd_order WHERE paytime>=? AND pay_status='paid' AND pay_type NOT IN ('admin','mock') GROUP BY d`);
  const ordersN = bucket(`SELECT ${q('paytime')} d, COUNT(*) v FROM yd_order WHERE paytime>=? AND pay_status='paid' GROUP BY d`);
  const tasks = bucket(`SELECT ${q('createtime')} d, COUNT(*) v FROM yd_task WHERE createtime>=? GROUP BY d`);
  const images = bucket(`SELECT ${q('updatetime')} d, COUNT(*) v FROM yd_task_result WHERE updatetime>=? AND status='succeeded' GROUP BY d`);
  const failed = bucket(`SELECT ${q('updatetime')} d, COUNT(*) v FROM yd_task_result WHERE updatetime>=? AND status='failed' GROUP BY d`);
  const points = bucket(`SELECT ${q('createtime')} d, -SUM(change) v FROM yd_score_log WHERE createtime>=? AND type IN ('consume','refund') GROUP BY d`);
  const out = { dates: [], users: [], revenue: [], orders: [], tasks: [], images: [], failed: [], points: [] };
  for (let t = start; t < end; t += DAY) {
    const d = Math.floor((t + 28800) / DAY);
    out.dates.push(fmtTime(t).slice(5, 10));
    out.users.push(users_.get(d) || 0);
    out.revenue.push(money(revenue.get(d) || 0));
    out.orders.push(ordersN.get(d) || 0);
    out.tasks.push(tasks.get(d) || 0);
    out.images.push(images.get(d) || 0);
    out.failed.push(failed.get(d) || 0);
    out.points.push(points.get(d) || 0);
  }
  return out;
});
route('/stats/rank', ({ p }) => {
  const since = now() - Math.max(1, Math.min(90, int(p.days, 7))) * DAY;
  return {
    scenes: db.all(`SELECT scene_name name, module, COUNT(*) tasks, SUM(success_count) ok, SUM(fail_count) bad, SUM(charged_points - refunded_points) points FROM yd_task WHERE createtime>=? GROUP BY module ORDER BY tasks DESC LIMIT 12`, since),
    models: db.all(`SELECT model, kind, COUNT(*) calls, SUM(ok) ok, CAST(AVG(ms) AS INTEGER) avg_ms FROM yd_ai_log WHERE createtime>=? GROUP BY model, kind ORDER BY calls DESC LIMIT 10`, since),
    consumers: db.all(`SELECT l.user_id, u.nickname, u.username, u.mobile, -SUM(l.change) points FROM yd_score_log l LEFT JOIN yd_user u ON u.id=l.user_id WHERE l.createtime>=? AND l.type IN ('consume','refund') GROUP BY l.user_id HAVING points>0 ORDER BY points DESC LIMIT 10`, since),
    levels: db.all(`SELECT member_level level, COUNT(*) n FROM yd_user WHERE deletetime=0 AND member_level<>'free' AND member_expiretime>? GROUP BY member_level`, now()),
    balance: db.val('SELECT COALESCE(SUM(score),0) FROM yd_user WHERE deletetime=0'),
    matting: db.all(`SELECT r.status, COUNT(*) n FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id WHERE t.createtime>=? AND t.module IN ('toolbox.cutout','pod.smartcutout','toolbox.idphoto','toolbox.cutoutpro','product.whitebg') GROUP BY r.status`, since),
  };
});

// ---------- 用户详情 / 批量 / 导出 ----------
route('/user/detail', ({ p }) => {
  const u = users.getUser(int(p.id));
  if (!u) fail('用户不存在');
  const id = u.id;
  return {
    user: {
      id, username: u.username, nickname: u.nickname, avatar: u.avatar, mobile: u.mobile, email: u.email, score: u.score, status: u.status,
      member_level: users.effectiveLevel(u), member_expiretime: u.member_expiretime ? fmtTime(u.member_expiretime) : '', invite_code: u.invite_code,
      parent_user_id: u.parent_user_id,
      jointime: fmtTime(u.jointime), logintime: u.logintime ? fmtTime(u.logintime) : '', joinip: u.joinip || '', remark: u.remark,
    },
    stats: {
      paid: money(db.val(`SELECT COALESCE(SUM(amount),0) FROM yd_order WHERE user_id=? AND pay_status='paid'`, id)),
      orders: db.val(`SELECT COUNT(*) FROM yd_order WHERE user_id=? AND pay_status='paid'`, id),
      tasks: db.val('SELECT COUNT(*) FROM yd_task WHERE user_id=?', id),
      images: db.val(`SELECT COUNT(*) FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id WHERE t.user_id=? AND r.status='succeeded'`, id),
      consumed: -(db.val(`SELECT COALESCE(SUM(change),0) FROM yd_score_log WHERE user_id=? AND type IN ('consume','refund')`, id) || 0),
      invitees: db.val('SELECT COUNT(*) FROM yd_user WHERE parent_user_id=? AND deletetime=0', id),
    },
    orders: db.all('SELECT * FROM yd_order WHERE user_id=? ORDER BY id DESC LIMIT 20', id).map((o) => orders.orderView(o)),
    tasks: db.all('SELECT id, scene_name, status, count, success_count, charged_points, refunded_points, createtime FROM yd_task WHERE user_id=? ORDER BY id DESC LIMIT 20', id).map((t) => ({ ...t, createtime: fmtTime(t.createtime) })),
    logs: db.all('SELECT * FROM yd_score_log WHERE user_id=? ORDER BY id DESC LIMIT 30', id).map((x) => ({ ...x, time: fmtTime(x.createtime) })),
    invitees: db.all('SELECT id, nickname, username, mobile, jointime FROM yd_user WHERE parent_user_id=? AND deletetime=0 ORDER BY id DESC LIMIT 20', id).map((x) => ({ ...x, jointime: fmtTime(x.jointime) })),
    images: db.all(`SELECT r.url FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id WHERE t.user_id=? AND r.status='succeeded' AND r.url<>'' AND r.deleted=0 ORDER BY r.id DESC LIMIT 12`, id).map((x) => x.url),
  };
});
route('/user/batch', ({ p, admin }) => {
  const ids = (Array.isArray(p.ids) ? p.ids : String(p.ids || '').split(',')).map((x) => int(x)).filter(Boolean);
  if (!ids.length) fail('请先选择用户');
  let n = 0;
  for (const id of ids) {
    const u = users.getUser(id);
    if (!u) continue;
    if (p.action === 'disable') { db.update('yd_user', { status: 'hidden' }, 'id=?', id); db.run('DELETE FROM yd_token WHERE user_id=?', id); }
    else if (p.action === 'enable') db.update('yd_user', { status: 'normal' }, 'id=?', id);
    else if (p.action === 'score') { if (!int(p.change)) fail('请输入点数'); users.changeScore(id, int(p.change), 'adjust', str(p.remark) || '后台批量调整', '', admin.id); }
    else if (p.action === 'grant') { if (!int(p.days)) fail('请输入天数'); users.grantMembership(id, str(p.level) || 'basic', int(p.days)); }
    else fail('未知操作');
    n++;
  }
  return { count: n };
});
route('/users/export', () => {
  const rows = db.all('SELECT * FROM yd_user WHERE deletetime=0 ORDER BY id DESC LIMIT 100000').map((u) => ({
    ...u, member_level: users.effectiveLevel(u), member_expiretime: u.member_expiretime ? fmtTime(u.member_expiretime) : '', jointime: fmtTime(u.jointime), logintime: u.logintime ? fmtTime(u.logintime) : '',
  }));
  return { filename: `users-${fmtTime(now()).slice(0, 10)}.csv`, content: csv(rows, [['id', 'ID'], ['username', '用户名'], ['nickname', '昵称'], ['mobile', '手机'], ['email', '邮箱'], ['score', '点数'], ['member_level', '会员'], ['member_expiretime', '会员到期'], ['parent_user_id', '上级'], ['invite_code', '邀请码'], ['status', '状态'], ['jointime', '注册时间'], ['logintime', '最近登录']]) };
});
route('/orders/export', ({ p }) => {
  const where = ['1=1']; const args = [];
  if (p.pay_status) { where.push('pay_status=?'); args.push(p.pay_status); }
  if (p.start) { where.push('createtime>=?'); args.push(Math.floor(new Date(p.start + 'T00:00:00+08:00') / 1000)); }
  if (p.end) { where.push('createtime<?'); args.push(Math.floor(new Date(p.end + 'T00:00:00+08:00') / 1000) + DAY); }
  const rows = db.all(`SELECT * FROM yd_order WHERE ${where.join(' AND ')} ORDER BY id DESC LIMIT 100000`, ...args).map((o) => ({ ...orders.orderView(o), user_id: o.user_id }));
  return { filename: `orders-${fmtTime(now()).slice(0, 10)}.csv`, content: csv(rows, [['order_sn', '订单号'], ['user_id', '用户ID'], ['title', '商品'], ['amount', '金额'], ['points', '点数'], ['pay_type_text', '支付方式'], ['pay_status', '状态'], ['createtime_text', '创建时间'], ['paytime_text', '支付时间']]) };
});
route('/order/refund', ({ p, admin }) => {
  const o = db.get(`SELECT * FROM yd_order WHERE order_sn=? AND pay_status='paid'`, str(p.order_sn));
  if (!o) fail('订单不存在或未支付');
  db.tx(() => {
    db.update('yd_order', { pay_status: 'refunded', updatetime: now() }, 'id=?', o.id);
    if (p.deduct && o.points > 0) users.changeScore(o.user_id, -Math.min(o.points, (users.getUser(o.user_id) || {}).score || 0), 'adjust', `订单退款扣回 ${o.order_sn}`, '', admin.id);
  });
  return null;
});

// ---------- 作品审核 ----------
route('/gallery', ({ p }) => {
  const { limit, offset } = pageArgs(p, 40, 200);
  const where = [`r.status='succeeded'`, `r.url<>''`, 'r.deleted=0'];
  const args = [];
  if (int(p.user_id)) { where.push('t.user_id=?'); args.push(int(p.user_id)); }
  if (str(p.keyword)) { where.push('(t.scene_name LIKE ? OR t.module LIKE ?)'); args.push(`%${str(p.keyword)}%`, `%${str(p.keyword)}%`); }
  const sql = `FROM yd_task_result r JOIN yd_task t ON t.id=r.task_id WHERE ${where.join(' AND ')}`;
  return {
    list: db.all(`SELECT r.id, r.url, r.task_id, r.idx, r.label, t.user_id, t.scene_name, t.module, r.updatetime ${sql} ORDER BY r.id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((x) => ({ ...x, time: fmtTime(x.updatetime) })),
    total: db.val(`SELECT COUNT(*) ${sql}`, ...args),
  };
});
route('/gallery/del', ({ p }) => {
  const ids = (Array.isArray(p.ids) ? p.ids : [p.id]).map((x) => int(x)).filter(Boolean);
  for (const id of ids) db.update('yd_task_result', { deleted: 1 }, 'id=?', id);
  return { count: ids.length };
});

// ---------- 站点品牌（客服二维码 / Logo） ----------
const BRAND_DIR = path.join(path.dirname(path.resolve(config.root, config.dbFile || './data/yuduo.db')), 'brand');
const BRAND_ICONS = [['favicon-32.png', 32], ['favicon-64.png', 64], ['apple-touch-icon.png', 180], ['icon-192.png', 192], ['icon-512.png', 512]];
route('/brand/upload', async ({ files, p }) => {
  const f = files[0];
  if (!f) fail('请选择图片');
  const kind = str(p.kind);
  if (!['kefu', 'logo'].includes(kind)) fail('未知类型');
  if (!/^image\//.test(f.mimetype || '') && !storage.sniff(f.buffer)) fail('请上传图片');
  fs.mkdirSync(BRAND_DIR, { recursive: true });
  fs.writeFileSync(path.join(BRAND_DIR, `${kind}.png`), f.buffer);
  // 换 Logo 时顺带生成浏览器标签图标、手机桌面图标（需要服务器装了缩图工具；没装就只换 Logo）
  if (kind === 'logo') {
    const { squarePng } = require('../core/thumbs');
    for (const [name, size] of BRAND_ICONS) squarePng(path.join(BRAND_DIR, 'logo.png'), path.join(BRAND_DIR, name), size);
  }
  return { url: `/brand/${kind}.png?t=${Date.now()}` };
});
// ---------- 工具封面 ----------
const coverJobs = new Map();   // slug -> { state: 'running' | 'error', error }
const slugOk = (v) => { const x = str(v, 80); if (!/^[a-z0-9][a-z0-9-]*$/i.test(x)) fail('工具标识不正确'); return x; };
const setCover = (slug, url) => { const m = { ...(S.get('tool_covers') || {}) }; if (url) m[slug] = url; else delete m[slug]; S.set('tool_covers', m); };
route('/tools/covers', () => ({ covers: S.get('tool_covers') || {}, jobs: Object.fromEntries(coverJobs), gen: S.get('cover_gen') || {} }));
route('/tools/cover/upload', async ({ files, p }) => {
  const slug = slugOk(p.slug);
  const f = files[0];
  if (!f || !storage.sniff(f.buffer)) fail('请上传图片');
  const r = await storage.saveBuffer(f.buffer, { mimetype: storage.sniff(f.buffer), category: 'cover' });
  setCover(slug, r.fullurl);
  return { url: r.fullurl };
});
route('/tools/cover/reset', ({ p }) => { setCover(slugOk(p.slug), ''); return null; });
// AI 生成封面：后台排队执行（每张约半分钟），前端轮询 /tools/covers
let coverQueue = Promise.resolve();
route('/tools/cover/generate', ({ p }) => {
  const list = (Array.isArray(p.items) ? p.items : [p]).slice(0, 200).map((x) => ({ slug: slugOk(x.slug), name: str(x.name, 40), desc: str(x.desc, 200), tip: str(x.tip, 400), extra: str(x.extra, 400) }));
  for (const it of list) {
    if (coverJobs.get(it.slug) && coverJobs.get(it.slug).state === 'running') continue;
    coverJobs.set(it.slug, { state: 'running' });
    coverQueue = coverQueue.then(async () => {
      try {
        // 1) 文本模型先把这个工具“画什么”想清楚：左边输入、右边结果（和参考平台一样的前后对比封面）
        let plan = null;
        try {
          const text = await engine.relay().chat({
            system: '你是电商 AI 作图平台的视觉设计师，为每个工具设计一眼能看懂的功能封面。只输出 JSON。',
            prompt: [
              `工具名：${it.name}`, it.desc ? `功能：${it.desc}` : '', it.extra ? `站长要求（必须满足）：${it.extra}` : '', it.tip ? `用法：${it.tip.replace(/\n/g, ' ')}` : '',
              '封面统一版式：左右对比图——左半边是用户上传的「输入」（如平铺服装、白底商品、原模特照、线稿等），右半边是这个工具生成的「结果」，中间一个白色半透明弧形箭头从左指向右。工具本身能一次出多张的（套图、多姿势、多场景），右边用 2×2 或 3 张拼格展示多个结果。',
              '商品要选电商里最常见、质感好的爆款（如精华液、连衣裙、针织衫、运动鞋、包包、耳机），模特统一为气质好的亚洲年轻模特（男装用男模），结果图要达到品牌广告大片水准。',
              '要求：输入和结果必须是同一件商品/同一个人，结果要非常直观地体现这个工具的作用，看一眼就知道这个工具干什么。如果这个工具不适合左右对比（如文案、标注、拼图），就画一张直接展示成品效果的图。',
              '返回 JSON：{"layout":"compare 或 single","left":"左边画什么（具体到商品、颜色、背景）","right":"右边画什么（具体）","single":"single 时画什么"}',
            ].filter(Boolean).join('\n'),
            json: true, which: 'chat', temperature: 0.6,
          });
          plan = require('../ai/relay').RelayClient.parseJson(text);
        } catch { /* 文本模型不可用时用通用版式 */ }
        const prompt = plan && plan.layout === 'single' && plan.single
          ? `电商 AI 作图工具「${it.name}」的功能封面：${plan.single}。真实商业摄影质感，暖白色调，干净高级。画面中不要出现任何文字、Logo、水印。`
          : [
            `电商 AI 作图工具「${it.name}」的功能封面，左右对比构图（左右各占一半，中间细分界线）。`,
            `左半边（输入）：${(plan && plan.left) || (it.desc ? `用户上传的原图，${it.desc}之前` : '用户上传的原图')}。`,
            `右半边（结果）：${(plan && plan.right) || (it.desc ? `${it.desc}之后的效果` : '处理后的效果')}。`,
            '中间放一个白色半透明、带轻微投影的弧形箭头从左指向右。左右是同一件商品/同一个人（颜色、款式、细节完全一致），对比效果一眼能看懂。',
            '品牌广告大片水准：专业商业摄影布光，柔和自然光与通透高光，浅景深，皮肤和面料质感真实细腻，色彩干净统一（暖白/米色/浅粉为主），构图饱满留白恰当，超清细节。',
            '画面中不要出现任何文字、字母、Logo、水印、界面元素；不要畸形手指和多余肢体。',
          ].join('');
        const cg = S.get('cover_gen') || {};
        const mk = str(p.model_key) || cg.model_key || 'm2';
        const outs = await engine.relay().image({ ...(mk.startsWith('ref:') ? { modelRef: mk.slice(4) } : { modelKey: mk }), prompt, ratio: cg.ratio || '1:1', resolution: cg.resolution || '4K', n: 1 });
        let o = outs[0];
        if (!o.buffer && o.url) o = await storage.fetchBuffer(o.url);
        const r = await storage.saveBuffer(o.buffer, { mimetype: o.mimetype || storage.sniff(o.buffer) || 'image/png', category: 'cover' });
        setCover(it.slug, r.fullurl);
        coverJobs.delete(it.slug);
      } catch (e) {
        coverJobs.set(it.slug, { state: 'error', error: engine.cleanError(e) });
      }
    });
  }
  return { queued: list.length };
});
route('/brand/reset', ({ p }) => {
  const kind = str(p.kind);
  if (!['kefu', 'logo'].includes(kind)) fail('未知类型');
  try { fs.unlinkSync(path.join(BRAND_DIR, `${kind}.png`)); } catch {}
  if (kind === 'logo') for (const [name] of BRAND_ICONS) { try { fs.unlinkSync(path.join(BRAND_DIR, name)); } catch {} }
  return null;
});

// ---------- 抠图 ----------
route('/matting/status', async ({ p }) => {
  const st = await matting.localStatus(!!p.force);
  return { ...st, settings: S.maskSecrets(S.get('matting')) };
});
// 效果测试在后台跑，前端轮询结果（本地 BiRefNet 首次加载 + 推理可能要一分钟以上，手机浏览器长时间挂着的请求容易断）
const mattingTests = new Map();
route('/matting/test', async ({ files, p }) => {
  const f = files[0];
  let buf = f ? f.buffer : null;
  if (!buf && p.image) buf = (await storage.fetchBuffer(str(p.image))).buffer;
  if (!buf) fail('请上传测试图片');
  const id = crypto.randomBytes(6).toString('hex');
  const job = { done: false, out: {}, at: Date.now() };
  mattingTests.set(id, job);
  for (const [k, v] of mattingTests) if (Date.now() - v.at > 3600000) mattingTests.delete(k);
  const save = async (r) => ({ url: (await storage.saveBuffer(r.buffer, { mimetype: r.mimetype, category: 'test' })).fullurl, confidence: r.confidence, engine: r.engine, ms: r.ms });
  (async () => {
    const t0 = Date.now();
    const pw = p.ai || p.picwish;
    await Promise.all([
      pw ? (async () => { try { job.out.picwish = await save(await matting.picwishCutout(buf)); job.out.picwish.ms = Date.now() - t0; } catch (e) { job.out.picwish = { error: e.message }; } })() : null,
    ]);
    job.done = true;
  })();
  return { id };
});
route('/matting/test/result', ({ p }) => {
  const job = mattingTests.get(str(p.id));
  if (!job) fail('测试任务不存在或已过期');
  return { done: job.done, ...job.out };
});

// ---------- 链接解析 ----------

// ---------- 管理员 ----------
route('/admins', () => ({ list: db.all('SELECT id, username, nickname, role, status, createtime, logintime FROM yd_admin ORDER BY id').map((a) => ({ ...a, createtime: fmtTime(a.createtime), logintime: a.logintime ? fmtTime(a.logintime) : '' })) }));
route('/admin/save', ({ p, admin }) => {
  if (admin.role && admin.role !== 'super') fail('只有超级管理员可以管理账号');
  const row = { nickname: str(p.nickname), role: ['super', 'operator', 'viewer'].includes(p.role) ? p.role : 'operator', status: p.status === 'hidden' ? 'hidden' : 'normal' };
  if (p.password) {
    if (String(p.password).length < 10 || !/[A-Za-z]/.test(p.password) || !/\d/.test(p.password)) fail('密码至少 10 位，并且要同时包含字母和数字');
    const h = hashPassword(p.password); row.password = h.hash; row.salt = h.salt;
  }
  if (int(p.id)) {
    if (int(p.id) === admin.id && (row.status === 'hidden' || row.role !== 'super')) fail('不能停用或降级自己');
    db.update('yd_admin', row, 'id=?', int(p.id));
    if (row.status === 'hidden') db.run('DELETE FROM yd_admin_token WHERE admin_id=?', int(p.id));
    return null;
  }
  if (!str(p.username) || !p.password) fail('请填写账号和密码');
  if (db.get('SELECT id FROM yd_admin WHERE username=?', str(p.username))) fail('账号已存在');
  db.insert('yd_admin', { username: str(p.username), ...row, createtime: now() });
  return null;
});
route('/admin/del', ({ p, admin }) => {
  if (admin.role && admin.role !== 'super') fail('只有超级管理员可以管理账号');
  if (int(p.id) === admin.id) fail('不能删除自己');
  db.run('DELETE FROM yd_admin WHERE id=?', int(p.id));
  db.run('DELETE FROM yd_admin_token WHERE admin_id=?', int(p.id));
  return null;
});
route('/admin/logs', ({ p }) => {
  const { limit, offset } = pageArgs(p, 30);
  const where = str(p.keyword) ? 'WHERE action LIKE ? OR username LIKE ? OR detail LIKE ?' : '';
  const args = str(p.keyword) ? [`%${str(p.keyword)}%`, `%${str(p.keyword)}%`, `%${str(p.keyword)}%`] : [];
  return {
    list: db.all(`SELECT * FROM yd_admin_log ${where} ORDER BY id DESC LIMIT ? OFFSET ?`, ...args, limit, offset).map((x) => ({ ...x, time: fmtTime(x.createtime) })),
    total: db.val(`SELECT COUNT(*) FROM yd_admin_log ${where}`, ...args),
  };
});

// ---------- 系统 ----------
function dirSize(dir) {
  let n = 0, c = 0;
  const walk = (d) => { let es = []; try { es = fs.readdirSync(d, { withFileTypes: true }); } catch { return; } for (const e of es) { const f = path.join(d, e.name); if (e.isDirectory()) walk(f); else { try { n += fs.statSync(f).size; c++; } catch {} } } };
  walk(dir);
  return { bytes: n, files: c };
}
let sizeCache = { t: 0, v: null };
route('/system/info', async () => {
  const dbFile = path.resolve(config.root, config.dbFile || './data/yuduo.db');
  if (Date.now() - sizeCache.t > 300000) sizeCache = { t: Date.now(), v: dirSize(path.resolve(config.root, config.uploadDir || './data/uploads')) };
  let pkg = {};
  try { pkg = JSON.parse(fs.readFileSync(path.join(config.root, 'package.json'), 'utf8')); } catch {}
  let disk = null;
  try { const s = fs.statfsSync(path.dirname(dbFile)); disk = { total: s.blocks * s.bsize, free: s.bavail * s.bsize }; } catch {}
  const mt = await matting.localStatus();
  return {
    version: pkg.version || '', node: process.version, platform: `${process.platform} ${process.arch}`, uptime: Math.floor(process.uptime()),
    memory: process.memoryUsage().rss, db_size: (() => { try { return fs.statSync(dbFile).size; } catch { return 0; } })(), uploads: sizeCache.v, disk,
    queue: db.val(`SELECT COUNT(*) FROM yd_task_result WHERE status IN ('queued','running')`),
    frontend: config.frontendDist || '', public_url: config.publicBaseUrl, matting: { ok: mt.ok, error: mt.error, model: mt.model },
    tasks_total: db.val('SELECT COUNT(*) FROM yd_task'), users_total: db.val('SELECT COUNT(*) FROM yd_user WHERE deletetime=0'),
  };
});
route('/system/backup', () => {
  const dir = path.join(path.dirname(path.resolve(config.root, config.dbFile || './data/yuduo.db')), 'backup');
  fs.mkdirSync(dir, { recursive: true });
  const name = `yuduo-${fmtTime(now()).replace(/[-: ]/g, '').slice(0, 14)}.db`;
  db.run(`VACUUM INTO '${path.join(dir, name).replace(/'/g, "''")}'`);
  // 只保留最近 10 份
  const all = fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort();
  while (all.length > 10) { try { fs.unlinkSync(path.join(dir, all.shift())); } catch {} }
  return { name, size: fs.statSync(path.join(dir, name)).size, list: fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort().reverse() };
});
route('/system/backups', () => {
  const dir = path.join(path.dirname(path.resolve(config.root, config.dbFile || './data/yuduo.db')), 'backup');
  let list = [];
  try { list = fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort().reverse().map((f) => ({ name: f, size: fs.statSync(path.join(dir, f)).size })); } catch {}
  return { list, dir };
});
route('/system/cleanup', ({ p }) => {
  let n = 0;
  const tmp = path.join(path.dirname(path.resolve(config.root, config.dbFile || './data/yuduo.db')), 'tmp');
  try { for (const f of fs.readdirSync(tmp)) { const fp = path.join(tmp, f); if (Date.now() - fs.statSync(fp).mtimeMs > 3600e3) { fs.unlinkSync(fp); n++; } } } catch {}
  const days = int(p.log_days, 30);
  const logs = db.run('DELETE FROM yd_ai_log WHERE createtime < ?', now() - days * DAY).changes;
  db.run('DELETE FROM yd_captcha WHERE expiretime < ?', now());
  db.run('DELETE FROM yd_token WHERE expiretime > 0 AND expiretime < ?', now());
  db.run('DELETE FROM yd_admin_token WHERE expiretime < ?', now());
  return { tmp_files: n, ai_logs: logs };
});

// ---------------- 素材库（官方素材） ----------------
const gallery = require('../ai/gallery');
route('/library/list', ({ p }) => {
  const { limit, offset } = pageArgs(p, 40, 200);
  const where = ['1=1'];
  const args = [];
  if (['draft', 'online', 'offline', 'ref'].includes(p.status)) { where.push('status=?'); args.push(p.status); } else where.push("status!='ref'");
  if (int(p.cat_id)) { where.push('cat_id=?'); args.push(int(p.cat_id)); }
  if (int(p.job_id)) { where.push('job_id=?'); args.push(int(p.job_id)); }
  if (str(p.q)) { where.push('(title LIKE ? OR prompt LIKE ?)'); args.push(`%${str(p.q)}%`, `%${str(p.q)}%`); }
  const catMap = new Map(gallery.cats().map((c) => [c.id, c]));
  const counts = Object.fromEntries(db.all('SELECT status, COUNT(*) n FROM yd_gallery GROUP BY status').map((r) => [r.status, r.n]));
  // 「已上架」按前台顺序排（= 首页灵感发现 / 素材库「推荐」的顺序），并带上在前台的位置
  const front = p.status === 'online';
  const pos = front ? new Map(gallery.frontOrder().map((id, i) => [id, i + 1])) : null;
  return {
    front,
    list: db.all(`SELECT * FROM yd_gallery WHERE ${where.join(' AND ')} ORDER BY ${front ? gallery.FRONT_ORDER : 'id DESC'} LIMIT ? OFFSET ?`, ...args, limit, offset).map((g) => ({ ...gallery.itemView(g, catMap), ...(pos ? { pos: pos.get(g.id) || 0 } : {}) })),
    total: db.val(`SELECT COUNT(*) FROM yd_gallery WHERE ${where.join(' AND ')}`, ...args),
    counts,
    cats: gallery.cats().map((c) => ({ id: c.id, name: c.name, sort: c.sort, count: db.val('SELECT COUNT(*) FROM yd_gallery WHERE cat_id=?', c.id) || 0 })),
  };
});
route('/library/save', ({ p }) => {
  const g = db.get('SELECT * FROM yd_gallery WHERE id=?', int(p.id));
  if (!g) fail('素材不存在');
  const up = { updatetime: now() };
  if (p.title !== undefined) up.title = str(p.title, 40);
  if (p.prompt !== undefined) up.prompt = str(p.prompt, 4000);
  if (p.cat_id !== undefined) up.cat_id = int(p.cat_id);
  if (p.tags !== undefined) up.tags = JSON.stringify((Array.isArray(p.tags) ? p.tags : String(p.tags).split(/[,，\s]+/)).map((x) => str(x, 20)).filter(Boolean).slice(0, 8));
  if (['draft', 'online', 'offline'].includes(p.status)) up.status = p.status;
  if (p.sort !== undefined) up.sort = int(p.sort);
  db.update('yd_gallery', up, 'id=?', g.id);
  if (up.status === 'online' && g.status !== 'online' && p.sort === undefined) gallery.placeNew([g.id]);
  return null;
});
route('/library/batch', ({ p }) => {
  const ids = (Array.isArray(p.ids) ? p.ids : [p.ids]).map((x) => int(x)).filter(Boolean).slice(0, 1000);
  if (!ids.length) fail('请选择素材');
  const IN = `id IN (${ids.map(() => '?').join(',')})`;
  if (p.action === 'online' || p.action === 'offline') {
    const fresh = p.action === 'online' ? db.all(`SELECT id FROM yd_gallery WHERE ${IN} AND status!='online' ORDER BY id DESC`, ...ids).map((r) => r.id) : [];
    db.run(`UPDATE yd_gallery SET status=?, updatetime=? WHERE ${IN}`, p.action, now(), ...ids);
    if (fresh.length) gallery.placeNew(fresh);
  }
  else if (p.action === 'move') db.run(`UPDATE yd_gallery SET cat_id=?, updatetime=? WHERE ${IN}`, int(p.cat_id), now(), ...ids);
  else if (p.action === 'delete') db.run(`DELETE FROM yd_gallery WHERE ${IN}`, ...ids);
  else fail('未知操作');
  return { n: ids.length };
});
// 前台顺序：置顶 / 置底 / 上移 / 下移 / 移到第 N 位（只对已上架的）
route('/library/order', ({ p }) => {
  const ids = (Array.isArray(p.ids) ? p.ids : [p.id]).map((x) => int(x)).filter(Boolean).slice(0, 500);
  if (!ids.length) fail('请选择素材');
  return { order: gallery.reorder(ids, str(p.action), int(p.pos)) };
});
route('/library/cat/save', ({ p }) => {
  const name = str(p.name, 20);
  if (!name) fail('请填写分类名称');
  const dup = db.get('SELECT id FROM yd_gallery_cat WHERE name=? AND id<>?', name, int(p.id));
  if (dup) fail('已有同名分类');
  if (int(p.id)) db.update('yd_gallery_cat', { name, sort: int(p.sort) }, 'id=?', int(p.id));
  else return { id: db.insert('yd_gallery_cat', { name, sort: int(p.sort, 99), createtime: now() }) };
  return null;
});
route('/library/cat/del', ({ p }) => {
  db.run('UPDATE yd_gallery SET cat_id=0 WHERE cat_id=?', int(p.id));
  db.run('DELETE FROM yd_gallery_cat WHERE id=?', int(p.id));
  return null;
});
// 「帮我想主题」：AI 推荐批量生成的主题；AI 不可用时给一组常用主题
const THEME_FALLBACK = ['口红 小红书风 粉色系', '夏季防晒霜 海边场景', '女装连衣裙 法式街拍', '男士T恤 白底电商主图', '运动鞋 城市街头 动感', '护肤精华 大理石台面 高级感', '零食坚果 温馨家居 暖色调', '手机壳 极简纯色背景', '香水 光影氛围 奢华', '母婴用品 柔和自然光', '双十一 促销海报', '咖啡杯 早晨窗边 生活感'];
route('/library/themes', async ({ p }) => {
  const cats = gallery.cats().map((c) => ({ name: c.name, count: db.val('SELECT COUNT(*) FROM yd_gallery WHERE cat_id=?', c.id) }));
  try {
    const items = await require('../ai/relay').runWithFeature({ text: 'gallery' }, () => require('../ai/llm').galleryThemes({ cats, hint: str(p.hint), count: 12 }));
    if (items.length) return { items, ai: true };
  } catch (e) { return { items: THEME_FALLBACK.map((theme) => ({ theme, category: '' })), ai: false, error: e.message }; }
  return { items: THEME_FALLBACK.map((theme) => ({ theme, category: '' })), ai: false };
});
// 图库搜图（Unsplash / Pexels）→ 导入为参考素材；参考素材可 AI 改图 / 生成同类
route('/library/stock/search', async ({ p }) => {
  try { return await require('../ai/stock').search(str(p.source) || 'unsplash', str(p.q), int(p.page) || 1); } catch (e) { fail(e.message); }
  return null;
});
route('/library/stock/import', ({ p }) => {
  try { return { job_id: gallery.importStock({ items: p.items, similar: p.similar, cat_id: p.cat_id, model_key: str(p.model_key) || 'm1', resolution: str(p.resolution) || '2K' }) }; } catch (e) { fail(e.message); }
  return null;
});
route('/library/remix', ({ p }) => {
  try { return { job_id: gallery.startRemix({ ids: p.ids, mode: str(p.mode), per: p.per, instruction: str(p.instruction), model_key: str(p.model_key) || 'm1', resolution: str(p.resolution) || '2K' }) }; } catch (e) { fail(e.message); }
  return null;
});
route('/library/generate', ({ p }) => {
  try { return { job_id: gallery.startGenerate({ theme: p.theme, count: p.count, cat_id: p.cat_id, ratio: str(p.ratio) || '3:4', model_key: str(p.model_key) || 'm1', resolution: str(p.resolution) || '2K' }) }; } catch (e) { fail(e.message); }
  return null;
});
route('/library/upload', ({ p }) => {
  try {
    return { job_id: gallery.startUpload({ images: p.images, auto_cat: !!int(p.auto_cat), cat_id: p.cat_id, similar: p.similar, publish: p.publish === undefined ? true : !!int(p.publish), model_key: str(p.model_key) || 'm1', resolution: str(p.resolution) || '2K', ratio: str(p.ratio) }) };
  } catch (e) { fail(e.message); }
  return null;
});
// 电商提示词包：列表（带是否已导入）/ 选中条目出图进待审核
route('/library/pack', () => ({ list: gallery.packList() }));
route('/library/pack/run', ({ p }) => {
  try { return { job_id: gallery.startPack({ ids: p.ids, per: p.per, model_key: str(p.model_key) || 'm1', resolution: str(p.resolution) || '2K' }) }; } catch (e) { fail(e.message); }
  return null;
});
route('/library/jobs', () => ({
  list: db.all('SELECT * FROM yd_gallery_job ORDER BY id DESC LIMIT 20').map((j) => ({ id: j.id, kind: j.kind, title: j.title, total: j.total, done: j.done, failed: j.failed, status: j.status, error: j.error, time: fmtTime(j.createtime) })),
}));

// ---------------- 操作日志 ----------------
const READONLY = /(^\/(me|dashboard|settings|users|orders|tasks|gallery|admins|login|search)$)|\/(list|logs|detail|status|trend|rank|catalogs|info|backups|export|models|records|finance|features|fetch_models|jobs)$/;
const ACTION_NAMES = { '/user/save': '编辑用户', '/user/score': '调整点数', '/user/grant': '开通会员', '/user/batch': '批量操作用户', '/user/login_as': '模拟登录用户', '/order/paid': '订单标记已付', '/order/close': '关闭订单', '/order/create': '后台开通套餐', '/order/refund': '订单退款', '/redeem/generate': '生成兑换码', '/redeem/disable': '作废兑换码', '/task/retry': '重试任务', '/settings/save': '修改系统设置', '/library/save': '编辑素材', '/library/batch': '批量操作素材', '/library/generate': '批量生成素材', '/library/upload': '上传识图素材', '/library/pack/run': '导入电商提示词包', '/library/order': '调整素材顺序', '/library/cat/save': '保存素材分类', '/library/cat/del': '删除素材分类', '/gallery/del': '删除作品', '/brand/upload': '上传品牌图', '/brand/reset': '恢复品牌图', '/admin/save': '保存管理员', '/admin/del': '删除管理员', '/coupon/grant': '发放优惠券', '/password': '修改密码', '/system/backup': '备份数据库', '/system/cleanup': '清理缓存', '/logout': '退出登录' };
function logAction(ctx, pathname) {
  if (READONLY.test(pathname) || /^\/relay\/|^\/matting\/|^\/upload$/.test(pathname)) return;
  let action = ACTION_NAMES[pathname];
  const m = /^\/crud\/(\w+)\/(\w+)$/.exec(pathname);
  if (!action && m) action = `${m[2] === 'del' ? '删除' : '保存'}·${m[1]}`;
  const p = { ...ctx.p };
  for (const k of ['password', 'old_password', 'new_password', 'value', 'items']) if (p[k] !== undefined) p[k] = k === 'value' ? `(${p.group || ''})` : '***';
  try { db.insert('yd_admin_log', { admin_id: ctx.admin.id, username: ctx.admin.username, action: action || pathname, detail: JSON.stringify(p).slice(0, 500), ip: ctx.ip, createtime: now() }); } catch {}
}

function ipAllowed(ip) {
  const wl = ((S.get('security') || {}).admin_ip_whitelist || []).map((x) => String(x || '').trim()).filter(Boolean);
  if (!wl.length || ip === '127.0.0.1' || ip === '::1') return true;
  return wl.some((b) => ip === b || ((b.endsWith('.') || b.endsWith('*') || b.endsWith(':')) && ip.startsWith(b.replace(/\*$/, ''))));
}

async function handle(req, res, pathname) {
  if (!ipAllowed(clientIp(req))) return sendJson(res, 404, { code: 0, msg: 'Not Found' });
  const m = r.match(pathname);
  if (!m) return sendJson(res, 404, { code: 0, msg: '接口不存在' });
  try {
    const parsed = await parseRequest(req);
    const p = { ...parsed.query, ...parsed.body };
    const ctx = { req, res, p, files: parsed.files, params: m.params, ip: clientIp(req), admin: null };
    if (m.opts.auth !== false) {
      ctx.admin = adminByToken(req.headers['admin-token']);
      if (!ctx.admin) return sendJson(res, 401, { code: 401, msg: '请先登录后台' });
    }
    if (ctx.admin && ctx.admin.role === 'viewer' && !READONLY.test(pathname) && !/^\/(logout|password)$/.test(pathname)) fail('只读账号不能执行此操作');
    const data = await m.handler(ctx);
    if (ctx.admin) logAction(ctx, pathname);
    return ok(res, data === undefined ? null : data);
  } catch (e) {
    if (e instanceof ApiError) return sendJson(res, e.status || 200, { code: e.code, msg: e.message });
    console.error('[admin]', e);
    return sendJson(res, 200, { code: 0, msg: e.message || String(e) });
  }
}

module.exports = { handle, ipAllowed };
