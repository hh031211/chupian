# 接口清单

- 基础地址：`{publicBaseUrl}/ydapi`，全部为 `POST`，请求体 JSON（上传为 multipart）
- 登录态：请求头 `token: <登录返回的 token>`
- 返回统一格式：`{"code":1,"msg":"ok","time":"...","data":{...}}`；`code=0` 为业务错误（看 `msg`），`code=401` / HTTP 401 为未登录
- 列表分页参数：`page`、`limit`（部分为 `pageSize` / `page_size`）

## 账号

| 接口 | 参数 | 返回 data |
|---|---|---|
| `/captcha/create` | – | `{key, image}` 图形验证码（SVG data URI） |
| `/user/login` | `account` `password` `captcha_key?` `captcha?` `keeptime` | `{userinfo:{...,token,expires_in}}` |
| `/user/register` | `username` `password` `captcha_key` `captcha` `invite_code` `keeptime` | 同上，`is_new:1` |
| `/user/mobilelogin` | `mobile` `captcha`(短信码) `invite_code` `keeptime` | 同上，新用户自动注册 |
| `/user/emaillogin` | `email` `captcha` `invite_code` `keeptime` | 同上 |
| `/sms/send` | `mobile` `event`(mobilelogin/bind/changemobile) | `{}`（调试模式返回 `debug_code`） |
| `/ems/send` | `email` `event` | 同上 |
| `/user/logout` | – | – |
| `/user/info` | – | `{userinfo}` |
| `/user/profile` | `nickname` / `username` / `avatar` | `{userinfo}` |
| `/user/sendmobilecode` `/user/bindmobile` | `mobile` `event` (`captcha`) | `{userinfo}` |
| `/user/sendemailcode` `/user/bindemail` | `email` (`captcha`) | `{userinfo}` |
| `/user/changepwd` | `old_password` `new_password` | `{userinfo}` |
| `/user/delete` | `confirm` `reason` | 注销账号 |
| `/wechat/qrcode` | `mode`(login/bind) `invite_code` | `{qr_url, state}` 公众号带参二维码 |
| `/wechat/status` | `state` | `{status: pending/success/expired/failed, mode, userinfo, token}` |
| `/wechat/authorize` | `mode` `redirect` | `{auth_url}` 微信内网页授权 |
| `/wechat/unbind` | – | `{userinfo}` |
| `/wechat/notify` | 公众号服务器回调（GET 校验 / POST 事件） | – |
| `/wechat/callback` | 网页授权回调，302 回前端 `?wx_state=` | – |

`userinfo` 字段：`id username nickname mobile email avatar score locked_score member_level member_level_name member_expiretime(_text) is_distributor distribution_rate distribution_opentime(_text) enable_video video_cost video_m3_cost enterprise_owner_id is_enterprise_subaccount invite_code parent_user_id jointime password_set wechat wechat_openid token expires_in`

## 会员 / 支付

| 接口 | 参数 | 返回 data |
|---|---|---|
| `/member/plans` | – | `{plans:{basic:[], enterprise:[], pack:[]}}` 每项 `id title tag price original_price points days note highlight` |
| `/member/order` | `plan_id` `pay_type`(wxpay/mppay) `coupon_id` | `{order:{order_sn,...}, pay:{type, code_url \| jsapi}}` |
| `/member/status` | `order_sn` | `{order:{pay_status}, userinfo}`（会主动向微信查单） |
| `/member/orders` `/member/logs` | `page` `limit` | `{list, total}` |
| `/member/rights` | – | `{redeems, activities, coupons:{valid,used,expired}}` |
| `/member/coupons` | `amount` | `{list}` 可用券 |
| `/member/claimcoupon` | `activity_id` | – |
| `/member/redeem` | `code` | `{userinfo}` |
| `/member/center` | – | 概况 |
| `/member/subaccounts` `/member/addsubaccount` `/member/editsubaccount` `/member/delsubaccount` | 企业子账号增删改 | – |
| `/pay/wechat/notify` | 微信支付 V3 回调 | – |
| `/pay/mock?order_sn=` | 模拟支付页（后台开启 mock 时） | – |

## 分销 / 任务中心

| 接口 | 说明 |
|---|---|
| `/distribution/info` | 分销首页：`plans invite_code invite_link invited wallet{withdrawable,pending,withdrawn} distribution_rate stats{today,yesterday,week,month}` |
| `/distribution/plans` `/distribution/order` `/distribution/status` `/distribution/orders` | 开通分销（下单、查单） |
| `/distribution/team` | 我邀请的用户 `{list:[{id,name,score,level,joined_at,orders,commission}]}` |
| `/distribution/agentorders` | 佣金订单 `{list:[{order_sn,user,product,amount,rate,commission,status,status_text,time}]}` |
| `/distribution/withdraws` `/distribution/withdraw` | 提现记录 / 申请提现（`amount channel name account receipt_qrcode`） |
| `/distribution/redeemplans` `/distribution/buyredeem` `/distribution/redeemcodes` | 代理拿码价购买兑换码（钱包或微信付） / 我的兑换码 |
| `/distribution/rank` `/distribution/rankfans` `/distribution/delegate/overview` | 排行榜、粉丝数、数据看板 |
| `/distribution/promomaterials` | 推广素材 |
| `/distribution/settings` `/distribution/savesettings` | 分站换牌设置（名称、Logo、域名） |
| `/distribution/branding` `/distribution/brandinghost` | 按邀请码 / 域名取分站品牌（无需登录） |
| `/task/center` | 邀请好友得点数：`invite_code invite_link invited_count rewarded_points reward_points reward_every invites[]` |

## 资料库

| 接口 | 说明 |
|---|---|
| `/upload/image` `/upload/file` | multipart `file` + `category`，返回 `{url, fullurl, mimetype, filesize, width, height}` |
| `/material/lists` `addgroup` `renamegroup` `delgroup` `add` `move` `del` | 素材库（`source=user/official`） |
| `/prompt/lists` `addgroup` `renamegroup` `delgroup` `add` `edit` `move` `del` | 提示词库 |
| `/notice/lists` `/notice/read` | 公告 `{notice:[], log:[]}` |
| `/feedback/submit` | 意见反馈 |
| `/{board}.records/lists` | 作品记录（board: product/model/marketing/material/toolbox/pod/derive/crossborder/video/design/batch），`{items:[{task_id,scene,scene_name,cover,count,images:[{id,index,url,status,label}],remark,createtime,...原始参数}], total, accounts}` |
| `/{board}.records/del` `delimg` `remark` | 删除到回收站 / 删除单张 / 备注 |
| `/trash/lists` `restore` `del` `clear` | 回收站（30 天自动清理） |
| `/canvas/index` `detail` `create` `save` `rename` `delete` `copywrite` | 无限画布 |
| `/handoff/create` `status` `history` `upload` | 手机扫码传图（`page_url` 指向 `/h5/handoff.html`） |
| `/asset/lists` `filters` `one` `cats` | 官方资源目录（模特/模板/场景/案例），后台导入 |
| `/model.favorite/lists` `add` `del` `sync` | 模特收藏 |
| `/model.recent/lists` `touch` | 最近使用的模特 |
| `/product.stylefavorite/lists` `add` `del` `sync` | 风格/模板收藏 |
| `/ecom.compliancelabel/templates` `lists` `save` `del` `favorites` `favorite` `sync` | 合规标签 |
| `/batch.draft/save` `lists` `get` `del`，`/batch.brand/lists` `save` `del` | 批量出图草稿 / 品牌预设 |
| `/toolbox.clickrate/history` `delete` | 点击率预测历史 |

## AI 生成

### 通用任务格式

所有出图接口返回同一结构，前端用 `/status` 轮询（约 2 秒一次）：

```json
{
  "task": { "id": 12, "status": "queued|running|succeeded|partial|failed", "count": 4, "success_count": 2, "fail_count": 0,
            "charged_points": 16, "refunded_points": 0, "model_key": "m1", "resolution": "2K", "ratio": "3:4", "scene": "change_bg" },
  "results": [ { "id": 31, "index": 1, "label": "换背景", "status": "succeeded", "url": "https://.../a.png", "content": "", "kind": "", "error": "" } ],
  "errors":  [ { "index": 3, "error": "生成失败原因" } ]
}
```

### 功能模块（通配）

`/{控制器}/generate`、`/{控制器}/status`（`task_id`）、`/{控制器}/regen`（`task_id` `index`）；专业版工具为 `/retry`。

特殊动作：

| 接口 | 说明 |
|---|---|
| `/product.detailpage/generate` | 详情页：`modules[]` 每个模块一张 |
| `/product.detailpage/outline` | 详情页大纲 `{outline:[{value,name,suggestion,copy}]}` |
| `/product.detailpage/supplementfields` | AI 判断需补充的商品参数 `{fields}` |
| `/product.detailpage/styledescribestream` | 流式：参考图风格描述 |
| `/product.productmain/generate` | 商品套图：`modules[]` |
| `/product.productmain/outline` | 套图规划（`count` 张） |
| `/product.productmain/customset` `customset_outline` | 自定义套图（`units[]` / `styles[]`） |
| `/product.productmain/heroImage` | 商品主图（模板复刻：`templates[] × count`） |
| `/product.productmain/styleanalyze` `/model.pose/styleanalyze` | 爆款风格分析 `{styles, platform}` |
| `/product.hotreplica/outline` | 爆款复刻规划 |
| `/product.sku/generate` | SKU 图：`template` + `products[]` |
| `/product.hostbatch/generate` `status` | 批量托管 |
| `/batch.image/generate` `status` `regen` | 批量出图：`units[]` |
| `/{控制器}/aiwritestream` | 流式 AI 帮写（SSE：`event: message data:{delta}` … `event: done data:{charged_points}`）。支持 product.changebg / video.imagetovideo / product.productmain / product.seeding / product.garmentmulti / model.pose / pod.aiwrite / product.detailpage / batch.image |
| `/material.copywriting/generate` `status` `history` | AI 文案（异步）`{ids}` → `{list:[{id,status,variants:[{text}]}]}` |
| `/toolbox.precheck/check` | 投前检测 `{reports:[{image,overall,tier,dims:[{key,score,level,note}]}]}` |
| `/toolbox.clickrate/predict` | 主图点击率预测 `{reports, best, ranking, compare, bestReason}` |
| `/product.listinglink/parse` `transfer` | 商品链接采集图片 / 转存 |
| `/model.exclusive/lists` `generate` `status` `claim` `del` | 专属模特 |

### AI 助手 / 改图 / 对话作图

| 接口 | 说明 |
|---|---|
| `/ai/image` | AI 助手自由生图：`prompt count images aspectRatio resolution style model_key language` |
| `/ai/status` `/ai/history` `/ai/delete` `/ai/remark` `/ai/regenimage` | 状态、历史（含企业子账号筛选 `account`）、删除、备注、单张重生成 |
| `/ai/editimage` | 一句话改图 / 作品二次修改：`prompt source_url ref_images mark_url resolution aspect_ratio count` → `{record_id, record_ids}` |
| `/ai/editstatus` `/ai/editlist` | 改图状态 `{status,url,error}` / 改图记录 |
| `/ai/chatdraw/create` `status` `sessions` `detail` `delete` | 对话作图（多轮会话，`base_url` 为基于上一张继续改） |
| `/canvas/copywrite` | 画布：一图出多平台文案 `{copy:{taobao,douyin,xiaohongshu,moments,idle,selling_points}}` |
| `/works/detail` | 作品详情（含原始表单 `form`，用于复刻） |

### 控制器一览（150 个）

| 控制器 | 前端 scene | 功能 |
|---|---|---|
| `product.changebg` | change_bg | 商品换背景 |
| `product.listinglink` | listing_link | 链接出图上架 |
| `product.whitebg` | white_bg | 商品白底图 |
| `product.patternextract` | pattern_extract | 印花提取 |
| `product.multiview` | multi_view | 商品多视角图 |
| `product.threeview` | three_view | 三视图 |
| `product.closeup` | close_up | 商品细节图 |
| `product.imagetranslate` | image_translate | 图片翻译 |
| `product.productmain` | product_main | 商品套图 |
| `product.garmentmulti` | garment_multi | 百变服饰图 |
| `product.seeding` | seeding | 一键种草图 |
| `product.webreplica` | web_replica | 种草网感复刻 |
| `product.composite` | product_composite | 商品图合成 |
| `product.hotreplica` | hot_replica | 爆款图复刻 |
| `product.fabrictryon` | fabric_tryon | 面料上身 |
| `product.flatto3d` | flat_to_3d | 平铺转3D |
| `product.materialenhancement` | material_enhancement | 材质增强 |
| `product.materialapply` | material_apply | 产品替换 |
| `product.outfitsplit` | outfit_split | 实拍转平铺 |
| `product.maincollage` | main_collage | 主图拼图 |
| `product.clothingztc` | clothing_ztc | 商品直通车图 |
| `product.productretouchpro` | product_retouch_pro |  |
| `product.productlightstudio` | product_light_studio |  |
| `product.copylight` | copy_light | AI换布光 |
| `product.endorsement` | product_endorsement |  |
| `product.detailsheet` | product_detail_sheet |  |
| `product.sellingpoint` | product_selling_point |  |
| `product.skuvariant` | product_sku_variant |  |
| `product.productseriesconsistency` | product_series_consistency |  |
| `product.wrinkleremove` | product_wrinkle_remove |  |
| `product.fabricrestore` | product_fabric_restore |  |
| `product.coveredit` | product_cover_edit |  |
| `model.tryonany` | tryon_any | 万物上身 |
| `model.accessory` | accessory | AI 试戴 |
| `model.mannequintryon` | mannequin_tryon | 平铺/人台试衣 |
| `model.swapmodel` | swap_model | AI 换模特 |
| `model.humantryon` | human_tryon | 真人图试衣 |
| `model.pose` | pose | 模特换姿势 |
| `model.posescene` | pose_scene | 模特多种换 |
| `model.bodyadjust` | body_adjust | 模特塑形 |
| `model.shoetryon` | shoe_tryon | 鞋靴试穿 |
| `model.faceswap` | face_swap | AI 换脸 |
| `model.modeldeai` | model_deai | 模特去AI感 |
| `model.relight` | relight | 模拍换景 |
| `model.recolor` | recolor | 服饰换色 |
| `model.outfitset` | outfit_set | 服饰商拍套图 |
| `model.lookbook` | lookbook | 服饰种草图 |
| `model.handheld` | handheld | 手持商品 |
| `model.img2img` | img2img | 模特图生图 |
| `marketing.mainimage` | main_image | 高转化主图 |
| `marketing.festival` | festival | 节日海报 |
| `marketing.banner` | banner | 横版 Banner |
| `marketing.popup` | popup | 促销弹窗 |
| `marketing.livebg` | live_bg | 直播背景图 |
| `marketing.socialcard` | social_card | 社媒种草图 |
| `marketing.aiposter` | ai_poster | 智能设计 |
| `marketing.marketingimage` | marketing_image | 营销图 |
| `marketing.posterreplica` | marketing_poster_replica |  |
| `marketing.creativevariants` | marketing_creative_variants |  |
| `marketing.campaignkit` | marketing_campaign_kit |  |
| `marketing.creatorcover` | marketing_creator_cover |  |
| `marketing.graphiccover` | marketing_graphic_cover |  |
| `marketing.imagecopy` | marketing_image_copy |  |
| `material.paramboard` | param_board | 参数板块 |
| `material.featurestack` | feature_stack | 卖点堆叠 |
| `material.usagescene` | usage_scene | 使用场景 |
| `material.comparechart` | compare_chart | 对比图 |
| `material.sizechart` | size_chart | 尺码图 |
| `material.packagedesign` | material_package_design |  |
| `material.labeldesign` | material_label_design |  |
| `material.packageseries` | material_package_series |  |
| `material.packagemockup` | material_package_mockup |  |
| `material.instructioncard` | material_instruction_card |  |
| `material.tagdesign` | material_tag_design |  |
| `toolbox.aiedit` | ai_edit | AI 万能改图 |
| `toolbox.productexplode` | product_explode | 产品分解图 |
| `toolbox.cutout` | cutout | AI 抠图 |
| `toolbox.upscale` | upscale | 图片超清 |
| `toolbox.outpaint` | outpaint | AI 扩图 |
| `toolbox.removewatermark` | remove_watermark | AI 消除 |
| `toolbox.limbfix` | limb_fix | 手脚修复 |
| `toolbox.clothesfix` | clothes_fix | 服饰修复 |
| `toolbox.shoesfix` | shoes_fix | 鞋靴修复 |
| `toolbox.losslessresize` | lossless_resize | 无损改尺寸 |
| `toolbox.logodesign` | logo_design | 设计 Logo |
| `toolbox.productpile` | product_pile | 商品堆品图 |
| `toolbox.idphoto` | id_photo | 证件照制作 |
| `toolbox.proportrait` | pro_portrait | AI职业形象照 |
| `toolbox.artportrait` | art_portrait | AI艺术写真照 |
| `pod.alloverextract` | allover_extract | 满印提取 |
| `pod.seamlesspattern` | seamless_pattern | 四方连续图 |
| `pod.imagevariant` | image_variant | 图裂变 |
| `pod.styletransfer` | style_transfer | 风格转绘 |
| `pod.localreplace` | local_replace | 局部替换 |
| `pod.printdesign` | print_design | AI 印花设计 |
| `pod.materialbond` | material_bond | 素材粘合 |
| `pod.printmockup` | print_mockup | 印花效果图 |
| `pod.smartcutout` | smart_cutout | 智能抠图 |
| `pod.podmainimage` | pod_main_image | 套版主图 |
| `pod.targetedreplace` | targeted_replace | 定向替换图 |
| `pod.podsizeimage` | pod_size_image | 商品尺寸图 |
| `pod.podsceneimage` | pod_scene_image | 场景图 |
| `pod.skindesign` | skin_design | 产品皮肤设计 |
| `pod.printcrop` | print_crop | 图案裁剪 |
| `pod.fulfillmentart` | fulfillment_art | 履约制图 |
| `model.setfission` | set_fission | 套图裂变 |
| `derive.styleinnovate` | style_innovate | 款式创新 |
| `derive.stylefusion` | style_fusion | 款式融合 |
| `derive.inspiredredesign` | inspired_redesign | 灵感改款 |
| `derive.fabricreplace` | fabric_replace | 面料替换 |
| `derive.colorreplace` | color_replace | 颜色替换 |
| `derive.seriesderive` | series_derive | 套系衍生 |
| `derive.seasonshift` | season_shift | 季节转款 |
| `derive.partredesign` | part_redesign | 局部改款 |
| `derive.techsketch` | tech_sketch | 工艺线稿 |
| `derive.ageshift` | age_shift | 同款换拍 |
| `derive.outfitmatrix` | outfit_matrix | 搭配矩阵图 |
| `crossborder.listinggenerate` | crossborder_listing_generate |  |
| `crossborder.platformimageset` | crossborder_platform_image_set |  |
| `crossborder.listinglocalize` | crossborder_listing_localize |  |
| `crossborder.languagesizematrix` | crossborder_language_size_matrix |  |
| `crossborder.aplusbrandstory` | crossborder_aplus_brand_story |  |
| `crossborder.listingcompliance` | crossborder_listing_compliance |  |
| `crossborder.skulistingpack` | crossborder_sku_listing_pack |  |
| `toolbox.aitextedit` | toolbox_ai_text_edit |  |
| `toolbox.multiimagefusion` | toolbox_multi_image_fusion |  |
| `toolbox.photostyletransfer` | toolbox_photo_style_transfer |  |
| `toolbox.lineartstudio` | toolbox_lineart_studio |  |
| `toolbox.smartlayout` | toolbox_smart_layout |  |
| `video.imagetovideo` | image_to_video | 图生视频 |
| `video.tryonvideo` | tryon_video | 试衣视频 |
| `video.motioncopy` | motion_copy | 动作复刻 |
| `video.productdemo` | product_demo | 产品演示视频 |
| `video.liveclip` | live_clip | 直播切片 |
| `video.avatarpromo` | video_avatar_promo |  |
| `video.batchavatar` | video_batch_avatar |  |
| `video.producttvc` | video_product_tvc |  |
| `video.producteffects` | video_product_effects |  |
| `video.localize` | video_localize |  |
| `video.productreplica` | video_product_replica |  |
| `design.freeposter` | design_free_poster |  |
| `design.flyerfold` | design_flyer_fold |  |
| `design.infographic` | design_infographic |  |
| `design.coverset` | design_cover_set |  |
| `design.longform` | design_longform | 设计长图 |
| `toolbox.cutoutpro` | cutout（专业版） | AI 抠图 |
| `toolbox.upscalepro` | upscale（专业版） | 图片超清 |
| `toolbox.eliminatepro` | eliminate（专业版） |  |
| `toolbox.outpaintpro` | outpaint（专业版） | AI 扩图 |
| `toolbox.watermarkpro` | watermark（专业版） |  |

## 管理后台接口（`/admin/api/*`，请求头 `admin-token`）

`login` `logout` `me` `password` `dashboard` `users` `user/save` `user/score` `user/grant` `user/logs` `orders` `order/paid` `order/close` `order/create`
`crud/{plans|dist_plans|coupons|notices|promo|material_cats|materials|asset_cats|compliance_tpl|platform_models|feedback|agents}/{list|save|del}`
`redeem/list` `redeem/generate` `redeem/disable` `withdraws` `withdraw/audit` `commissions` `tasks` `task/detail` `task/retry` `ai/logs`
`settings` `settings/save` `relay/models` `relay/test_chat` `relay/test_image` `asset/catalogs` `asset/list` `asset/import` `asset/save` `asset/del` `upload`
