# 橙图 · 完整交接说明（给接手的 Claude / 开发者）

> 接手第一件事：通读本文件，再按需看 `docs/ENGINEERING.md`（架构细节）、`docs/DEPLOY.md`（发布/迁移）、`tests/README.md`（测试）、`docs/RELAY.md`（中转站）、`docs/ACCEPTANCE.md`（174 个工具核对表）。
> 每次改完代码：更新本文件的「版本历史」和「待办」，并把最新源码包交给站长保存。

---

## 一、站长是谁、怎么合作（最重要）

- **语言**：一律中文。
- **风格**：回复简短直接；不要长篇总结、不要反复确认、不要思考很久再回。站长原话：“你不用思考那么久回我，太浪费我额度和时间了”“不要做太多无意义浪费额度的事情，不用反复总结”。
- **交付方式**：改完直接给「发布包（.tar.gz + .sha256）+ 部署命令」，站长自己上传部署。站长只想知道“怎么部署”，不需要过程描述。
- **操作环境**：站长主要用 **iPhone** 操作，SSH 用 Termius；命令必须能整段复制粘贴；截图都是手机截图。
- **底线**：不破坏已有功能；**不改整体设计风格**（站长认可现在的风格：橙色主色、暖白底；要“更美更高端”，但要求按截图逐处优化，不要推倒重来）。
- **质量要求**：目标是“成熟商业 SaaS 的工程质量”，不追求代码多；效果类功能（如抠图）要“最好的效果”，会拿竞品（佐糖）对比。
- **诚实**：发现文件缺失、没测到、做不到的地方要直说，不要假装做完。站长会自己逐个功能试用并截图反馈。
- **安全**：站长在聊天里发过后台密码和佐糖 Key——这些**不要写进代码或文档**，需要时让站长在后台填写；建议站长改密码。

## 二、项目背景

- 橙图（原名“鱼朵工具箱”，已完全去掉鱼朵品牌）：AI 电商作图 SaaS，**174 个工具、3020 个模板**，面向电商卖家/美工；服装类功能多（站长朋友做服装电商设计）。
- 旧站只剩前台编译产物（dist），**后端源码丢失**，后端是完全重写的；前台一部分页面已用新前端重写，其余仍是旧前台编译产物 + 补丁。
- 生图/改图/识图/文本都调用站长自己的 **AI 中转站**（OpenAI 兼容接口，例：wokey，Base URL 要填 `https://api.wokey.ai`，**不要带 /v1**，带了会报 wrong_gateway_host）。
- 注册登录：手机短信验证码 + 账号密码（没有微信登录）。
- 目前用户很少（1~2 家公司在用），处于打磨阶段。

## 三、服务器与线上环境

- 华为云香港（按 IP 推断），**190.92.242.73**，Ubuntu，2 核 7.1G 内存 + **4G 交换文件**（`/swapfile`，安装抠图模型时自动创建）。仅 HTTP、无域名、无 HTTPS。
- 运行：pm2 进程名 **`chengtu`**，Node 22，监听 80 端口；后台 `http://190.92.242.73/admin`。
- 目录（版本化部署）：
  ```
  /opt/chengtu/
    releases/<版本>/          每个版本一份完整代码 + web/（构建好的前台）
    current -> releases/<当前版本>
    shared/config.json        端口、publicBaseUrl、数据库路径等（所有版本共用）
    shared/data/              数据库 yuduo.db、uploads/、brand/、cos/（旧素材图缓存）、matting/（抠图模型+venv）、logs/
    shared/ecosystem.config.cjs  pm2 配置
    backups/                  每次部署前自动备份的数据库
  ```
- 旧目录 `/root/yuduo-server` 是迁移前的老版本，已不用（日志里偶尔能看到它的旧路径）。
- 抠图模型已装：`/opt/chengtu/shared/data/matting/models/{birefnet-general.onnx(928M), isnet-general-use.onnx}`。

## 四、代码结构

| 位置 | 内容 |
|---|---|
| `src/server.js` | HTTP 入口：接口 `/ydapi/*`、后台 `/admin`、静态前台、`/cos/*`（旧 CDN 素材本地副本，没有就跳回原 CDN）、按 `web/ct-routes.json` 分流新/旧前台 |
| `src/core/` | `db.js`(node:sqlite)、`settings.js`(**后台可改配置 + 默认值 DEFAULTS**，存 yd_setting 表，读取时与默认值深合并)、`users.js`(点数 charge/refund/changeScore)、`storage.js`、`http.js` |
| `src/ai/engine.js` | 建任务、**计价 priceOf / 清晰度上限 capResolution / 抠图免费额度 mattingCosts**、执行队列、失败退点、按实际清晰度退差价 |
| `src/ai/builder.js` | 各工具前端参数 → 生成规格（spec）；抠图类走 `compileMatting` |
| `src/ai/relay.js` | 中转站客户端（多渠道、备用模型、各模型最高清晰度降档） |
| `src/ai/matting.js` | 抠图引擎：佐糖接口 + 本地 BiRefNet + 后处理 |
| `tools/matting/matting_worker.py` | 本地抠图常驻进程（onnxruntime），主体内部强制实心、边缘引导滤波细化；输入已带透明通道时只做后处理（换底色/证件照裁切） |
| `src/admin/api.js` + `public/admin/index.html` | 后台接口 + 后台单页（菜单 MENU、各页面函数） |
| `src/routes/*.js` | 前台接口；`library.js` 里有 `/site/matting`（免费张数）、`/site/tool_covers`（工具封面） |
| `public/brand/ct-addon.js` | 注入旧前台的增强脚本：抠图页免费张数提示、手机端底部操作栏留白、**手机下载弹出“保存到相册”** |
| `frontend/` | 新前端 Vue 3.5 + vue-router 4.6 + Vite 6（JSX），整站唯一前端。页面见 `frontend/src/app-routes.js`；工具在 `frontend/src/data/tools.js`；官方素材从后端 /gallery/* 读取 |
| `tools/web/build.js` | 构建完整前台：旧前台 + 新前端 + `ct-routes.json` + `ct-tools.json`（工具清单，给后台封面页用） |
| `tools/release.js` | `pack / install / verify / activate / deploy / rollback / status / backups / migrate` |
| `tools/mock-relay.js` | 测试用模拟中转站（也模拟佐糖接口） |
| `tests/` | `node tests/run.js [unit|api|e2e|deploy]`，一次性沙箱，随机端口、临时库、模拟中转站/佐糖；退出码非 0 即失败 |

### 新旧前台之间的约定（改动时别破坏）
- 登录态：`localStorage['yd.user.v1']`（含 token），新前端改动后发合成 StorageEvent 通知旧前台。
- 跳转登录：`?login=&redirect=`；一键同款：`sessionStorage['yd.tpl.tongkuan']`。
- 首页上传的图带进工作台：IndexedDB `ct-handoff`（174 个工具里 168 个自动放入，6 个无图片输入的除外）。
- 接口同源 `/ydapi`，请求头 `token`。

## 五、开发 / 构建 / 测试

- 正常电脑：`npm install`（只装测试用的 playwright）→ `cd frontend && npm install && npm run build && cd ..` → `node tests/run.js`。
- （前一个开发环境 npm 不通，用 esbuild 自写的离线构建脚本代替 Vite，产物结构一致；换到正常环境直接用 `npm run build`。）
- 测试现状（1.5.0）：单元、接口、浏览器、发布演练全部通过（浏览器 208 项）。
- 测试小知识：模拟中转站提示词含 `FAILME` 会失败、含 `MOCK_MAX2K` 只出 1536 长边；佐糖 Key=`bad` 返回 401、`slow` 一直处理中；同一张图上传会去重，需要多张时在 URL 后加 `?n=1`。
- 改了 `frontend/` 必须重新构建再打包；改了 `public/brand/ct-addon.js` 也会进构建（构建号变化，浏览器缓存自动失效）。

## 六、发布流程

1. 改代码 → `node tests/run.js unit api e2e` 全过 → `package.json` 版本号 +1 → git 提交。
2. `node tools/release.js pack` → `dist/chengtu-<版本>-<时间>-<提交>.tar.gz` + `.sha256`。
3. 站长上传两个文件到服务器 `/root/`，执行：
   ```bash
   cd /root && sha256sum -c <包名>.tar.gz.sha256
   node /opt/chengtu/current/tools/release.js deploy /root/<包名>.tar.gz
   ```
   部署会：校验 → 在沙箱跑接口测试 → 备份数据库 → 切换 current → 重启 → 健康检查，失败自动回退；最后一行给出回滚命令。
4. 常见坑：文件没上传到 `/root/` 会报“找不到发布包”；`.sha256` 文件只是校验码，必须和包一起传。

### 整站迁移到新服务器
```bash
# 旧服务器
pm2 stop chengtu
tar czf /root/chengtu-整站备份.tar.gz -C /opt --exclude='chengtu/shared/data/matting/venv' chengtu
pm2 start chengtu
# 新服务器（Ubuntu）
curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt-get install -y nodejs && npm i -g pm2
tar xzf /root/chengtu-整站备份.tar.gz -C /opt
pm2 start /opt/chengtu/shared/ecosystem.config.cjs && pm2 save && pm2 startup
bash /opt/chengtu/current/tools/setup-matting.sh && pm2 restart chengtu
# IP 变了：改 /opt/chengtu/shared/config.json 的 publicBaseUrl，再 pm2 restart chengtu
```

## 七、站长已拍板的业务规则

### 抠图（1.4.x 定型）
- 用到抠图的前台功能：**AI 抠图（两个入口 toolbox.cutout / toolbox.cutoutpro）、智能抠图 pod.smartcutout、证件照 toolbox.idphoto、商品白底图 product.whitebg**。全部走抠图引擎，其余功能（生图、换背景、模特图、识图、文案…）走中转站，模型站长在后台自己选。
- 引擎（后台「抠图引擎」）：默认 **佐糖（PicWish）接口**（`https://techsz.aoscdn.com/api/tasks/visual/segmentation`，异步轮询，0.5 算粒/张，约 1 分 2 一张）；可切 **本地满血 BiRefNet**（2 核约 45 秒/张，峰值内存约 6GB）。佐糖失败（余额不足、超时）自动用本地兜底。**中转站 AI 抠图已删除**（站长试过，GPT 重绘会糊、偏色）。
- 白底图：佐糖直接出白底 JPG；证件照：佐糖按人像抠，再由本地进程换底色、裁尺寸（所以本地引擎必须装着）。
- **计费**：抠图免费，每人每天免费张数（默认 10，站长后台设过 5），四个抠图功能共用；用完后「按点数扣费」（默认 3 点，证件照/白底图可单独设价，留空同通用价）或「当天不能再抠」。只按抠图设置扣，不叠加工具本身价格；失败不占免费张数并退点；非会员也能用（后台开关“抠图需要会员”）。
- 前台抠图页：隐藏出图模型/分辨率，按钮显示“免费”，上方显示“今日免费抠图还剩 X / N 张”。
- 效果对比结论：满血 BiRefNet ≈ 佐糖（连铺开的白纱也能抠到）；BiRefNet-lite 抠不到白纱；ISNet 小模型最差。阿里云分割抠图便宜（高清 0.007 元/张）但站长注册不了，放弃。

### 生图清晰度与计价
- 后台模型库可给生图模型设「最高清晰度」（站长的中转站不支持 4K，应设 2K）；用户选得更高时自动降档并**按实际清晰度扣点**。
- 中转站实际出图低于所选清晰度（没设上限时）会自动**退差价**，点数明细里有一条“实际出图 2K（所选 4K）退差价”。
- 默认价格：模型2.0（m1）1K/2K/4K = 3/4/5 点，模型2.5（m2）= 4/5/6 点（旧前台写死显示这套价格，后台改价后前台显示不会跟着变——已知限制）。
- 后台模型库里「文本」和「识图」是两种类型，分开选（识图模型槽只列识图类型）。
- 后台「今日消耗点数」= 消费 − 失败退回。
- 关于 gpt-image-2.5：官方只有 flare（快）和 sunburst（质量最好）两个；建议普通生图用 flare，改图/换装用 sunburst。

### 工具封面（1.5.0）
- 174 个工具中 69 个原本没有封面。后台「内容运营 → 工具封面」：查看/保存原图、上传替换、AI 生成（用中转站 m1 1K，后台排队，前端轮询）、恢复原图、一键为缺图工具批量生成。
- 前台优先用后台封面（`/ydapi/site/tool_covers`，localStorage `ct.toolCovers` 缓存）。

### 页面素材图替换（1.5.1）
- 工作台里的示例图、效果图、机位示例等都是旧前台写死的 `/cos/...` 素材图。站长在同一浏览器登录过后台后，前台左下角出现「🖼 替换图片」按钮：开启后点任意图片 → 上传新图替换 / 查看保存 / 恢复原图。
- 菜单里还有「AI 一键换图」（1.5.3 起）：打开即用识图模型（vision）看完同组所有图（`/admin/api/images/ai/suggest`），自动写「统一替换方案」（换成另一款同类商品/另一位模特，写清细节）和每张要保持的机位姿势，站长可改；生成时第 1 张先出，其余以它为参考保证同一人同一商品。原「AI 改图（以这张为底图）」：写要求后用中转站（默认 m2，2K）以原图为底图重画；勾选「同一组一起改」时，先改点的那张，其余几张以它为参考图，保证同一个人/同一套衣服（接口 `/admin/api/images/ai` + `/images/ai/status`，后台异步）。
- 实现：`settings.image_overrides { 'cos 后路径': 上传图地址 }`，`src/server.js` 的 `/cos/` 路由优先返回替换图；`/cos/` 缓存改为 1 小时，替换后最多 1 小时内所有人可见。CSS 背景图不在此列。

### 其它已做的体验修复
- 手机端：抠图等 Pro 工具底部固定操作栏变高后，页面底部自动留白，结果区能滑出来。
- 手机端：下载/批量下载弹出图片预览，iPhone 可“保存到相册”（系统分享面板 → 存储图像）或长按保存；也可“存到文件”。
- 手机工具列表描述过长时省略号显示，点数靠右对齐。
- 后台抠图效果测试改为后台运行 + 轮询（手机浏览器长请求会断，报 Load failed）。

## 八、待办 / 站长提过的想法

1. **工具封面**：站长可在后台一键 AI 生成 69 张缺图封面，效果不好再逐个替换（站长要求“前台很多功能没有图片，我需要图片”）。
2. **前台 UI 精修**：站长想要“更美、更高端、更好用、更顶尖”，但额度有限 → 让站长截图圈出具体问题，逐处改；不要大改。
3. **网站提速**（站长觉得 sciclaw.cn 很快）：买域名 → Caddy/Nginx 配 HTTPS + HTTP/2 → 视情况迁国内服务器 + ICP 备案 + CDN；模板/素材图转 WebP。站长还没买域名。
4. **iPhone 真机确认**“保存到相册”按钮是否出现（headless 浏览器测不了 navigator.share）。
5. 白纱等半透明区域：佐糖/满血 BiRefNet 已解决；只有本地小模型兜底时会差。
6. 旧前台价格显示写死（见上），如站长改价需要同步，可在 ct-addon.js 里按后台价格改写。

## 九、站长的其它项目（不要混淆）
- 「衣图 / Yitu」：给朋友公司做的服装主图自动化网站（另一台华为云香港服务器 119.13.88.136），与橙图无关。

## 十、版本历史
- 1.3.0 版本化部署、独立新前端、测试体系
- 1.3.1 模型最高清晰度（降档+按实际计价）、文本/识图分开
- 1.3.2 抠图改为原图像素+实心主体、AI 精细按清晰度计价、今日消耗扣退回、手机底栏留白、手机存相册
- 1.3.3 中转站实际清晰度低于所选时退差价
- 1.3.4 / 1.3.5 本地抠图用 BiRefNet（lite → 满血），安装脚本适配版本化目录 + 自动交换分区
- 1.4.0 抠图改佐糖接口 + 每日免费张数，删除中转站抠图
- 1.4.1 白底图/证件照也走抠图引擎
- 1.4.2 证件照/白底图单独设超出价
- 1.4.3 后台抠图测试异步、本地超时放宽
- 1.5.0 后台工具封面管理、手机工具列表溢出修复
- 1.5.1 前台「替换图片」模式：工作台里任意素材图可替换 / 恢复
- 1.5.2 替换图片支持 AI 改图（以原图为底图），同组多张保持一致
- 1.5.3 AI 一键换图：自动识图写方案；手机工具搜索结果不再被头图裁切
- 1.15.0：前台可选的生图模型不再固定两个：后台「中转站 / 模型 → ③ 功能 → 模型」里可添加任意多个（relay.image_models 的 m3、m4…），每个填前台名称、说明、模型、1K/2K/4K 每张点数（存在 pricing.image[键]），开关控制前台显示；m1/m2 只能关不能删（默认值会补回来）。priceOf 按所选模型键取价，没填的按 m1；relay.imageModel 遇到关掉 / 没配模型的键退回 m1。
- 1.14.2：手机整体显示比例（index.html 里按 `__CT_MSCALE__` 改 viewport initial-scale，默认 0.88，后台「站点信息 → 手机显示比例」可调；屏幕短边 ≥600 的平板 / 电脑不受影响）。
- 1.14.1：手机顶栏站点名变长后头像被挤出屏幕。
- 1.14.0：品牌改名「出片儿」（前台品牌名都读后台「站点信息 → 站点名称」，老库里名字还是「橙图」的启动时自动换新）；浏览器主题色改为深色（修手机 Safari 弹窗时底部出现大橙边）；后台上传 Logo 时自动生成浏览器标签图标和手机桌面图标；删除无用的 tools/prompt-library.js。
- 1.13.0：域名 + HTTPS + 缩略图。
  - `tools/setup-domain.sh 域名`：装 Caddy（自动 HTTPS、HTTP/2/3）和 libvips-tools；网站改为 127.0.0.1:8360，Caddy 对外 80/443；www 和 IP 访问跳到 https://域名；`--undo` 还原。会把旧的 publicBaseUrl / http://IP 写进 config.aliasBaseUrls。
  - 接口返回的 JSON 里，aliasBaseUrls 开头的 /uploads/ 地址自动换成 publicBaseUrl（`http.js fixUrls`），数据库不改；`storage.localFileOf` 也认这些旧地址。
  - 缩略图：`/uploads/xxx.png?w=宽度` → `src/core/thumbs.js` 用 vipsthumbnail（没有就用 ImageMagick convert）生成 WebP，缓存在 数据目录/thumbs；没工具 / 失败时返回原图。前端 `platform/thumb.js`，宽度取后台「站点信息 → 缩略图宽度」（默认 480，高清屏 ×2，大图卡片再 ×2）。预览、下载、继续改都用原图。
- 1.12.0：
  - 删除分销（开通 / 佣金 / 提现 / 分站 / 推广素材）、企业子账号、AI 专属模特、提示词库的前后端和后台页面；旧数据表不再创建，老库里的表保留不动。企业版会员等级保留（只是没有子账号）。邀请好友得点数（/task/center）保留。
  - 首页对话 = 项目（`yd_session`）：/ai/image 带 `session_id`（0 = 新建）、`session_title`、`user_prompt`、`plan`、`mode`、`turn`；对话模式先调 /ai/plan（`llm.planEdit`：返回 回复 + 给模型的精确编辑指令 + 4~12 字标题），再用指令出图（`refined: 1`）；没经过理解的带图生成（快速模式 / 理解失败）后端自动补一句「其余内容保持与参考图一致」。项目库里一段对话只显示一个项目（标题用对话标题），点开 `/?s=对话ID` 还原整段对话（/ai/session）；删除 / 恢复整段对话一起。
  - 回收站页面 `/trash`（左侧导航、手机菜单、项目库右上角），30 天自动清除，可恢复 / 彻底删除 / 清空。
  - 素材库重建：删掉 3020 个引用外站（cos.huotu333.cn）的模板和 /cos 转发；官方素材改为站长自己生成：后台「素材库」（`src/ai/gallery.js`、`yd_gallery*` 表）批量生成（主题 → 文本模型想画面配提示词 → 生图 → 待审核）、上传识图（识图写提示词、自动归类、直接上架）、识图生成同类（待审核）。前台读 /gallery/cats、/gallery/lists。生图用「功能 → 模型」里的「素材库批量出图」（feature key `gallery`），文字 / 识图用 `text:gallery`。
  - 模型多用途：`model_meta[ref].caps = ['image','text','vision','video']`（`relay.capsOf / canDo`），后台模型库可多选；老配置只有 `type` 的按 type 换算。
  - 登录账号（用户名）注册后不能改，账号信息里显示为「登录账号」只可复制。
  - 修复：1.11.0 删「链接解析」页时误删了后台 7 个设置页（计费规则、站点信息、注册与登录、会员与邀请、支付、短信邮件、存储），已恢复；后台 JS 语法错误导致整个后台白屏，已修复，并加了「后台所有菜单页都能打开」的浏览器测试。
- 1.11.0 大精简：删掉旧前台（legacy/ 原始产物、注入脚本 ct-addon、旧页面适配、工作台交接、手机传图页、兑换码 H5），整站只剩新版前端；所有页面地址都返回同一个 index.html，旧地址由前端 `redirectOf()` 跳到新页面；构建产物里的 sw.js 会清掉旧版在访客浏览器里注册的离线缓存。工具只保留 5 个（`frontend/src/data/tools.js`，后端 `src/ai/modules.js` 的 ENABLED 白名单，其余模块接口返回「该功能已下线」）：AI 抠图 toolbox.cutout、商品换背景 product.changebg、商品套图 product.productmain（先 outline 再按规划出图）、证件照 toolbox.idphoto（尺寸在前端裁切下载）、商品图合成 product.composite / 主图拼图 product.maincollage。新工作台 `pages/Tool.jsx`（/tool/:key）。删掉的后端：提示词库、画布、手机传图、收藏/最近使用、合规标签、批量草稿、点击率、文案、专属模特、改图/对话作图、链接采集（scraper）、本地抠图模型（BiRefNet / Python）、页面素材图替换。首页间距修正（base.css 的 `.ct p{margin:0}` 改为 :where，之前压掉了所有段落间距）、点数里程表式滚动、素材库统一 3:4、修复繁体/英文界面在旧页面上的标题死循环。
- 1.10.0 账户相关全部换成新版界面：`overlays/AccountCenter.jsx`（账号信息：头像/昵称/用户名/手机/邮箱/密码/注销；购买记录 /member/orders；使用记录 /member/logs；邀请好友 /task/center；兑换码 /member/redeem；意见反馈），用 `components/SxDialog.jsx`（桌面居中、手机底部弹出）。打开：`openAcct(key)`。新页面 帮助中心 `pages/Help.jsx`（/faq 常见问题、/learn 使用教程，内容写在文件里）。我的 `pages/Account.jsx` 重做，入口全部指向新版弹窗。我的素材上传改为弹窗（拖拽 / 点击、选分组），列表区域也可直接拖入。点数数字 1 秒模糊滚动（Shell 的 RollNum）。界面语言：简体 / 繁體 / English（`platform/i18n.js` 在页面上替换文字；繁体字表 `i18n-tw.json`，英文词典 `i18n-en.json`，切换后刷新）。会员弹窗角标改为渐变。首页留白加大、Logo 不再被裁切。
- 1.9.1 素材库重做（`pages/Inspire.jsx`）：只有「官方素材 / 我的素材」两个标签。官方素材＝排序 + 五类筛选 + 瀑布流；点图进整页详情（大图 + 提示词 + 一键同款，URL `?id=` 可后退关闭）；一键同款上传 1~10 张图 → `/ai/prompt/adapt`（识图改写模板提示词，计费键 prompt_adapt）→ 可编辑确认 → `sendToHome({images,prompt,ratio})` 回首页。我的素材＝ /material/* 上传、分组、多选去创作 / 删除。首页首屏占满，去掉最近项目、灵感发现和输入框悬浮。base.css 的 `.ct button/.ct a` 改为 `:where(.ct)`，避免压过组件自己的文字颜色。
- 1.9.0 橙图 Studio 新视觉（自有设计：深墨底 + 暖白文字 + 琥珀→珊瑚渐变，样式在 `frontend/src/styles/studio.css`，类名前缀 sx-）：
  - 外壳 `shell/Shell.jsx`：桌面左侧悬浮导航（新建/首页/工具箱/项目库/素材库）+ 顶栏（使用教程、点数、头像菜单）；手机顶栏（☰ 菜单、最近项目、点数、头像菜单）。账户菜单含购买记录、使用记录、邀请、常见问题、兑换码、公告、反馈、客服、界面语言、退出。旧前台页面同样挂这套外壳（legacy 让出 96px 左边距 + 60px 顶部）。
  - 首页 `pages/Home.jsx`：对话 / 快速 / 电商套图三种模式；点发送不跳页，标题区收起、对话流在本页展开（AI 先说明修改思路 `/ai/plan`、预计等待倒计时、结果卡片可预览/复制链接/下载/继续改/重新生成），「新对话」回到初始首页。快速模式多张图逐张并行；电商套图选平台/市场/语言/风格 + 套图数量（3/5/8），逐张调用 /ai/image。魔法棒 `/ai/prompt/optimize`（文字计费键 prompt_optimize，默认 0）。参考图可预览、标注（`components/Annotator.jsx`）、排序、删除；结果全屏预览 `components/Lightbox.jsx`。下滑时输入框悬浮在底部（可关）。首页下方：最近项目、灵感发现瀑布流（模板，点「做同款」）。
  - 项目库支持 `?open=任务ID` 直接打开详情（顶栏「最近项目」用）。
- 1.8.0 前台改版第 3~5 阶段：新前端所有页面统一深色（`styles/home.css` 末尾在 `.ct-main` 内重设颜色令牌）；首页「精选模板」（热度前 8，点即套用：模板图=图1 + 提示词）；素材库（原场景灵感 /templates）「一键同款」改为回到首页创作台（`platform/assistant.js` sendToHome / takeHomePrefill）；新页面「项目库」 /projects、/m/projects（`pages/Projects.jsx`，数据 /all.records/lists，详情可下载、继续改、删除、再做一次）；标题改为 工具箱 / 素材库 / 项目库。工具箱沿用「按目标 + 按分类」两种组织方式。
- 1.7.0 前台改版第 1、2 阶段（参考椒图）：
  - 导航壳 `shell/Shell.jsx`：深色左栏只留 首页 / 工具箱 / 项目库(/generated) / 素材库(/templates) + 学习、公告、意见反馈、客服；手机去掉底部导航，改为顶栏(☰+Logo+登录) + 侧边抽屉。意见反馈弹窗写入后台「用户反馈」。
  - 首页 `pages/Home.jsx` + `styles/home.css`：深色创作台。模式：对话（图片 /ai/image 最多 10 张参考图按顺序=图1~N，或视频 /video.imagetovideo/generate）、快速、电商套图（交给工作台）。模型 / 清晰度 / 比例 / 张数弹层，结果在本页轮询显示，可下载、重新生成、基于结果继续改。
  - 后端新增只读接口 `/ydapi/site/models`（出图/视频模型、各清晰度实际扣点）。
  - 下一步（第 3~5 阶段）：首页精选模板、工具箱按任务分类、素材库/项目库新页面。
- 1.6.4 「我的作品」默认（未选具体功能）显示全部板块 + 一句话作图/对话作图的记录（之前只显示当前板块，别处做的图找不到）
- 1.6.3 首页一句话作图支持一次上传多张（最多 6 张），带进 AI 助手 / 工作台（旧前台补丁：助手接收 images 数组）
- 1.6.2 封面/换图出图设置可调（settings.cover_gen，默认模型2.5、4K、1:1），封面提示词加强（广告大片、多结果拼格）
- 1.6.0 去掉本地抠图（站长决定只用佐糖）：抠图全走佐糖，纯色底由佐糖直接出；后台抠图页只保留佐糖 Key、免费额度、计费。服务器上的模型可删除（rm -rf /opt/chengtu/shared/data/matting）。
- 1.5.6 防卡顿：高精度抠图模型用完即释放、抠图进程空闲 3 分钟退出；后台封面图懒加载
- 1.5.5 AI 封面改为“先让文本模型设计左输入/右结果，再出左右对比图”（参考平台版式），单个生成可写要求
- 1.5.4 整组换图改为服务器后台执行（`/images/ai/batch`，可离开页面，按钮显示进度）；被遮挡/吞点击的图片按坐标识别也能替换

## 1.15.1
- 生图模型优先级：用户在前台选了第一个（m1）以外的模型时，以用户选的为准，不再被「常用入口 / 板块 / 功能」单独指定的生图模型盖掉；选 m1 时仍按单独指定。
- gpt-image（非 gpt-image-1 / dall-e）选 2K / 4K 时传真实像素尺寸（4K 总像素上限 3840×2160，方图 2880×2880）；中转站报尺寸错误时自动退回 1024 三档重试。

## 1.15.2
- 全屏预览改用 2048 宽 WebP 大图（`thumb.js preview()`，后端缩略图档位加 2048），加载失败回退原图：4K 大 PNG 在手机上点开显示「?」的问题。下载仍是原图。
- 下载文件名：`download` 属性原来是布尔值，iOS 存成「true.png」；改为「出片儿_原文件名」（`dlName()`）。

## 1.16.0（速度）
- 离线缓存 Service Worker（tools/web/build.js `swCode()`，只在 https 启用；本地测试 `localStorage.ct_sw=1`）：/app/assets 缓存优先；前台路由（来自 app-routes.js）先用缓存的页面框架秒开、后台更新，下次打开即新版。接口 / 图片 / 后台不经过。
  - 更新后旧页面加载不到分块：router.onError 清缓存刷新一次。紧急停用：打包时设 `CT_SW_OFF=1`（发出注销版 sw.js）。
- index.html：入口静态分块 modulepreload（并行下载）；首屏加载圈（JS 未到前不再纯空白）。
- 全屏预览：先显示 2048 宽 WebP，后台下载原图，下完自动换成原图（长按保存即原图），角标「原图加载中… / 原图」。
- tests/deploy：去掉已下线的 /cos 素材检查。

## 1.17.0（腾讯云 COS）
- 后台「存储」页：「测试 COS」按钮（/storage/test）：上传 16×16 测试图 → 公网读取 → 数据万象 webp → CORS（Origin=站点前端地址）→ 删除，逐项给出修复提示。
- 前台 thumb.js：COS 图（*.cos.*.myqcloud.com 或 storage.cos.domain，/site/config 的 img_hosts）用数据万象 `?imageMogr2/thumbnail/{w}x>/format/webp/quality/85/ignore-error/1`；全站缩略图加载失败自动换原图（restoreOnError）。后台素材库缩略图同理。
- storage.js：cosHost / cosBase / cosDelete，cosPut 可传配置。旧图仍在本机，不迁移。

## 1.17.1
- 下载原图统一走 platform/download.js：fetch 原图（带进度）→ 手机支持系统分享时弹「保存到相册 / 存到文件」（navigator.share files，需点击触发），否则 blob + a.download 保存。原因：图在 COS（跨域）时 <a download> 被忽略，iOS 存出黑图。组件 components/DownloadSheet.jsx 挂在 App.jsx。
- 下载文件名改为 chupianer_xxx（Chromium 等对中文 download 名会存成「download」）。

## 1.18.0
- 新工具「模特换装」（/tool/tryon，后端 model.humantryon 重新启用）：衣服图（≤3，存 st.bgs）+ 模特图（≤20）+ 替换部位 → builder 每张模特一个出图单元 [模特, ...衣服]，按张计价；比例默认跟模特图。
- 工具页结果下载也改走 downloadImage。

## 1.18.1
- 注册用户名只允许英文字母、数字、下划线（3-32 位）；含中文提示「不能用中文」，含其它符号提示具体字符。已有的中文用户名不受影响，照常登录。

## 1.19.0
- 短信新增服务商 `aliyun_pnvs`：阿里云「号码认证服务 → 短信认证」SendSmsVerifyCode（dypnsapi.aliyuncs.com），用系统赠送签名 + 模板，个人实名即可，无需执照 / 备案。验证码仍由本站生成和校验（TemplateParam {code, min:'10'}）。AccessKey / 签名 / 模板 CODE 复用 sms.aliyun 字段。
- notify.js 抽出 aliyunRpc；后台「通知」页加「发送测试短信」（/sms/test）。

## 1.19.1
- 后台素材库「批量生成 / 生成同类」的模型下拉：前台模型（按 relay.image_models，含新增的 m3…）+ 模型库所有生图模型（值 `ref:渠道::模型`，gallery.drawOne 用 modelRef 直接调用）。

## 1.19.2
- 素材库「批量生成」弹窗加「✨ 帮我想主题」：/library/themes → llm.galleryThemes（文本模型 text:gallery，参考各分类现有张数，可用输入框内容当方向），点推荐项自动填主题并选好分类；AI 不可用时给 12 个常用主题。

## 1.20.0（旧素材库）
- src/ai/legacy-templates.json.gz：从 a911f2d^ 的 frontend/public/data/templates.json 精简（id/标题/类型/行业/比例/basePrompt/图 cos.huotu333.cn），3020 条。
- 后台素材库「导入旧素材库」→ /library/legacy/import：导入为 status='ref'、source='legacy'（按图片地址去重；类型映射到分类）。「全部」不含 ref；前台只读 online，看不到。
- 选中任意素材 →「AI 改图」（mode=edit：参考原图重画，drawPrompt 与保存的 prompt 分开）/「生成同类」（mode=similar：llm.similarIdeas 想新画面，不带原图）→ gallery.startRemix → 待审核。

## 1.21.0（图库搜图，替换旧素材库）
- 删除 1.20.0 的旧素材库（legacy-templates.json.gz 与导入接口）；启动时 gallery.purgeLegacy() 删掉 source='legacy' 的参考素材（用它们生成的新图保留）。
- src/ai/stock.js：Unsplash（Client-ID，使用时上报 download_location）/ Pexels 搜索；Key 在 settings.stock（后台搜图弹窗里填）。
- 后台素材库「从图库搜图」→ /library/stock/search、/library/stock/import → gallery.importStock：识图写提示词 → status='ref'（参考素材，前台不显示）；可每张顺便生成 N 张同类（不带原图）。参考素材继续用「AI 改图 / 生成同类」。

## 1.21.1
- 「识图生成同类」：上传的原图存为参考素材（status=ref），不再进待审核；任务进度只算新生成的图（total = 张数 × 同类数）。启动时把以前误进待审核的原图（source=upload、所属任务 kind=similar）改成 ref。
- 后台 imageModelOptions()：素材库各弹窗、工具封面的模型下拉统一列出前台模型 + 模型库生图模型（ref:渠道::模型）；工具封面生成支持 ref:。

## 1.22.0（画布 · 第一期）
- 首页对话 = 左边对话 + 右边无限画布（电脑宽屏 ≥1100px：.sx-home.is-studio，画布 .sx-cv.is-dock 固定在右侧；手机 / 窄屏：对话标题栏「画布」按钮切到全屏画布 .sx-cv.is-full）。
- components/Canvas.jsx：对话每一轮自动成一行（参考图去重 + 结果 / 生成中占位），拖动画布 / 拖图 / 滚轮（ctrl 缩放）/ 双指缩放、适应画布、撤销重做、删除（隐藏）、下载、上传图片到画布。
  选中图片工具条：AI 超清放大（2K/4K）、AI 扩图（比例）、反推提示词（还原画面 / 总结模板 → 文字节点）、一键抠图（toolbox.cutout，挂在当前对话）、图片裁剪（前端裁 → 上传 → 新节点）、添加到聊天、生成视频；文字节点：复制、用作提示词。
  超清 / 扩图 / 抠图由 Home.onTool 作为新的一轮提交（mode=quick，refined=1），对话和画布里都会出现。
- 后端：yd_canvas（session_id → doc JSON：pos / hidden / extra），/ai/canvas/get|save；/ai/describe（llm.reversePrompt，文本功能 text:prompt_reverse，计价 pricing.text.prompt_reverse，默认免费）。
- 第二期待做：局部修改 / 智能消除（画笔蒙版）、无痕改字、图片翻译。

## 1.23.0（画布 · 第二期）
- 修复：手机上画布 ↔ 对话切换时组件卸载，0.6s 防抖的保存被 clearTimeout 取消，裁剪图 / 反推文字丢失。现在卸载时立即保存（flush），并按对话缓存在内存（CACHE）。
- 工具面板（Canvas.jsx PANELS / panelView）：超清放大、扩图（含「智能」比例）、局部修改、AI 智能消除、无痕改字、图片翻译；都可选前台模型、清晰度、张数，显示扣点。
  局部修改 / 消除 / 改字（可选）用画笔涂抹：前端把半透明红色标记画到原图上传成第二张参考图（图1 原图、图2 标记图），指令要求只改标记区域、其余像素级不变。适用于所有模型（不依赖 openai mask）。
- Home.onTool('gen', {prompt, images, show, ratio, res, count, model, label}) 统一提交 /ai/image；display_images 记录对话里显示的图（不显示标记图），/ai/session 返回该字段。
- 图片裁剪是浏览器本地裁剪（canvas），不调用 AI、不扣点，裁好上传到存储。

## 1.24.0（精准改字 / 图片翻译）
- tools/textedit/server.py：本机 Python 服务（127.0.0.1:8361，pm2 名 chengtu-text），/ocr（RapidOCR，估算文字颜色 / 背景色 / 粗细）、/inpaint（LaMa ONNX，512 裁块推理只贴回 mask；没模型用 OpenCV TELEA）、/mark、/composite（AI 擦好的图只在文字框内羽化贴回原图）、/subset（fontTools 先裁字再固定字重，woff2）。重活信号量 1，推理线程 TE_THREADS=2。
- 安装：tools/setup-textedit.sh（venv、依赖、LaMa 模型、11 个 OFL 字体、pm2、自检）。release.js 部署时若存在 chengtu-text 则用新版本 server.py 重启。站长自有授权字体放 shared/textedit/fonts/custom/。
- 后端 src/routes/text.js：/text/status|detect|erase（local 免费；ai 按所选模型 2K 价扣点，失败退回）|translate（文本功能 text:text_translate，计价 pricing.text.text_translate）|font。
- 前端 components/TextEditor.jsx：识别框 → 改字 / 全部翻译 → 擦除 → 可拖动文字层（字体、粗细、颜色、字号自动适配、描边、斜体）→ 浏览器 canvas 合成导出 → 画布新节点。服务未安装时可「改用 AI 重绘」（旧面板）。
- 测试沙箱：本机有 python3+opencv 时自动起 sidecar（TE_FAKE_OCR 固定识别结果），否则跳过相关测试；CT_TEXTEDIT_OFF=1 强制关。

## 1.25.0（工具箱 · 无限画布）
- data/tools.js 新增 canvas（path: '/?canvas=new'，工具箱第一张大卡）；toolPath 支持 path；工具页顶部切换只用 WORK_TOOLS（不含画布）。
- /ai/session/create：新建空白项目 + 一条「锚点」任务（module=canvas，status=succeeded，无结果、不扣点），项目库 / 回收站 / 最近项目才能找到它；/ai/session 过滤锚点并返回 session.canvas。
- Home：st.blank（空白画布也算对话态）、startCanvas()、?s=…&canvas=1 打开（手机直接全屏画布）；项目库卡片 module=canvas 时带 canvas=1。
- 项目库封面：没有生成结果时用画布上第一张图（yd_canvas.extra）。画布空状态加「上传图片到画布」大按钮。

## 1.33.0（阿里云验证码 2.0 + 测速页）
- 人机验证 src/core/human.js：后台「内容安全 → 人机验证」选 aliyun 并填 prefix / 场景 ID（AccessKey 留空用短信的）后，发短信（未登录）、账号注册、账号登录都要先过阿里云验证；服务端调 VerifyIntelligentCaptcha（captcha.cn-shanghai.aliyuncs.com，2023-03-05，复用 notify.aliyunRpc 签名），接口异常按官方建议放行。未开启时仍是图形验证码。
- 前端 platform/human.js：动态加载 o.alicdn.com 的 AliyunCaptcha.js，initAliyunCaptcha 绑定真实按钮（#ct-auth-go / #ct-auth-send，弹出式），先跑我们自己的表单校验（捕获阶段拦截）再验证，success 回调带 captcha_verify_param 提交。开启时 CSP 自动放行 *.alicdn.com。
- 测试：沙箱 CT_HUMAN_MOCK=1（captcha_verify_param='mock-pass' 视为通过），e2e 用假 SDK 走完整流程。真实阿里云 SDK 没法在沙箱里测，站长开通后需实测一次。
- 测速页 /speed（public/speed.html）：测网页、接口、服务器图片、COS 图片各 3 次取中值，给出结论（COS 明显慢就建议图片走服务器中转）。

## 1.32.0（后台调首页素材顺序）
- 后台素材库「已上架」按前台顺序显示（gallery.FRONT_ORDER = sort DESC, hot DESC, id DESC，前台默认排序同一个），每张显示「第 N 位」，可置顶 / ↑ / ↓ / 移到第 N 位，勾选多张可批量置顶 / 置底（/library/order → gallery.reorder：先把全部已上架按当前顺序写成明确的 sort，再移动）。
- 新上架的素材（批量上架或编辑改成上架）自动排到最前面（gallery.placeNew）。
- 首页 #ct-boot 首屏数据：已上架素材数量 / sort 合计 / 更新时间变了就立即重算；前台只用 2 分钟内的页面自带数据，调完顺序刷新就能看到。
- 后台素材网格手机上两列。

## 1.31.2（站长：1.31.0/1.31.1 太紧凑，要回到之前宽松大气的首页并做得更精美）
- 首页恢复 1.30 的宽松首屏：大 Logo、大标题、模式说明、大创作框（带「参考图」大按钮）、整屏留白和下滑箭头、最近项目区块（没封面的项目改成渐变底 + 图标 + 「画布 / 对话」标签，不再是空方块）。
- 在此基础上精修：标题更饱满、模式切换选中项和创作框加细高光与深投影；创作框下方新增「试试」示例（白底主图 / 模特上身 / 换个场景 / 大促海报 / 卖点图，点一下填入输入框，Home.jsx QUICK）。
- 保留 1.31.x 的：灵感发现分类标签、素材卡底部压字 + 做同款、玻璃质感登录按钮、白边修复、发布后自动换新版、防机器注册。
- 教训：站长喜欢宽松、有呼吸感的首屏，不要为了「首屏多露素材」压缩首页。

## 1.31.1（首页再精简 + 首次打开白边 + 防机器注册）
- 首页：去掉「最近项目」区块（手机顶栏的时钟按钮 / 电脑侧栏项目库里有），模式说明文字收起（按钮 title 里），参考图按钮缩成小方块，创作框更紧凑；样式在 studio.css「首页（1.31.1 重排）」块。
- 白边：快照阶段 html 还没有 ctx-sx/ctx-app 等 class，body 有默认 8px 外边距且没有深色背景 → 白边 + 页面右移被裁。index.html 头部加内联 html,body{margin:0;background:#0A0A0C}；快照脚本同时补上 ctx-sx ctx-home（手机加 ctx-mtop）。
- 发布后第一次打开显示旧版：SW 后台取到新页面、入口 JS 不同时 postMessage('ct-new-version')，页面 15 秒内没被操作过就自动刷新一次（sessionStorage ct_upd 防循环）。
- 防机器注册：图形验证码改为服务器画的 PNG（以前 SVG 里字符是 <text> 明文，脚本直接能读答案）；只能试一次、生成 1 秒内提交视为机器；新增 register.gift_need_mobile（默认开）：账号注册不送点，第一次绑定手机号时 users.onVerified 补发（同一手机号只送一次，ref=reg-gift:<手机>），邀请奖励按 ct_invite_ok 表（已验证手机的被邀请人）计数。

## 1.31.0（首页改版 + 电商提示词包 + 素材库拼音 / 标签）
- 首页改成紧凑首屏：去掉中间大 Logo 和下滑箭头，标题缩小、创作框上移，手机打开第一屏就能看到素材；样式在 studio.css 末尾「1.31 首页改版」块（只作用于 .sx-home:not(.is-chat)，对话模式不受影响）。
- 灵感发现：上方加分类标签（.sx-feed__cats，先用 #ct-boot 里的 cats，再静默刷新）；素材卡改为底部渐变压字（.sx-flow__cap），电脑上悬停出现「做同款」（/templates?id=&same=1 → Inspire 自动打开一键同款）。
- 右上角登录按钮改为玻璃质感（.sx-login）。
- 电商提示词包：src/data/prompt-pack-ecom.js（34 条，参考 CC0 / MIT 开源提示词库的电商案例 + 结构化写法用中文重写，无真实品牌）；后台素材库「电商提示词包」勾选出图进待审核（gallery.startPack，source=pack:<id> 标记已导入），接口 /library/pack、/library/pack/run。
- 素材库：拼音首字母搜索（src/core/pinyin-initials.js，GB2312 一级字 3755 个，kh → 口红）；风格标签筛选（/gallery/tags，/gallery/lists 支持 tag）。
- 电商套图大纲提示词（llm.js OUTLINE_SYS）改为结构化写法，并要求文案避开广告法禁用词。

## 1.30.1
- 修复手机 Safari 首页右侧被裁（登录按钮、创作框、素材卡贴边/出屏）：首页光晕 .sx-aura 是 160vw 宽 + blur，iOS 会把页面撑宽；现在包一层 .sx-aurawrap（left/right:0 + overflow:hidden）彻底裁掉。
- 首屏不再出现空白 Logo：新增 /brand/logo-sm.webp（服务器按当前 Logo 生成 256 宽 WebP，约 5KB，后台换 Logo 自动更新），前台所有 Logo 改用它，页面头部 preload。
- 模型名一开始就对：#ct-boot 里带 /site/models（未登录价），首屏快照的内联脚本直接把模型名 / 图标填上；Home.loadModels 先用它，登录用户再取会员价。
- sendIndex 的 bodyKey 改为内容哈希（以前用长度，页面内容变了但长度相同时 ETag/压缩缓存会用旧的）。

## 1.30.0（首次打开提速，不动图片质量）
- 首页 HTML 自带首屏数据：服务器在 index.html 里放 #ct-boot（站点信息 + 灵感发现第一页素材，30 秒缓存），前端 site.js boot() 读取；省两次接口往返，缩略图宽度 / 图片域名一开始就对（不会下两遍图）。
- <link rel=preconnect> 提前连好 COS 图片域名（不带 crossorigin，<img> 才能复用）；灵感发现每列前 2 张图 eager + fetchpriority=high。
- 首屏快照：打包时（tools/web/snapshot.js，需要打包机有 playwright，CT_NO_SNAP=1 关闭）把首页第一屏渲染成静态 HTML 放进 index.html（<template id=ct-snap-d/m> + 一段内联脚本，CSP 哈希自动放行）；只在中文首页 / 生效，JS 加载完 app.mount 直接替换；html.ctx-snap 期间动画跳到结束避免重播，1.5 秒后移除。
- tools/tune-net.sh：服务器开 BBR + fq、初始拥塞窗口 32（开机自启服务 chengtu-initcwnd）、空闲不重新慢启动、TCP Fast Open。部署后执行一次即可。

## 1.29.0（后台改版 + 首页下滑不再浮输入框）
- 后台 public/admin/index.html：整套样式改成和前台一致的深色 + 橙色（tokens 在 :root，浅色是 [data-theme=light]，右上角切换，localStorage yd_admin_theme='light'|'dark'，默认深色）。
- 侧边栏分组可折叠（.nav-sec / .nav-g[data-ng] / .nav-gb，折叠状态存 yd_admin_navfold；当前页所在分组总是展开；折叠的分组标题上显示待办角标数）。链接仍是 .nav a[href=#key]，e2e 只靠 hash 导航，不受折叠影响。
- 数据概览的多条安全提醒合并成一个卡片（.alert.err.secwarn）；设置表单最大宽度 900px；图表/提示框颜色跟随主题。所有页面、id、功能未删。
- 首页：往下滑创作框不再浮到底部遮挡素材；创作框滑出屏幕后右下角出现「去创作」按钮（.sx-backtop），点了回到顶部并聚焦输入框。

## 1.28.4
- 修复 1.28.0 起首页创作框变窄：.sx-slotwrap 没有宽度，在居中的 flex 列里被收缩；现在 width:100%（对话模式 display:contents）。
- 右上角账户菜单：功能改成 4 列图标网格（账号管理/购买记录/使用记录/兑换码/邀请好友/公告与更新/常见问题/使用教程）+ 意见反馈 / 联系客服两个按钮 + 退出登录；头部显示会员等级徽章和 ID。文字没变（测试和英文翻译照常）。
- 下滑时浮在底部的创作框改紧凑（参考图按钮 52px、输入框矮一些）。

## 1.28.3（切换页面提速）
- App.jsx：RouterView 外包 KeepAlive（CtTools/CtInspire/CtProjects/CtAccount/CtHelp/CtLegal，最多 6 个），切回看过的页面直接显示；Projects / Account 在 onActivated 时后台刷新；Inspire 失活时摘掉 Esc 监听和 ctx-lock。首页、单个工具页、回收站不缓存。
- router.prefetchPages()：首屏后浏览器空闲时预下载所有页面代码。
- 存 COS 的图片（png/jpg/webp，>150KB，有 vips/ImageMagick）顺带生成 960 宽 WebP 小图：原图名带 _t，小图 key = 原图 key + '.w960.webp'；前端 thumb() 对 _t 图宽 ≤960 直接用小图（不让数据万象现缩 4K 大图），大图预览仍走数据万象；rawOf 能还原。旧图照旧走数据万象。

## 1.28.2
- 上传压缩例外：工具页「抠图」「证件照」不压缩（结果和原图一样大）；画布上传长边上限 4096（后面可能放大 / 抠图）。uploadImage 的 compress 可传数字作为长边上限。

## 1.28.1（提速：少走服务器 10M 上行）
- 前端 uploadImage(file, fields, { compress: true })：用户选的图上传前在浏览器里缩到长边 ≤3072、JPG 0.92（透明 PNG 保持 PNG，变大就用原图）。首页、工具页、一键同款、我的素材、画布上传、头像都开了；改字导出 / 裁剪等生成结果不压缩。
- 服务器发给模型的参考图（engine.loadImages → forModel）：>1.2MB 或长边 >2560 的先用 vips/ImageMagick 缩到 2560、JPG 92（thumbs.recode）。抠图、带蒙版的局部重绘不缩（要原尺寸）。
- 可选「出图存为高质量 JPG」（后台 存储配置 → storage.save_jpeg，默认关）：不透明出图转 JPG 95，分辨率不变，体积约 PNG 1/4；透明图保持 PNG。

## 1.28.0
- 首页创作框下方加 components/HomeFeed.jsx：「最近项目」（登录后，/all.records/lists 前 10 个，横向滑动，点开回到对话 / 画布）+「灵感发现」（/gallery/lists 瀑布流，按列高分配卡片，滑到底自动加载，点卡片进 /templates?id= 详情做同款）。
- 往下滑时创作框滑出屏幕就浮到底部（.sx-slot.is-float，原位置用 .sx-slotwrap 占住高度防跳动），滑回顶部放回原位；首页页脚移到瀑布流最下面。注意已有旧的 .sx-recent 样式，新组件用 .sx-rproj。

## 1.27.1（安全加固第二轮）
- 后台读设置时密钥脱敏（********+末 4 位，settings.maskSecrets）；保存时掩码换回原值（unmaskSecrets，数组按 id 对应；base_url 改了就不沿用旧 Key，防止把真 Key 发到别人填的地址）。只读 / 运营账号也看不到完整 Key。
- 令牌只存哈希（'h:'+sha256）：yd_token / yd_admin_token；老的明文令牌兼容到过期。改密码 / 后台重置密码 / 禁用 → 踢掉其它登录。
- 首页 CSP（脚本只允许本站 + 两段内联脚本的 sha256），frame-ancestors / object-src none 等；跨域只放行本站域名（corsOrigins 写 "allow-any" 才全开）。
- 未登录接口请求体最多 256KB（超了回 413），任务参数最多 300KB，请求超时 15 分钟。
- 后台登录：同账号 30 分钟错 10 次锁定（防换 IP 爆破），失败写操作日志；管理员密码至少 10 位含字母数字；可选「后台只允许这些 IP」（security.admin_ip_whitelist，锁住了用 tools/admin-unlock.js 解除）。
- 用户密码至少 8 位且含字母和数字（password_min 下限 8）；账号不存在时也算一遍 scrypt，防按响应时间探测账号。
- 发布时 config.json / 数据库 / 备份目录权限收紧到 600 / 700。
- tools/harden-server.sh：ufw 只开 SSH/80/443、fail2ban、自动安全更新、检查内部端口和 SSH 密码登录。

## 1.27.0（安全加固）
- src/core/guard.js：内存频率限制（security.rate_limit，默认开；测试沙箱关）。登录：IP 30 次/10 分钟；同一账号错 3 次（或同 IP 错 5 次）后要图形验证码，错 10 次锁 15 分钟。短信：同 IP 发 2 条后要图形验证码、8 条/小时、20 条/天，全站每天 security.sms_daily_cap（默认 300）。注册 10 次/小时/IP，反馈 10 次/小时/IP，兑换码 10 次/10 分钟/用户，下单 20 次/10 分钟，上传 300 次/10 分钟，免费 AI 接口（/ai/plan、describe、prompt/*、/text/*）每用户 10 分钟上限，单 IP 全部接口 3000 次/5 分钟。
- SSRF：storage.fetchBuffer 只允许 http/https，解析 DNS 拒绝内网 / 本机 / 链路本地地址，手动跟随跳转逐跳检查；自己配置的中转站 / 佐糖 / COS / 本站地址放行（config.allowPrivateFetch=true 可全放开）。
- 上传：类型只看文件内容（不信 Content-Type），拒绝 SVG / HTML；/upload/file 只收图片、视频、PDF。/uploads 下非图片视频一律 attachment + CSP sandbox。
- 安全响应头（nosniff、X-Frame-Options、Referrer-Policy、HTTPS 时 HSTS）；500 错误不再把内部报错发给前端；safeJoin / localFileOf 防同名前缀目录穿越。
- 微信支付回调核对金额；头像、反馈图片只收 http(s) / /uploads 地址；改字服务拒绝超过 6000 万像素的图。
- 后台概览顶部「安全提醒」：默认 / 弱管理员密码、模拟支付开着、短信调试模式、防刷关闭、程序没监听在 127.0.0.1。后台改密码至少 10 位且含字母和数字。

## 1.26.4
- 新增前台页面：/company-profile（关于我们）、/terms-of-service（用户协议）、/privacy-policy（隐私政策），pages/Legal.jsx；内容走 /site/legal，后台「站点信息 → 协议与关于我们」可自定义，留空用 src/core/legal.js 默认模板（自动套站点名、运营主体、联系方式）。之前这三个地址会跳回首页。
- 启动时把数据库里前台可见的「橙图」（公告、套餐、优惠券、素材分类/标题/提示词、所有设置）统一改成「出片儿」（server.js）。

## 1.26.3
- 登录/注册弹窗重做（LoginModal.jsx + overlays.css「登录 / 注册」）：手机和电脑都是居中卡片（sheetOnMobile=false），品牌光晕 + 大 logo、下划线标签、无标签的图标输入行（+86、内嵌获取验证码 / 图形码 / 显示密码）、渐变主按钮、圆形协议勾选。元素 id 和测试用的 class 保持不变。

## 1.26.2
- 账号注册（用户名+密码）必须填图形验证码：settings register.register_captcha（默认开，后台「注册设置」可关）；验证码一次性。测试沙箱 / 发布演练设置 CT_CAPTCHA_DEBUG=1 时 /captcha/create 返回 debug_code，正式环境不设。

## 1.26.1
- 手机输入框浮到屏幕中间：index.html 视口同时锁 width=屏宽÷比例 和 initial/min/max-scale=比例（iOS 点输入框不再自动放大导致可视区错位）；Home 监听 visualViewport，--ct-vv-bottom 让输入框跟着可视区底边；手机 html/body overflow-x: clip。

## 1.26.0
- 无痕改字排版：预览和导出共用 canvas 逐字绘制（TextEditor.jsx drawLayer），不再有橙色框；字号按原文字墨迹高度匹配、字距按原文字墨迹宽度反推（track，单位 em）、基线按原文字墨迹中线固定，默认左对齐到原起点（画面正中的按居中），可切左/中/右。
- 字重自动匹配：可变字体（[wght]）按 300–900 各裁一份，在浏览器里渲染原文字算墨迹密度，和 OCR 侧 density 比最接近的；静态字体只分 400/700。FontFace 带 weight 描述符，避免浏览器二次假加粗。/text/font 返回 variable。
- 擦除传 keep（不改的文字框），sidecar make_mask 绕开，相邻行不再被擦花；OCR 侧 merge_lines 把同一行断开的片段拼回去，过滤低分/无文字碎片。
- 画布「AI 智能消除」默认本地 LaMa：前端把涂抹笔画画成黑底白色蒙版 → /text/inpaint（免费，只动涂抹区域），结果放原图旁；改字服务不可用或选「AI 重绘擦除」才走生图。
- 项目库卡片加删除（进回收站，画布项目同样适用）；手机输入框：viewport 改成按屏宽缩放，对话底部留白跟随输入框实际高度（--ct-comp-h）。

## 1.25.1
- 画布表改名 ct_canvas_doc：正式库里有旧系统的同名 yd_canvas 表（列不同），导致项目库「no such column: doc」、画布一直没存上。项目库封面查询加 try。deploy 测试里造了旧同名表。
- 画布：画布工具做出的一轮（输入图都已在画布上）不再重复摆「参考图」，结果放在原图右边空位（避免重叠）；额外节点先布局。
- iPhone：画布打开时拦截 gesturestart/gesturechange、多指 touchmove、画布内双击，防止整页被放大导致工具栏跑出屏幕。
- 改字编辑器：撤销 / 重做（文字层快照）、按住对比原图。改字服务：启动预热 OCR 与 LaMa、线程数按 CPU（2~3）、PNG 压缩级别 2、超过 3s 的请求打日志。
