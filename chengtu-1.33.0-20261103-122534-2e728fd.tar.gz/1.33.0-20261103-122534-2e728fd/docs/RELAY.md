# 中转站调用说明（生图 / 改图 / 文本 / 视频）

调用层代码：`src/ai/relay.js`。后端所有 AI 能力都走这个文件；它不依赖项目里的其它代码，可以单独复制到别的 Node 项目里用（Node ≥ 18）。

---

## 1. 配置结构

后台「中转站设置 → 高级 JSON」就是下面这个结构，独立使用时直接传给 `new RelayClient(cfg)`：

```jsonc
{
  "channels": [
    { "id": "main", "name": "主中转站", "base_url": "https://api.xxx.com", "api_key": "sk-xxx", "enabled": true, "timeout": 300 },
    { "id": "backup", "base_url": "https://api.yyy.com/v1", "api_key": "sk-yyy" }   // base_url 带不带 /v1 都可以
  ],
  "image_models": {
    "m1": { "label": "模型2.0", "channel": "main", "model": "gpt-image-1", "mode": "openai", "size_strategy": "openai", "quality": "high", "extra": {} },
    "m2": { "label": "模型2.5", "channel": "main", "model": "gemini-2.5-flash-image", "mode": "chat" }
  },
  "chat_model":   { "channel": "main", "model": "gpt-4o-mini", "temperature": 0.7 },
  "vision_model": { "channel": "main", "model": "gpt-4o" },
  "video_models": {
    "m1": { "channel": "main", "model": "sora-2", "mode": "openai-video", "seconds": 8 },
    "m3": { "channel": "main", "model": "veo3", "mode": "chat-video" }
  },
  "save_remote": true,      // 中转站返回图片链接时，下载到自己的存储（防止链接过期）
  "max_ref_images": 10,     // 单次最多带几张参考图
  "retry": 1,               // 单次请求网络/5xx 错误自动重试次数
  "retry_task": 0,          // 任务级重试（整张图重跑）次数
  "image_timeout": 300      // 生图超时秒数
}
```

### 生图模式 `mode`

| mode | 接口 | 适用模型 | 说明 |
|---|---|---|---|
| `openai` | `POST /v1/images/generations`（无参考图）<br>`POST /v1/images/edits`（有参考图，multipart，多图用 `image[]`） | gpt-image-1 / gpt-image-1.5 / gpt-image-2、dall-e-3、部分中转站的 flux / seedream | 返回 `data[].b64_json` 或 `data[].url` |
| `chat` | `POST /v1/chat/completions` | gemini-2.5-flash-image（nano-banana）、gpt-4o-image、doubao-seedream 等“对话出图”模型 | 参考图以 `image_url`（data URI）放进 messages；从返回的 `message.images`、markdown 图片、data URI 或图片链接中提取 |
| `gemini` | `POST /v1beta/models/{model}:generateContent` | 走 Gemini 原生协议的中转站 | `inline_data` 传图，`imageConfig.aspectRatio` 控制比例 |

### 尺寸策略 `size_strategy`

| 值 | 行为 |
|---|---|
| `openai`（默认） | 只传 gpt-image 支持的三档：横 `1536x1024`、竖 `1024x1536`、方 `1024x1024`；比例为“原图/自动”时传 `auto` |
| `pixels` | 按比例和清晰度计算精确像素（1K 长边 1024、2K 长边 2048、4K 长边 3840，16 的倍数），适合支持任意尺寸的模型 |
| `none` | 不传 size，只在提示词里写比例 |

无论哪种策略，提示词末尾都会附上 `[输出画面比例：3:4，清晰度 2K]`（`ratio_hint: false` 可关闭）。

### 其它模型字段

- `quality`：`high` / `medium` / `low` / `auto`（gpt-image）
- `response_format`：有的中转站要求显式传 `b64_json`
- `output_format`：`png` / `jpeg` / `webp`
- `edit_image_field`：改图的文件字段名，默认多图用 `image[]`、单图用 `image`；个别中转站要求固定 `image`
- `extra`：任意附加参数，原样合并进请求体（如 `{"moderation":"low"}`、`{"background":"transparent"}`）
- `modalities: false`：chat 模式默认会带 `modalities:["image","text"]`，中转站不认就设为 false
- `send_aspect_ratio: true`：chat 模式附带 `image_config.aspect_ratio`（OpenRouter 风格）

---

## 2. 在代码里调用

```js
const { RelayClient } = require('./src/ai/relay');
const relay = new RelayClient(cfg);

// 文生图
const [img] = await relay.image({ modelKey: 'm1', prompt: '白色陶瓷马克杯，木桌，清晨自然光，电商主图', ratio: '1:1', resolution: '2K' });
// img => { buffer: <Buffer>, mimetype: 'image/png' }  或  { url: 'https://...' }
require('fs').writeFileSync('out.png', img.buffer);

// 改图 / 图生图 / 多图融合：images 支持 URL、本地 Buffer、data URI
const [edited] = await relay.image({
  modelKey: 'm1',
  prompt: '第1张是商品，第2张是背景参考：把商品放进第2张的场景，商品保持不变',
  images: ['https://cdn.xxx.com/product.png', fs.readFileSync('bg.jpg')],
  ratio: '3:4',
});

// 局部重绘（openai 模式支持 mask：透明区域为要修改的部分）
await relay.image({ prompt: '把这里换成一束花', images: [srcBuf], mask: maskPngBuf });

// 文本
const text = await relay.chat({ system: '你是电商文案', prompt: '给保温杯写 3 条卖点' });

// 识图（自动用 vision_model）
const desc = await relay.chat({ prompt: '描述这张商品图', images: ['https://.../a.jpg'] });

// 流式输出
await relay.chat({ prompt: '写一段种草文案', onDelta: (t) => process.stdout.write(t) });

// 要求 JSON（自动加 response_format，不支持时自动降级）
const raw = await relay.chat({ prompt: '输出 {"title":"..."}', json: true });
const obj = RelayClient.parseJson(raw);

// 视频
const v = await relay.video({ modelKey: 'm1', prompt: '模特缓慢转身', image: 'https://.../model.jpg', seconds: 8, ratio: '9:16' });
// v => { buffer, mimetype:'video/mp4' } 或 { url }

// 模型列表（测试连通）
console.log(await relay.listModels());
```

错误统一抛出 `RelayError`（`message` 为中文说明，`status` 为 HTTP 状态码，`body` 为原始返回）。4xx（参数错误、余额不足、内容审核）不重试，网络错误/5xx/429 按 `retry` 自动重试。

---

## 3. 命令行工具

```bash
export RELAY_BASE_URL=https://api.xxx.com
export RELAY_API_KEY=sk-xxx
export RELAY_IMAGE_MODEL=gpt-image-1        # 可选
export RELAY_IMAGE_MODE=openai              # openai | chat | gemini
export RELAY_CHAT_MODEL=gpt-4o-mini         # 可选

node tools/relay-test.js models
node tools/relay-test.js image --prompt "白底产品图，一只保温杯" --ratio 1:1 --res 2K
node tools/relay-test.js edit  --prompt "把背景换成海边" --image ./a.png --image ./bg.jpg
node tools/relay-test.js chat  --prompt "写一句保温杯卖点" --image ./a.png --stream
node tools/relay-test.js video --prompt "模特缓慢转身" --image ./model.png --seconds 8
# 也可以：--config relay.json（结构同上面的配置 JSON）
```

结果保存在当前目录的 `relay-output/`。

---

## 4. 等价的 curl（方便和中转站客服对接排查）

```bash
# 文生图
curl https://api.xxx.com/v1/images/generations -H "Authorization: Bearer sk-xxx" -H "Content-Type: application/json" \
  -d '{"model":"gpt-image-1","prompt":"一只橘猫","size":"1024x1536","quality":"high","n":1}'

# 改图（多张参考图）
curl https://api.xxx.com/v1/images/edits -H "Authorization: Bearer sk-xxx" \
  -F model=gpt-image-1 -F prompt="把背景换成海边" -F size=1024x1024 \
  -F "image[]=@product.png" -F "image[]=@bg.jpg"

# 对话出图（nano-banana 等）
curl https://api.xxx.com/v1/chat/completions -H "Authorization: Bearer sk-xxx" -H "Content-Type: application/json" \
  -d '{"model":"gemini-2.5-flash-image","modalities":["image","text"],"messages":[{"role":"user","content":[{"type":"text","text":"把衣服换成红色"},{"type":"image_url","image_url":{"url":"https://.../a.png"}}]}]}'

# 视频（Sora 2 风格）
curl https://api.xxx.com/v1/videos -H "Authorization: Bearer sk-xxx" -F model=sora-2 -F prompt="镜头推进" -F seconds=8 -F size=720x1280 -F input_reference=@first.png
curl https://api.xxx.com/v1/videos/{id} -H "Authorization: Bearer sk-xxx"
curl https://api.xxx.com/v1/videos/{id}/content -H "Authorization: Bearer sk-xxx" -o out.mp4
```

---

## 5. 后端怎么用中转站（出图流程）

1. 前端提交 `/{板块}.{功能}/generate`（如 `/product.changebg/generate`），参数里已经带了前端拼好的 `guidance`、`bg_prompt`、`items`、`image_roles` 等
2. `builder.js` 把参数编译成若干“出图单元”：每张结果一个，各自带提示词、参考图、比例、清晰度
   - `items[]` / `unit_count` / `modules[]` / `units[]` / 模板 × 张数 / 商品 × 背景 等拆分规则都在这里
   - 提示词 = 功能说明 + 图片角色 + 本张要求 + 前端 guidance + 用户描述 + 选项参数 + 投放设置
3. `engine.js` 按单元计价、一次性扣点，写入任务队列；后台 worker 按用户等级并发调用 `relay.image()`
4. 结果图存到本地 / COS，前端轮询 `/status` 拿到 `results[].url`；失败的单元自动退点
5. 后台「生成任务」里可以看到每张图的完整提示词和参考图，方便调优

想调整某个功能的出图效果，可以改 `src/ai/modules.js` 里的 `DEFAULT_TASK`（各板块的总要求），或在 `builder.js` 里加针对某个模块的编译规则。
