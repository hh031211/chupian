# 橙图前台 · 工程结构（v2）

## 一句话

前台由**两个独立的单页应用**组成，一次构建、由后端按路径分流：

| | 新前端 `frontend/` | 旧前台 `legacy/original/` |
|---|---|---|
| 是什么 | Vue 3 + vue-router + Vite 源码工程 | 原站编译产物（没有源码） |
| 负责的页面 | `/` `/ai-tools` `/templates` `/account`，手机 `/m/tools` `/m/templates` `/m/mine` | 工作台（174 个工具）、个人中心各模块、学习中心、批量、画布等其余页面 |
| 运行方式 | 自己的 Vue 实例、路由、状态、登录弹窗、会员支付弹窗 | 原样运行；构建时打补丁（换牌、换色、客服、备案、链接解析），并注入**新导航外壳** |
| 修改方式 | 改源码，`npm run build` | 只能加补丁（`tools/web/legacy.js`），第二阶段逐个页面迁入新前端后删除 |

新前端**不读取旧编译文件里的任何内部导出**（上一版的 `vue.js` / `bridge.js` 借用旧包里 `c4`、`dL` 这类压缩变量名，已全部删除）。

## 两个应用之间只通过公开约定交互

| 约定 | 内容 | 代码 |
|---|---|---|
| 页面地址 | 路径表 `frontend/src/app-routes.js`，后端（`web/ct-routes.json`）和旧前台里的外壳共用；跨应用整页跳转 | `platform/nav.js` |
| 后端接口 | `POST /ydapi/…`，同源，请求头 `token` | `platform/http.js` |
| 登录会话 | `localStorage["yd.user.v1"] = {token, expires_in, isLoggedIn, loginAt, profile}`，写入后派发 `storage` 事件，旧前台的用户仓库据此同步；格式由单元测试与旧前台原函数逐字段对比 | `platform/session.js` |
| 登录地址 | `?login=phone|account&mode=register&redirect=/原页面`（旧前台同一约定） | `entries/app.js` |
| 一句话作图预填 | `sessionStorage["yd.tpl.tongkuan"] = {prompt, image, title}` | `platform/assistant.js` |
| 首页上传 → 工作台 | 图片暂存在浏览器 IndexedDB（`ct-handoff`，10 分钟过期，取出即删），工作台页面上的外壳放进上传框并触发 `change`，后续上传、生成走工作台自己的逻辑 | `platform/handoff.js`、`legacy/workbench-handoff.js` |
| 语言 | `localStorage["yd.lang.v1"]`，旧页面刷新生效 | `overlays/misc.jsx` |
| 旧前台路由器 | 只用 vue-router 公开 API（`#app.__vue_app__.config.globalProperties.$router` 的 `push / beforeEach / afterEach / currentRoute`） | `entries/legacy-shell.js` |

## 目录

```
frontend/
  index.html, vite.config.js, package.json   标准 Vite 工程（vue 3.5.34、vue-router 4.6.4、vite 6.4.1，版本锁定）
  src/
    app-routes.js        新前端负责的路径（唯一来源）
    router.js, App.jsx   路由（页面按需加载）与根组件
    entries/app.js       新前端入口
    entries/legacy-shell.js  旧前台页面上的导航外壳入口（独立 Vue 实例）
    platform/            与外部的约定：接口、会话、跳转、站点信息、上传交接、助手预填
    stores/              当前用户、收藏 / 最近使用
    shell/Shell.jsx      左侧导航、底部导航、全部弹层
    overlays/            登录、会员支付（含二维码）、公告、客服、新建创作、账户菜单、提示消息
    pages/               首页、AI 工具中心、场景灵感、个人中心
    components/          图标、作品图、工具卡、弹层外框、二维码
    lib/                 纯逻辑：搜索、模板规则；vendor/qrcodegen.js（Nayuki，MIT）
    data/                工具目录 / 场景卡片 / 模板筛选（由 legacy/extract-data.mjs 从旧产物按数据形状导出）
    styles/              设计令牌、组件、外壳、弹层、页面、旧页面适配
  public/data/templates.json   3020 个模板（约 4MB，场景灵感页按需加载）
  tests/unit/            新前端单元测试（node --test）
legacy/
  original/              旧前台原始产物（只读，legacy/original.sha256 锁定）
  extract-data.mjs       一次性数据导出（--check 可核对 JSON 与旧产物是否一致）
tools/web/
  legacy.js              旧前台只读构建：校验 → 复制 → 接口同源 → 换牌 → 换色与补丁 → 素材图走 /cos → 按内容哈希改名
  build.js               旧前台 + 新前端 → 一个全新目录（含 ct-routes.json、build-info.json、files.sha256）
```

组件用 **JSX + Vue 渲染函数**编写（Vite 内置 esbuild 处理，`vite.config.js` 里 `jsxInject` 自动引入 `h`），不需要额外插件。

## 构建

```bash
cd frontend && npm install && npm run build      # → frontend/dist（含 .vite/manifest.json）
node tools/web/build.js --out build/web     # → 完整前台；输出目录必须不存在，任何输入都不会被修改
```

- 旧前台部分**可重复构建**：同样的输入得到逐字节相同的输出（单元测试验证）；构建号取内容哈希
- 必需补丁没命中会直接构建失败（宁可不发布，也不发布半成品）
- `version.json` 保持原样（改了旧前台会一直弹「新版本可用」）

> 关于本次交付的 `frontend/dist`：开发环境（本沙箱）无法访问 npm 仓库，装不了 Vite，所以这一次的产物是用等价流程生成的——vue / vue-router 用 GitHub 上同版本 tag 的官方源码构建，esbuild 打包，产物结构（`dist/index.html`、`assets/`、`.vite/manifest.json`）与 `vite build` 一致，并通过了全部测试。**在能访问 npm 的机器上执行 `npm install && npm run build` 即为标准构建**；建议第一次标准构建后把生成的 `package-lock.json` 提交进仓库，锁定依赖的完整版本树。

## 后端相关改动

- `GET /health`：返回后端版本、前台构建号；测试沙箱额外返回沙箱标识
- 新前端路径返回 `web/app/index.html`，其余返回旧前台 `web/index.html`
- 只有带内容哈希的文件（`/assets/`、`/app/assets/`）长期缓存，其余 1 小时
- `GET /cos/…`：素材图优先返回 `<数据目录>/cos` 里的副本，否则 302 到原 CDN
- `POST /ydapi/site/config`：站点名、公司、备案号、客服时间、登录方式开关（新前端读取）
- 安全：短信「调试模式」默认关闭——之前默认开启，未配置短信服务时会把验证码直接返回给浏览器，任何人都能登录任意手机号账号

## 第二阶段（下一步）

把旧前台页面逐个迁入新前端，每迁一个就从 `app-routes.js` 加一条路径、删掉对应补丁：

1. 工作台（174 个工具共用一套框架，迁完后首页上传可以直接内存交接，不再需要 IndexedDB）
2. 我的作品 / 生成记录、点数明细、订单记录
3. 个人中心其余模块、分销推广
4. 旧前台全部迁完后删除 `legacy/` 和 `styles/legacy.css`
