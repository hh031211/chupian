# 橙图 · 版本化发布与回滚

以前的更新方式是解压覆盖代码、在 `/root/dist-ip` 里原地打补丁（删除再恢复 `assets`）。出问题只能靠备份目录手工恢复，而且代码、前台、配置、数据库没有对应关系。

现在改为**每个版本一个只读目录**，用软链接切换：

```
/opt/chengtu/
  releases/
    1.3.0-20261023-221500-abc1234/   后端代码 + web/（构建好的前台）+ release.json + SHA256SUMS（只读）
    legacy-20261023-230000/          迁移前的线上版本（可回滚）
  current -> releases/1.3.0-…        当前版本（软链接，切换是原子操作）
  shared/
    config.json                      正式配置（路径全部是绝对路径）
    data/                            数据库、上传文件、品牌图、素材图 cos/ …（所有版本共用，发布不动它）
    ecosystem.config.cjs             pm2 配置（运行 current/src/server.js）
    release.config.json              服务管理方式、健康检查超时
  backups/<时间>_<原版本>_to_<新版本>/   每次切换前的数据库快照（在线 VACUUM INTO）+ 配置副本，保留最近 20 份
  deploy.log                         发布记录
```

## 发布流程做了什么

`release.js deploy <发布包>` 依次执行下面几步，任一步失败都**不会切换**：

1. **安装**：校验发布包的 sha256，解压到 `releases/<版本>`，逐个文件核对 `SHA256SUMS`，设为只读
2. **验证**：再核对一次文件完整性；用该版本自带的代码和测试，在临时目录 + 临时数据库 + 模拟中转站里跑全部接口测试，不读写正式数据
3. **切换**：备份数据库和配置 → 软链接指向新版本 → 重启服务
4. **健康检查**：确认后端版本号、前台构建号都是新版本的；新前端首页、旧前台工作台、站点接口、新前端脚本都能正常访问
5. **自动回退**：健康检查失败时切回原版本并重启，退出码非 0。数据库不动；需要时可以用第 3 步的快照恢复

以上每一步都在 `tests/deploy/` 里真实演练过：打包、安装、校验和、上线、发布后数据保留、回滚、恢复数据库快照、坏版本自动回退、旧目录迁移。

## 第一次：从现在的目录结构迁移（只做一次）

现在线上是 `/root/yuduo-server`（代码 + `data/`）和 `/root/dist-ip`（前台），pm2 进程名 `yuduo-server`。迁移**只复制、不修改**这两个目录，随时可以退回。

```bash
# 0. 上传 chengtu-<版本>.tar.gz 和 chengtu-<版本>.tar.gz.sha256 到 /root
cd /root && sha256sum -c chengtu-<版本>.tar.gz.sha256

# 1. 先取出发布工具
mkdir -p /tmp/ct && tar -xzf chengtu-<版本>.tar.gz -C /tmp/ct

# 2. 迁移：会先停掉旧进程（保证数据库复制完整），再把数据、配置、已下载的素材图复制到 /opt/chengtu/shared，
#    并把当前线上代码 + 前台做成一个可回滚的版本 legacy-<时间>
node /tmp/ct/<版本>/tools/release.js migrate --from /root/yuduo-server --web /root/dist-ip --old-pm2 yuduo-server

# 3. 用新的进程配置启动（此时运行的仍是迁移前的线上版本，网站恢复访问）
pm2 delete yuduo-server; pm2 start /opt/chengtu/shared/ecosystem.config.cjs && pm2 save

# 4. 发布新版本（安装 → 校验 → 沙箱测试 → 备份 → 上线 → 健康检查）
#    注意：这一次要用第 1 步解压出来的新工具——此时 current 指向迁移前的旧代码，里面还没有 release.js
node /tmp/ct/<版本>/tools/release.js deploy /root/chengtu-<版本>.tar.gz
```

第 2 步到第 3 步之间网站会停几秒到几十秒（取决于上传文件多少）。

**如果迁移后想完全退回旧方式**：`pm2 delete chengtu; cd /root/yuduo-server && pm2 start ecosystem.config.js`。注意迁移之后产生的新数据在 `/opt/chengtu/shared/data`，退回旧目录前要先把它复制回 `/root/yuduo-server/data`。

## 日常发布

```bash
# 本地 / CI（需要能访问 npm）
cd frontend && npm install && npm run build && cd ..
npm test                              # 可选但推荐：全部测试
npm run release:pack                  # → dist/chengtu-<版本>.tar.gz 和 .sha256

# 服务器
node /opt/chengtu/current/tools/release.js deploy /root/chengtu-<版本>.tar.gz
```

## 回滚

```bash
node /opt/chengtu/current/tools/release.js status                  # 看有哪些版本、当前是哪个
node /opt/chengtu/current/tools/release.js rollback                # 回到上一个版本（代码 + 前台 + 配置）
node /opt/chengtu/current/tools/release.js rollback <版本>          # 回到指定版本
node /opt/chengtu/current/tools/release.js backups                 # 数据库快照列表
node /opt/chengtu/current/tools/release.js rollback <版本> --restore-db <快照目录名>   # 同时把数据库恢复到某次切换前
```

- 回滚本身也会先做一次数据库快照，所以「恢复数据库」之后还能再恢复回来
- **恢复数据库会丢失快照之后产生的数据**（新注册、新订单、新作品记录），只在新版本写坏了数据时使用；一般回滚代码即可
- 上传文件、品牌图、素材图在 `shared/data`，任何回滚都不会动它们

## 其它命令

| 命令 | 作用 |
|---|---|
| `release.js install <包>` | 只安装不上线 |
| `release.js verify <版本>` | 校验文件 + 沙箱接口测试（`--skip-tests` 只校验文件） |
| `release.js activate <版本>` | 切换到已安装的版本（带备份、健康检查、自动回退） |

服务管理默认用 pm2（进程名 `chengtu`），可在 `shared/release.config.json` 改成 `{"service": {"type": "systemd", "unit": "chengtu"}}`。所有命令也可以加 `--home <目录>` 或设置环境变量 `CT_HOME`，换一个安装目录。

## 素材图（可选）

旧前台的模板图、案例图都在原站 CDN `cos.huotu333.cn`。现在前台统一引用本站 `/cos/…`：数据目录里有副本就直接返回，没有就跳转回原 CDN。想完全不依赖原站：

```bash
node /opt/chengtu/current/tools/mirror-cos.js --to /opt/chengtu/shared/data/cos
```

只下载、不修改前台文件，可以中断、可以重复执行。迁移时，以前下载到 `/root/dist-ip/cos` 的图片已经自动复制过去。
