'use strict';
// 生图模型选择与尺寸：用户选的模型优先；gpt-image-2 选 2K / 4K 传真实像素
const { test } = require('node:test');
const assert = require('node:assert/strict');
const { RelayClient, computeSize, runWithFeature } = require('../../src/ai/relay');

test('4K 尺寸不超过 3840×2160 总像素', () => {
  assert.equal(computeSize('1:1', '4K', 'pixels'), '2880x2880');
  assert.equal(computeSize('16:9', '4K', 'pixels'), '3840x2160');
  assert.equal(computeSize('1:1', '2K', 'pixels'), '2048x2048');
  assert.equal(computeSize('1:1', '4K', 'openai'), '1024x1024');
});

test('用户选了别的前台模型时，不被「首页创作」单独指定的模型盖掉', () => {
  const ch = (id) => ({ id, name: id, base_url: 'http://x', key: 'k', enabled: true });
  const rl = new RelayClient({
    channels: [ch('old'), ch('new')],
    image_models: { m1: { ref: 'old::gpt-image-2.5-sunburst' }, m3: { ref: 'new::gpt-image-2.5-flare', enabled: true } },
    feature_models: { 'kind:ai': 'old::gpt-image-2.5-sunburst' },
  });
  runWithFeature({ module: 'ai.image', board: 'ai', kind: 'ai' }, () => {
    assert.equal(rl.imageModel('m3').channel, 'new');
    assert.equal(rl.imageModel('m3').model, 'gpt-image-2.5-flare');
    assert.equal(rl.imageModel('m1').channel, 'old');
  });
});
