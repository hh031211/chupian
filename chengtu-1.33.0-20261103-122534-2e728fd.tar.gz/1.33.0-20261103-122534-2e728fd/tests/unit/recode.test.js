'use strict';
// 图片重编码：发给模型的大图缩小、出图存 JPG（没装缩图工具的环境跳过）
const { test } = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const path = require('node:path');
process.env.YD_CONFIG = process.env.YD_CONFIG || path.join(os.tmpdir(), 'ct-none.json');
const thumbs = require('../../src/core/thumbs');
const storage = require('../../src/core/storage');
const zlib = require('node:zlib');

function png(w, h, alpha) {
  const ch = alpha ? 4 : 3;
  const raw = Buffer.alloc((w * ch + 1) * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * ch + 1) + 1 + x * ch; const n = (Math.random() * 16) | 0; raw[o] = ((x / w) * 200 + n) | 0; raw[o + 1] = ((y / h) * 200 + n) | 0; raw[o + 2] = (120 + n) | 0; if (alpha) raw[o + 3] = x < w / 2 ? 0 : 255; }
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const v of b) c = crcT[(c ^ v) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = alpha ? 6 : 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 1 })), chunk('IEND', Buffer.alloc(0))]);
}

const skip = thumbs.status().enabled ? false : '没有 vips / ImageMagick';

test('透明检测', () => {
  assert.equal(thumbs.hasAlpha(png(8, 8, true)), true);
  assert.equal(thumbs.hasAlpha(png(8, 8, false)), false);
});

test('大图缩到长边 2560 并转 JPG；透明图保持 PNG；不放大小图', { skip }, async () => {
  const big = png(3200, 1800, false);
  const r = await thumbs.recode(big, { max: 2560, q: 92 });
  assert.ok(r && r.mimetype === 'image/jpeg');
  const s = storage.imageSize(r.buffer);
  assert.equal(Math.max(s.width, s.height), 2560);
  const a = await thumbs.recode(png(3000, 1000, true), { max: 2560 });
  if (a) { assert.equal(a.mimetype, 'image/png'); assert.equal(storage.imageSize(a.buffer).width, 2560); }
  const same = await thumbs.recode(png(1600, 900, false), { max: 0, q: 95 });
  if (same) assert.equal(storage.imageSize(same.buffer).width, 1600, '只转格式不改分辨率');
});
