'use strict';
// 存 COS 时顺带生成 960 宽 WebP 小图：原图文件名带 _t，小图 = 原图地址 + .w960.webp（模拟 COS，不连外网）
const { test } = require('node:test');
const assert = require('node:assert/strict');
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ct-cos-'));
process.env.YD_CONFIG = path.join(tmp, 'none.json');
process.env.YD_DB_FILE = path.join(tmp, 't.db');
const S = require('../../src/core/settings');
const thumbs = require('../../src/core/thumbs');
const storage = require('../../src/core/storage');

function png(w, h) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3; const n = (Math.random() * 16) | 0; raw[o] = ((x / w) * 200 + n) | 0; raw[o + 1] = ((y / h) * 200 + n) | 0; raw[o + 2] = 120 + n; }
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const v of b) c = crcT[(c ^ v) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 1 })), chunk('IEND', Buffer.alloc(0))]);
}

test('存 COS：大图带 _t 并上传 .w960.webp 小图；小图片不生成', { skip: thumbs.status().enabled ? false : '没有缩图工具' }, async () => {
  S.load();
  S.set('storage', { driver: 'cos', cos: { secret_id: 'id', secret_key: 'key', bucket: 'b-1', region: 'ap-hongkong', domain: '', prefix: 'uploads' } });
  const puts = [];
  const orig = global.fetch;
  global.fetch = async (url, init) => { puts.push({ url: String(url), type: init.headers['Content-Type'], size: init.body.length, body: init.body }); return { ok: true, status: 200, text: async () => '' }; };
  try {
    const r = await storage.saveBuffer(png(1600, 1200), { mimetype: 'image/png', category: 'gen' });
    assert.match(r.fullurl, /_t\.png$/);
    const t = puts.find((p) => p.url.endsWith('_t.png.w960.webp'));
    assert.ok(t, '应上传小图');
    assert.equal(t.type, 'image/webp');
    assert.equal(storage.imageSize(Buffer.from(t.body)).width, 960);
    puts.length = 0;
    const small = await storage.saveBuffer(png(40, 40), { mimetype: 'image/png', category: 'gen' });
    assert.doesNotMatch(small.fullurl, /_t\./);
    assert.equal(puts.length, 1);
  } finally { global.fetch = orig; }
});
