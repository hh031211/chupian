'use strict';
// 安全：防爆破、防短信轰炸、上传类型、内网地址（SSRF）、越权、安全响应头
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, cap, BASE, API } = require('../lib/client');

before(guard);
const setSec = async (v) => admin('/settings/save', { group: 'security', value: { ip_register_limit_per_day: 0, banned_words: [], ip_blacklist: [], ...v } });
after(() => setSec({ rate_limit: false }));

test('防爆破：同一账号连续输错 3 次后要图形验证码，错 10 次锁定', async () => {
  await setSec({ rate_limit: true });
  const u = await newUser();
  for (let i = 0; i < 3; i++) assert.match((await apiFail('/user/login', { account: u.username, password: 'wrong' + i })).msg, /账号或密码不正确/);
  assert.match((await apiFail('/user/login', { account: u.username, password: u.password })).msg, /请输入图形验证码/);
  const ok = await api('/user/login', { account: u.username, password: u.password, ...(await cap()) });
  assert.ok(ok.token, '填对图形验证码后能登录');
  await setSec({ rate_limit: false });
});

test('防短信轰炸：同一 IP 发 2 条后必须填图形验证码', async () => {
  await setSec({ rate_limit: true });
  const base = 13800000000 + Math.floor(Math.random() * 900000);
  await api('/sms/send', { mobile: String(base + 1) });
  await api('/sms/send', { mobile: String(base + 2) });
  assert.match((await apiFail('/sms/send', { mobile: String(base + 3) })).msg, /图形验证码/);
  await api('/sms/send', { mobile: String(base + 3), ...(await cap()) });
  await setSec({ rate_limit: false });
});

test('上传：只收真实的图片，网页 / SVG / 伪装类型一律拒绝', async () => {
  const u = await newUser();
  const send = async (path, name, type, body) => {
    const fd = new FormData(); fd.append('file', new Blob([body], { type }), name);
    return (await fetch(API + path, { method: 'POST', headers: { token: u.token }, body: fd })).json();
  };
  assert.equal((await send('/upload/image', 'x.svg', 'image/svg+xml', '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')).code, 0);
  assert.equal((await send('/upload/file', 'x.html', 'text/html', '<html><script>alert(1)</script></html>')).code, 0);
  assert.equal((await send('/upload/file', 'x.png', 'image/png', '<html><script>alert(1)</script></html>')).code, 0);
});

test('SSRF：不能借服务器访问内网 / 本机地址', async () => {
  const u = await newUser({ member: 'basic', points: 50 });
  for (const image of ['http://169.254.169.254/latest/meta-data/', 'http://10.1.2.3/a.png', 'http://[::1]:22/', 'file:///etc/passwd']) {
    const r = await apiFail('/ai/describe', { image }, u.token);
    assert.doesNotMatch(r.msg, /^$/);
  }
  const { assertPublicUrl } = require('../../src/core/storage');
  await assert.rejects(assertPublicUrl('http://192.168.1.1/x.png'), /内网/);
  await assert.rejects(assertPublicUrl('http://127.0.0.1:8361/health'), /内网/);
});

test('越权：看不到、删不掉别人的作品和项目', async () => {
  const a = await newUser({ member: 'basic', points: 50 });
  const b = await newUser();
  const t = await api('/ai/image', { prompt: '一只猫', count: 1, resolution: '1K' }, a.token);
  const id = t.task ? t.task.id : t.task_id;
  assert.ok(id);
  await apiFail('/ai/status', { task_id: id }, b.token);
  await api('/all.records/del', { ids: [id] }, b.token);
  const mine = await api('/all.records/lists', {}, a.token);
  assert.ok(mine.items.some((x) => x.task_id === id), 'B 删不掉 A 的作品');
});

test('安全响应头、错误不泄露内部信息', async () => {
  const r = await fetch(BASE + '/');
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(r.headers.get('x-frame-options'), 'SAMEORIGIN');
  const bad = await fetch(BASE + '/uploads/../../config.json');
  assert.notEqual(bad.status, 200);
});

test('会话：改密码后其它设备的登录失效；数据库只存令牌哈希', async () => {
  const u = await newUser();
  const other = await api('/user/login', { account: u.username, password: u.password });
  await api('/user/changepwd', { old_password: u.password, new_password: 'newpass2026' }, u.token);
  await api('/user/info', {}, u.token);   // 当前设备还能用
  const r = await fetch(API + '/user/info', { method: 'POST', headers: { token: other.token, 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(r.status, 401, '另一台设备的登录应失效');
  const db = require('node:sqlite');
  assert.ok(db, 'node:sqlite');
});

test('首页有内容安全策略（CSP）；外站跨域请求拿不到授权头；未登录接口拒收超大请求', async () => {
  const r = await fetch(BASE + '/projects');
  if (/html/.test(r.headers.get('content-type') || '')) {   // 接口测试的沙箱不一定托管前端
    const csp = r.headers.get('content-security-policy') || '';
    assert.match(csp, /script-src 'self' 'sha256-/);
    assert.match(csp, /object-src 'none'/);
  }
  const evil = await fetch(API + '/site/config', { method: 'POST', headers: { Origin: 'https://evil.example', 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(evil.headers.get('access-control-allow-origin'), null);
  const big = await fetch(API + '/user/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ account: 'x', password: 'y'.repeat(400 * 1024) }) });
  assert.equal(big.status, 413);
});

test('密码规则：注册至少 8 位且要字母 + 数字', async () => {
  const { uid } = require('../lib/client');
  assert.match((await apiFail('/user/register', { username: 'pw' + uid(), password: '12345678', ...(await cap()) })).msg, /字母和数字/);
  assert.match((await apiFail('/user/register', { username: 'pw' + uid(), password: 'ab12', ...(await cap()) })).msg, /8-32/);
});
