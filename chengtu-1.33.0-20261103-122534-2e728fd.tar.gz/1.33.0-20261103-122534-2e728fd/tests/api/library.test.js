'use strict';
// 资料库：上传、我的素材、公告、反馈、数据隔离
const fs = require('node:fs');
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, upload, API, BASE, FIXTURE } = require('../lib/client');

let U; let IMG;
before(async () => {
  await guard();
  U = await newUser({ member: 'basic', points: 20 });
  IMG = (await upload(U.token)).fullurl;
});

test('上传图片：返回可访问地址，拒绝非图片', async () => {
  const up = await upload(U.token);
  assert.ok(up.fullurl && up.width > 0);
  const res = await fetch(new URL(up.fullurl, BASE));
  assert.equal(res.status, 200);
  const fd = new FormData();
  fd.append('file', new Blob(['not an image'], { type: 'text/plain' }), 'a.txt');
  const r = await (await fetch(API + '/upload/image', { method: 'POST', headers: { token: U.token }, body: fd })).json();
  assert.notEqual(r.code, 1);
});

test('素材库：分组、添加、移动、改名、删除', async () => {
  const g = await api('/material/addgroup', { name: '分组A' }, U.token);
  const mat = await api('/material/add', { group_id: g.group.id, name: 'x', url: IMG }, U.token);
  await api('/material/add', { group_id: 'default', name: 'y', fullurl: IMG }, U.token);
  const list = await api('/material/lists', { source: 'user', group_id: 0 }, U.token);
  assert.ok(list.materials.length >= 1);
  await api('/material/move', { ids: [mat.material.id], group_id: 'default' }, U.token);
  await api('/material/renamegroup', { id: g.group.id, name: 'B' }, U.token);
  await api('/material/del', { ids: [mat.material.id] }, U.token);
  await api('/material/delgroup', { id: g.group.id }, U.token);
});

test('公告（未登录可看）、已读、意见反馈', async () => {
  await admin('/crud/notices/save', { title: '测试公告', content: '<p>内容</p>', type: 'notice', status: 'normal' });
  const anon = await api('/notice/lists');
  assert.ok(anon.notice.some((n) => n.title === '测试公告'));
  const nl = await api('/notice/lists', {}, U.token);
  const n = nl.notice.find((x) => x.title === '测试公告');
  await api('/notice/read', { ids: [n.id] }, U.token);
  assert.equal((await api('/notice/lists', {}, U.token)).notice.find((x) => x.id === n.id).is_read, 1);
  await api('/feedback/submit', { type: 'bug', content: '测试', phone: '1' }, U.token);
});

test('素材库（官方素材）接口：未登录可看分类和列表', async () => {
  const cats = await api('/gallery/cats');
  assert.ok(Array.isArray(cats.cats));
  const l = await api('/gallery/lists', { page: 1, limit: 10, sort: 'hot', q: '口红' });
  assert.ok(Array.isArray(l.items));
  assert.equal((await api('/gallery/one', { id: 999999 })).item, null);
});

test('访问其他用户的数据被拒绝', async () => {
  const other = await newUser({ member: 'basic' });
  const d = await api('/product.changebg/generate', { images: [IMG], count: 1, bg_prompt: '客厅' }, U.token);
  await apiFail('/product.changebg/status', { task_id: d.task.id }, other.token);
  const g = await api('/material/addgroup', { name: '私有分组' }, U.token);
  await api('/material/add', { fullurl: IMG, group_id: g.group.id }, U.token);
  const mine = await api('/material/lists', { group_id: g.group.id }, other.token);
  assert.equal(mine.materials.length, 0, '看不到别人的素材');
});

test('旧素材图地址 /cos/ 已下线（素材库已清空，改为站长自己生成 / 上传）', async () => {
  const r = await fetch(BASE + '/cos/images/home/feature/x.png', { redirect: 'manual' });
  assert.notEqual(r.status, 302);
});


test('列表缩略图：?w= 返回 WebP 小图（原图不变）；没装缩图工具时返回原图', async () => {
  const { spawnSync } = require('node:child_process');
  const os = require('node:os'); const path = require('node:path');
  const big = path.join(os.tmpdir(), `ct-big-${process.pid}.png`);
  // 造一张约 1MB 以上的 PNG（没有 ImageMagick 时用随机像素的 PNG 编码）
  if (spawnSync('convert', ['-size', '1600x1600', 'plasma:fractal', big]).status !== 0) {
    const zlib = require('node:zlib'); const W = 900; const H = 900;
    const raw = Buffer.alloc((W * 3 + 1) * H); require('node:crypto').randomFillSync(raw); for (let y = 0; y < H; y++) raw[y * (W * 3 + 1)] = 0;
    const chunk = (t, d) => { const b = Buffer.alloc(8 + d.length + 4); b.writeUInt32BE(d.length, 0); b.write(t, 4); d.copy(b, 8); const crc = zlib.crc32(Buffer.concat([Buffer.from(t), d])); b.writeUInt32BE(crc >>> 0, 8 + d.length); return b; };
    const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
    fs.writeFileSync(big, Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]));
  }
  const up = await upload(U.token, big);
  const url = new URL(up.fullurl, BASE);
  const orig = await fetch(url);
  const origSize = Buffer.from(await orig.arrayBuffer()).length;
  const t = await fetch(new URL(url.pathname + '?w=480', BASE));
  const buf = Buffer.from(await t.arrayBuffer());
  const { status } = require('../../src/core/thumbs');
  if (status().enabled) {
    assert.equal(t.headers.get('content-type'), 'image/webp');
    assert.ok(buf.length < origSize / 5, `缩略图应远小于原图（${buf.length} / ${origSize}）`);
  } else {
    assert.equal(buf.length, origSize, '没有缩图工具时返回原图');
  }
  assert.equal(Buffer.from(await (await fetch(url)).arrayBuffer()).length, origSize, '原图不变');
  fs.unlinkSync(big);
});
