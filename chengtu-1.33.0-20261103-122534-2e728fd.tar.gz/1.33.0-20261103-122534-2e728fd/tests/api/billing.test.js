'use strict';
// 会员与支付：套餐、优惠券、下单、模拟支付到账、兑换码、子账号共享点数、分销佣金与提现
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, score, mockPay, uid } = require('../lib/client');

before(guard);

test('套餐列表包含基础会员、企业版、加油包', async () => {
  const { plans } = await api('/member/plans');
  for (const k of ['basic', 'enterprise', 'pack']) assert.ok(plans[k] && plans[k].length, `缺少 ${k} 套餐`);
  for (const p of plans.basic) assert.ok(p.id && p.title && Number(p.price) > 0);
});

test('下单 → 模拟支付 → 会员与点数到账（金额、优惠券、订单状态都正确）', async () => {
  const u = await newUser();
  const { plans } = await api('/member/plans', {}, u.token);
  const plan = plans.basic[1];
  const act = await admin('/crud/coupons/save', { title: '满99减10', amount: 10, threshold_amount: 99, valid_days: 30, total: 100, per_user: 1 });
  await api('/member/claimcoupon', { activity_id: act.id }, u.token);
  await apiFail('/member/claimcoupon', { activity_id: act.id }, u.token); // 每人限领 1 张
  const { list } = await api('/member/coupons', { amount: plan.price }, u.token);
  const coupon = list.find((c) => c.title === '满99减10');
  assert.ok(coupon, '领到的优惠券应可用于该套餐');

  const before = await score(u.token);
  const ord = await api('/member/order', { plan_id: plan.id, pay_type: 'wxpay', coupon_id: coupon.id }, u.token);
  assert.equal(Number(ord.order.amount), Math.max(0.01, Number(plan.price) - 10));
  assert.ok(ord.pay.code_url, '应返回支付二维码内容');
  assert.equal((await api('/member/status', { order_sn: ord.order.order_sn }, u.token)).order.pay_status, 'pending');
  await mockPay(ord.pay.code_url);
  const st = await api('/member/status', { order_sn: ord.order.order_sn }, u.token);
  assert.equal(st.order.pay_status, 'paid');
  assert.equal(st.userinfo.member_level, plan.level || 'basic');
  assert.equal(st.userinfo.score, before + Number(plan.points), '点数应按套餐到账');
  // 重复确认支付不会重复到账（幂等）
  await mockPay(ord.pay.code_url);
  assert.equal(await score(u.token), before + Number(plan.points));
  // 优惠券已使用
  const rights = await api('/member/rights', {}, u.token);
  assert.ok(rights.coupons.used.some((c) => c.id === coupon.id));
  const orders = await api('/member/orders', {}, u.token);
  assert.ok((orders.list || orders.items || []).some((o) => o.order_sn === ord.order.order_sn));
  await api('/member/logs', {}, u.token);
});

test('加油包只能在会员期内购买', async () => {
  const u = await newUser();
  const { plans } = await api('/member/plans', {}, u.token);
  const r = await apiFail('/member/order', { plan_id: plans.pack[0].id, pay_type: 'wxpay' }, u.token);
  assert.match(r.msg, /会员/);
});

test('兑换码：到账一次，重复兑换失败', async () => {
  const u = await newUser();
  const before = await score(u.token);
  const { codes } = await admin('/redeem/generate', { points: 50, count: 1, title: '50点' });
  const r = await api('/member/redeem', { code: codes[0] }, u.token);
  assert.equal(r.userinfo.score, before + 50);
  await apiFail('/member/redeem', { code: codes[0] }, u.token);
  await apiFail('/member/redeem', { code: 'NOT-A-CODE' }, u.token);
});

test('子账号、分销接口已下线', async () => {
  const u = await newUser({ member: 'enterprise', points: 10 });
  for (const p of ['/member/subaccounts', '/member/addsubaccount', '/distribution/info', '/distribution/order', '/distribution/withdraw']) {
    const r = await (await fetch(require('../lib/client').API + p, { method: 'POST', headers: { 'Content-Type': 'application/json', token: u.token }, body: '{}' })).json();
    assert.notEqual(r.code, 1, p + ' 应已下线');
  }
  const me = (await api('/user/info', {}, u.token)).userinfo;
  assert.equal(me.is_distributor, undefined);
  assert.equal(me.is_enterprise_subaccount, undefined);
  const inv = await api('/task/center', {}, u.token);
  assert.ok(inv.invite_code, '邀请记录照常可用');
});
