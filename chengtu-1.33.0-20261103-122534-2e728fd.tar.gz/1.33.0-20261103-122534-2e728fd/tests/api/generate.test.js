'use strict';
// 生成链路：提交任务 → 出图 → 扣点 → 失败退点 → 作品保存 → 下载 → 回收站；各类工具接口；AI 助手 / 改图 / 对话作图
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, score, upload, waitTask, sleep, BASE, API } = require('../lib/client');

let U; let IMG;
before(async () => {
  await guard();
  U = await newUser({ member: 'enterprise', points: 5000 });
  IMG = (await upload(U.token)).fullurl;
});

test('非会员不能生成（按后台设置），不扣点', async () => {
  const free = await newUser();
  const img = (await upload(free.token)).fullurl;
  const before = await score(free.token);
  const r = await apiFail('/product.changebg/generate', { images: [img], count: 1, bg_prompt: '海边' }, free.token);
  assert.match(r.msg, /会员/);
  assert.equal(await score(free.token), before);
});

test('出图成功：按张扣点、结果可访问、作品出现在记录里、可下载', async () => {
  const before = await score(U.token);
  const d = await api('/product.changebg/generate', { images: [IMG], count: 2, ratio: '原图', bg_prompt: '海边木栈道', model_key: 'm1' }, U.token);
  const charged = Number(d.task.charged_points);
  assert.ok(charged > 0, '应扣点');
  assert.equal(await score(U.token), before - charged, '提交时立即扣点');
  const r = await waitTask('/product.changebg/status', d.task.id, U.token);
  assert.equal(r.task.status, 'succeeded');
  const urls = (r.results || r.images || []).map((x) => (typeof x === 'string' ? x : x.url)).filter(Boolean);
  assert.equal(urls.length, 2, '应生成 2 张');
  assert.equal(await score(U.token), before - charged, '成功不退点');
  // 下载：结果图可直接访问，是图片
  for (const u of urls) {
    const res = await fetch(new URL(u, BASE));
    assert.equal(res.status, 200, '结果图应可下载：' + u);
    assert.match(res.headers.get('content-type') || '', /^image\//);
    assert.ok((await res.arrayBuffer()).byteLength > 100);
  }
  // 作品保存：全部记录 / 分类记录里都有
  const all = await api('/all.records/lists', { page: 1, limit: 20 }, U.token);
  const rec = all.items.find((t) => t.task_id === d.task.id);
  assert.ok(rec, '作品应出现在「我的作品」');
  assert.equal(rec.images.filter((x) => x.url).length, 2);
  const byScene = await api('/product.records/lists', { scene: 'change-bg', page: 1, limit: 5 }, U.token);
  assert.ok(byScene.items.some((t) => t.task_id === d.task.id));
});

test('出图失败：自动退回点数，记录标记失败', async () => {
  const before = await score(U.token);
  const d = await api('/product.changebg/generate', { images: [IMG], count: 1, ratio: '原图', bg_prompt: 'FAILME 触发模拟失败', model_key: 'm1' }, U.token);
  assert.ok(Number(d.task.charged_points) > 0);
  assert.equal(await score(U.token), before - Number(d.task.charged_points));
  const r = await waitTask('/product.changebg/status', d.task.id, U.token);
  assert.equal(r.task.status, 'failed');
  await sleep(300);
  assert.equal(await score(U.token), before, '失败的点数应全部退回');
  const logs = await api('/member/logs', {}, U.token);
  assert.ok(JSON.stringify(logs).includes('生成失败退回'), '点数明细里应有退回记录');
});

test('部分失败只退失败那几张', async () => {
  const before = await score(U.token);
  const d = await api('/product.productmain/generate', { images: [IMG], aspectRatio: '1:1', modules: [{ value: 'a', name: '主图', suggestion: 'front view' }, { value: 'b', name: '卖点图', suggestion: 'FAILME side' }] }, U.token);
  const charged = Number(d.task.charged_points);
  const r = await waitTask('/product.productmain/status', d.task.id, U.token);
  assert.equal(r.task.status, 'partial');
  await sleep(300);
  const after = await score(U.token);
  assert.ok(after > before - charged && after < before, `应只退失败部分（扣 ${charged}，前 ${before}，后 ${after}）`);
});

test('重新生成单张：再扣一次该张点数', async () => {
  const d = await api('/product.composite/generate', { images: [IMG, IMG], count: 1, user_instruction: '放在厨房台面上' }, U.token);
  await waitTask('/product.composite/status', d.task.id, U.token);
  const before = await score(U.token);
  const rg = await api('/product.composite/regen', { task_id: d.task.id, index: 1 }, U.token);
  assert.equal(await score(U.token), before - Number(rg.charged_points));
  const r = await waitTask('/product.composite/status', d.task.id, U.token);
  assert.equal(r.task.status, 'succeeded');
});

test('保留的工具都能出图；已下线的功能接口拒绝', async () => {
  const gen = async (mod, body) => {
    const d = await api(`/${mod}/generate`, body, U.token);
    const r = await waitTask(`/${mod}/status`, d.task.id, U.token);
    assert.equal(r.task.status, 'succeeded', `${mod} 应成功：${JSON.stringify(r.errors || r.task).slice(0, 200)}`);
    return r;
  };
  await gen('product.productmain', { images: [IMG], aspectRatio: '1:1', modules: [{ value: 'a', name: '主图', suggestion: 's1', ratio: '1:1' }, { value: 'b', name: '卖点图', suggestion: 's2', copy: '轻薄' }] });
  await gen('product.composite', { images: [IMG, IMG], count: 2, ratio: '1:1', user_instruction: '放在木桌上' });
  await gen('product.maincollage', { images: [IMG, IMG, IMG], count: 1, ratio: '1:1', layout_label: '一大多小' });
  await gen('product.changebg', { images: [IMG], bg_refs: [IMG], count: 1, ratio: '原图', bg_prompt: '' });
  await gen('video.imagetovideo', { images: [IMG], count: 1, prompt: '转身' });
  for (const m of ['model.tryonany', 'product.detailpage', 'product.whitebg', 'batch.image', 'material.copywriting', 'toolbox.cutoutpro']) {
    const e = await apiFail(`/${m}/generate`, { images: [IMG], count: 1, prompt: 'x' }, U.token);
    assert.match(e.msg, /下线/, `${m} 应已下线`);
  }
});

test('作品删除 → 回收站 → 恢复 → 彻底删除', async () => {
  const d = await api('/product.changebg/generate', { images: [IMG], count: 1, bg_prompt: '客厅' }, U.token);
  await waitTask('/product.changebg/status', d.task.id, U.token);
  const id = d.task.id;
  await api('/product.records/remark', { id, remark: '备注' }, U.token);
  await api('/product.records/del', { ids: [id] }, U.token);
  let all = await api('/all.records/lists', { page: 1, limit: 50 }, U.token);
  assert.ok(!all.items.some((t) => t.task_id === id), '删除后不在作品列表');
  const trash = await api('/trash/lists', { page: 1, limit: 100, account: 'all' }, U.token);
  assert.ok(JSON.stringify(trash).includes(`"task_id":${id}`), '应进入回收站');
  await api('/trash/restore', { items: [{ board: 'product', task_id: id }] }, U.token);
  all = await api('/all.records/lists', { page: 1, limit: 50 }, U.token);
  assert.ok(all.items.some((t) => t.task_id === id), '恢复后回到作品列表');
  await api('/product.records/del', { ids: [id] }, U.token);
  await api('/trash/del', { items: [{ board: 'product', task_id: id }] }, U.token);
  await api('/trash/clear', { account: 'all' }, U.token);
});

test('AI 助手（一句话作图）：出图、历史、重新生成、删除', async () => {
  const ai = await api('/ai/image', { prompt: '猫', count: 2, images: [IMG], aspectRatio: '3:4', resolution: '1K', model_key: 'm2' }, U.token);
  const r = await waitTask('/ai/status', ai.task.id, U.token);
  assert.equal(r.results.length, 2);
  await api('/ai/history', { limit: 24, page: 1 }, U.token);
  await api('/ai/remark', { task_id: ai.task.id, remark: 'r' }, U.token);
  await api('/ai/regenimage', { task_id: ai.task.id, index: 1 }, U.token);
  await waitTask('/ai/status', ai.task.id, U.token);
  await api('/ai/delete', { task_id: ai.task.id }, U.token);
});

test('首页对话：先理解需求（回复 + 精确指令 + 标题），一段对话 = 项目库里一个项目，能重新打开；删除整段进回收站可恢复', async () => {
  const plan = await api('/ai/plan', { prompt: '把这个小女孩改成小男孩', images: [IMG] }, U.token);
  assert.ok(plan.text && plan.prompt && plan.title, '对话模式返回回复、给模型的指令和标题');
  const a = await api('/ai/image', { prompt: plan.prompt, refined: 1, user_prompt: '把这个小女孩改成小男孩', plan: plan.text, title: plan.title, session_id: 0, session_title: plan.title, mode: 'chat', turn: 'k1', images: [IMG], count: 1, aspectRatio: 'auto', resolution: '1K' }, U.token);
  const sid = a.task.session_id;
  assert.ok(sid > 0, '第一次生成建对话');
  await waitTask('/ai/status', a.task.id, U.token);
  const b = await api('/ai/image', { prompt: '再把背景换成海边', user_prompt: '再把背景换成海边', session_id: sid, mode: 'quick', turn: 'k2', images: [IMG], count: 1, aspectRatio: 'auto', resolution: '1K' }, U.token);
  assert.equal(b.task.session_id, sid, '同一对话继续');
  await waitTask('/ai/status', b.task.id, U.token);
  const all = await api('/all.records/lists', { page: 1, limit: 50 }, U.token);
  const mine = all.items.filter((x) => x.session_id === sid);
  assert.equal(mine.length, 1, '一段对话在项目库里只算一个项目');
  assert.equal(mine[0].title, plan.title, '项目名用对话标题，不是「AI 助手」');
  const s = await api('/ai/session', { id: sid }, U.token);
  assert.equal(s.session.title, plan.title);
  assert.equal(s.tasks.length, 2);
  assert.equal(s.tasks[0].params.user_prompt, '把这个小女孩改成小男孩');
  assert.equal(s.tasks[0].params.plan, plan.text);
  assert.ok(s.tasks[0].results.length >= 1);
  assert.ok((await api('/ai/session', { task_id: b.task.id }, U.token)).tasks.length === 2, '按任务也能打开整段对话');
  const other = await newUser({ member: 'basic' });
  await apiFail('/ai/session', { id: sid }, other.token);
  await api('/all.records/del', { ids: [mine[0].task_id] }, U.token);
  assert.ok(!(await api('/all.records/lists', { page: 1, limit: 50 }, U.token)).items.some((x) => x.session_id === sid), '整段对话删除');
  const tr = await api('/trash/lists', {}, U.token);
  const it = tr.items.find((x) => x.session_id === sid);
  assert.ok(it && it.title === plan.title && it.count >= 2, '回收站里一段对话算一项');
  await api('/trash/restore', { ids: [it.task_id] }, U.token);
  assert.equal((await api('/ai/session', { id: sid }, U.token)).tasks.length, 2, '恢复整段对话');
});

test('商品套图：AI 规划每张图', async () => {
  const d = await api('/product.productmain/outline', { images: [IMG], count: 3, aspectRatio: '1:1', settings: { language: '中文' } }, U.token);
  assert.equal(d.outline.length, 3);
  assert.ok(d.outline.every((o) => o.name));
});

test('模型「最高清晰度」：选 4K 自动降到 2K 生成，按 2K 扣点；不设上限时按 4K', async () => {
  const before = await admin('/settings', {});
  const relayCfg = before.settings.relay;
  const ref = `${relayCfg.image_models.m1.channel}::${relayCfg.image_models.m1.model}`;
  const table = before.settings.pricing.image.m1;
  const save = (meta) => admin('/settings/save', { group: 'relay', value: { ...relayCfg, model_meta: { ...(relayCfg.model_meta || {}), [ref]: meta } } });
  try {
    await save({ type: 'image', mode: 'openai', max_resolution: '2K' });
    const s0 = await score(U.token);
    const d = await api('/product.changebg/generate', { images: [IMG], count: 1, bg_prompt: '海边', model_key: 'm1', resolution: '4K' }, U.token);
    assert.equal(Number(d.task.charged_points), Number(table['2K']), '应按 2K 扣点');
    assert.equal(await score(U.token), s0 - Number(table['2K']));
    const r = await waitTask('/product.changebg/status', d.task.id, U.token);
    assert.equal(r.task.status, 'succeeded');
    assert.equal(String(r.task.resolution).toUpperCase(), '2K');
    // 首页创作台同样降档计价
    const ai = await api('/ai/image', { prompt: '换成红色', images: [IMG], count: 1, resolution: '4K', model_key: 'm1' }, U.token);
    assert.equal(Number(ai.task.charged_points), Number(table['2K']));
    await waitTask('/ai/status', ai.task.id, U.token);
    await save({ type: 'image', mode: 'openai' });
    const d2 = await api('/product.changebg/generate', { images: [IMG], count: 1, bg_prompt: '海边', model_key: 'm1', resolution: '4K' }, U.token);
    assert.equal(Number(d2.task.charged_points), Number(table['4K']), '不设上限时按 4K 扣点');
    await waitTask('/product.changebg/status', d2.task.id, U.token);
  } finally {
    await admin('/settings/save', { group: 'relay', value: relayCfg });
  }
});

test('后台「今日消耗点数」扣除失败退回的点数', async () => {
  // 「今日」按北京时间零点切换；测试恰好跨过零点时重测一次
  const day = () => Math.floor((Date.now() / 1000 + 8 * 3600) / 86400);
  for (let attempt = 0; attempt < 2; attempt++) {
    const start = day();
    const d0 = await admin('/dashboard', {});
    const u = await newUser({ member: 'enterprise', points: 100 });
    const img = (await upload(u.token)).fullurl;
    const bad = await api('/product.changebg/generate', { images: [img], count: 1, bg_prompt: 'FAILME 触发模拟失败', model_key: 'm1' }, u.token);
    await waitTask('/product.changebg/status', bad.task.id, u.token);
    const ok = await api('/product.changebg/generate', { images: [img], count: 1, bg_prompt: '海边', model_key: 'm1' }, u.token);
    await waitTask('/product.changebg/status', ok.task.id, u.token);
    const d1 = await admin('/dashboard', {});
    if (day() !== start) continue;
    assert.equal(d1.points_consumed_today - d0.points_consumed_today, Number(ok.task.charged_points), '失败退回的点数不应计入消耗');
    return;
  }
});

test('中转站实际只出 2K（后台没设上限）：选 4K 先按 4K 扣，出图后按实际 2K 退差价', async () => {
  const table = (await admin('/settings', {})).settings.pricing.image;
  const s0 = await score(U.token);
  const d = await api('/product.changebg/generate', { images: [IMG], count: 1, bg_prompt: '海边 MOCK_MAX2K', model_key: 'm1', resolution: '4K' }, U.token);
  assert.equal(Number(d.task.charged_points), Number(table.m1['4K']));
  await waitTask('/product.changebg/status', d.task.id, U.token);
  await sleep(300);
  assert.equal(s0 - await score(U.token), Number(table.m1['2K']), '最终应只扣 2K 的点数');
});
