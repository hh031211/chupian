'use strict';
// 管理后台：登录鉴权、各管理列表、中转站联调（指向模拟中转站）
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, admin, ADMIN } = require('../lib/client');

before(guard);

test('后台未登录 / 密码错误被拒绝', async () => {
  const r = await (await fetch(ADMIN + '/dashboard', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json();
  assert.notEqual(r.code, 1);
  const bad = await (await fetch(ADMIN + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: process.env.CT_TEST_ADMIN_USER, password: 'wrong' }) })).json();
  assert.notEqual(bad.code, 1);
});

test('后台各页面数据接口', async () => {
  for (const p of ['/dashboard', '/users', '/orders', '/tasks', '/ai/logs', '/settings', '/redeem/list', '/library/list', '/library/jobs', '/relay/features']) await admin(p, {});
  for (const n of ['plans', 'coupons', 'notices', 'feedback']) await admin(`/crud/${n}/list`, {});
  // 已删除的功能（分销、子账号、专属模特、资源目录）接口不再存在
  for (const p of ['/withdraws', '/commissions', '/asset/catalogs']) assert.notEqual((await (await fetch(ADMIN + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).code, 1);
  for (const n of ['dist_plans', 'promo', 'agents', 'platform_models', 'materials']) await assert.rejects(admin(`/crud/${n}/list`, {}));
});

test('中转站联调：模型列表、文本、出图（模拟中转站）', async () => {
  const m = await admin('/relay/models', {});
  assert.ok(JSON.stringify(m).includes('gpt-image-1'));
  await admin('/relay/test_chat', {});
  await admin('/relay/test_image', {});
});

test('模型可以同时有多种用途（生图 + 文字 + 识图）：功能里按用途选得到', async () => {
  const { settings } = await admin('/settings', {});
  const relay = settings.relay;
  const ref = `${relay.image_models.m1.channel}::${relay.image_models.m1.model}`;
  const meta = { ...(relay.model_meta || {}) };
  meta[ref] = { ...(meta[ref] || {}), type: 'image', caps: ['image', 'text', 'vision'], mode: (meta[ref] || {}).mode || 'openai' };
  await admin('/settings/save', { group: 'relay', value: { ...relay, model_meta: meta, feature_models: { ...(relay.feature_models || {}), 'text:prompt_plan': ref } } });
  try {
    const { capsOf, canDo } = require('../../src/ai/relay');
    assert.deepEqual(capsOf(meta[ref]), ['image', 'text', 'vision']);
    assert.ok(canDo(meta[ref], 'text') && canDo(meta[ref], 'image') && canDo(meta[ref], 'vision') && !canDo(meta[ref], 'video'));
    assert.deepEqual(capsOf({ type: 'vision' }), ['text', 'vision'], '老配置（单一类型）照常识别');
    const t = await admin('/relay/test_model', { ref, cap: 'text' });
    assert.equal(t.type, 'text');
    const i = await admin('/relay/test_model', { ref, cap: 'image' });
    assert.equal(i.type, 'image');
  } finally { await admin('/settings/save', { group: 'relay', value: relay }); }
});

test('后台素材库：批量生成 → 待审核 → 上架；上传识图直接上架、自动归类；识图生成同类；前台只看到已上架的', async () => {
  const { API } = require('../lib/client');
  const waitJobs = async () => { for (let i = 0; i < 60; i++) { const j = await admin('/library/jobs', {}); if (!j.list.some((x) => x.status === 'running')) return j.list; await new Promise((r) => setTimeout(r, 300)); } throw new Error('素材任务超时'); };
  const g = await admin('/library/generate', { theme: '口红 小红书风', count: 2, ratio: '3:4' });
  assert.ok(g.job_id);
  let jobs = await waitJobs();
  const gj = jobs.find((x) => x.id === g.job_id);
  assert.equal(gj.done, 2, '批量生成 2 张');
  // 也可以直接指定模型库里的某个生图模型
  const { settings: S1 } = await admin('/settings', {});
  const m1 = S1.relay.image_models.m1; const ref = m1.ref || `${m1.channel}::${m1.model}`;
  const g2 = await admin('/library/generate', { theme: '香水 极简', count: 1, ratio: '1:1', model_key: 'ref:' + ref });
  jobs = await waitJobs();
  assert.equal(jobs.find((x) => x.id === g2.job_id).done, 1, '直接指定模型库模型也能出图');
  let L = await admin('/library/list', { job_id: g.job_id });
  assert.equal(L.list.length, 2);
  assert.ok(L.list.every((x) => x.status === 'draft' && x.prompt && x.title && x.image), '生成的进待审核，带标题和提示词');
  const pub0 = (await (await fetch(API + '/gallery/lists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).data.total;
  await admin('/library/batch', { ids: L.list.map((x) => x.id), action: 'online' });
  const pub1 = (await (await fetch(API + '/gallery/lists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).json()).data;
  assert.equal(pub1.total, pub0 + 2, '上架后前台可见');
  assert.ok(pub1.items[0].prompt, '前台素材带提示词');
  // 上传识图（自动归类、直接上架）+ 生成同类
  const up = await admin('/library/upload', { images: [pub1.items[0].image], auto_cat: 1, publish: 1, similar: 2 });
  jobs = await waitJobs();
  const uj = jobs.find((x) => x.id === up.job_id);
  assert.equal(uj.done, 2, '进度只算新生成的同类图');
  assert.equal(uj.total, 2);
  L = await admin('/library/list', { job_id: up.job_id });
  assert.equal(L.list.length, 2, '原图不进待审核 / 上架');
  assert.equal(L.list.filter((x) => x.source === 'similar' && x.status === 'draft').length, 2, '同类图进待审核');
  const refs = await admin('/library/list', { job_id: up.job_id, status: 'ref' });
  assert.equal(refs.list.length, 1, '原图存为参考素材');
  // 只上传识图（不生成同类）：直接上架
  const up2 = await admin('/library/upload', { images: [pub1.items[1].image], auto_cat: 1, publish: 1, similar: 0 });
  jobs = await waitJobs();
  assert.equal(jobs.find((x) => x.id === up2.job_id).done, 1);
  assert.equal((await admin('/library/list', { job_id: up2.job_id })).list.filter((x) => x.status === 'online').length, 1, '上传识图直接上架');
  assert.ok(L.list.every((x) => x.category), '自动归类');
  // 编辑 / 移动 / 下架 / 删除 / 分类
  const c = await admin('/library/cat/save', { name: '测试分类' + Date.now() });
  await admin('/library/batch', { ids: [L.list[0].id], action: 'move', cat_id: c.id });
  await admin('/library/save', { id: L.list[0].id, title: '改过的标题', prompt: '改过的提示词', status: 'offline' });
  const one = (await admin('/library/list', { job_id: up.job_id })).list.find((x) => x.id === L.list[0].id);
  assert.equal(one.title, '改过的标题'); assert.equal(one.status, 'offline'); assert.equal(one.cat_id, c.id);
  await admin('/library/cat/del', { id: c.id });
  await admin('/library/batch', { ids: L.list.map((x) => x.id), action: 'delete' });
  assert.equal((await admin('/library/list', { job_id: up.job_id })).list.length, 0);
});

test('前台可选多个生图模型：后台加一个「模型3」并定价 → 前台列表出现 → 用它出图按它的价格扣点', async () => {
  const { api, newUser, upload, waitTask, score } = require('../lib/client');
  const { settings } = await admin('/settings', {});
  const relay = settings.relay; const pricing = settings.pricing;
  const m1 = relay.image_models.m1;
  await admin('/settings/save', { group: 'relay', value: { ...relay, image_models: { ...relay.image_models, m3: { ...m1, label: '测试模型3', desc: '真4K', enabled: true } } } });
  await admin('/settings/save', { group: 'pricing', value: { ...pricing, image: { ...(pricing.image || {}), m3: { '1K': 7, '2K': 8, '4K': 9 } } } });
  try {
    const u = await newUser({ member: 'basic', points: 100 });
    const list = await api('/site/models', {}, u.token);
    const m3 = list.image.find((x) => x.key === 'm3');
    assert.ok(m3 && m3.label === '测试模型3' && m3.desc === '真4K', '前台列表里有新模型');
    assert.equal(m3.prices['1K'], 7);
    const before = await score(u.token);
    const d = await api('/ai/image', { prompt: '一只猫', count: 1, aspectRatio: '1:1', resolution: '1K', model_key: 'm3', images: [] }, u.token);
    await waitTask('/ai/status', d.task.id, u.token);
    assert.equal(before - await score(u.token), 7, '按模型3的价格扣点');
    // 关掉后前台不显示
    await admin('/settings/save', { group: 'relay', value: { ...relay, image_models: { ...relay.image_models, m3: { ...m1, label: '测试模型3', enabled: false } } } });
    assert.ok(!(await api('/site/models', {}, u.token)).image.some((x) => x.key === 'm3'));
    void upload;
  } finally {
    await admin('/settings/save', { group: 'relay', value: relay });
    await admin('/settings/save', { group: 'pricing', value: pricing });
  }
});

test('存储：COS 没填完时「测试 COS」提示缺哪些；站点配置带图片域名', async () => {
  const { settings } = await admin('/settings', {});
  const st = settings.storage;
  await assert.rejects(admin('/storage/test', {}), /请先填写并保存：.*SecretId/);
  await admin('/settings/save', { group: 'storage', value: { ...st, cos: { ...st.cos, domain: 'https://img.example.com/' } } });
  try {
    const { api } = require('../lib/client');
    const cfg = await api('/site/config', {});
    assert.deepEqual(cfg.img_hosts, ['https://img.example.com']);
  } finally { await admin('/settings/save', { group: 'storage', value: st }); }
});

test('短信：没选服务商时「发送测试短信」给出提示；手机号格式校验', async () => {
  const { admin: a } = require('../lib/client');
  await assert.rejects(a('/sms/test', { mobile: '123' }), /正确的手机号/);
  const { settings } = await a('/settings', {});
  if (settings.sms.provider === 'none') await assert.rejects(a('/sms/test', { mobile: '13800000000' }), /先选择短信服务商/);
});

test('素材库「帮我想主题」：AI 推荐主题（带分类）', async () => {
  const r = await admin('/library/themes', { hint: '' });
  assert.ok(r.items.length >= 1 && r.items.every((x) => x.theme));
  assert.equal(r.ai, true);
});

test('图库搜图：没填 Key 时提示；选中的图识图后存为参考素材（前台不显示）→ 生成同类 / AI 改图 → 新图进待审核', async () => {
  const { API: API2, BASE, upload, newUser } = require('../lib/client');
  const waitJobs = async () => { for (let i = 0; i < 80; i++) { const j = await admin('/library/jobs', {}); if (!j.list.some((x) => x.status === 'running')) return j.list; await new Promise((r) => setTimeout(r, 300)); } throw new Error('素材任务超时'); };
  assert.equal((await admin('/library/stock/search', { source: 'unsplash', q: 'lipstick' })).need_key, true);
  const { settings } = await admin('/settings', {});
  await admin('/settings/save', { group: 'stock', value: { ...(settings.stock || {}), pexels_key: 'test-key' } });
  // 后台读出来的 Key 是脱敏的；原样保存回去不会把真 Key 冲掉
  const masked = ((await admin('/settings', {})).settings.stock || {}).pexels_key;
  assert.equal(masked, '********-key');
  await admin('/settings/save', { group: 'stock', value: { ...(settings.stock || {}), pexels_key: masked } });
  assert.equal(require('../../src/core/settings').unmaskSecrets({ pexels_key: masked }, { pexels_key: 'test-key' }).pexels_key, 'test-key');
  assert.equal(require('../../src/core/settings').unmaskSecrets({ base_url: 'https://evil.example', api_key: '********-key' }, { base_url: 'https://relay.example', api_key: 'sk-test-key' }).api_key, '', '换了地址不能沿用旧 Key');
  await admin('/settings/save', { group: 'stock', value: settings.stock || { unsplash_key: '', pexels_key: '' } });
  // 用一张本站图模拟图库图片
  const u = await newUser({});
  const up = await upload(u.token);
  const full = new URL(up.fullurl || up.url, BASE).href;
  const r = await admin('/library/stock/import', { items: [{ source: 'pexels', id: 'p1', full, thumb: full, width: 800, height: 1000, author: '某摄影师' }], similar: 1 });
  let jobs = await waitJobs();
  assert.equal(jobs.find((x) => x.id === r.job_id).done, 2, '1 张参考 + 1 张同类');
  const ref = await admin('/library/list', { status: 'ref' });
  const it = ref.list.find((x) => x.image === full);
  assert.ok(it && it.prompt && it.source === 'pexels');
  const all = await admin('/library/list', { status: '' });
  assert.ok(all.list.every((x) => x.status !== 'ref'), '「全部」不含参考素材');
  const pub = (await (await fetch(API2 + '/gallery/lists', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"limit":60}' })).json()).data;
  assert.ok(!pub.items.some((x) => x.image === full), '前台不显示参考素材');
  const e = await admin('/library/remix', { ids: [it.id], mode: 'edit', per: 1, instruction: '换成暖色调' });
  jobs = await waitJobs();
  assert.equal(jobs.find((x) => x.id === e.job_id).done, 1);
  assert.match((await admin('/library/list', { job_id: e.job_id })).list[0].prompt, /暖色调/);
});

test('后台电商提示词包：列表、选中出图进待审核、标记已导入；前台拼音首字母搜索、风格标签筛选', async () => {
  const { api } = require('../lib/client');
  const { list } = await admin('/library/pack', {});
  assert.ok(list.length >= 30, '至少 30 条');
  assert.ok(list.every((x) => x.id && x.title && x.prompt && x.category && x.ratio && Array.isArray(x.tags)));
  assert.ok(list.every((x) => !/(Adidas|Coca|Nike|Chanel|可口可乐|耐克|香奈儿)/i.test(x.prompt)), '不出现真实品牌');
  const pick = list.find((x) => x.id === 'e23');
  const r = await admin('/library/pack/run', { ids: ['e23', 'e06'], per: 1, resolution: '1K' });
  for (let i = 0; i < 60; i++) { const j = (await admin('/library/jobs', {})).list.find((x) => x.id === r.job_id); if (j && j.status !== 'running') { assert.equal(j.done, 2); break; } await new Promise((res) => setTimeout(res, 300)); }
  const L = await admin('/library/list', { job_id: r.job_id });
  assert.equal(L.list.length, 2);
  assert.ok(L.list.every((x) => x.status === 'draft'), '进待审核');
  const one = L.list.find((x) => x.title === pick.title);
  assert.equal(one.prompt, pick.prompt);
  assert.equal(one.category, pick.category);
  assert.equal((await admin('/library/pack', {})).list.find((x) => x.id === 'e23').imported, 1, '标记已导入');
  await assert.rejects(admin('/library/pack/run', { ids: [] }));
  await admin('/library/batch', { ids: L.list.map((x) => x.id), action: 'online' });
  const s = await api('/gallery/lists', { q: 'xhs' });
  assert.ok(s.items.some((x) => x.title === pick.title), '拼音首字母 xhs 搜到「小红书种草封面」');
  const tags = (await api('/gallery/tags', {})).tags;
  assert.ok(Array.isArray(tags));
  const t = await api('/gallery/lists', { tag: '小红书' });
  assert.ok(t.items.length >= 1 && t.items.every((x) => x.tags.includes('小红书')), '按标签筛选');
});

test('后台素材顺序：已上架按前台顺序显示；置顶 / 上移 / 下移 / 移到第 N 位 / 批量置底，前台首页顺序跟着变；新上架排最前', async () => {
  const { api } = require('../lib/client');
  const waitJob = async (id) => { for (let i = 0; i < 60; i++) { const j = (await admin('/library/jobs', {})).list.find((x) => x.id === id); if (j && j.status !== 'running') return; await new Promise((r) => setTimeout(r, 300)); } };
  const g = await admin('/library/generate', { theme: '排序测试', count: 4, ratio: '1:1' });
  await waitJob(g.job_id);
  const mine = (await admin('/library/list', { job_id: g.job_id })).list.map((x) => x.id);
  await admin('/library/batch', { ids: mine, action: 'online' });
  const front = async () => (await api('/gallery/lists', { page: 1, limit: 60 })).items.map((x) => x.id);
  let f = await front();
  assert.deepEqual(f.slice(0, 4).sort(), mine.slice().sort(), '新上架的排在最前');
  const L = await admin('/library/list', { status: 'online', limit: 200 });
  assert.ok(L.front);
  assert.deepEqual(L.list.map((x) => x.id), f.slice(0, L.list.length), '后台已上架的顺序 = 前台顺序');
  assert.equal(L.list[0].pos, 1);
  const last = f[f.length - 1];
  let r = await admin('/library/order', { ids: [last], action: 'top' });
  assert.equal(r.order[last], 1);
  f = await front(); assert.equal(f[0], last, '置顶后前台第一个');
  await admin('/library/order', { ids: [last], action: 'down' });
  f = await front(); assert.equal(f[1], last, '下移一位');
  await admin('/library/order', { ids: [last], action: 'up' });
  f = await front(); assert.equal(f[0], last, '上移一位');
  r = await admin('/library/order', { ids: [last], action: 'to', pos: 3 });
  f = await front(); assert.equal(f[2], last, '移到第 3 位'); assert.equal(r.order[last], 3);
  await admin('/library/order', { ids: [f[0], f[1]], action: 'bottom' });
  const f2 = await front(); assert.deepEqual(f2.slice(-2), [f[0], f[1]], '批量置底，保持先后');
  const off = (await admin('/library/list', { status: 'draft', limit: 1 })).list[0];
  if (off) await assert.rejects(admin('/library/order', { ids: [off.id], action: 'top' }), '未上架的不能排序');
});
