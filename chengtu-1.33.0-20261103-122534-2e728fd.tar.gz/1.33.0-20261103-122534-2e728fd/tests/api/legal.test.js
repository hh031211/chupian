'use strict';
// 关于我们 / 用户协议 / 隐私政策：默认模板按站点信息填好；后台填了就用后台的
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin } = require('../lib/client');

before(guard);

test('协议页面：默认模板、后台自定义、旧品牌名自动替换', async () => {
  for (const key of ['about', 'terms', 'privacy']) {
    const d = await api('/site/legal', { key });
    assert.ok(d.title && d.content.length > 100, key);
    assert.doesNotMatch(d.content, /\{(name|company|email|phone|contact)\}|橙图|\u0000/);
  }
  assert.match((await api('/site/legal', { key: 'terms' })).title, /用户协议/);
  await apiFail('/site/legal', { key: 'nope' });
  await admin('/settings/save', { group: 'legal', value: { about: '## 我们\n{name}很棒，原名橙图\n- 第一条', terms: '', privacy: '' } });
  const a = await api('/site/legal', { key: 'about' });
  assert.match(a.content, /^## 我们\n出片儿很棒，原名出片儿\n- 第一条$/);
  await admin('/settings/save', { group: 'legal', value: { about: '', terms: '', privacy: '' } });
});
