'use strict';
// 账号：注册、登录、短信验证码登录、资料、改密码、退出、未登录拦截、站点信息
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, uid, cap, BASE } = require('../lib/client');

before(guard);

test('健康检查返回沙箱标识和版本', async () => {
  const j = await (await fetch(BASE + '/health')).json();
  assert.equal(j.code, 1);
  assert.equal(j.data.sandbox, process.env.CT_TEST_SANDBOX);
  assert.ok(j.data.version);
});

test('站点信息（新前端读取）', async () => {
  const d = await api('/site/config');
  assert.equal(typeof d.name, 'string');
  assert.equal(typeof d.service_hours, 'string');
  assert.equal(d.username_register, true);
});

test('账号注册 → 登录 → 资料 → 改密码 → 退出', async () => {
  const u = await newUser();
  assert.ok(u.token.length > 30, '应返回登录凭证');
  assert.ok(u.info.score >= 0);
  await apiFail('/user/register', { username: u.username, password: 'pass1234', ...(await cap()) }); // 重名
  await apiFail('/user/login', { account: u.username, password: 'wrong' });
  const login = await api('/user/login', { account: u.username, password: 'pass1234' });
  const token = login.userinfo.token;
  assert.equal((await api('/user/info', {}, token)).userinfo.username, u.username);
  await api('/user/profile', { nickname: '测试员' }, token);
  await apiFail('/user/profile', { username: 'changed' + Date.now() }, token); // 登录账号注册后不能改
  assert.equal((await api('/user/info', {}, token)).userinfo.nickname, '测试员');
  await api('/user/changepwd', { old_password: 'pass1234', new_password: 'pass5678' }, token);
  await apiFail('/user/login', { account: u.username, password: 'pass1234' });
  const t2 = (await api('/user/login', { account: u.username, password: 'pass5678' })).userinfo.token;
  await api('/user/logout', {}, t2);
  await apiFail('/user/info', {}, t2, 401);
});

test('未登录访问需要登录的接口返回 401', async () => {
  for (const p of ['/user/info', '/member/orders', '/upload/image', '/all.records/lists']) await apiFail(p, {}, '', 401);
});

test('手机验证码登录：未注册自动注册，验证码错误被拒绝', async () => {
  const mobile = '139' + String(Date.now()).slice(-8);
  const sent = await api('/sms/send', { mobile, event: 'mobilelogin' });
  assert.match(String(sent.debug_code), /^\d{6}$/, '沙箱打开了短信调试模式，应返回验证码');
  await apiFail('/sms/send', { mobile, event: 'mobilelogin' }); // 60 秒内重复发送
  await apiFail('/user/mobilelogin', { mobile, captcha: '000000' === sent.debug_code ? '111111' : '000000' });
  const r = await api('/user/mobilelogin', { mobile, captcha: sent.debug_code });
  assert.equal(r.is_new, 1);
  assert.equal(r.userinfo.mobile, mobile);
  await apiFail('/sms/send', { mobile: '12345' });
});

test('短信调试模式默认关闭（正式环境不会把验证码返回给浏览器）', async () => {
  const s = await admin('/settings', {});
  const defaults = s.defaults || s.DEFAULTS || null;
  if (defaults && defaults.sms) assert.equal(defaults.sms.debug, false);
  // 关掉调试模式后，未配置短信服务时发送验证码应直接失败，不返回验证码
  await admin('/settings/save', { group: 'sms', value: { provider: 'none', debug: false } });
  try {
    const r = await apiFail('/sms/send', { mobile: '138' + String(Date.now()).slice(-8), event: 'mobilelogin' });
    assert.ok(!r.data || !r.data.debug_code);
  } finally {
    await admin('/settings/save', { group: 'sms', value: { provider: 'none', debug: true } });
  }
});

test('图形验证码开启后，账号登录必须带验证码', async () => {
  const u = await newUser();
  await admin('/settings/save', { group: 'register', value: { login_captcha: true } });
  try {
    const r = await apiFail('/user/login', { account: u.username, password: 'pass1234' });
    assert.match(r.msg, /图形验证码/);
    const cap = await api('/captcha/create');
    assert.ok(cap.key && /^data:image\/png;base64,/.test(cap.image));
    assert.equal((await api('/site/config')).login_captcha, true);
  } finally {
    await admin('/settings/save', { group: 'register', value: { login_captcha: false } });
  }
});

test('邀请码注册绑定上级', async () => {
  const parent = await newUser();
  const me = await api('/user/info', {}, parent.token);
  const child = await api('/user/register', { username: 'c' + uid(), password: 'pass1234', invite_code: me.userinfo.invite_code, ...(await cap()) });
  assert.equal(Number(child.userinfo.parent_user_id), Number(parent.id));
});

test('注销账号后无法再登录', async () => {
  const u = await newUser();
  await api('/user/delete', { confirm: '注销', reason: 'test' }, u.token);
  await apiFail('/user/login', { account: u.username, password: 'pass1234' });
});

test('同一网络每日注册上限生效（正式环境默认 20 个）', async () => {
  const before = await admin('/settings', {});
  await newUser(); // 保证今天这个网络至少注册过 1 个
  await admin('/settings/save', { group: 'security', value: { ...before.settings.security, ip_register_limit_per_day: 1 } });
  try {
    const r = await apiFail('/user/register', { username: 'lim' + uid(), password: 'pass1234', ...(await cap()) });
    assert.match(r.msg, /注册次数过多/);
    // 手机号验证码登录自动注册同样受限
    const mobile = '136' + String(Date.now()).slice(-8);
    const sent = await api('/sms/send', { mobile, event: 'mobilelogin' });
    assert.match((await apiFail('/user/mobilelogin', { mobile, captcha: sent.debug_code })).msg, /注册次数过多/);
  } finally {
    await admin('/settings/save', { group: 'security', value: { ...before.settings.security, ip_register_limit_per_day: 0 } });
  }
  assert.equal(before.defaults.security.ip_register_limit_per_day, 20);
});

test('注册：用户名只能用英文字母、数字、下划线；中文和其它符号给出明确提示', async () => {
  const e1 = await apiFail('/user/register', { username: 'gonghe_123哈哈', password: 'pass1234', ...(await cap()) });
  assert.match(e1.msg, /不能用中文/);
  const e2 = await apiFail('/user/register', { username: 'gonghe_123..', password: 'pass1234', ...(await cap()) });
  assert.match(e2.msg, /不能包含「\.」/);
});

test('注册：必须填对图形验证码，验证码只能用一次', async () => {
  const e1 = await apiFail('/user/register', { username: 'cap' + uid(), password: 'pass1234' });
  assert.match(e1.msg, /请输入图形验证码/);
  const c = await cap();
  const e2 = await apiFail('/user/register', { username: 'cap' + uid(), password: 'pass1234', captcha_key: c.captcha_key, captcha: 'ZZZZ' });
  assert.match(e2.msg, /图形验证码不正确/);
  const c2 = await cap();
  const ok = await api('/user/register', { username: 'cap' + uid(), password: 'pass1234', ...c2 });
  assert.ok(ok.userinfo.id);
  await apiFail('/user/register', { username: 'cap' + uid(), password: 'pass1234', ...c2 }); // 同一个验证码不能再用
});

test('防机器批量注册：图形验证码是位图（不含可读文字）、只能试一次；账号注册不送点，绑定手机后才送（同一手机号只送一次），邀请奖励也要验证手机', async () => {
  const { api, cap, uid } = require('../lib/client');
  const c = await api('/captcha/create');
  assert.match(c.image, /^data:image\/png;base64,/);
  assert.ok(!Buffer.from(c.image.split(',')[1], 'base64').toString('latin1').includes(c.debug_code), '图里不含答案文字');
  // 错一次就作废
  const bad = await (await fetch(require('../lib/client').API + '/user/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'cap' + uid(), password: 'abc12345', captcha_key: c.key, captcha: 'ZZZZ' }) })).json();
  assert.equal(bad.code, 0);
  const again = await (await fetch(require('../lib/client').API + '/user/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'cap' + uid(), password: 'abc12345', captcha_key: c.key, captcha: c.debug_code }) })).json();
  assert.equal(again.code, 0, '同一张图不能再试');
  // 邀请人
  const inviter = await api('/user/register', { username: 'inv' + uid(), password: 'abc12345', ...(await cap()) });
  const invCode = inviter.userinfo.invite_code;
  const score0 = (await api('/user/info', {}, inviter.token)).userinfo.score;
  const r = await api('/user/register', { username: 'gift' + uid(), password: 'abc12345', invite_code: invCode, ...(await cap()) });
  assert.equal(r.userinfo.score, 0, '账号注册先不送点');
  assert.equal((await api('/user/info', {}, inviter.token)).userinfo.score, score0, '被邀请人没验证手机前，不给邀请奖励');
  const mobile = '139' + String(Date.now()).slice(-8);
  const sent = await api('/user/sendmobilecode', { mobile, event: 'bind' }, r.token);
  const b = await api('/user/bindmobile', { mobile, captcha: sent.debug_code, event: 'bind' }, r.token);
  assert.ok(b.userinfo.score > 0, '绑定手机后补发新人赠送');
  assert.ok((await api('/user/info', {}, inviter.token)).userinfo.score > score0, '绑定手机后邀请人拿到奖励');
});

test('阿里云验证码（沙箱模拟）：开启后注册 / 发短信必须带验证结果，验证不通过被拒绝；前台拿到公开配置（不含密钥）', async () => {
  const { api, apiFail, admin, uid } = require('../lib/client');
  const { settings } = await admin('/settings', {});
  const old = settings.security;
  try {
    await admin('/settings/save', { group: 'security', value: { ...old, human: { provider: 'aliyun', aliyun: { prefix: 'px1', scene_id: 'sc1', region: 'cn', access_key_id: 'AK', access_key_secret: 'SK-secret' } } } });
    const cfg = await api('/site/config', {});
    assert.deepEqual(cfg.human, { provider: 'aliyun', prefix: 'px1', scene_id: 'sc1', region: 'cn' });
    assert.ok(!JSON.stringify(cfg).includes('SK-secret'));
    const r = await fetch(require('../lib/client').BASE + '/');
    if (/html/.test(r.headers.get('content-type') || '')) assert.match(r.headers.get('content-security-policy') || '', /o\.alicdn\.com/);
    assert.match((await apiFail('/user/register', { username: 'hv' + uid(), password: 'abc12345' })).msg, /安全验证/);
    assert.match((await apiFail('/user/register', { username: 'hv' + uid(), password: 'abc12345', captcha_verify_param: 'bad' })).msg, /未通过/);
    const ok = await api('/user/register', { username: 'hv' + uid(), password: 'abc12345', captcha_verify_param: 'mock-pass' });
    assert.ok(ok.token);
    const mobile = '137' + String(Date.now()).slice(-8);
    assert.match((await apiFail('/sms/send', { mobile, event: 'mobilelogin' })).msg, /安全验证/);
    const sent = await api('/sms/send', { mobile, event: 'mobilelogin', captcha_verify_param: 'mock-pass' });
    assert.ok(sent.debug_code);
  } finally {
    await admin('/settings/save', { group: 'security', value: old });
  }
  assert.equal((await api('/site/config', {})).human.provider, 'builtin');
});
