'use strict';
// 精准改字：识别 → 本机擦除 / AI 擦除（扣点、只贴回文字区域）→ 翻译
const { test, before } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, newUser, upload, score, BASE } = require('../lib/client');

before(guard);
const on = !!process.env.CT_TEST_TEXTEDIT;

test('精准改字：识别文字 → 本机擦除 → AI 擦除（扣点）→ 翻译', { skip: on ? false : '本机没有 python3 + opencv，跳过' }, async () => {
  const u = await newUser({ member: 'basic', points: 100 });
  const st = await api('/text/status', {}, u.token);
  assert.equal(st.enabled, true); assert.equal(st.ocr, true);
  const up = await upload(u.token);
  const image = up.fullurl || up.url;
  const d = await api('/text/detect', { image }, u.token);
  assert.equal(d.items.length, 2);
  assert.equal(d.items[0].text, '夏季新品');
  assert.ok(d.items[0].w > 0 && d.items[0].h > 0 && /^#[0-9a-f]{6}$/.test(d.items[0].color));
  const e1 = await api('/text/erase', { image, boxes: [d.items[0]] }, u.token);
  assert.ok(/\.png$/.test(e1.url)); assert.ok(['lama', 'opencv'].includes(e1.engine));
  const r = await fetch(new URL(e1.url, BASE)); assert.equal(r.status, 200);
  const before = await score(u.token);
  const e2 = await api('/text/erase', { image, boxes: [d.items[0]], engine: 'ai' }, u.token);
  assert.equal(e2.engine, 'ai'); assert.ok(e2.charged_points > 0);
  assert.equal(before - await score(u.token), e2.charged_points, 'AI 擦除按出图价扣点');
  const tr = await api('/text/translate', { texts: d.items.map((x) => x.text), lang: '英语' }, u.token);
  assert.equal(tr.texts.length, 2);
  await apiFail('/text/erase', { image, boxes: [] }, u.token);
  // 旁边不改的文字（keep）擦除时绕开
  const e3 = await api('/text/erase', { image, boxes: [d.items[0]], keep: [d.items[1]] }, u.token);
  assert.ok(/\.png$/.test(e3.url));
});

// 8×8 的黑底蒙版，中间 4×4 涂白（画布「AI 智能消除」本地擦除用）
function maskPng() {
  const zlib = require('zlib');
  const raw = Buffer.alloc(8 * 9);
  for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) raw[y * 9 + 1 + x] = x >= 2 && x < 6 && y >= 2 && y < 6 ? 255 : 0;
  const crcT = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
  const crc = (b) => { let c = 0xffffffff; for (const v of b) c = crcT[(c ^ v) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(8, 0); ihdr.writeUInt32BE(8, 4); ihdr[8] = 8; ihdr[9] = 0;
  return 'data:image/png;base64,' + Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]).toString('base64');
}

test('画布智能消除（本地）：按涂抹蒙版擦除，免费', { skip: on ? false : '本机没有 python3 + opencv，跳过' }, async () => {
  const u = await newUser({ points: 0 });
  const up = await upload(u.token);
  const image = up.fullurl || up.url;
  const r = await api('/text/inpaint', { image, mask: maskPng() }, u.token);
  assert.ok(/\.png$/.test(r.url)); assert.ok(['lama', 'opencv'].includes(r.engine));
  await apiFail('/text/inpaint', { image, mask: '' }, u.token);
});
