'use strict';
// 抠图：佐糖接口（模拟）、每人每天免费张数、超出扣点 / 拒绝、非会员可用、Key 无效时报错并退点
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { guard, api, apiFail, admin, newUser, score, upload, waitTask } = require('../lib/client');

let saved; let relayUrl;
const setM = async (v) => admin('/settings/save', { group: 'matting', value: { ...saved, picwish_base: relayUrl, fallback_local: false, ...v } });
before(async () => {
  await guard();
  const st = (await admin('/settings', {})).settings;
  saved = st.matting;
  relayUrl = st.relay.channels[0].base_url.replace(/\/v1\/?$/, '');
});
after(async () => { if (saved) await admin('/settings/save', { group: 'matting', value: saved }); });

test('佐糖抠图：每天免费 2 张，第 3 张按超出价扣点；非会员也能用', async () => {
  await setM({ engine: 'picwish', picwish_key: 'k-test', free_daily: 2, over_action: 'charge', over_price: 3 });
  const u = await newUser({ points: 50 });   // 非会员
  const one = (await upload(u.token)).fullurl;
  const imgs = [one + '?n=1', one + '?n=2', one + '?n=3'];   // 同一张图上传会去重，用不同地址模拟 3 张
  const q0 = await api('/site/matting', {}, u.token);
  assert.equal(q0.remaining, 2);
  const s0 = await score(u.token);
  const d = await api('/toolbox.cutout/generate', { images: imgs }, u.token);
  assert.equal(Number(d.task.charged_points), 3, '前 2 张免费，第 3 张扣 3 点');
  const r = await waitTask('/toolbox.cutout/status', d.task.id, u.token);
  assert.equal(r.task.status, 'succeeded');
  assert.equal(s0 - await score(u.token), 3);
  const q1 = await api('/site/matting', {}, u.token);
  assert.equal(q1.remaining, 0);
  assert.equal((await api('/site/matting', {})).logged_in, false, '未登录也能查询');
});

test('免费张数用完后设为「当天不能再抠」：拒绝且不扣点', async () => {
  await setM({ engine: 'picwish', picwish_key: 'k-test', free_daily: 1, over_action: 'block' });
  const u = await newUser({ points: 50 });
  const img = (await upload(u.token)).fullurl;
  const d = await api('/toolbox.cutout/generate', { images: [img] }, u.token);
  await waitTask('/toolbox.cutout/status', d.task.id, u.token);
  const s0 = await score(u.token);
  const e = await apiFail('/toolbox.cutout/generate', { images: [img] }, u.token);
  assert.match(e.msg, /免费抠图已用完/);
  assert.equal(await score(u.token), s0);
});

test('佐糖 Key 无效：任务失败、点数退回、失败的不占免费张数', async () => {
  await setM({ engine: 'picwish', picwish_key: 'bad', free_daily: 1, over_action: 'charge', over_price: 2 });
  const u = await newUser({ points: 50 });
  const img = (await upload(u.token)).fullurl;
  const s0 = await score(u.token);
  const img2 = img + '?n=2';
  const d = await api('/toolbox.cutout/generate', { images: [img, img2] }, u.token);
  const r = await waitTask('/toolbox.cutout/status', d.task.id, u.token);
  assert.equal(r.task.status, 'failed');
  assert.equal(await score(u.token), s0, '失败应退回点数');
  assert.equal((await api('/site/matting', {}, u.token)).remaining, 1, '失败的不算用掉免费张数');
});

test('证件照也走抠图引擎，占用同一份免费张数', async () => {
  await setM({ engine: 'picwish', picwish_key: 'k-test', free_daily: 5, over_action: 'charge', over_price: 3 });
  const u = await newUser({ points: 50 });
  const img = (await upload(u.token)).fullurl;
  const d = await api('/toolbox.idphoto/generate', { images: [img], bg_color: '#438edb', size_px: '295x413' }, u.token);
  assert.equal(Number(d.task.charged_points), 0);
  const r = await waitTask('/toolbox.idphoto/status', d.task.id, u.token);
  assert.equal(r.task.status, 'succeeded');
  assert.equal((await api('/site/matting', {}, u.token)).remaining, 4);
});

test('证件照可单独设超出价；抠图类只按抠图设置扣点，不叠加', async () => {
  await setM({ engine: 'picwish', picwish_key: 'k-test', free_daily: 0, over_action: 'charge', over_price: 3, over_price_idphoto: 1 });
  const u = await newUser({ points: 50 });
  const img = (await upload(u.token)).fullurl;
  const w = await api('/toolbox.idphoto/generate', { images: [img], bg_color: '#ffffff' }, u.token);
  assert.equal(Number(w.task.charged_points), 1, '证件照按单独价 1 点');
  const c = await api('/toolbox.cutout/generate', { images: [img], output: 'png' }, u.token);
  assert.equal(Number(c.task.charged_points), 3, '抠图按通用价 3 点');
  const q = await api('/site/matting', {}, u.token);
  assert.equal(q.over_prices['id-photo'], 1);
  await waitTask('/toolbox.idphoto/status', w.task.id, u.token);
  await waitTask('/toolbox.cutout/status', c.task.id, u.token);
});

test('后台效果测试：后台运行、轮询拿结果（佐糖出图）', async () => {
  await setM({ engine: 'picwish', picwish_key: 'k-test' });
  const u = await newUser();
  const img = (await upload(u.token)).fullurl;
  const { id } = await admin('/matting/test', { image: img, picwish: 1 });
  let d = { done: false };
  for (let i = 0; i < 30 && !d.done; i++) { await new Promise((r) => setTimeout(r, 500)); d = await admin('/matting/test/result', { id }); }
  assert.equal(d.done, true);
  assert.ok(d.picwish && d.picwish.url, '佐糖应出图：' + JSON.stringify(d.picwish));

});

test('工具封面：上传替换、前台读取、恢复原图；AI 生成走中转站', async () => {
  const { BASE } = require('../lib/client');
  const fs = require('node:fs');
  const { FIXTURE } = require('../lib/client');
  const login = await (await fetch(BASE + '/admin/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: process.env.CT_TEST_ADMIN_USER, password: process.env.CT_TEST_ADMIN_PASS }) })).json();
  const fd = new FormData();
  fd.append('file', new Blob([fs.readFileSync(FIXTURE)], { type: 'image/png' }), 'c.png');
  fd.append('slug', 'changebg');
  const up = await (await fetch(BASE + '/admin/api/tools/cover/upload', { method: 'POST', headers: { 'admin-token': login.data.token }, body: fd })).json();
  assert.equal(up.code, 1, up.msg);
  assert.equal((await api('/site/tool_covers', {})).covers['changebg'], up.data.url);
  await admin('/tools/cover/generate', { slug: 'productset', name: '商品套图', desc: '测试' });
  let st;
  for (let i = 0; i < 40; i++) { st = await admin('/tools/covers', {}); if (st.covers['productset'] || (st.jobs['productset'] || {}).state === 'error') break; await new Promise((r) => setTimeout(r, 300)); }
  assert.ok(st.covers['productset'], 'AI 封面应生成：' + JSON.stringify(st.jobs));
  await admin('/tools/cover/reset', { slug: 'changebg' });
  await admin('/tools/cover/reset', { slug: 'productset' });
  assert.deepEqual((await api('/site/tool_covers', {})).covers, {});
});
