'use strict';
// 发布与回滚演练：在临时目录（CT_HOME）里真实执行 打包 → 安装 → 校验 → 切换 → 回滚 → 恢复数据库 → 坏版本自动回退。
// 服务用 pidfile 模式（工具自己拉起进程），不依赖 pm2，也不碰正式环境。
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { freePort } = require('../lib/sandbox');

const ROOT = path.resolve(__dirname, '..', '..');
const TOOL = path.join(ROOT, 'tools', 'release.js');
let HOME; let PKGS; let port; let base;

function rel(...a) {
  const r = spawnSync(process.execPath, [TOOL, ...a], { env: { ...process.env, CT_HOME: HOME, CT_CAPTCHA_DEBUG: '1' }, encoding: 'utf8', timeout: 180000 });
  return { code: r.status, out: (r.stdout || '') + (r.stderr || '') };
}
const current = () => path.basename(fs.realpathSync(path.join(HOME, 'current')));
// 服务每次切换都会重启；不复用旧连接，连接被关闭时重试
async function req(url, init = {}) {
  for (let i = 0; ; i++) {
    try { return await (await fetch(url, { ...init, headers: { ...(init.headers || {}), Connection: 'close' } })).json(); } catch (e) { if (i >= 4) throw e; await new Promise((r) => setTimeout(r, 500)); }
  }
}
const health = async () => (await req(base + '/health')).data;
const cap = async () => { const c = (await req(base + '/ydapi/captcha/create', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).data; return { captcha_key: c.key, captcha: c.debug_code }; };
const post = (p, b) => req(base + '/ydapi' + p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) });

function pack() {
  const r = rel('pack', '--out', PKGS);
  assert.equal(r.code, 0, r.out);
  return /发布包：(\S+\.tar\.gz)/.exec(r.out)[1];
}

before(async () => {
  HOME = fs.mkdtempSync(path.join(os.tmpdir(), 'chengtu-home-'));
  PKGS = path.join(HOME, 'pkgs');
  port = await freePort();
  base = `http://127.0.0.1:${port}`;
  fs.mkdirSync(path.join(HOME, 'shared'), { recursive: true });
  fs.writeFileSync(path.join(HOME, 'shared', 'config.json'), JSON.stringify({ port, host: '127.0.0.1', publicBaseUrl: base, siteUrl: base, dbFile: 'data/yuduo.db', admin: { initUsername: 'admin', initPassword: 'x' + Date.now() }, worker: { enabled: false } }));
  fs.writeFileSync(path.join(HOME, 'shared', 'release.config.json'), JSON.stringify({ service: { type: 'pidfile' }, healthTimeout: 25 }));
});
after(() => {
  try { process.kill(Number(fs.readFileSync(path.join(HOME, 'shared', 'server.pid'), 'utf8')), 'SIGTERM'); } catch { /* 已停止 */ }
  spawnSync('chmod', ['-R', 'u+w', HOME]);
  fs.rmSync(HOME, { recursive: true, force: true });
});

let v1; let v2;

test('打包 → 安装 → 校验 → 上线（第 1 个版本）', async () => {
  const p1 = pack();
  assert.ok(fs.existsSync(p1 + '.sha256'));
  const ins = rel('install', p1);
  assert.equal(ins.code, 0, ins.out);
  v1 = path.basename(p1).replace(/^chengtu-|\.tar\.gz$/g, '');
  // 用版本目录里自带的代码和测试，在独立沙箱里跑一遍接口测试（服务器上 deploy 时同样会做）
  const ver = rel('verify', v1);
  assert.equal(ver.code, 0, ver.out.slice(-2000));
  assert.match(ver.out, /沙箱测试通过/);
  const act = rel('activate', v1);
  assert.equal(act.code, 0, act.out);
  assert.equal(current(), v1);
  const h = await health();
  assert.equal(h.status, 'ok');
  assert.ok(h.web && h.web.build);
  const home = await (await fetch(base + '/', { headers: { Connection: 'close' } })).text();
  assert.match(home, /\/app\/assets\//, '首页应由新前端提供');
  // 数据库、上传目录在 shared/data，不在版本目录里
  assert.ok(fs.existsSync(path.join(HOME, 'shared', 'data', 'yuduo.db')));
  const cfg = JSON.parse(fs.readFileSync(path.join(HOME, 'shared', 'config.json'), 'utf8'));
  assert.equal(cfg.frontendDist, path.join(HOME, 'current', 'web'));
  assert.ok(path.isAbsolute(cfg.dbFile) && path.isAbsolute(cfg.uploadDir));
});

test('版本目录被改动时校验失败', () => {
  const f = path.join(HOME, 'releases', v1, 'src', 'server.js');
  fs.chmodSync(f, 0o644);
  const orig = fs.readFileSync(f);
  fs.appendFileSync(f, '\n// tampered\n');
  const r = rel('verify', v1, '--skip-tests');
  assert.notEqual(r.code, 0);
  assert.match(r.out, /被改动 src\/server\.js/);
  fs.writeFileSync(f, orig);
  // 用版本目录里自带的代码和测试，在独立沙箱里跑一遍接口测试（服务器上 deploy 时同样会做）
  const ver = rel('verify', v1);
  assert.equal(ver.code, 0, ver.out.slice(-2000));
  assert.match(ver.out, /沙箱测试通过/);
});

test('发布第 2 个版本：数据保留；回滚到第 1 个版本', async () => {
  const reg = await post('/user/register', { username: 'keep' + Date.now() % 100000, password: 'pass1234', ...(await cap()) });
  assert.equal(reg.code, 1);
  await new Promise((r) => setTimeout(r, 1100)); // 版本号精确到秒
  const p2 = pack();
  v2 = path.basename(p2).replace(/^chengtu-|\.tar\.gz$/g, '');
  const d = rel('deploy', p2, '--skip-tests');
  assert.equal(d.code, 0, d.out);
  assert.equal(current(), v2);
  assert.equal((await post('/user/login', { account: reg.data.userinfo.username, password: 'pass1234' })).code, 1, '发布新版本不应丢数据');
  const backups = fs.readdirSync(path.join(HOME, 'backups'));
  assert.ok(backups.some((b) => b.includes(`_to_${v2}`)), '切换前应备份数据库');
  const rb = rel('rollback');
  assert.equal(rb.code, 0, rb.out);
  assert.equal(current(), v1);
  assert.equal((await health()).status, 'ok');
  assert.equal((await post('/user/login', { account: reg.data.userinfo.username, password: 'pass1234' })).code, 1);
});

test('回滚并恢复数据库快照', async () => {
  // 切到 v2（会生成一份快照），之后新增的用户在恢复快照后应消失
  assert.equal(rel('activate', v2).code, 0);
  const snap = fs.readdirSync(path.join(HOME, 'backups')).sort().pop();
  const later = await post('/user/register', { username: 'gone' + Date.now() % 100000, password: 'pass1234', ...(await cap()) });
  assert.equal(later.code, 1);
  const r = rel('rollback', v1, '--restore-db', snap);
  assert.equal(r.code, 0, r.out);
  assert.equal(current(), v1);
  assert.notEqual((await post('/user/login', { account: later.data.userinfo.username, password: 'pass1234' })).code, 1, '恢复快照后，快照之后的数据应回到快照时的状态');
});

test('坏版本：健康检查失败时自动切回原版本，退出码非 0', async () => {
  const bad = `${v2}-broken`;
  const src = path.join(HOME, 'releases', v2);
  const dst = path.join(HOME, 'releases', bad);
  fs.cpSync(src, dst, { recursive: true });
  spawnSync('chmod', ['-R', 'u+w', dst]);
  fs.writeFileSync(path.join(dst, 'src', 'server.js'), "console.error('boom'); process.exit(1);\n");
  const info = JSON.parse(fs.readFileSync(path.join(dst, 'release.json'), 'utf8'));
  info.version = bad; info.createdAt = new Date().toISOString();
  fs.writeFileSync(path.join(dst, 'release.json'), JSON.stringify(info));
  const before = current();
  const r = rel('activate', bad);
  assert.notEqual(r.code, 0, '坏版本上线应失败');
  assert.match(r.out, /自动回退/);
  assert.equal(current(), before, '应切回原版本');
  assert.equal((await health()).status, 'ok', '原版本应恢复服务');
});

test('状态与备份列表', () => {
  const s = rel('status');
  assert.equal(s.code, 0);
  assert.ok(s.out.includes(v1) && s.out.includes(v2));
  assert.equal(rel('backups').code, 0);
});
