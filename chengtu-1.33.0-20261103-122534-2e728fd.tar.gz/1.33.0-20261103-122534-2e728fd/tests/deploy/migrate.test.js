'use strict';
// 旧目录结构（/root/yuduo-server + /root/dist-ip）→ 版本化结构 的一次性迁移演练：
// 原目录不被修改；数据、配置、已下载的素材图迁到 shared/；旧版本可作为回滚目标；之后正常发布新版本。
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
const { freePort } = require('../lib/sandbox');

const ROOT = path.resolve(__dirname, '..', '..');
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'chengtu-migrate-'));
const OLD = path.join(TMP, 'root', 'yuduo-server');
const WEB = path.join(TMP, 'root', 'dist-ip');
const HOME = path.join(TMP, 'opt', 'chengtu');
after(() => { try { process.kill(Number(fs.readFileSync(path.join(HOME, 'shared', 'server.pid'), 'utf8'))); } catch { /* */ } spawnSync('chmod', ['-R', 'u+w', TMP]); fs.rmSync(TMP, { recursive: true, force: true }); });

const rel = (...a) => { const r = spawnSync(process.execPath, [path.join(ROOT, 'tools', 'release.js'), ...a], { env: { ...process.env, CT_HOME: HOME }, encoding: 'utf8', timeout: 180000 }); return { code: r.status, out: (r.stdout || '') + (r.stderr || '') }; };
const digest = (dir) => { const h = crypto.createHash('sha256'); const walk = (d) => { for (const f of fs.readdirSync(d).sort()) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else { h.update(p); h.update(fs.readFileSync(p)); } } }; walk(dir); return h.digest('hex'); };

test('迁移旧目录 → 上线新版本 → 可回滚到迁移前的版本', async () => {
  const port = await freePort();
  // 1) 模拟线上旧结构：代码 + config.json + data/（数据库、上传文件）+ 前台目录（含以前下载的素材图 cos/）
  fs.mkdirSync(OLD, { recursive: true });
  for (const item of ['src', 'public', 'tools', 'package.json', 'config.example.json']) fs.cpSync(path.join(ROOT, item), path.join(OLD, item), { recursive: true });
  fs.writeFileSync(path.join(OLD, 'config.json'), JSON.stringify({ port, host: '127.0.0.1', publicBaseUrl: `http://127.0.0.1:${port}`, frontendDist: WEB, worker: { enabled: false } }));
  fs.mkdirSync(path.join(OLD, 'data', 'uploads', 'product'), { recursive: true });
  fs.writeFileSync(path.join(OLD, 'data', 'uploads', 'product', 'a.png'), 'png');
  const db = new DatabaseSync(path.join(OLD, 'data', 'yuduo.db'));
  db.exec('CREATE TABLE legacy_marker (x TEXT); INSERT INTO legacy_marker VALUES (\'keep\')');
  db.exec('CREATE TABLE yd_canvas (id INTEGER PRIMARY KEY, name TEXT)');   // 旧系统同名表（列不同），新版不能依赖它
  db.close();
  const { buildWeb } = require('../../tools/web/build');
  await buildWeb({ out: WEB });
  fs.mkdirSync(path.join(WEB, 'cos', 'images'), { recursive: true });
  fs.writeFileSync(path.join(WEB, 'cos', 'images', 'm.png'), 'mirrored');
  const before = [digest(OLD), digest(WEB)];

  // 2) 迁移
  fs.mkdirSync(path.join(HOME, 'shared'), { recursive: true });
  fs.writeFileSync(path.join(HOME, 'shared', 'release.config.json'), JSON.stringify({ service: { type: 'pidfile' }, healthTimeout: 25 }));
  const m = rel('migrate', '--from', OLD, '--web', WEB);
  assert.equal(m.code, 0, m.out);
  assert.deepEqual([digest(OLD), digest(WEB)], before, '迁移不能修改原目录');
  const legacyV = path.basename(fs.realpathSync(path.join(HOME, 'current')));
  assert.match(legacyV, /^legacy-/);
  assert.ok(fs.existsSync(path.join(HOME, 'shared', 'data', 'yuduo.db')));
  assert.ok(fs.existsSync(path.join(HOME, 'shared', 'data', 'uploads', 'product', 'a.png')));
  assert.ok(fs.existsSync(path.join(HOME, 'shared', 'data', 'cos', 'images', 'm.png')), '已下载的素材图应迁到数据目录');
  assert.ok(fs.readFileSync(path.join(HOME, 'shared', 'ecosystem.config.cjs'), 'utf8').includes(path.join(HOME, 'current', 'src', 'server.js')));
  const cfg = JSON.parse(fs.readFileSync(path.join(HOME, 'shared', 'config.json'), 'utf8'));
  assert.equal(cfg.port, port);
  assert.equal(cfg.frontendDist, path.join(HOME, 'current', 'web'));

  // 3) 发布新版本
  const pk = rel('pack', '--out', path.join(TMP, 'pkgs'));
  assert.equal(pk.code, 0, pk.out);
  const pkg = /发布包：(\S+\.tar\.gz)/.exec(pk.out)[1];
  const d = rel('deploy', pkg, '--skip-tests');
  assert.equal(d.code, 0, d.out);
  const base = `http://127.0.0.1:${port}`;
  const h = (await (await fetch(base + '/health', { headers: { Connection: 'close' } })).json()).data;
  assert.equal(h.status, 'ok');
  // 1.12.0 起旧素材库（/cos）已下线，不再检查
  const db2 = new DatabaseSync(path.join(HOME, 'shared', 'data', 'yuduo.db'));
  assert.equal(db2.prepare('SELECT x FROM legacy_marker').get().x, 'keep', '旧数据保留');
  assert.ok(db2.prepare("SELECT name FROM sqlite_master WHERE name='ct_canvas_doc'").get(), '画布表用新名字建好');
  db2.close();

  // 4) 回滚到迁移前的版本
  const rb = rel('rollback', legacyV);
  assert.equal(rb.code, 0, rb.out);
  assert.equal(path.basename(fs.realpathSync(path.join(HOME, 'current'))), legacyV);
  assert.equal((await fetch(base + '/', { headers: { Connection: 'close' } })).status, 200);
});
