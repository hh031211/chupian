#!/usr/bin/env node
'use strict';
/**
 * 出片儿测试入口。每次运行都在全新的沙箱里进行（见 tests/lib/sandbox.js），不会连接、读取或修改正式环境。
 *
 *   node tests/run.js                 全部（单元 + 接口 + 浏览器）
 *   node tests/run.js unit api        只跑单元和接口测试（不需要浏览器）
 *   node tests/run.js e2e             只跑浏览器测试
 *   node tests/run.js deploy          只跑发布 / 回滚演练（临时目录，pidfile 模式）
 *   node tests/run.js e2e --grep 工作台   只跑名字匹配的用例
 *   --keep    结束后保留沙箱目录（数据库、日志），排查问题用
 *   --web <dir>  使用已构建好的前台目录（默认现场构建一份临时的）
 *
 * 任何用例失败、沙箱起不来、构建失败，退出码都不为 0。
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { startSandbox } = require('./lib/sandbox');

const ROOT = path.resolve(__dirname, '..');
const argv = process.argv.slice(2);
const flag = (k) => argv.includes('--' + k);
const opt = (k) => { const i = argv.indexOf('--' + k); return i >= 0 ? argv[i + 1] : ''; };
const optVals = new Set(['--web', '--grep'].flatMap((k) => { const i = argv.indexOf(k); return i >= 0 ? [argv[i + 1]] : []; }));
const picked = argv.filter((a) => !a.startsWith('--') && !optVals.has(a));
const ALL = ['unit', 'api', 'e2e', 'deploy'];
const SUITES = picked.length ? picked : ALL;
for (const s of SUITES) if (!ALL.includes(s)) { console.error('未知测试集：' + s + '（可选 ' + ALL.join(' / ') + '）'); process.exit(2); }

const files = (dir) => (fs.existsSync(dir) ? fs.readdirSync(dir) : []).filter((f) => f.endsWith('.test.js') || f.endsWith('.test.mjs')).sort().map((f) => path.join(dir, f));

// 收到 Ctrl+C / kill 时：结束正在跑的测试进程和沙箱服务器，不留孤儿进程
let running = null;
let activeSandbox = null;
for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
  process.on(sig, async () => {
    console.error(`\n收到 ${sig}，正在清理测试进程和沙箱…`);
    if (running && running.exitCode === null) running.kill('SIGTERM');
    if (activeSandbox) await activeSandbox.stop({ keep: true }).catch(() => {});
    process.exit(130);
  });
}

function runNodeTests(list, env, { concurrency = 1 } = {}) {
  if (!list.length) return Promise.resolve(0);
  return new Promise((resolve) => {
    const args = ['--test', `--test-concurrency=${concurrency}`, '--test-reporter=spec'];
    if (opt('grep')) args.push(`--test-name-pattern=${opt('grep')}`);
    const child = spawn(process.execPath, [...args, ...list], { stdio: 'inherit', env: { ...process.env, ...env } });
    running = child;
    child.on('exit', (code, sig) => { running = null; resolve(code === null ? 1 : code || (sig ? 1 : 0)); });
  });
}

async function main() {
  const results = [];
  let sandbox = null;
  let tmpWeb = '';
  try {
    if (SUITES.includes('unit')) {
      console.log('\n━━ 单元测试（新前端纯逻辑 + 构建工具）');
      results.push(['unit', await runNodeTests([...files(path.join(ROOT, 'frontend', 'tests', 'unit')), ...files(path.join(__dirname, 'unit'))], {}, { concurrency: 4 })]);
    }
    if (SUITES.includes('deploy')) {
      console.log('\n━━ 发布 / 回滚演练');
      results.push(['deploy', await runNodeTests(files(path.join(__dirname, 'deploy')), {})]);
    }
    const needServer = SUITES.includes('api') || SUITES.includes('e2e');
    if (needServer) {
      let web = '';
      if (SUITES.includes('e2e')) {
        web = opt('web');
        if (!web) {
          console.log('\n━━ 构建临时前台（frontend/dist）');
          const { buildWeb } = require('../tools/web/build');
          tmpWeb = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'chengtu-web-')), 'web');
          await buildWeb({ out: tmpWeb });
          web = tmpWeb;
        }
      }
      console.log('\n━━ 启动测试沙箱');
      sandbox = await startSandbox({ web, keep: flag('keep') });
      activeSandbox = sandbox;
      console.log(`   地址 ${sandbox.base}  沙箱 ${sandbox.id}  目录 ${sandbox.dir}`);
      const env = {
        CT_TEST_BASE: sandbox.base, CT_TEST_SANDBOX: sandbox.id,
        CT_TEST_ADMIN_USER: sandbox.admin.username, CT_TEST_ADMIN_PASS: sandbox.admin.password, CT_TEST_TEXTEDIT: sandbox.textedit ? '1' : '',
        CT_TEST_ARTIFACTS: path.join(sandbox.dir, 'artifacts'), CT_TEST_DATA_DIR: path.join(sandbox.dir, 'data'),
      };
      if (SUITES.includes('api')) {
        console.log('\n━━ 接口测试');
        results.push(['api', await runNodeTests(files(path.join(__dirname, 'api')), env)]);
      }
      if (SUITES.includes('e2e')) {
        console.log('\n━━ 浏览器测试（Chromium，桌面 / 平板 / 手机）');
        results.push(['e2e', await runNodeTests(files(path.join(__dirname, 'e2e')), env)]);
      }
    }
  } catch (e) {
    console.error('\n❌ 测试环境出错：' + (e && e.stack || e));
    results.push(['setup', 1]);
  }
  const failed = results.filter(([, c]) => c !== 0);
  if (sandbox) await sandbox.stop({ keep: flag('keep') || failed.length > 0 });
  if (tmpWeb) fs.rmSync(path.dirname(tmpWeb), { recursive: true, force: true });
  console.log('\n━━ 结果');
  for (const [s, c] of results) console.log(`   ${c === 0 ? '✅' : '❌'} ${s}`);
  if (failed.length && sandbox) console.log(`   失败现场已保留：${sandbox.dir}（server.log 为后端日志，artifacts/ 为截图）`);
  process.exitCode = failed.length ? 1 : 0;
}

main();
