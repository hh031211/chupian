# 出片儿 · 后端服务

这套后端是根据前端 `dist` 逆向还原出来的，和现有前端**直接对接**：接口路径、参数、返回字段都按前端代码一一对齐。前端代码不用改，只需要把接口域名指向新后端。

- **零依赖**：只用 Node.js 内置能力（HTTP、`node:sqlite`、crypto、fetch），**不需要 `npm install`**
- **全部接口**：前端能调用的 670 个接口路径全部实现（含 150 个出图模块 × generate/status/regen）
- **管理后台**：`/admin`，管理用户、订单、套餐、兑换码、分销提现、公告、素材、资源目录、生成任务，以及中转站/计费/支付/短信等配置
- **AI 中转站**：OpenAI 兼容接口，支持 gpt-image 系列（`/images`）、对话出图模型（gemini-image / nano-banana / seedream 等）、Gemini 原生、Sora 视频；文本走 chat/vision
- 调用层 `src/ai/relay.js` 可以单独拿出去用，另附命令行工具 `tools/relay-test.js`

---

## 1. 环境要求

- **Node.js ≥ 22.13**（推荐 22 LTS 或 24），内置 SQLite，无需安装数据库
- Linux / Windows / macOS 均可；生产建议 Linux + PM2 + Nginx

```bash
node -v   # v22.13.0 以上
```

## 2. 快速启动

```bash
cd yuduo-server
cp config.example.json config.json     # 按下方说明修改
node --no-warnings src/server.js       # 或 npm start
```

启动后：

| 地址 | 说明 |
|---|---|
| `http://服务器:8360/ydapi/...` | 前端调用的接口 |
| `http://服务器:8360/admin` | 管理后台（首次启动自动创建 `admin / admin123456`，**登录后立即改密码**） |
| `http://服务器:8360/uploads/...` | 上传与生成的图片（本地存储模式） |
| `http://服务器:8360/h5/handoff.html` | 手机扫码传图页面（前端“手机上传”功能用） |

### config.json 说明

```jsonc
{
  "port": 8360,
  "apiPrefix": "/ydapi",                       // 前端写死的接口前缀，保持不变
  "publicBaseUrl": "https://api.你的域名.com",   // 后端对外地址（用于图片 URL、支付回调、微信回调）
  "siteUrl": "https://www.你的域名.com",          // 前端站点地址（邀请链接、微信登录回跳）
  "dbFile": "./data/yuduo.db",                 // SQLite 数据库文件
  "uploadDir": "./data/uploads",               // 本地图片目录
  "frontendDist": "",                          // 可选：填前端 dist 路径，后端顺带托管前端
  "corsOrigins": ["*"],                        // 允许跨域的前端域名，生产建议写具体域名
  "admin": { "path": "/admin", "initUsername": "admin", "initPassword": "admin123456" },
  "worker": { "enabled": true, "globalConcurrency": 8 }   // 全站同时出图张数上限
}
```

## 3. 前端

前台由两部分组成，构建成一个目录、由本服务托管（`frontendDist`）：

- **新前端** `frontend/`：Vue 3 + vue-router + Vite 源码工程（首页、AI 工具中心、场景灵感、个人中心、全站导航、登录、会员支付）
- **旧前台** `legacy/original/`：原站编译产物（无源码），只读、校验和锁定；工作台、个人中心各模块等仍由它提供，构建时打补丁并注入新导航

```bash
cd frontend && npm install && npm run build && cd ..   # 新前端 → frontend/dist
node tools/web/build.js --out build/web            # 旧前台 + 新前端 → build/web（输出目录必须不存在）
```

接口地址一律同源（`/ydapi`），IP、域名、测试环境用同一份产物，不需要再替换地址。架构说明见 `docs/ENGINEERING.md`。

## 4. 配置中转站（必做）

后台 → AI 生成 → **中转站 / 模型**，按页面上的 4 步走：

1. **中转站**：填接口地址（如 `https://api.xxx.com`，不用带 `/v1`）和 Key，点「获取模型」自动拉取模型列表。可以加多个中转站
2. **模型库**：系统按模型名自动判断「生图 / 文本识图 / 视频」和调用方式，判断错了在这里改；每个模型都能单独点「测试」
3. **功能 → 模型**：先选好默认模型（前台“模型2.0 / 模型2.5”、文本、识图、视频），然后可以给任意前台功能（抠图、白底图、海报、套图规划、投前检测……共 160+ 项）单独指定模型，也可以整个板块统一指定；没指定的跟随默认
4. **测试 / 高级**：连通性测试、重试次数、原始 JSON

详细说明见 [docs/RELAY.md](docs/RELAY.md)。

## 5. 计费规则（点数）

后台 → 系统设置 → `pricing`（默认值和前端显示一致）：

| 项目 | 默认 |
|---|---|
| 模型2.0（m1）每张 | 1K=3 / 2K=4 / 4K=5 |
| 模型2.5（m2）每张 | 1K=4 / 2K=5 / 4K=6 |
| 视频 | 每个 40 点（m3 按秒，每秒 5 点） |
| 文本类 | `text` 里分别配置，默认套图规划/帮写免费，风格分析 1、文案 1、投前检测每张 1、点击率每张 2 |

- 下单时**先扣点**，出图失败**自动退点**（`refund_failed`）
- 企业子账号消耗主账号点数
- `member.generate_requires_member=true`（默认）：和前端一致，只有会员能出图

## 6. 支付、短信、微信、存储

在后台 → 系统设置里填写对应 JSON：

| 分组 | 说明 |
|---|---|
| `payment` | 微信支付 V3：`appid` `mchid` `serial_no` `private_key`（商户私钥 PEM 全文）`apiv3_key`。回调地址自动为 `{publicBaseUrl}/ydapi/pay/wechat/notify`。电脑端走 Native 扫码，微信内走 JSAPI。**联调阶段**可设 `"mock": true`，扫码进入模拟支付页一键支付（上线前务必关闭）。 |
| `sms` | `provider: "aliyun"` + AccessKey、签名、模板（模板变量 `${code}`）。`debug: true` 且未配置时，验证码打印在日志并在接口返回（**仅测试用，上线务必改成 false**）。 |
| `mail` | SMTP 发邮箱验证码（465 SSL 或 587 STARTTLS）。 |
| ~~`wechat_mp`~~ | 微信登录已从前台移除（后台开关 register.wechat_login 默认关闭）。以下为原说明： 服务号 AppID/Secret/Token。公众号后台“服务器配置”URL 填 `https://api.你的域名.com/ydapi/wechat/notify`（明文模式），网页授权域名填 API 域名。PC 扫码关注登录、微信内授权登录、绑定微信都靠它。 |
| `storage` | 默认本地存储；改成 `"driver": "cos"` 并填腾讯云 COS 参数，图片直接存 COS（可配 CDN 域名）。 |
| `distribution` | 最低提现金额、分站可选主域名 `base_domains`、分销协议。 |

## 7. 生产部署（版本化发布）

正式环境用 `tools/release.js`：每个版本一个只读目录，切换前自动备份数据库、切换后健康检查，失败自动回退；任何版本都能一键回滚。完整步骤见 **`docs/DEPLOY.md`**。

```bash
npm run release:pack                                      # 本地 / CI：生成 dist/chengtu-<版本>.tar.gz
node /opt/chengtu/current/tools/release.js deploy chengtu-<版本>.tar.gz   # 服务器：安装 → 校验 → 沙箱测试 → 上线
node /opt/chengtu/current/tools/release.js rollback       # 回到上一个版本
```

### Nginx（API 域名）

见 `deploy/nginx.conf.example`。

## 8. 原后台丢失后需要重新录入的数据

后台源码和数据库都丢了，下面这些**原来存在数据库里的内容**需要重新录入（功能都已就绪）：

| 数据 | 在哪录入 | 影响 |
|---|---|---|
| 会员套餐、价格 | 运营 → 会员套餐（已预置一套默认值） | 开通会员弹窗 |
| 模特库、场景库、模板库、案例等官方资源 | 内容 → 资源目录（JSON 批量导入） | 模特广场、模板选择、案例展示。目录为空时前端会用内置兜底数据 |
| 官方素材 | 内容 → 官方素材 | 素材库“官方”分类 |
| 平台专属模特 | 内容 → 平台专属模特 | 专属模特“可领取”列表 |
| 合规标签模板 | 内容 → 合规标签模板 | 为空时前端用内置模板 |
| 公告/更新日志 | 内容 → 公告 | 顶部铃铛 |

资源目录 `catalog` 名称（前端会读取的）：`ai_models` `category_models` `pose_models` `accessory_models` `shoe_models` `model_scenes` `official_materials` `template_main` `template_handheld` `template_showcase` `template_cases` `template_cases_detail` `template_detail_panels` `template_propaganda` `template_insp` `template_gallery`。

## 9. 本地抠图（不走 AI，零成本）

抠图、智能抠图、证件照默认走**本地模型**（ISNet，CPU 推理，单张约 2~4 秒），不消耗中转站额度：

```bash
bash tools/setup-matting.sh      # 安装 Python 依赖 + 下载模型（约 400MB，一次即可）
pm2 restart chengtu
```

- 后台 → AI 生成 → **抠图引擎**：切换策略、上传图片对比本地 / AI 效果
- 策略 `auto`（默认）：先本地抠，自动给结果打“置信度”，低于阈值（默认 0.8）再让 AI 抠一遍，两者取更干净的
- 「AI 抠图 Pro」固定走 AI；AI 出图如果没有透明通道，会再用本地模型去掉纯色背景
- 没装本地模型时自动改用 AI，功能不受影响

## 10. 品牌信息与素材图

- 公司名 / 备案号 / 邮箱 / 电话 / 客服时间：后台 → 系统设置 → **站点信息**，实时生效
- 客服二维码、Logo：在「站点信息」页直接上传替换（保存在数据目录，所有版本共用）
- 旧素材图（原 CDN `cos.huotu333.cn`）统一走本站 `/cos/…`：已下载到 `<数据目录>/cos` 的直接返回，没有的跳转回原 CDN。
  想完全不依赖原站：`node tools/mirror-cos.js --to /opt/chengtu/shared/data/cos`（只下载，不改前台文件，可重复执行）

## 11. 测试（全部在隔离沙箱里运行，不碰正式数据）

```bash
npm install && npx playwright install chromium   # 首次：安装浏览器测试依赖
npm test                                         # 单元 + 接口 + 浏览器 + 发布回滚演练；任何失败退出码非 0
```

说明见 `tests/README.md`。联调用的假中转站：`node tools/mock-relay.js 9900`（后台通道地址填 `http://127.0.0.1:9900`）。

## 12. 目录结构

```
src/
  server.js            入口：路由、静态文件、前端托管
  core/                配置、数据库、用户与点数、订单与分佣、存储、验证码、短信邮件、微信
  ai/
    relay.js           ★ 中转站调用封装（可独立使用）
    builder.js         把前端表单参数编译成出图单元（张数拆分、参考图分配、提示词合成）
    engine.js          任务队列：计费 → 并发调度 → 调中转站 → 存图 → 失败退点
    llm.js             文本/识图能力：套图大纲、风格分析、投前检测、点击率、文案、帮写
    matting.js         抠图引擎：本地模型 + AI，按置信度自动取优
    modules.js         150 个功能模块的注册表（scene ↔ 控制器 ↔ 板块）
  routes/              user / member / distribution / library / generate
  admin/api.js         后台接口
public/admin/          后台页面
public/h5/             手机传图页
frontend/              新前端源码工程（Vue 3 + vue-router + Vite）
legacy/                旧前台原始产物（只读）+ 数据导出工具
tools/
  web/                 前台构建（旧前台只读打补丁 + 合并新前端）
  release.js           版本化发布 / 回滚 / 迁移
  mirror-cos.js        素材图下载到数据目录
  relay-test、mock-relay、setup-matting.sh、matting/（本地抠图进程）
tests/                 测试（沙箱、接口、浏览器、发布演练），说明见 tests/README.md
docs/                  ENGINEERING.md（前端架构）、DEPLOY.md（发布回滚）、ACCEPTANCE.md（功能核对）、API.md、RELAY.md
```
