module.exports = {
  apps: [{
    name: 'yuduo-server',
    script: 'src/server.js',
    node_args: '--no-warnings',
    instances: 1,            // SQLite + 内置任务队列：保持单实例
    autorestart: true,
    max_memory_restart: '1500M',
    env: { NODE_ENV: 'production' },
    out_file: './data/logs/out.log',
    error_file: './data/logs/error.log',
    time: true,
  }],
};
