// 出片儿 离线缓存：再次打开 / 刷新秒开（由 tools/web/build.js 生成）
const SHELL = 'ct-shell-v1', ASSETS = 'ct-assets-v1';
const ROUTES = [/^\/\/?$/, /^\/ai-tools\/?$/, /^\/m\/tools\/?$/, /^\/tool\/[^\/]+\/?$/, /^\/templates\/?$/, /^\/m\/templates\/?$/, /^\/projects\/?$/, /^\/m\/projects\/?$/, /^\/trash\/?$/, /^\/account\/?$/, /^\/m\/mine\/?$/, /^\/faq\/?$/, /^\/learn\/?$/, /^\/company-profile\/?$/, /^\/terms-of-service\/?$/, /^\/privacy-policy\/?$/];
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== SHELL && k !== ASSETS) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener('message', (e) => {
  if (e.data === 'ct-clear') e.waitUntil(Promise.all([caches.delete(SHELL), caches.delete(ASSETS)]));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== self.location.origin) return;
  if (u.pathname.startsWith('/app/assets/')) {
    e.respondWith((async () => {
      const c = await caches.open(ASSETS);
      const hit = await c.match(req, { ignoreSearch: true });
      if (hit) return hit;
      const r = await fetch(req);
      if (r.ok) c.put(req, r.clone());
      return r;
    })());
    return;
  }
  if (req.mode === 'navigate' && ROUTES.some((x) => x.test(u.pathname))) {
    e.respondWith((async () => {
      const c = await caches.open(SHELL);
      const hit = await c.match('/__shell');
      const entry = (t) => (//app/assets/app-[w-]+.js/.exec(t) || [''])[0];
      const net = fetch(req).then(async (r) => {
        if (r.ok && (r.headers.get('content-type') || '').includes('text/html')) {
          await c.put('/__shell', r.clone());
          // 缓存里是旧版本：告诉页面有新版（页面还没被操作过就自动刷新一次）
          if (hit) {
            try {
              const [a, b] = await Promise.all([hit.clone().text(), r.clone().text()]);
              if (entry(a) && entry(b) && entry(a) !== entry(b)) for (const cl of await self.clients.matchAll({ type: 'window' })) cl.postMessage('ct-new-version');
            } catch (err) { /* ignore */ }
          }
        }
        return r;
      });
      if (hit) { e.waitUntil(net.catch(() => {})); return hit.clone(); }
      return net;
    })());
  }
});
