#!/usr/bin/env bash
# 绑定域名 + 自动 HTTPS（Caddy）+ 缩略图工具（libvips）。可重复执行。
#   用法：bash /opt/chengtu/current/tools/setup-domain.sh chupianer.com
# 做的事：
#   1. 安装 Caddy（自动申请 / 续期免费 HTTPS 证书，HTTP/2、HTTP/3）和 libvips-tools（生成列表缩略图）
#   2. 网站程序改为只在本机 127.0.0.1:8360 监听，由 Caddy 对外提供 80 / 443
#   3. https://域名 为主站；www.域名、http://IP 自动跳转到 https://域名
#   4. 以前存的 http://IP/uploads/... 图片地址自动换成 https://域名/...（不改数据库）
# 出问题时还原：bash /opt/chengtu/current/tools/setup-domain.sh --undo
set -euo pipefail
CT_HOME="${CT_HOME:-/opt/chengtu}"
CFG="$CT_HOME/shared/config.json"
CUR="$CT_HOME/current"
say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "请用 root 执行"
[ -f "$CFG" ] || die "找不到配置 $CFG"

if [ "${1:-}" = "--undo" ]; then
  [ -f "$CFG.bak-domain" ] || die "没有可还原的备份"
  say "还原：网站程序重新直接监听 80 端口，停用 Caddy"
  systemctl stop caddy 2>/dev/null || true
  systemctl disable caddy 2>/dev/null || true
  cp "$CFG.bak-domain" "$CFG"
  pm2 restart chengtu --update-env >/dev/null && pm2 save >/dev/null
  echo "已还原，可用 http://IP 访问"
  exit 0
fi

DOMAIN="$(echo "${1:-}" | tr 'A-Z' 'a-z' | sed -E 's#^https?://##; s#/.*$##; s#^www\.##')"
[ -n "$DOMAIN" ] || die "用法：bash $0 你的域名（例如 chupianer.com）"

say "检查域名解析"
PUBIP="$(curl -s4 --max-time 8 https://api.ipify.org || curl -s4 --max-time 8 https://ifconfig.me || true)"
for h in "$DOMAIN" "www.$DOMAIN"; do
  got="$(getent ahostsv4 "$h" | awk '{print $1; exit}' || true)"
  echo "  $h → ${got:-（没有解析）}"
  if [ -n "$PUBIP" ] && [ "$got" != "$PUBIP" ]; then die "$h 没有解析到本服务器 $PUBIP。请在域名后台添加 A 记录（@ 和 www → $PUBIP），等几分钟再执行"; fi
done
echo "  本服务器公网 IP：${PUBIP:-未知}"

say "安装 Caddy 和缩略图工具（首次约 1~2 分钟）"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq libvips-tools curl gnupg debian-keyring debian-archive-keyring apt-transport-https >/dev/null
if ! command -v caddy >/dev/null 2>&1; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -qq
  apt-get install -y -qq caddy >/dev/null || true
fi
command -v caddy >/dev/null 2>&1 || die "Caddy 安装失败，请把上面的输出截图发给开发"
systemctl stop caddy 2>/dev/null || true
echo "  Caddy $(caddy version | awk '{print $1}')，vipsthumbnail $(vipsthumbnail --version 2>/dev/null | head -1 | awk '{print $2}')"

say "修改网站配置"
[ -f "$CFG.bak-domain" ] || cp "$CFG" "$CFG.bak-domain"
DOMAIN="$DOMAIN" PUBIP="$PUBIP" CFG="$CFG" node -e '
const fs = require("fs");
const c = JSON.parse(fs.readFileSync(process.env.CFG, "utf8"));
const d = process.env.DOMAIN, ip = process.env.PUBIP;
const base = "https://" + d;
const alias = new Set(c.aliasBaseUrls || []);
for (const u of [c.publicBaseUrl, c.siteUrl, ip && "http://" + ip, ip && "http://" + ip + ":" + (c.port || 80), "http://" + d, "http://www." + d, "https://www." + d]) if (u && u.replace(/\/$/, "") !== base) alias.add(u.replace(/\/$/, ""));
c.aliasBaseUrls = [...alias];
c.publicBaseUrl = base; c.siteUrl = base;
c.port = 8360; c.host = "127.0.0.1"; c.trustProxy = true;
fs.writeFileSync(process.env.CFG, JSON.stringify(c, null, 2));
console.log("  网站地址：" + base + "；以前的图片地址自动换新：" + c.aliasBaseUrls.join("、"));
'
# 后台「站点信息」：前端地址（邀请链接用）、域名
CUR_SRC="$CUR/src" YD_CONFIG="$CFG" DOMAIN="$DOMAIN" node --no-warnings -e '
const S = require(process.env.CUR_SRC + "/core/settings");
const site = S.get("site") || {};
S.set("site", { ...site, frontend_url: "https://" + process.env.DOMAIN, domain: process.env.DOMAIN });
console.log("  后台「站点信息」前端地址已改为 https://" + process.env.DOMAIN);
' || echo "  （前端地址请到后台「站点信息」里手动填 https://$DOMAIN）"

say "写入 Caddy 配置"
cat > /etc/caddy/Caddyfile <<EOF
# 由 setup-domain.sh 生成
$DOMAIN {
	encode zstd gzip
	request_body {
		max_size 60MB
	}
	reverse_proxy 127.0.0.1:8360 {
		transport http {
			read_timeout 600s
			write_timeout 600s
		}
	}
}
www.$DOMAIN {
	redir https://$DOMAIN{uri} permanent
}
# 用 IP 或其它地址访问的，都跳到正式域名
http:// {
	redir https://$DOMAIN{uri} permanent
}
EOF
caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile >/dev/null 2>&1 || die "Caddy 配置检查失败"

say "切换：网站程序改到 127.0.0.1:8360，Caddy 接管 80 / 443"
pm2 restart chengtu --update-env >/dev/null
pm2 save >/dev/null
for i in $(seq 1 30); do curl -s -o /dev/null --max-time 2 http://127.0.0.1:8360/health && break; sleep 1; done
curl -s -o /dev/null --max-time 3 http://127.0.0.1:8360/health || { cp "$CFG.bak-domain" "$CFG"; pm2 restart chengtu >/dev/null; die "网站程序没能在 8360 端口启动，已还原"; }
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; ufw allow 443/udp >/dev/null; fi
systemctl enable caddy >/dev/null 2>&1
systemctl restart caddy

say "申请 HTTPS 证书并检查（最多等 90 秒）"
ok=0
for i in $(seq 1 45); do
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "https://$DOMAIN/health" || true)"
  if [ "$code" = 200 ]; then ok=1; break; fi
  sleep 2
done
if [ "$ok" = 1 ]; then
  printf '\n\033[1;32m✓ 完成：https://%s 已可访问（www 和 IP 访问会自动跳转过来）\033[0m\n' "$DOMAIN"
  echo "  证书由 Caddy 自动续期，不用管。缩略图工具已装好。"
else
  echo
  echo "✗ https://$DOMAIN 暂时打不开。常见原因：服务器商的安全组 / 防火墙没放行 443 端口。"
  echo "  请到服务器商控制台放行 TCP 80、443（和 UDP 443），然后执行：systemctl restart caddy"
  echo "  Caddy 日志：journalctl -u caddy --no-pager -n 30"
  echo "  想先恢复原来的 IP 访问：bash $CUR/tools/setup-domain.sh --undo"
  exit 1
fi
