'use strict';
// 本地“假中转站”：模拟 OpenAI 兼容接口，用于不花钱联调整个系统。
// 用法：node tools/mock-relay.js 9900   然后后台把中转站 base_url 设为 http://127.0.0.1:9900
const http = require('node:http');
const zlib = require('node:zlib');

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let n = 0; n < buf.length; n++) {
    c = (crc ^ buf[n]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(w, h, seed = 0) {
  const raw = Buffer.alloc((w * 3 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 3 + 1)] = 0;
    for (let x = 0; x < w; x++) {
      const i = y * (w * 3 + 1) + 1 + x * 3;
      raw[i] = (x * 255 / w + seed * 40) & 255; raw[i + 1] = (y * 255 / h) & 255; raw[i + 2] = (128 + seed * 70) & 255;
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

let n = 0;
const stats = { requests: 0, images: 0, failures: 0 };
let quiet = !!process.env.MOCK_RELAY_QUIET;
function handler(req, res) {
  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => {
    const body = Buffer.concat(chunks).toString('utf8');
    const url = req.url.split('?')[0];
    stats.requests++;
    if (!quiet) console.log(new Date().toISOString(), req.method, url, body.length);
    const json = (o, s = 200) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    // 模拟佐糖抠图接口：X-API-KEY = bad 时返回 401；=slow 时一直处理中
    if (url === '/api/tasks/visual/segmentation' && req.method === 'POST') {
      const k = req.headers['x-api-key'];
      if (!k || k === 'bad') return json({ status: 401, message: 'Unauthorized' });
      stats.picwish = (stats.picwish || 0) + 1;
      return json({ status: 200, message: 'success', data: { task_id: (k === 'slow' ? 'slow_' : 'pw_') + Date.now() } });
    }
    if (url.startsWith('/api/tasks/visual/segmentation/')) {
      const id = url.split('/').pop();
      if (id.startsWith('slow_')) return json({ status: 200, message: 'success', data: { task_id: id, state: 4, progress: 50 } });
      const host = req.headers.host;
      return json({ status: 200, message: 'success', data: { task_id: id, state: 1, progress: 100, image: `http://${host}/pw/result.png` } });
    }
    if (url === '/pw/result.png') { res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(png(300, 400, 7)); }
    if (url.endsWith('/v1/models')) return json({ data: ['gpt-image-1', 'gpt-4o-mini', 'gpt-4o', 'sora-2', 'gemini-2.5-flash-image-preview', 'nano-banana', 'seedream-4.0', 'flux-kontext-pro', 'claude-sonnet-4', 'veo3', 'text-embedding-3-small'].map((id) => ({ id })) });
    if (url.endsWith('/v1/images/generations') || url.endsWith('/v1/images/edits')) {
      if (body.includes('FAILME')) { stats.failures++; return json({ error: { message: 'mock failure' } }, 500); }
      stats.images++;
      // 提示词带 MOCK_MAX2K：模拟只支持到 2K 的中转站（不管要多大都只出 1536 长边）
      const [w, h] = body.includes('MOCK_MAX2K') ? [1536, 1024] : [256, 320];
      return setTimeout(() => json({ data: [{ b64_json: png(w, h, n++).toString('base64') }] }), 800);
    }
    if (/:generateContent$/.test(url)) {
      return json({ candidates: [{ content: { parts: [{ text: 'ok' }, { inlineData: { mimeType: 'image/png', data: png(200, 200, n++).toString('base64') } }] } }] });
    }
    if (url.endsWith('/v1/chat/completions')) {
      let j = {};
      try { j = JSON.parse(body); } catch {}
      if (/image|banana|seedream/i.test(j.model || '')) {
        return json({ choices: [{ message: { role: 'assistant', content: '好的，这是生成的图片：![img](data:image/png;base64,' + png(180, 240, n++).toString('base64') + ')' } }] });
      }
      const wantJson = j.response_format && j.response_format.type === 'json_object';
      const text = wantJson
        ? JSON.stringify({ outline: [{ value: 'a', name: '主图', suggestion: '白底居中', copy: '新品' }, { value: 'b', name: '场景', suggestion: '客厅', copy: '' }], styles: [{ id: 's1', name: '极简', desc: '干净', colors: ['#fff'], prompt: 'minimal' }], platform: '淘宝', fields: [{ key: 'material', label: '材质', options: ['棉', '麻'] }], reports: [{ overall: 80, dims: [] }], taobao: '标题', selling_points: ['好'], summary: '一组模特正侧背示例图', plan: '换成一位短发年轻女模特，穿浅蓝色衬衫和白色阔腿裤，浅灰摄影棚', reply: '我会把图里的小女孩改成小男孩，衣服、帽子和背景都保持不变。', prompt: '在参考图的基础上，把画面中的小女孩改为小男孩；人物的服装、帽子、姿势、背景、光线与构图保持与原图一致。', title: '小女孩改为小男孩', category: '小红书风格', tags: ['口红', '小红书'], items: [{ index: 1, theme: '口红 小红书风 粉色系', keep: '正面站姿', title: '玫瑰色口红平铺', category: '美妆个护', tags: ['口红'], prompt: '一支玫瑰色口红斜放在奶油色大理石台面上，柔和自然光' }, { index: 2, theme: '中秋月饼礼盒 节日海报', keep: '侧面', title: '口红试色海报', category: '营销海报', tags: ['口红'], prompt: '三支口红并排，粉色背景，画面上方写「春日试色」' }] })
        : '这是模拟中转站返回的文本。';
      if (j.stream) {
        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
        for (const ch of text.match(/.{1,6}/gs)) res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: ch } }] })}\n\n`);
        res.write('data: [DONE]\n\n');
        return res.end();
      }
      return json({ choices: [{ message: { role: 'assistant', content: text } }] });
    }
    if (url.endsWith('/v1/videos') && req.method === 'POST') return json({ id: 'vid_' + Date.now(), status: 'queued' });
    if (/\/v1\/videos\/[^/]+$/.test(url)) return json({ status: 'completed', progress: 100 });
    if (/\/v1\/videos\/[^/]+\/content$/.test(url)) { res.writeHead(200, { 'Content-Type': 'video/mp4' }); return res.end(Buffer.from('00000018667479706d703432', 'hex')); }
    json({ error: { message: 'not found' } }, 404);
  });
}

/** 启动模拟中转站；port 传 0 自动分配。返回 { server, port, url, stats, close() } */
function startMockRelay(port = 0, host = '127.0.0.1', opts = {}) {
  if (opts.quiet) quiet = true;
  return new Promise((resolve, reject) => {
    const server = http.createServer(handler);
    server.on('error', reject);
    server.listen(port, host, () => {
      const p = server.address().port;
      resolve({ server, port: p, url: `http://${host}:${p}`, stats, close: () => new Promise((r) => server.close(() => r())) });
    });
  });
}
module.exports = { startMockRelay, png };

if (require.main === module) {
  startMockRelay(Number(process.argv[2] || 9900)).then((m) => console.log('mock relay on ' + m.url));
}
