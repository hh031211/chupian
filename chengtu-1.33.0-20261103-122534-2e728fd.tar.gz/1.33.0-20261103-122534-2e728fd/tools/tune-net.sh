#!/usr/bin/env bash
# 服务器网络提速（香港 → 内地跨境线路专用），可重复执行：
#   - BBR 拥塞控制 + fq：跨境线路有丢包时不再大幅降速（对首次打开、图片下载提升明显）
#   - 初始拥塞窗口 32：第一次打开时 HTML/CSS/JS 少等 1~2 个来回
#   - 连接空闲后不重新慢启动、开启 TCP Fast Open
# 用法：bash /opt/chengtu/current/tools/tune-net.sh
set -e
[ "$(id -u)" = 0 ] || { echo "请用 root 执行"; exit 1; }

modprobe tcp_bbr 2>/dev/null || true
echo tcp_bbr > /etc/modules-load.d/bbr.conf
cat > /etc/sysctl.d/90-chengtu-net.conf <<'EOF'
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_notsent_lowat = 131072
net.ipv4.tcp_mtu_probing = 1
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 131072 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
EOF
sysctl -q -p /etc/sysctl.d/90-chengtu-net.conf

# 初始拥塞窗口：写成开机自动执行的服务（重启后也生效）
cat > /usr/local/sbin/chengtu-initcwnd <<'EOF'
#!/bin/sh
R=$(ip route show default | head -1 | sed 's/ initcwnd [0-9]*//; s/ initrwnd [0-9]*//')
[ -n "$R" ] && ip route change $R initcwnd 32 initrwnd 32
exit 0
EOF
chmod +x /usr/local/sbin/chengtu-initcwnd
cat > /etc/systemd/system/chengtu-initcwnd.service <<'EOF'
[Unit]
Description=chengtu: larger TCP initial congestion window
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/chengtu-initcwnd
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now chengtu-initcwnd.service >/dev/null 2>&1 || /usr/local/sbin/chengtu-initcwnd

echo "✅ 拥塞控制：$(sysctl -n net.ipv4.tcp_congestion_control)  队列：$(sysctl -n net.core.default_qdisc)"
echo "✅ 默认路由：$(ip route show default | head -1)"
