#!/usr/bin/env bash
# 出片儿 · 服务器安全加固（可重复执行，不会把你锁在外面）
#   bash /opt/chengtu/current/tools/harden-server.sh
# 做的事：
#   1. 防火墙（ufw）：只开 SSH（自动识别端口）、80、443；8360 / 8361 等内部端口外网访问不到
#   2. fail2ban：SSH 密码连续输错 5 次封 IP 1 小时（挡住全网扫 22 端口猜密码的机器人）
#   3. 自动安装系统安全更新（unattended-upgrades）
#   4. 检查网站程序 / 改字服务是否只监听本机
set -euo pipefail
say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m⚠ %s\033[0m\n' "$*"; }
[ "$(id -u)" = 0 ] || { echo "请用 root 执行"; exit 1; }
export DEBIAN_FRONTEND=noninteractive

SSH_PORT="$(ss -tlnp 2>/dev/null | awk '/sshd/ {sub(/.*:/, "", $4); print $4; exit}')"
SSH_PORT="${SSH_PORT:-22}"
say "SSH 端口：$SSH_PORT"

say "安装 ufw、fail2ban、自动安全更新"
apt-get update -qq >/dev/null
apt-get install -y -qq ufw fail2ban unattended-upgrades >/dev/null

say "配置防火墙（先放行 SSH，再开启，不会断开当前连接）"
ufw allow "$SSH_PORT"/tcp >/dev/null
ufw allow 80/tcp >/dev/null
ufw allow 443/tcp >/dev/null
ufw allow 443/udp >/dev/null   # HTTP/3
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw --force enable >/dev/null
ufw status | sed 's/^/   /'

say "配置 fail2ban（SSH 防爆破）"
cat > /etc/fail2ban/jail.d/chupianer.conf <<JAIL
[sshd]
enabled = true
port = $SSH_PORT
maxretry = 5
findtime = 10m
bantime = 1h
JAIL
systemctl enable --now fail2ban >/dev/null 2>&1 || true
systemctl restart fail2ban || true

say "开启自动安全更新"
cat > /etc/apt/apt.conf.d/20auto-upgrades <<AU
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
AU

say "检查内部端口是否只在本机监听"
for p in 8360 8361; do
  line="$(ss -tlnp 2>/dev/null | awk -v p=":$p" '$4 ~ p"$" {print $4}' | head -1)"
  if [ -z "$line" ]; then echo "   $p：没在运行"; continue; fi
  case "$line" in 127.0.0.1:*|\[::1\]:*) echo "   ✅ $p 只在本机：$line" ;; *) warn "$p 对外开放：$line（防火墙已挡住，但建议 config.json 里 host 改成 127.0.0.1）" ;; esac
done

say "检查 SSH 设置"
if sshd -T 2>/dev/null | grep -q '^passwordauthentication yes'; then
  warn "SSH 还允许密码登录。最安全的做法是改用密钥登录（Termius 里生成密钥 → 把公钥加到服务器 → 再关闭密码登录）。需要的话让开发者带你一步步做，别自己直接关，否则会登不上。"
else
  echo "   ✅ SSH 已禁用密码登录"
fi

echo
echo "✅ 加固完成。雨云控制台的「安全组」也建议只放行 $SSH_PORT、80、443。"
