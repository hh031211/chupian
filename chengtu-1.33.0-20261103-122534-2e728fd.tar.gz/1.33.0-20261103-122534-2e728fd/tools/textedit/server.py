#!/usr/bin/env python3
"""
出片儿 · 精准改字服务（只监听本机 127.0.0.1:8361，由网站后端调用）

  POST /ocr        {image}                      → 识别文字：位置、内容、颜色、粗细、字号
  POST /inpaint    {image, boxes}               → 擦掉这些框里的文字（LaMa 模型；没装模型时用 OpenCV 兜底）
  POST /mark       {image, boxes}               → 在原图上用红色标出这些框（给 AI 擦除用）
  POST /composite  {base, patch, boxes}         → 只把 patch（AI 擦好的图）在这些框里的部分贴回原图，框外保持原图像素
  POST /subset     {font, text, weight}         → 按要用到的字裁出很小的 woff2 / woff 字体（浏览器排字用）
  GET  /health                                  → 状态

图片一律 base64（PNG / JPEG / WebP）。重活（OCR / 擦除）同一时间只跑 1 个，其它排队，不会把服务器 CPU 吃满。
环境变量：TE_DIR（模型和字体目录，默认本文件旁的 data/）、TE_PORT（默认 8361）、TE_THREADS（推理线程，默认 2）
"""
import base64
import io
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np
import cv2
from PIL import Image

TE_DIR = os.environ.get('TE_DIR') or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
PORT = int(os.environ.get('TE_PORT') or 8361)
THREADS = int(os.environ.get('TE_THREADS') or max(2, min(3, os.cpu_count() or 2)))
FAKE_OCR = os.environ.get('TE_FAKE_OCR')   # 测试用：返回固定的识别结果（JSON 文件路径）
FONT_DIR = os.path.join(TE_DIR, 'fonts')
LAMA_PATH = os.path.join(TE_DIR, 'lama_fp32.onnx')
HEAVY = threading.Semaphore(1)
cv2.setNumThreads(THREADS)

# 字体：id → (显示名, 文件名, 默认粗细)
FONTS = [
    ('noto-sans', '思源黑体', 'NotoSansSC[wght].ttf'),
    ('noto-serif', '思源宋体', 'NotoSerifSC[wght].ttf'),
    ('zcool-kuaile', '站酷快乐体', 'ZCOOLKuaiLe-Regular.ttf'),
    ('zcool-qingke', '站酷庆科黄油体', 'ZCOOLQingKeHuangYou-Regular.ttf'),
    ('zcool-xiaowei', '站酷小薇体', 'ZCOOLXiaoWei-Regular.ttf'),
    ('mashanzheng', '马善政毛笔楷书', 'MaShanZheng-Regular.ttf'),
    ('zhimangxing', '志莽行书', 'ZhiMangXing-Regular.ttf'),
    ('longcang', '龙藏体', 'LongCang-Regular.ttf'),
    ('montserrat', 'Montserrat（英文）', 'Montserrat[wght].ttf'),
    ('playfair', 'Playfair（英文衬线）', 'PlayfairDisplay[wght].ttf'),
    ('bebas', 'Bebas Neue（英文标题）', 'BebasNeue-Regular.ttf'),
]


def font_list():
    out = []
    for fid, name, fn in FONTS:
        if os.path.exists(os.path.join(FONT_DIR, fn)):
            out.append({'id': fid, 'name': name, 'var': '[wght]' in fn})
    # 站长自己上传的字体：fonts/custom/*.ttf|otf
    cdir = os.path.join(FONT_DIR, 'custom')
    if os.path.isdir(cdir):
        for fn in sorted(os.listdir(cdir)):
            if fn.lower().endswith(('.ttf', '.otf')):
                out.append({'id': 'custom:' + fn, 'name': os.path.splitext(fn)[0]})
    return out


def font_path(fid):
    if fid.startswith('custom:'):
        fn = os.path.basename(fid[7:])
        p = os.path.join(FONT_DIR, 'custom', fn)
        return p if os.path.exists(p) else None
    for i, _, fn in FONTS:
        if i == fid:
            p = os.path.join(FONT_DIR, fn)
            return p if os.path.exists(p) else None
    return None


# ---------------- 图片编解码 ----------------
Image.MAX_IMAGE_PIXELS = 60_000_000   # 超过 6000 万像素的图直接拒绝（防止超大图片把内存撑爆）


def dec(b64):
    if ',' in b64[:100]:
        b64 = b64.split(',', 1)[1]
    im = Image.open(io.BytesIO(base64.b64decode(b64)))
    if im.width * im.height > Image.MAX_IMAGE_PIXELS:
        raise ValueError('图片太大（超过 6000 万像素）')
    im.load()
    alpha = None
    if im.mode in ('RGBA', 'LA', 'P'):
        im = im.convert('RGBA')
        alpha = np.array(im)[:, :, 3]
    rgb = np.array(im.convert('RGB'))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), alpha


def enc(bgr, alpha=None):
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    im = Image.fromarray(rgb)
    if alpha is not None and alpha.shape[:2] == rgb.shape[:2]:
        im.putalpha(Image.fromarray(alpha))
    buf = io.BytesIO()
    im.save(buf, 'PNG', optimize=False, compress_level=2)
    return base64.b64encode(buf.getvalue()).decode()


# ---------------- OCR ----------------
_ocr = None


def ocr_engine():
    global _ocr
    if _ocr is None:
        from rapidocr_onnxruntime import RapidOCR
        try:
            _ocr = RapidOCR(intra_op_num_threads=THREADS, inter_op_num_threads=1)
        except TypeError:
            _ocr = RapidOCR()
    return _ocr


def has_ocr():
    if FAKE_OCR:
        return True
    try:
        import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def text_style(img, poly):
    """估计这段文字的颜色、背景色、粗细，以及笔画实际占的范围（ink，比 OCR 框更贴字）"""
    x, y, w, h = cv2.boundingRect(np.array(poly, dtype=np.int32))
    H, W = img.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    crop = img[y0:y1, x0:x1]
    out = {'color': '#111111', 'bg': '#ffffff', 'weight': 400, 'ink': None, 'density': 0}
    if crop.size == 0 or crop.shape[0] < 3 or crop.shape[1] < 3:
        return out
    px = crop.reshape(-1, 3).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    _, lab, cen = cv2.kmeans(px, 2, None, crit, 2, cv2.KMEANS_PP_CENTERS)
    lab = lab.reshape(crop.shape[:2])
    border = np.concatenate([lab[0, :], lab[-1, :], lab[:, 0], lab[:, -1]])
    bg_i = int(np.bincount(border, minlength=2).argmax())
    tx_i = 1 - bg_i
    hexc = lambda c: '#%02x%02x%02x' % (int(np.clip(c[2], 0, 255)), int(np.clip(c[1], 0, 255)), int(np.clip(c[0], 0, 255)))
    mask = (lab == tx_i).astype(np.uint8)
    out['bg'] = hexc(cen[bg_i])
    if mask.sum() < 6:
        out['color'] = hexc(cen[tx_i])
        return out
    # 文字颜色：抗锯齿边缘会把颜色「冲淡」，取离背景色最远的那部分像素的中位数
    tp = crop[mask > 0].astype(np.float32)
    d = np.linalg.norm(tp - cen[bg_i], axis=1)
    core = tp[d >= np.percentile(d, 55)]
    out['color'] = hexc(np.median(core, axis=0) if len(core) else cen[tx_i])
    ys, xs = np.nonzero(mask)
    ix0, ix1, iy0, iy1 = int(xs.min()), int(xs.max()) + 1, int(ys.min()), int(ys.max()) + 1
    out['ink'] = [x0 + ix0, y0 + iy0, x0 + ix1, y0 + iy1]
    out['density'] = round(float(mask.sum()) / max(1, (ix1 - ix0) * (iy1 - iy0)), 4)
    dist = cv2.distanceTransform(mask, cv2.DIST_L2, 3)
    stroke = 2 * float(np.percentile(dist[dist > 0], 90))
    ratio = stroke / max(1, iy1 - iy0)
    out['weight'] = 800 if ratio > 0.17 else 700 if ratio > 0.13 else 600 if ratio > 0.105 else 500 if ratio > 0.085 else 400
    return out


GOOD = __import__('re').compile(r'[0-9A-Za-z一-鿿぀-ヿ가-힯]')


CJK = __import__('re').compile(r'[一-鿿぀-ヿ가-힯，。！？：；、（）]')


def merge_lines(raw):
    """同一行里被 OCR 断开的几段（间距很小、字高相近、横排）拼回一段"""
    rows = []
    for poly, text, score in raw:
        pts = np.array(poly, dtype=np.float32)
        x0, y0 = pts.min(axis=0); x1, y1 = pts.max(axis=0)
        rows.append({'poly': poly, 'text': str(text), 'score': float(score), 'x0': float(x0), 'x1': float(x1), 'y0': float(y0), 'y1': float(y1)})
    rows.sort(key=lambda r: (round((r['y0'] + r['y1']) / 2), r['x0']))
    out = []
    used = [False] * len(rows)
    for i, a in enumerate(rows):
        if used[i]:
            continue
        used[i] = True
        cur = dict(a)
        while True:
            h = cur['y1'] - cur['y0']
            best = -1
            for j, b in enumerate(rows):
                if used[j]:
                    continue
                bh = b['y1'] - b['y0']
                if not (0.7 < bh / max(1.0, h) < 1.4):
                    continue
                if abs((b['y0'] + b['y1']) / 2 - (cur['y0'] + cur['y1']) / 2) > 0.3 * h:
                    continue
                gap = b['x0'] - cur['x1']
                if -0.3 * h <= gap <= 0.45 * h and (best < 0 or b['x0'] < rows[best]['x0']):
                    best = j
            if best < 0:
                break
            b = rows[best]; used[best] = True
            gap = b['x0'] - cur['x1']
            sep = '' if (CJK.search(cur['text'][-1:]) or CJK.search(b['text'][:1]) or gap < 0.2 * h) else ' '
            cur['text'] = cur['text'] + sep + b['text']
            cur['score'] = min(cur['score'], b['score'])
            cur['x1'] = max(cur['x1'], b['x1']); cur['y0'] = min(cur['y0'], b['y0']); cur['y1'] = max(cur['y1'], b['y1'])
            cur['poly'] = [[cur['x0'], cur['y0']], [cur['x1'], cur['y0']], [cur['x1'], cur['y1']], [cur['x0'], cur['y1']]]
        out.append([cur['poly'], cur['text'], cur['score']])
    return out


def do_ocr(img):
    H, W = img.shape[:2]
    if FAKE_OCR:
        with open(FAKE_OCR, encoding='utf-8') as f:
            raw = [[[[p[0] * W, p[1] * H] for p in it['poly']], it['text'], 0.99] for it in json.load(f)]
    else:
        # 大图先缩到长边 2000 识别（快、准），坐标再放大回去
        k = min(1.0, 2000.0 / max(W, H))
        small = cv2.resize(img, (int(W * k), int(H * k)), interpolation=cv2.INTER_AREA) if k < 1 else img
        res, _ = ocr_engine()(small)
        raw = [[[[p[0] / k, p[1] / k] for p in r[0]], r[1], r[2]] for r in (res or [])]
    raw = merge_lines(raw)
    items = []
    for i, (poly, text, score) in enumerate(raw):
        t = str(text).strip()
        # 去掉误识别的碎片：图标、信号格、标点、太小的框
        if not t or float(score) < 0.6 or not GOOD.search(t):
            continue
        if len(GOOD.findall(t)) <= 1 and float(score) < 0.85:
            continue
        pts = np.array(poly, dtype=np.float32)
        (cx, cy), (rw, rh), ang = cv2.minAreaRect(pts)
        # 统一成「横向」：宽 ≥ 高，角度在 -45~45
        if rw < rh:
            rw, rh, ang = rh, rw, ang - 90 if ang > 0 else ang + 90
        if ang > 45:
            ang -= 90
        if ang < -45:
            ang += 90
        if rh < 6:
            continue
        sty = text_style(img, pts)
        items.append({
            'id': 't%d' % i, 'text': str(text), 'score': round(float(score), 3), 'poly': [[round(p[0], 1), round(p[1], 1)] for p in poly],
            'cx': round(float(cx), 1), 'cy': round(float(cy), 1), 'w': round(float(rw), 1), 'h': round(float(rh), 1), 'angle': round(float(ang), 2),
            'color': sty['color'], 'bg': sty['bg'], 'weight': sty['weight'], 'ink': sty['ink'], 'density': sty['density'],
        })
    return {'width': W, 'height': H, 'items': items}


# ---------------- 擦除 ----------------
def box_mask(shape, boxes, pad_ratio=0.18):
    H, W = shape[:2]
    m = np.zeros((H, W), np.uint8)
    for b in boxes:
        w, h = float(b['w']), float(b['h'])
        pad = max(3.0, h * pad_ratio)
        rect = ((float(b['cx']), float(b['cy'])), (w + pad * 2, h + pad * 2), float(b.get('angle') or 0))
        pts = cv2.boxPoints(rect).astype(np.int32)
        cv2.fillPoly(m, [pts], 255)
    return m


_lama = None


def lama():
    global _lama
    if _lama is None and os.path.exists(LAMA_PATH):
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = THREADS
        so.inter_op_num_threads = 1
        _lama = ort.InferenceSession(LAMA_PATH, so, providers=['CPUExecutionProvider'])
    return _lama


def lama_region(img, mask, sess):
    """把每块要擦的区域裁成正方形 → 缩到 512 → LaMa → 放大回去，只贴回 mask 内"""
    out = img.copy()
    n, lab, stats, _ = cv2.connectedComponentsWithStats((mask > 0).astype(np.uint8), 8)
    H, W = img.shape[:2]
    # 相邻的小块合并成一组处理，减少推理次数
    done = np.zeros(n, bool)
    for i in range(1, n):
        if done[i]:
            continue
        x, y, w, h = stats[i][:4]
        side = int(max(w, h) * 2.2 + 32)
        side = max(side, 256)
        side = min(side, max(W, H))
        cx, cy = x + w / 2, y + h / 2
        x0 = int(min(max(0, cx - side / 2), max(0, W - side)))
        y0 = int(min(max(0, cy - side / 2), max(0, H - side)))
        x1, y1 = min(W, x0 + side), min(H, y0 + side)
        for j in range(i, n):
            jx, jy, jw, jh = stats[j][:4]
            if jx >= x0 and jy >= y0 and jx + jw <= x1 and jy + jh <= y1:
                done[j] = True
        crop = out[y0:y1, x0:x1]
        cm = mask[y0:y1, x0:x1]
        ch, cw = crop.shape[:2]
        im512 = cv2.resize(crop, (512, 512), interpolation=cv2.INTER_AREA if max(ch, cw) > 512 else cv2.INTER_CUBIC)
        m512 = cv2.resize(cm, (512, 512), interpolation=cv2.INTER_NEAREST)
        x_img = cv2.cvtColor(im512, cv2.COLOR_BGR2RGB).astype(np.float32).transpose(2, 0, 1)[None] / 255.0
        x_m = (m512 > 127).astype(np.float32)[None, None]
        names = [i_.name for i_ in sess.get_inputs()]
        mname = next((n_ for n_ in names if 'mask' in n_.lower()), names[1])
        iname = next(n_ for n_ in names if n_ != mname)
        res = sess.run(None, {iname: x_img, mname: x_m})[0][0]
        res = res.transpose(1, 2, 0)
        if res.max() <= 1.5:
            res = res * 255.0
        res = cv2.cvtColor(np.clip(res, 0, 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
        res = cv2.resize(res, (cw, ch), interpolation=cv2.INTER_CUBIC)
        sel = cm > 0
        crop[sel] = res[sel]
        out[y0:y1, x0:x1] = crop
    return out


def make_mask(img, boxes, keep=None, mask_b64=None):
    """要擦的区域：画笔涂抹的 mask，或文字框（四周留一点余量）；不擦进旁边不改的文字"""
    H, W = img.shape[:2]
    if mask_b64:
        mm, _ = dec(mask_b64)
        mm = cv2.cvtColor(mm, cv2.COLOR_BGR2GRAY)
        if mm.shape[:2] != (H, W):
            mm = cv2.resize(mm, (W, H), interpolation=cv2.INTER_NEAREST)
        m = (mm > 127).astype(np.uint8) * 255
        k = max(3, int(min(H, W) / 250) | 1)
        return cv2.dilate(m, np.ones((k, k), np.uint8))
    m = box_mask(img.shape, boxes, 0.12)
    if keep:
        km = box_mask(img.shape, keep, 0.02)
        m[km > 0] = 0
    return m


def do_inpaint(img, boxes, keep=None, mask_b64=None):
    mask = make_mask(img, boxes, keep, mask_b64)
    sess = None
    try:
        sess = lama()
    except Exception as e:  # 模型坏了就兜底
        print('[textedit] LaMa 加载失败：', e, file=sys.stderr)
    if sess is not None:
        return lama_region(img, mask, sess), 'lama'
    r = min(9, max(3, int(np.median([b['h'] for b in boxes]) * 0.15))) if boxes else 7
    return cv2.inpaint(img, mask, r, cv2.INPAINT_TELEA), 'opencv'


def do_mark(img, boxes):
    mask = box_mask(img.shape, boxes)
    red = img.copy()
    red[mask > 0] = (0.4 * red[mask > 0] + 0.6 * np.array([32, 32, 255])).astype(np.uint8)
    return red


def do_composite(base, patch, boxes, mask_b64=None):
    H, W = base.shape[:2]
    if patch.shape[:2] != (H, W):
        patch = cv2.resize(patch, (W, H), interpolation=cv2.INTER_CUBIC)
    mask = (make_mask(base, boxes, None, mask_b64) if mask_b64 else box_mask(base.shape, boxes, 0.3)).astype(np.float32) / 255.0
    k = max(3, int(min(H, W) / 300) | 1)
    mask = cv2.GaussianBlur(mask, (k * 2 + 1, k * 2 + 1), 0)[:, :, None]
    return (base * (1 - mask) + patch * mask).astype(np.uint8)


# ---------------- 字体子集 ----------------
_sub_cache = {}


def do_subset(fid, text, weight):
    p = font_path(fid)
    if not p:
        raise ValueError('字体不存在：' + fid)
    key = (fid, text, int(weight or 400))
    if key in _sub_cache:
        return _sub_cache[key]
    from fontTools.ttLib import TTFont
    from fontTools import subset
    try:
        import brotli  # noqa: F401
        flavor = 'woff2'
    except Exception:
        flavor = 'woff'   # 没装 brotli 时用 woff（稍大一点）
    # 先裁字（保留可变轴，快），再把裁好的小字体固定到要的粗细
    f = TTFont(p, lazy=True)
    opts = subset.Options()
    opts.layout_features = ['*']
    opts.name_IDs = ['*']
    opts.notdef_outline = True
    opts.hinting = False
    sub = subset.Subsetter(opts)
    sub.populate(text=(text or '') + ' ')
    sub.subset(f)
    var = 'fvar' in f and any(a.axisTag == 'wght' for a in f['fvar'].axes)
    if 'fvar' in f:
        from fontTools.varLib import instancer
        axes = {a.axisTag: a for a in f['fvar'].axes}
        loc = {tag: ax.defaultValue for tag, ax in axes.items()}
        if 'wght' in axes:
            a = axes['wght']
            loc['wght'] = max(a.minValue, min(a.maxValue, float(weight or 400)))
        f = instancer.instantiateVariableFont(f, loc)
    buf = io.BytesIO()
    f.flavor = flavor
    f.save(buf)
    b = {'font': base64.b64encode(buf.getvalue()).decode(), 'variable': var}
    if len(_sub_cache) > 300:
        _sub_cache.clear()
    _sub_cache[key] = b
    return b


# ---------------- HTTP ----------------
class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        pass

    def _send(self, code, obj):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.startswith('/health'):
            self._send(200, {'ok': True, 'ocr': has_ocr(), 'lama': os.path.exists(LAMA_PATH), 'fonts': font_list()})
        else:
            self._send(404, {'error': 'not found'})

    def do_POST(self):
        t0 = time.time()
        try:
            n = int(self.headers.get('Content-Length') or 0)
            if n > 120 * 1024 * 1024:
                raise ValueError('图片太大')
            p = json.loads(self.rfile.read(n) or b'{}')
            path = self.path.split('?')[0]
            if path == '/subset':
                return self._send(200, do_subset(str(p.get('font') or ''), str(p.get('text') or '')[:2000], p.get('weight') or 400))
            with HEAVY:
                if path == '/ocr':
                    img, _ = dec(p['image'])
                    return self._send(200, do_ocr(img))
                if path == '/inpaint':
                    img, alpha = dec(p['image'])
                    out, engine = do_inpaint(img, p.get('boxes') or [], p.get('keep') or None, p.get('mask') or None)
                    return self._send(200, {'image': enc(out, alpha), 'engine': engine, 'ms': int((time.time() - t0) * 1000)})
                if path == '/mark':
                    img, _ = dec(p['image'])
                    return self._send(200, {'image': enc(do_mark(img, p.get('boxes') or []))})
                if path == '/composite':
                    base, alpha = dec(p['base'])
                    patch, _ = dec(p['patch'])
                    return self._send(200, {'image': enc(do_composite(base, patch, p.get('boxes') or [], p.get('mask') or None), alpha)})
            self._send(404, {'error': 'not found'})
        except Exception as e:
            self._send(500, {'error': str(e)[:300]})
        finally:
            ms = int((time.time() - t0) * 1000)
            if ms > 3000:
                print('[textedit] %s 用时 %.1fs' % (self.path, ms / 1000), flush=True)


def warmup():
    """启动后先把 OCR 和 LaMa 模型加载好、各跑一次，用户第一次用就不用等模型加载"""
    t0 = time.time()
    try:
        with HEAVY:
            if not FAKE_OCR and has_ocr():
                img = np.full((120, 400, 3), 245, np.uint8)
                cv2.putText(img, 'warm up 123', (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (20, 20, 20), 3)
                ocr_engine()(img)
            sess = lama()
            if sess is not None:
                img = np.full((300, 300, 3), 200, np.uint8)
                lama_region(img, box_mask(img.shape, [{'cx': 150, 'cy': 150, 'w': 120, 'h': 30}]), sess)
        print('[textedit] 模型预热完成 %.1fs' % (time.time() - t0), flush=True)
    except Exception as e:
        print('[textedit] 预热失败：', e, file=sys.stderr, flush=True)


if __name__ == '__main__':
    os.makedirs(FONT_DIR, exist_ok=True)
    threading.Thread(target=warmup, daemon=True).start()
    srv = ThreadingHTTPServer(('127.0.0.1', PORT), H)
    srv.daemon_threads = True
    print('[textedit] 精准改字服务已启动 127.0.0.1:%d（OCR：%s，LaMa：%s，字体 %d 个）' % (PORT, '有' if has_ocr() else '未安装', '有' if os.path.exists(LAMA_PATH) else '未安装，用 OpenCV 兜底', len(font_list())), flush=True)
    srv.serve_forever()
