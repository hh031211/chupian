#!/usr/bin/env node
'use strict';
// 后台被「只允许这些 IP」锁在外面时，在服务器上执行：
//   YD_CONFIG=/opt/chengtu/shared/config.json node /opt/chengtu/current/tools/admin-unlock.js && pm2 restart chengtu
// 作用：清空后台 IP 白名单（其它设置不动）
process.env.YD_CONFIG = process.env.YD_CONFIG || '/opt/chengtu/shared/config.json';
const S = require('../src/core/settings');
S.load();
const sec = S.get('security') || {};
S.set('security', { ...sec, admin_ip_whitelist: [] });
console.log('✅ 已清空后台 IP 白名单，请执行 pm2 restart chengtu 让网站重新读取设置');
