#!/usr/bin/env node
'use strict';
/**
 * 中转站命令行调用工具（独立使用，不需要启动后端）
 *
 * 配置方式（二选一）：
 *  1) 环境变量：RELAY_BASE_URL、RELAY_API_KEY、RELAY_IMAGE_MODEL(默认 gpt-image-1)、RELAY_IMAGE_MODE(openai|chat|gemini)、
 *              RELAY_CHAT_MODEL(默认 gpt-4o-mini)、RELAY_VIDEO_MODEL(默认 sora-2)
 *  2) 配置文件：--config relay.json（结构同后台「中转站设置」高级 JSON）
 *
 * 用法：
 *   node tools/relay-test.js models
 *   node tools/relay-test.js image  --prompt "白底产品图，一只保温杯" --ratio 1:1 --res 2K --n 1
 *   node tools/relay-test.js edit   --prompt "把背景换成海边" --image ./a.png [--image https://.../b.png] [--mask ./mask.png]
 *   node tools/relay-test.js chat   --prompt "写一句保温杯卖点" [--image ./a.png] [--stream]
 *   node tools/relay-test.js video  --prompt "模特缓慢转身" --image ./a.png --seconds 8
 *
 * 生成的图片/视频保存在当前目录 relay-output/ 下。
 */
const fs = require('node:fs');
const path = require('node:path');
const { RelayClient, computeSize } = require('../src/ai/relay');

const argv = process.argv.slice(2);
const cmd = argv[0];
const get = (k, d = '') => { const i = argv.indexOf('--' + k); return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : d; };
const all = (k) => argv.reduce((a, x, i) => (x === '--' + k && argv[i + 1] ? [...a, argv[i + 1]] : a), []);
const has = (k) => argv.includes('--' + k);

function loadCfg() {
  const file = get('config');
  if (file) return JSON.parse(fs.readFileSync(file, 'utf8'));
  const base = process.env.RELAY_BASE_URL;
  const key = process.env.RELAY_API_KEY;
  if (!base || !key) {
    console.error('请设置环境变量 RELAY_BASE_URL 和 RELAY_API_KEY，或使用 --config relay.json');
    process.exit(1);
  }
  return {
    channels: [{ id: 'main', base_url: base, api_key: key, timeout: 600 }],
    image_models: { m1: { channel: 'main', model: process.env.RELAY_IMAGE_MODEL || 'gpt-image-1', mode: process.env.RELAY_IMAGE_MODE || 'openai', size_strategy: process.env.RELAY_SIZE || 'openai', quality: process.env.RELAY_QUALITY || 'high' } },
    chat_model: { channel: 'main', model: process.env.RELAY_CHAT_MODEL || 'gpt-4o-mini' },
    vision_model: { channel: 'main', model: process.env.RELAY_VISION_MODEL || process.env.RELAY_CHAT_MODEL || 'gpt-4o' },
    video_models: { m1: { channel: 'main', model: process.env.RELAY_VIDEO_MODEL || 'sora-2', mode: process.env.RELAY_VIDEO_MODE || 'openai-video' } },
    retry: 1,
  };
}

const imgInput = (s) => (/^(https?:|data:)/.test(s) ? s : fs.readFileSync(s));

async function save(out, ext) {
  const dir = path.resolve('relay-output');
  fs.mkdirSync(dir, { recursive: true });
  if (out.url && !out.buffer) { console.log('  远程地址：', out.url); return; }
  const f = path.join(dir, `${Date.now()}_${Math.random().toString(36).slice(2, 6)}.${ext || (out.mimetype || '').split('/')[1] || 'png'}`);
  fs.writeFileSync(f, out.buffer);
  console.log('  已保存：', f);
}

(async () => {
  if (!cmd || has('help')) { console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]); return; }
  const relay = new RelayClient(loadCfg(), { log: (e) => console.log(`  [${e.kind}] ${e.model} ${e.ok ? '成功' : '失败'} ${e.ms}ms ${e.error || ''}`) });
  const t0 = Date.now();
  if (cmd === 'models') {
    const list = await relay.listModels();
    console.log(list.join('\n'));
  } else if (cmd === 'image' || cmd === 'edit') {
    const images = all('image').map(imgInput);
    if (cmd === 'edit' && !images.length) throw new Error('edit 需要 --image');
    const ratio = get('ratio', '1:1');
    console.log(`→ ${images.length ? '改图' : '文生图'}  比例 ${ratio}  尺寸参数 ${computeSize(ratio, get('res', '2K'), (relay.cfg.image_models.m1 || {}).size_strategy)}`);
    const outs = await relay.image({ modelKey: get('model', 'm1'), prompt: get('prompt', '一只可爱的橘猫，产品摄影风格'), images, ratio, resolution: get('res', '2K'), n: Number(get('n', '1')), mask: get('mask') ? imgInput(get('mask')) : undefined });
    for (const o of outs) await save(o);
  } else if (cmd === 'chat') {
    const images = all('image').map(imgInput);
    const text = await relay.chat({ prompt: get('prompt', '你好'), system: get('system'), images, onDelta: has('stream') ? (d) => process.stdout.write(d) : undefined });
    if (!has('stream')) console.log(text); else console.log();
  } else if (cmd === 'video') {
    const img = get('image');
    const out = await relay.video({ modelKey: get('model', 'm1'), prompt: get('prompt', '镜头缓慢推进'), image: img ? imgInput(img) : null, seconds: Number(get('seconds', '8')), ratio: get('ratio', '9:16'), onProgress: (p, s) => process.stdout.write(`\r  进度 ${p}% ${s}   `) });
    console.log();
    await save(out, 'mp4');
  } else {
    console.log('未知命令：' + cmd + '（可用：models / image / edit / chat / video）');
  }
  console.log(`完成，用时 ${((Date.now() - t0) / 1000).toFixed(1)}s`);
})().catch((e) => { console.error('✗ ' + e.message); process.exit(1); });
