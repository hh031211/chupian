#!/usr/bin/env bash
# 安装「精准改字」服务：OCR 识别文字（RapidOCR）+ LaMa 擦除模型 + 免费商用字体。可重复执行。
#   用法：bash /opt/chengtu/current/tools/setup-textedit.sh
# 装在 /opt/chengtu/shared/textedit（venv、模型、字体），用 pm2 进程 chengtu-text 运行，只监听本机 127.0.0.1:8361
# 卸载 / 停用：pm2 delete chengtu-text && pm2 save
set -euo pipefail
CT_HOME="${CT_HOME:-/opt/chengtu}"
TE="$CT_HOME/shared/textedit"
CUR="$CT_HOME/current"
say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "请用 root 执行"
[ -f "$CUR/tools/textedit/server.py" ] || die "找不到 $CUR/tools/textedit/server.py，请先部署 1.24.0 或更新版本"
mkdir -p "$TE/fonts/custom"

say "1/5 安装 Python 运行环境"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip libgl1 libglib2.0-0 curl >/dev/null
[ -x "$TE/venv/bin/python" ] || python3 -m venv "$TE/venv"
PIP="$TE/venv/bin/pip"
$PIP install -q -U pip >/dev/null 2>&1 || true

say "2/5 安装 OCR 识别、图像处理、字体工具（约 1~3 分钟）"
PKGS="rapidocr-onnxruntime onnxruntime numpy pillow fonttools brotli"
$PIP install -q $PKGS || $PIP install -q -i https://pypi.tuna.tsinghua.edu.cn/simple $PKGS || die "Python 依赖安装失败，请截图发给开发"
"$TE/venv/bin/python" -c "import rapidocr_onnxruntime, onnxruntime, cv2, numpy, PIL, fontTools, brotli; print('  依赖 OK')"

say "3/5 下载 LaMa 擦除模型（约 200MB）"
if [ ! -s "$TE/lama_fp32.onnx" ]; then
  ok=0
  for u in "https://huggingface.co/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx" "https://hf-mirror.com/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx"; do
    if curl -fL --retry 2 --connect-timeout 20 -o "$TE/lama_fp32.onnx.part" "$u"; then mv "$TE/lama_fp32.onnx.part" "$TE/lama_fp32.onnx"; ok=1; break; fi
  done
  [ "$ok" = 1 ] && echo "  模型已下载" || { rm -f "$TE/lama_fp32.onnx.part"; echo "  ⚠️ 模型下载失败：先用 OpenCV 擦除（简单背景够用），之后可重新执行本脚本"; }
else echo "  模型已存在"; fi

say "4/5 下载免费商用字体（Google Fonts 开源字体，约 80MB）"
G="https://raw.githubusercontent.com/google/fonts/main/ofl"
while read -r path file; do
  [ -s "$TE/fonts/$file" ] && continue
  if curl -fsSL --retry 2 --connect-timeout 20 -o "$TE/fonts/$file.part" "$G/$path"; then mv "$TE/fonts/$file.part" "$TE/fonts/$file"; echo "  ✓ $file"; else rm -f "$TE/fonts/$file.part"; echo "  ⚠️ $file 下载失败（跳过）"; fi
done <<'LIST'
notosanssc/NotoSansSC%5Bwght%5D.ttf NotoSansSC[wght].ttf
notoserifsc/NotoSerifSC%5Bwght%5D.ttf NotoSerifSC[wght].ttf
zcoolkuaile/ZCOOLKuaiLe-Regular.ttf ZCOOLKuaiLe-Regular.ttf
zcoolqingkehuangyou/ZCOOLQingKeHuangYou-Regular.ttf ZCOOLQingKeHuangYou-Regular.ttf
zcoolxiaowei/ZCOOLXiaoWei-Regular.ttf ZCOOLXiaoWei-Regular.ttf
mashanzheng/MaShanZheng-Regular.ttf MaShanZheng-Regular.ttf
zhimangxing/ZhiMangXing-Regular.ttf ZhiMangXing-Regular.ttf
longcang/LongCang-Regular.ttf LongCang-Regular.ttf
montserrat/Montserrat%5Bwght%5D.ttf Montserrat[wght].ttf
playfairdisplay/PlayfairDisplay%5Bwght%5D.ttf PlayfairDisplay[wght].ttf
bebasneue/BebasNeue-Regular.ttf BebasNeue-Regular.ttf
LIST
echo "  （有正版授权的商用字体，可以把 .ttf / .otf 放进 $TE/fonts/custom/，重启服务后可选）"

say "5/5 启动服务（pm2：chengtu-text）"
pm2 delete chengtu-text >/dev/null 2>&1 || true
TE_DIR="$TE" pm2 start "$CUR/tools/textedit/server.py" --name chengtu-text --interpreter "$TE/venv/bin/python" --max-memory-restart 2G >/dev/null
pm2 save >/dev/null
for i in $(seq 1 30); do curl -s -o /dev/null --max-time 2 http://127.0.0.1:8361/health && break; sleep 1; done
H="$(curl -s --max-time 3 http://127.0.0.1:8361/health || true)"
[ -n "$H" ] || die "服务没有启动，日志：pm2 logs chengtu-text --lines 40"
echo "  $H" | cut -c1-300

# 自检：画一张带字的图识别一下
"$TE/venv/bin/python" - "$TE" <<'PY' || echo "  ⚠️ OCR 自检没通过（服务已启动，可先试用）"
import sys, os, io, base64, json, urllib.request
from PIL import Image, ImageDraw, ImageFont
te = sys.argv[1]
im = Image.new('RGB', (640, 200), (250, 240, 225)); d = ImageDraw.Draw(im)
fp = os.path.join(te, 'fonts', 'NotoSansSC[wght].ttf')
f = ImageFont.truetype(fp, 64) if os.path.exists(fp) else ImageFont.load_default()
d.text((40, 60), '出片儿测试', font=f, fill=(200, 30, 40))
b = io.BytesIO(); im.save(b, 'PNG')
r = urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8361/ocr', data=json.dumps({'image': base64.b64encode(b.getvalue()).decode()}).encode()), timeout=120)
items = json.loads(r.read())['items']
print('  OCR 自检：', [i['text'] for i in items])
PY
printf '\n\033[1;32m✓ 精准改字服务已安装\033[0m（以后部署新版本会自动重启它）\n'
