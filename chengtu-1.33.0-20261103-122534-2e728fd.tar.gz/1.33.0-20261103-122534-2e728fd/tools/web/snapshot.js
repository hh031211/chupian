'use strict';
/**
 * 首屏快照：打包时用无头浏览器把首页第一屏（标题、模式切换、创作框）渲染一遍，存成静态 HTML 放进 index.html。
 * 访客打开首页时，HTML 一到就能看到完整界面，不用等 JS 下载、执行完（JS 好了再无缝接管）。
 *
 * 只在打包机上有 playwright 时生成；没有就跳过（页面照常先显示加载圈），不影响发布。
 */
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.webmanifest': 'application/manifest+json' };

function serve(dir) {
  const server = http.createServer((req, res) => {
    const p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
    if (p.startsWith('/ydapi/')) { res.writeHead(200, { 'content-type': 'application/json' }); res.end('{"code":0,"msg":"snapshot","data":null}'); return; }
    let f = path.join(dir, p);
    if (!f.startsWith(dir) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = /\.\w{2,5}$/.test(p) ? '' : path.join(dir, 'index.html');
    if (!f || !fs.existsSync(f)) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
    res.end(fs.readFileSync(f));
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server)));
}

/** 返回 { d: 电脑版 HTML, m: 手机版 HTML }；生成不了返回 null */
async function snapshot(dir, { log = () => {} } = {}) {
  let chromium;
  try { ({ chromium } = require('playwright')); } catch { log('  首屏快照：本机没有 playwright，跳过'); return null; }
  const server = await serve(path.resolve(dir));
  const base = `http://127.0.0.1:${server.address().port}`;
  let browser;
  try {
    browser = await chromium.launch();
    const out = {};
    for (const [k, vp] of [['d', { width: 1440, height: 900 }], ['m', { width: 430, height: 900 }]]) {
      const page = await browser.newPage({ viewport: vp });
      await page.goto(base + '/', { waitUntil: 'load', timeout: 20000 });
      await page.waitForSelector('.sx-home .sx-comp', { timeout: 15000 });
      await page.waitForTimeout(600);
      out[k] = await page.evaluate(() => {
        const app = document.getElementById('app').cloneNode(true);
        app.querySelectorAll('.sx-feed, .sx-foot--end, .sx-backtop, .sx-drop, .ct-toast, [role=dialog], script, noscript').forEach((n) => n.remove());
        app.querySelectorAll('textarea').forEach((t) => { t.setAttribute('readonly', ''); t.removeAttribute('id'); });
        app.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
        return app.innerHTML.trim();
      });
      await page.close();
      if (!out[k] || !/sx-comp/.test(out[k])) throw new Error('首页没渲染出来');
    }
    log(`  首屏快照：电脑 ${(out.d.length / 1024).toFixed(1)}KB，手机 ${(out.m.length / 1024).toFixed(1)}KB`);
    return out;
  } catch (e) {
    log('  首屏快照生成失败，跳过：' + e.message);
    return null;
  } finally {
    if (browser) await browser.close().catch(() => {});
    server.close();
  }
}

/** 把快照放进 index.html：首页（且是中文界面）直接显示快照，其余页面照旧 */
function inject(html, snap) {
  if (!snap) return html;
  const esc = (s) => s.replace(/<\/template/gi, '<\\/template');
  const pick = "(function(){try{var d=document.documentElement;if(location.pathname!=='/'||/[?&](s|t|canvas)=/.test(location.search))return;var l=localStorage.getItem('yd.lang.v1');if(l&&l!=='zh-CN')return;var t=document.getElementById(innerWidth>=768?'ct-snap-d':'ct-snap-m');var a=document.getElementById('app');if(!t||!a)return;d.classList.add('ctx-snap','ctx-sx','ctx-home');if(innerWidth<768)d.classList.add('ctx-mtop');if(localStorage.getItem('yd.user.v1'))d.classList.add('ctx-snap-auth');a.innerHTML='';a.appendChild(t.content.cloneNode(true));try{var b=JSON.parse(document.getElementById('ct-boot').textContent);var im=(b.models&&b.models.image)||[];var o={};try{o=JSON.parse(localStorage.getItem('ct.home.opts.v2')||'{}')}catch(e){}var i=0;for(var k=0;k<im.length;k++)if(im[k].key===o.model)i=k;var m=im[i];var p=a.querySelector('.sx-bar__l .sx-pill');if(m&&p&&(!o.mode||o.mode==='chat')&&o.kind!=='video'){var lb=p.querySelector('.sx-pill__t'),ic=p.querySelector('.sx-opt__ico');if(lb)lb.textContent=m.label;var w=String(m.label||'').replace(/\\s+/g,''),x=w.match(/[A-Za-z]+|\\d+(\\.\\d+)?/);if(ic){ic.textContent=(x&&x[0].length<=4?x[0]:w.slice(0,2)).slice(0,4);var P=[['#ff9a5a','#ee4f8b'],['#7b8cff','#41c7c7'],['#f6c56b','#e2734a'],['#5bd1a0','#2f7fd8'],['#c58cff','#5b5bd6'],['#ff6f91','#ff9671']][i%6];ic.style.background='linear-gradient(135deg, '+P[0]+', '+P[1]+')';}}}catch(e){}}catch(e){}})();";
  const block = `<template id="ct-snap-d">${esc(snap.d)}</template><template id="ct-snap-m">${esc(snap.m)}</template>\n`
    + '<style>html.ctx-snap #app *{animation-delay:-30s!important}html.ctx-snap-auth #app .sx-login{visibility:hidden}</style>\n'
    + `<script>${pick}</script>\n`;
  const at = html.indexOf('<script type="module"');
  if (at < 0 || html.indexOf('<div id="app">') < 0) return html;
  return html.slice(0, at) + block + '    ' + html.slice(at);
}

module.exports = { snapshot, inject };
