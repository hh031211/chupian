#!/usr/bin/env node
'use strict';
/**
 * 构建前台到一个全新目录。不修改任何输入文件。
 *
 *   node tools/web/build.js --out build/web            # 输出目录必须不存在
 *   node tools/web/build.js --out build/web --app frontend/dist
 *
 * 输入：frontend/dist/（cd frontend && npm install && npm run build）、public/brand/
 * 输出：
 *   index.html                所有页面地址都返回它（= app/index.html）
 *   app/…                     前端产物（JS / CSS / 素材库数据）
 *   brand/…                   Logo、图标、客服二维码
 *   sw.js                     清掉旧版网站在访客浏览器里注册的离线缓存（旧版用过 Service Worker）
 *   manifest.webmanifest、robots.txt
 *   ct-tools.json             工具清单（后台「工具封面」用）
 *   build-info.json、files.sha256
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..', '..');
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
function listFiles(dir, base = dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...listFiles(p, base)); else out.push(path.relative(base, p).split(path.sep).join('/'));
  }
  return out.sort();
}
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}

/** 离线缓存（Service Worker）：让再次打开 / 刷新网站秒开
 *  - /app/assets/*（带内容哈希的 JS / CSS）：缓存优先，永不过期
 *  - 前台页面地址：先用缓存里的页面框架秒开，同时后台取最新的，下次打开就是新版
 *  - 接口、图片、后台等一律不经过缓存
 *  出问题时把 SW_KILL 发出去即可让所有访客清掉缓存 */
function swCode(routes) {
  const res = routes.map((r) => '^' + r.replace(/:[a-z]+/gi, '[^/]+').replace(/\//g, '\\/') + '\\/?$');
  return `// 出片儿 离线缓存：再次打开 / 刷新秒开（由 tools/web/build.js 生成）
const SHELL = 'ct-shell-v1', ASSETS = 'ct-assets-v1';
const ROUTES = [${res.map((x) => `/${x}/`).join(', ')}];
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== SHELL && k !== ASSETS) await caches.delete(k);
    await self.clients.claim();
  })());
});
self.addEventListener('message', (e) => {
  if (e.data === 'ct-clear') e.waitUntil(Promise.all([caches.delete(SHELL), caches.delete(ASSETS)]));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== self.location.origin) return;
  if (u.pathname.startsWith('/app/assets/')) {
    e.respondWith((async () => {
      const c = await caches.open(ASSETS);
      const hit = await c.match(req, { ignoreSearch: true });
      if (hit) return hit;
      const r = await fetch(req);
      if (r.ok) c.put(req, r.clone());
      return r;
    })());
    return;
  }
  if (req.mode === 'navigate' && ROUTES.some((x) => x.test(u.pathname))) {
    e.respondWith((async () => {
      const c = await caches.open(SHELL);
      const hit = await c.match('/__shell');
      const entry = (t) => (/\/app\/assets\/app-[\w-]+\.js/.exec(t) || [''])[0];
      const net = fetch(req).then(async (r) => {
        if (r.ok && (r.headers.get('content-type') || '').includes('text/html')) {
          await c.put('/__shell', r.clone());
          // 缓存里是旧版本：告诉页面有新版（页面还没被操作过就自动刷新一次）
          if (hit) {
            try {
              const [a, b] = await Promise.all([hit.clone().text(), r.clone().text()]);
              if (entry(a) && entry(b) && entry(a) !== entry(b)) for (const cl of await self.clients.matchAll({ type: 'window' })) cl.postMessage('ct-new-version');
            } catch (err) { /* ignore */ }
          }
        }
        return r;
      });
      if (hit) { e.waitUntil(net.catch(() => {})); return hit.clone(); }
      return net;
    })());
  }
});
`;
}

const SW_KILL = `// 旧版网站注册过离线缓存（Service Worker）。新版不再使用：清空缓存并注销自己，然后刷新已打开的页面。
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) await caches.delete(k);
    await self.registration.unregister();
    for (const c of await self.clients.matchAll({ type: 'window' })) c.navigate(c.url);
  })());
});
`;

async function toolList() {
  const { TOOLS } = await import(require('node:url').pathToFileURL(path.join(ROOT, 'frontend', 'src', 'data', 'tools-list.mjs')).href);
  return TOOLS.map((t) => ({ slug: t.key, cat: 'tools', board: '工具箱', name: t.name, desc: t.desc, tip: '', cover: '' }));
}

async function buildWeb({ out, appDist = path.join(ROOT, 'frontend', 'dist'), log = console.log } = {}) {
  out = path.resolve(out);
  if (fs.existsSync(out)) throw new Error('输出目录已存在：' + out);
  const manifestFile = path.join(appDist, '.vite', 'manifest.json');
  if (!fs.existsSync(manifestFile)) throw new Error(`找不到前端构建产物：${manifestFile}\n请先执行：cd frontend && npm install && npm run build`);
  const manifest = JSON.parse(fs.readFileSync(manifestFile, 'utf8'));
  const appEntry = manifest['index.html'];
  if (!appEntry) throw new Error('前端构建产物不完整（缺少 index.html 入口）');
  const appPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'frontend', 'package.json'), 'utf8'));

  const tmp = `${out}.tmp-${process.pid}`;
  fs.rmSync(tmp, { recursive: true, force: true });
  try {
    copyDir(appDist, path.join(tmp, 'app'));
    fs.rmSync(path.join(tmp, 'app', '.vite'), { recursive: true, force: true });
    // 1.10.x 的部署脚本健康检查要求页面里出现「/assets/index-」，留一行注释让旧脚本也能部署新版
    let idx = fs.readFileSync(path.join(tmp, 'app', 'index.html'), 'utf8').replace('</head>', '<!-- compat:/assets/index- -->\n</head>');
    // 入口 JS 静态引用的公共分块：和入口一起并行下载（不用等入口下完再发现）
    const entryJs = fs.readFileSync(path.join(tmp, 'app', appEntry.file), 'utf8');
    const pre = [...new Set([...entryJs.matchAll(/from\s*"(\/app\/assets\/[^"]+\.js)"/g)].map((m) => m[1]))];
    idx = idx.replace('</head>', pre.map((h) => `  <link rel="modulepreload" crossorigin href="${h}">\n`).join('') + '</head>');
    fs.writeFileSync(path.join(tmp, 'index.html'), idx);
    copyDir(path.join(ROOT, 'public', 'brand'), path.join(tmp, 'brand'));
    const { APP_ROUTES } = await import(require('node:url').pathToFileURL(path.join(ROOT, 'frontend', 'src', 'app-routes.js')).href);
    fs.writeFileSync(path.join(tmp, 'sw.js'), process.env.CT_SW_OFF ? SW_KILL : swCode(APP_ROUTES.map((r) => r.path)));
    fs.writeFileSync(path.join(tmp, 'robots.txt'), 'User-agent: *\nAllow: /\nDisallow: /account\nDisallow: /projects\n');
    fs.writeFileSync(path.join(tmp, 'manifest.webmanifest'), JSON.stringify({
      name: '出片儿', short_name: '出片儿', start_url: '/', scope: '/', display: 'standalone', background_color: '#0a0a0c', theme_color: '#0a0a0c', lang: 'zh-CN',
      icons: [{ src: '/brand/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: '/brand/icon-512.png', sizes: '512x512', type: 'image/png' }],
    }, null, 2) + '\n');
    log(`  前端：v${appPkg.version}，入口 ${appEntry.file}`);
    // 首屏快照（打包机有 playwright 才生成；CT_NO_SNAP=1 关闭）
    if (!process.env.CT_NO_SNAP) {
      const snap = await require('./snapshot').snapshot(tmp, { log });
      if (snap) fs.writeFileSync(path.join(tmp, 'index.html'), require('./snapshot').inject(fs.readFileSync(path.join(tmp, 'index.html'), 'utf8'), snap));
    }
    fs.writeFileSync(path.join(tmp, 'ct-tools.json'), JSON.stringify(await toolList()) + '\n');
    const build = sha256(fs.readFileSync(path.join(tmp, 'index.html'))).slice(0, 8);
    const info = { build, builtAt: new Date().toISOString(), app: { version: appPkg.version, entry: appEntry.file } };
    fs.writeFileSync(path.join(tmp, 'build-info.json'), JSON.stringify(info, null, 2) + '\n');
    // 自检：index.html 引用的文件都存在
    const html = fs.readFileSync(path.join(tmp, 'index.html'), 'utf8');
    for (const m of html.matchAll(/(?:src|href)="(\/app\/assets\/[^"?]+)/g)) {
      if (!fs.existsSync(path.join(tmp, m[1]))) throw new Error(`index.html 引用的文件不存在：${m[1]}`);
    }
    writeSums(tmp);
    fs.renameSync(tmp, out);
    return { out, ...info };
  } catch (e) {
    fs.rmSync(tmp, { recursive: true, force: true });
    throw e;
  }
}

function writeSums(dir) {
  const lines = listFiles(dir).filter((f) => f !== 'files.sha256').map((f) => `${sha256(fs.readFileSync(path.join(dir, f)))}  ${f}`);
  fs.writeFileSync(path.join(dir, 'files.sha256'), lines.join('\n') + '\n');
}

/** 校验目录与 files.sha256 一致；返回问题列表（空 = 完好） */
function verifySums(dir) {
  const file = path.join(dir, 'files.sha256');
  if (!fs.existsSync(file)) return ['缺少 files.sha256'];
  const problems = [];
  const want = new Map(fs.readFileSync(file, 'utf8').trim().split('\n').map((l) => { const i = l.indexOf('  '); return [l.slice(i + 2), l.slice(0, i)]; }));
  for (const [f, h] of want) {
    const p = path.join(dir, f);
    if (!fs.existsSync(p)) problems.push('缺少 ' + f);
    else if (sha256(fs.readFileSync(p)) !== h) problems.push('被改动 ' + f);
  }
  for (const f of listFiles(dir)) if (f !== 'files.sha256' && !want.has(f)) problems.push('多出 ' + f);
  return problems;
}

module.exports = { buildWeb, verifySums, writeSums, listFiles, copyDir, sha256 };

if (require.main === module) {
  const args = process.argv.slice(2);
  const opt = (k) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : ''; };
  const out = opt('out');
  if (!out) { console.error('用法：node tools/web/build.js --out <输出目录> [--app frontend/dist]'); process.exit(1); }
  buildWeb({ out, appDist: opt('app') ? path.resolve(opt('app')) : undefined })
    .then((r) => console.log(`✅ 前台构建完成：${r.out}（构建号 ${r.build}）`))
    .catch((e) => { console.error('❌ 构建失败：' + e.message); process.exit(1); });
}
