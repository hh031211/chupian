#!/usr/bin/env node
'use strict';
/**
 * 出片儿 · 版本化发布与回滚
 *
 * 服务器目录（默认 /opt/chengtu，可用环境变量 CT_HOME 或 --home 指定）：
 *   releases/<版本>/      每个版本一个只读目录：后端代码 + web/（构建好的前台）+ release.json + SHA256SUMS
 *   current -> releases/<版本>   当前版本（软链接，切换是原子操作）
 *   shared/config.json    正式配置（数据库、上传目录、前台目录都是绝对路径）
 *   shared/data/          数据库、上传文件、品牌图……（所有版本共用，发布不会动它）
 *   shared/ecosystem.config.cjs  pm2 配置（运行 current/src/server.js）
 *   backups/<时间>/       每次切换前的数据库快照 + 配置副本
 *   deploy.log            发布记录
 *
 * 命令：
 *   本地 / CI：
 *     node tools/release.js pack [--out dist]          构建前台并打成发布包 chengtu-<版本>.tar.gz
 *   服务器：
 *     node tools/release.js deploy <发布包>            = install + verify + activate（任一步失败都不会切换）
 *     node tools/release.js install <发布包>           解压到 releases/<版本>，校验文件完整性
 *     node tools/release.js verify <版本>              校验文件 + 在独立沙箱里跑接口测试（不碰正式数据）
 *     node tools/release.js activate <版本>            备份数据库 → 切换 → 重启 → 健康检查；失败自动切回原版本
 *     node tools/release.js rollback [<版本>] [--restore-db <备份目录名>]   回到上一个（或指定）版本；可同时恢复数据库快照
 *     node tools/release.js status | list | backups
 *     node tools/release.js migrate --from /root/yuduo-server --web /root/dist-ip   旧目录结构一次性迁移
 *
 * 服务管理（shared/release.config.json 的 service）：
 *   { "type": "pm2", "name": "chengtu" }（默认） | { "type": "systemd", "unit": "chengtu" } | { "type": "pidfile" }（测试用）
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawn, spawnSync, execFileSync } = require('node:child_process');

const ROOT = path.resolve(__dirname, '..');
const args = process.argv.slice(2);
const cmd = args[0];
const opt = (k, d = '') => { const i = args.indexOf('--' + k); return i >= 0 && args[i + 1] && !args[i + 1].startsWith('--') ? args[i + 1] : d; };
const flag = (k) => args.includes('--' + k);
const VALUE_OPTS = new Set(['--home', '--out', '--app', '--restore-db', '--from', '--web', '--old-pm2']);
const positional = args.slice(1).filter((a, i, arr) => !a.startsWith('--') && !VALUE_OPTS.has(arr[i - 1]));

const HOME = path.resolve(opt('home') || process.env.CT_HOME || '/opt/chengtu');
const P = {
  releases: path.join(HOME, 'releases'),
  current: path.join(HOME, 'current'),
  shared: path.join(HOME, 'shared'),
  config: path.join(HOME, 'shared', 'config.json'),
  data: path.join(HOME, 'shared', 'data'),
  releaseCfg: path.join(HOME, 'shared', 'release.config.json'),
  ecosystem: path.join(HOME, 'shared', 'ecosystem.config.cjs'),
  backups: path.join(HOME, 'backups'),
  log: path.join(HOME, 'deploy.log'),
  pid: path.join(HOME, 'shared', 'server.pid'),
};

// 打进发布包的内容（运行所需 + 验证所需）。不包含 data/、config.json、node_modules
const PACK_ITEMS = ['src', 'public', 'tools', 'tests', 'docs', 'deploy', 'package.json', 'config.example.json', 'ecosystem.config.js', 'README.md'];
const PACK_EXCLUDE = [/^tests\/e2e\//, /\.DS_Store$/, /^public\/ct-ui\//];

const sha256File = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const now = () => new Date().toISOString();
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

function log(msg) {
  console.log(msg);
  try { fs.mkdirSync(HOME, { recursive: true }); fs.appendFileSync(P.log, `${now()} ${msg}\n`); } catch { /* 本地打包时没有 HOME */ }
}
function die(msg, code = 1) { console.error('❌ ' + msg); process.exit(code); }

function listFiles(dir, base = dir) {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isSymbolicLink()) continue;
    if (e.isDirectory()) out.push(...listFiles(p, base)); else out.push(path.relative(base, p).split(path.sep).join('/'));
  }
  return out.sort();
}
function writeSums(dir) {
  const files = listFiles(dir).filter((f) => f !== 'SHA256SUMS');
  fs.writeFileSync(path.join(dir, 'SHA256SUMS'), files.map((f) => `${sha256File(path.join(dir, f))}  ${f}`).join('\n') + '\n');
  return files.length;
}
function checkSums(dir) {
  const file = path.join(dir, 'SHA256SUMS');
  if (!fs.existsSync(file)) return ['缺少 SHA256SUMS'];
  const problems = [];
  const want = new Map(fs.readFileSync(file, 'utf8').trim().split('\n').map((l) => [l.slice(66), l.slice(0, 64)]));
  for (const [f, h] of want) {
    const p = path.join(dir, f);
    if (!fs.existsSync(p)) problems.push('缺少 ' + f);
    else if (sha256File(p) !== h) problems.push('被改动 ' + f);
  }
  for (const f of listFiles(dir)) if (f !== 'SHA256SUMS' && !want.has(f)) problems.push('多出 ' + f);
  return problems;
}

function readJson(f, d = null) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } }
function currentVersion() { try { return path.basename(fs.realpathSync(P.current)); } catch { return ''; } }
function releases() {
  if (!fs.existsSync(P.releases)) return [];
  return fs.readdirSync(P.releases).filter((v) => fs.existsSync(path.join(P.releases, v, 'release.json')))
    .map((v) => ({ v, info: readJson(path.join(P.releases, v, 'release.json'), {}) }))
    .sort((a, b) => String(a.info.createdAt).localeCompare(String(b.info.createdAt)));
}
function releaseDir(v) {
  const d = path.join(P.releases, v);
  if (!v || !fs.existsSync(path.join(d, 'release.json'))) die('版本不存在：' + v + '（node tools/release.js list 查看）');
  return d;
}

// ------------------------------------------------------------------ pack
async function pack() {
  const outDir = path.resolve(opt('out', path.join(ROOT, 'dist')));
  const pkg = readJson(path.join(ROOT, 'package.json'));
  let commit = '';
  try { commit = execFileSync('git', ['rev-parse', '--short', 'HEAD'], { cwd: ROOT, stdio: ['ignore', 'pipe', 'ignore'] }).toString().trim(); } catch { /* 非 git 目录 */ }
  const version = `${pkg.version}-${stamp()}${commit ? '-' + commit : ''}`;
  const stage = fs.mkdtempSync(path.join(os.tmpdir(), 'chengtu-pack-'));
  const dir = path.join(stage, version);
  try {
    console.log(`==> 打包 ${version}`);
    fs.mkdirSync(dir);
    for (const item of PACK_ITEMS) {
      const src = path.join(ROOT, item);
      if (!fs.existsSync(src)) continue;
      if (fs.statSync(src).isDirectory()) {
        for (const f of listFiles(src)) {
          const rel = `${item}/${f}`;
          if (PACK_EXCLUDE.some((re) => re.test(rel))) continue;
          fs.mkdirSync(path.dirname(path.join(dir, rel)), { recursive: true });
          fs.copyFileSync(path.join(src, f), path.join(dir, rel));
        }
      } else fs.copyFileSync(src, path.join(dir, item));
    }
    console.log('==> 构建前台');
    const { buildWeb } = require('./web/build');
    const web = await buildWeb({ out: path.join(dir, 'web'), appDist: opt('app') ? path.resolve(opt('app')) : undefined });
    const info = { version, createdAt: now(), commit, node: process.version, backend: pkg.version, web: { build: web.build, app: web.app.version } };
    fs.writeFileSync(path.join(dir, 'release.json'), JSON.stringify(info, null, 2) + '\n');
    const n = writeSums(dir);
    fs.mkdirSync(outDir, { recursive: true });
    const file = path.join(outDir, `chengtu-${version}.tar.gz`);
    execFileSync('tar', ['-czf', file, '-C', stage, version]);
    fs.writeFileSync(file + '.sha256', `${sha256File(file)}  ${path.basename(file)}\n`);
    console.log(`✅ 发布包：${file}（${n} 个文件，${(fs.statSync(file).size / 1048576).toFixed(1)} MB）`);
    return file;
  } finally {
    fs.rmSync(stage, { recursive: true, force: true });
  }
}

// ------------------------------------------------------------------ install / verify
function install(pkgFile) {
  if (!pkgFile || !fs.existsSync(pkgFile)) die('找不到发布包：' + pkgFile);
  const sumFile = pkgFile + '.sha256';
  if (fs.existsSync(sumFile)) {
    const want = fs.readFileSync(sumFile, 'utf8').split(/\s+/)[0];
    if (sha256File(pkgFile) !== want) die('发布包校验失败（下载不完整或被改动）：' + pkgFile);
  }
  fs.mkdirSync(P.releases, { recursive: true });
  const tmp = fs.mkdtempSync(path.join(P.releases, '.incoming-'));
  try {
    execFileSync('tar', ['-xzf', pkgFile, '-C', tmp]);
    const [v] = fs.readdirSync(tmp);
    const src = path.join(tmp, v);
    const info = readJson(path.join(src, 'release.json'));
    if (!info || info.version !== v) die('发布包格式不正确（缺少 release.json）');
    const problems = checkSums(src);
    if (problems.length) die('发布包文件校验失败：\n  ' + problems.slice(0, 10).join('\n  '));
    const dst = path.join(P.releases, v);
    if (fs.existsSync(dst)) {
      if (!checkSums(dst).length) { log(`= 版本 ${v} 已安装，跳过`); return v; }
      die(`版本目录已存在且内容不一致：${dst}`);
    }
    fs.renameSync(src, dst);
    makeReadOnly(dst);
    log(`+ 已安装 ${v}`);
    return v;
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}
function makeReadOnly(dir) {
  for (const f of listFiles(dir)) { try { fs.chmodSync(path.join(dir, f), 0o444); } catch { /* ignore */ } }
}

function verify(v) {
  const dir = releaseDir(v);
  const problems = checkSums(dir);
  if (problems.length) { log(`✗ ${v} 文件校验失败：${problems.slice(0, 5).join('；')}`); return false; }
  log(`✓ ${v} 文件完整（${listFiles(dir).length} 个）`);
  if (flag('skip-tests')) { log('! 已跳过沙箱测试（--skip-tests）'); return true; }
  // 用该版本自己的代码，在临时目录 + 临时数据库 + 模拟中转站里跑接口测试；不读写 shared/data
  log(`… ${v} 沙箱接口测试`);
  const r = spawnSync(process.execPath, [path.join(dir, 'tests', 'run.js'), 'api'], { cwd: os.tmpdir(), stdio: 'inherit', env: { ...process.env, CT_HOME: '' } });
  if (r.status !== 0) { log(`✗ ${v} 沙箱测试未通过`); return false; }
  log(`✓ ${v} 沙箱测试通过`);
  return true;
}

// ------------------------------------------------------------------ 配置 / 服务
function releaseConfig() {
  return { service: { type: 'pm2', name: 'chengtu' }, healthTimeout: 40, ...(readJson(P.releaseCfg, {}) || {}) };
}
function prodConfig() {
  const c = readJson(P.config);
  if (!c) die('缺少正式配置：' + P.config + '（首次使用请先执行 migrate）');
  return c;
}
/** 正式配置里路径一律用绝对路径；前台目录固定指向 current/web */
function normalizeConfig(c) {
  const out = { ...c };
  out.dbFile = path.resolve(P.shared, c.dbFile && path.isAbsolute(c.dbFile) ? c.dbFile : path.join('data', path.basename(c.dbFile || 'yuduo.db')));
  out.uploadDir = path.resolve(P.shared, c.uploadDir && path.isAbsolute(c.uploadDir) ? c.uploadDir : path.join('data', 'uploads'));
  out.frontendDist = path.join(P.current, 'web');
  delete out.testSandbox;
  return out;
}

function writeEcosystem() {
  const svc = releaseConfig().service;
  const content = `// 由 tools/release.js 生成：pm2 始终运行 current（当前版本）里的代码
module.exports = {
  apps: [{
    name: ${JSON.stringify(svc.name || 'chengtu')},
    script: ${JSON.stringify(path.join(P.current, 'src', 'server.js'))},
    cwd: ${JSON.stringify(P.shared)},
    node_args: '--no-warnings',
    instances: 1,            // SQLite + 内置任务队列：保持单实例
    autorestart: true,
    max_memory_restart: '1500M',
    env: { NODE_ENV: 'production', YD_CONFIG: ${JSON.stringify(P.config)} },
    out_file: ${JSON.stringify(path.join(P.data, 'logs', 'out.log'))},
    error_file: ${JSON.stringify(path.join(P.data, 'logs', 'error.log'))},
    time: true,
  }],
};
`;
  fs.writeFileSync(P.ecosystem, content);
}

function run(bin, a) {
  const r = spawnSync(bin, a, { stdio: 'inherit' });
  if (r.status !== 0) throw new Error(`${bin} ${a.join(' ')} 失败（退出码 ${r.status}）`);
}

// 精准改字服务（tools/setup-textedit.sh 装过才有）：换成新版本的 server.py 重新启动
function restartTextedit() {
  const te = path.join(P.shared, 'textedit');
  const py = path.join(te, 'venv', 'bin', 'python');
  if (!fs.existsSync(py) || spawnSync('pm2', ['describe', 'chengtu-text'], { stdio: 'ignore' }).status !== 0) return;
  spawnSync('pm2', ['delete', 'chengtu-text'], { stdio: 'ignore' });
  const r = spawnSync('pm2', ['start', path.join(P.current, 'tools', 'textedit', 'server.py'), '--name', 'chengtu-text', '--interpreter', py, '--max-memory-restart', '2G'], { stdio: 'ignore', env: { ...process.env, TE_DIR: te } });
  if (r.status !== 0) console.log('  ⚠️ 改字服务重启失败，可执行：bash ' + path.join(P.current, 'tools', 'setup-textedit.sh'));
}
function restartService(version) {
  const svc = releaseConfig().service;
  if (svc.type === 'pm2') {
    writeEcosystem();
    const name = svc.name || 'chengtu';
    const has = spawnSync('pm2', ['describe', name], { stdio: 'ignore' }).status === 0;
    if (has) run('pm2', ['delete', name]); // delete + start：确保使用新的 ecosystem（路径、环境变量）
    run('pm2', ['start', P.ecosystem, '--update-env']);
    restartTextedit();
    spawnSync('pm2', ['save'], { stdio: 'ignore' });
  } else if (svc.type === 'systemd') {
    run('systemctl', ['restart', svc.unit || 'chengtu']);
  } else if (svc.type === 'pidfile') {
    stopPidfile();
    fs.mkdirSync(path.join(P.data, 'logs'), { recursive: true });
    const out = fs.openSync(path.join(P.data, 'logs', 'out.log'), 'a');
    const child = spawn(process.execPath, ['--no-warnings', path.join(P.current, 'src', 'server.js')], {
      cwd: P.shared, detached: true, stdio: ['ignore', out, out], env: { ...process.env, YD_CONFIG: P.config, CT_RELEASE: version },
    });
    child.unref();
    fs.writeFileSync(P.pid, String(child.pid));
  } else throw new Error('未知服务类型：' + svc.type);
}
function stopPidfile() {
  const pid = Number((() => { try { return fs.readFileSync(P.pid, 'utf8'); } catch { return 0; } })());
  if (!pid) return;
  try { process.kill(pid, 'SIGTERM'); } catch { return; }
  const t0 = Date.now();
  while (Date.now() - t0 < 8000) { try { process.kill(pid, 0); } catch { return; } spawnSync('sleep', ['0.2']); }
  try { process.kill(pid, 'SIGKILL'); } catch { /* 已退出 */ }
}

/** 健康检查：新版本真的在服务（版本号、前台构建号、新旧前台入口、接口） */
async function healthCheck(version) {
  const cfg = prodConfig();
  const base = `http://127.0.0.1:${cfg.port || 8360}`;
  const info = readJson(path.join(releaseDir(version), 'release.json'));
  const deadline = Date.now() + releaseConfig().healthTimeout * 1000;
  let last = '';
  while (Date.now() < deadline) {
    try {
      const h = (await (await fetch(base + '/health')).json()).data || {};
      // 迁移前的旧版本（没有版本信息）：只确认服务和首页正常
      if (info.migratedFrom && h.status === 'ok') {
        const r = await fetch(base + '/');
        if (r.status === 200) return true;
        throw new Error('首页返回 ' + r.status);
      }
      if (h.web && h.web.build === info.web.build && h.version === info.backend) {
        const checks = [
          ['/', (r, t) => r.status === 200 && t.includes('/app/assets/')],
          ['/workbench?cat=product&scene=change-bg', (r, t) => r.status === 200 && t.includes('/app/assets/')],
          ['/ydapi/site/config', (r, t) => r.status === 200 && JSON.parse(t).code === 1],
        ];
        for (const [p, ok] of checks) {
          const r = await fetch(base + p);
          const t = await r.text();
          if (!ok(r, t)) throw new Error(`${p} 返回异常（${r.status}）`);
        }
        const entry = /src="(\/app\/assets\/[^"]+\.js)"/.exec(await (await fetch(base + '/')).text());
        if (!entry || (await fetch(base + entry[1])).status !== 200) throw new Error('新前端脚本无法访问');
        return true;
      }
      last = `运行中的版本：后端 ${h.version}，前台 ${h.web && h.web.build}`;
    } catch (e) { last = e.message; }
    await new Promise((r) => setTimeout(r, 1000));
  }
  log(`✗ 健康检查失败：${last}`);
  return false;
}

// ------------------------------------------------------------------ 备份
function backup(from, to) {
  const cfg = normalizeConfig(prodConfig());
  const id = `${stamp()}_${from || 'none'}_to_${to}`.replace(/[^\w.+-]/g, '_');
  const dir = path.join(P.backups, id);
  fs.mkdirSync(dir, { recursive: true });
  fs.copyFileSync(P.config, path.join(dir, 'config.json'));
  if (fs.existsSync(cfg.dbFile)) {
    // VACUUM INTO：在线生成一致的数据库快照（服务运行中也安全）
    const { DatabaseSync } = require('node:sqlite');
    const db = new DatabaseSync(cfg.dbFile);
    try { db.exec(`VACUUM INTO '${path.join(dir, 'db.sqlite').replace(/'/g, "''")}'`); } finally { db.close(); }
  }
  fs.writeFileSync(path.join(dir, 'backup.json'), JSON.stringify({ id, createdAt: now(), from, to, dbFile: cfg.dbFile }, null, 2));
  // 只保留最近 20 份
  const all = fs.readdirSync(P.backups).sort();
  for (const old of all.slice(0, Math.max(0, all.length - 20))) fs.rmSync(path.join(P.backups, old), { recursive: true, force: true });
  log(`✓ 已备份数据库与配置：backups/${id}`);
  return id;
}

function switchTo(v) {
  const tmp = `${P.current}.tmp-${process.pid}`;
  fs.rmSync(tmp, { force: true });
  fs.symlinkSync(path.join('releases', v), tmp);
  fs.renameSync(tmp, P.current); // rename 覆盖软链接是原子的
}

// ------------------------------------------------------------------ activate / rollback
// 收紧文件权限：配置、数据库、备份只有 root 能读（服务器上别的账号 / 程序读不到密钥和用户数据）
function lockDown(cfg) {
  const ch = (f, m) => { try { if (fs.existsSync(f)) fs.chmodSync(f, m); } catch { /* 不支持就算了 */ } };
  ch(P.config, 0o600);
  for (const f of [cfg.dbFile, cfg.dbFile + '-wal', cfg.dbFile + '-shm']) ch(f, 0o600);
  ch(path.dirname(cfg.dbFile), 0o700);
  ch(P.backups, 0o700);
}

async function activate(v, { auto = true, restoreDb = '' } = {}) {
  releaseDir(v);
  const prev = currentVersion();
  const cfg = normalizeConfig(prodConfig());
  fs.writeFileSync(P.config, JSON.stringify(cfg, null, 2) + '\n');
  lockDown(cfg);
  const bid = backup(prev, v);
  if (restoreDb) restoreDatabase(restoreDb, cfg);
  switchTo(v);
  log(`→ 切换 ${prev || '（无）'} → ${v}，重启服务`);
  try { restartService(v); } catch (e) { log('✗ 重启失败：' + e.message); }
  if (await healthCheck(v)) { log(`✅ ${v} 已上线（回滚：node tools/release.js rollback${prev ? ' ' + prev : ''}）`); return true; }
  if (!auto || !prev) { log('✗ 新版本未通过健康检查，且没有可回退的版本'); return false; }
  log(`↩ 自动回退到 ${prev}`);
  switchTo(prev);
  try { restartService(prev); } catch (e) { log('✗ 回退重启失败：' + e.message); }
  const ok = await healthCheck(prev);
  log(ok ? `✓ 已回到 ${prev}（数据库未改动；需要时可用 backups/${bid} 恢复）` : `✗ 回退后仍不健康，请人工检查 ${P.data}/logs`);
  return false;
}

function restoreDatabase(id, cfg) {
  const src = path.join(P.backups, id, 'db.sqlite');
  if (!fs.existsSync(src)) die('备份不存在：' + id);
  const svc = releaseConfig().service;
  if (svc.type === 'pidfile') stopPidfile();
  else if (svc.type === 'pm2') spawnSync('pm2', ['stop', svc.name || 'chengtu'], { stdio: 'inherit' });
  else if (svc.type === 'systemd') spawnSync('systemctl', ['stop', svc.unit || 'chengtu'], { stdio: 'inherit' });
  for (const ext of ['-wal', '-shm']) fs.rmSync(cfg.dbFile + ext, { force: true });
  fs.copyFileSync(src, cfg.dbFile + '.restoring');
  fs.renameSync(cfg.dbFile + '.restoring', cfg.dbFile);
  log(`✓ 数据库已恢复为 backups/${id}`);
}

async function rollback(target) {
  const cur = currentVersion();
  const list = releases().map((r) => r.v);
  const v = target || list[list.indexOf(cur) - 1];
  if (!v) die('没有更早的版本可回退');
  if (v === cur && !opt('restore-db')) die('已经是 ' + v);
  const ok = await activate(v, { auto: true, restoreDb: opt('restore-db') });
  process.exitCode = ok ? 0 : 1;
}

// ------------------------------------------------------------------ migrate（旧结构 → 版本化结构，只复制不删除）
async function migrate() {
  const from = path.resolve(opt('from', '/root/yuduo-server'));
  const web = path.resolve(opt('web', '/root/dist-ip'));
  if (fs.existsSync(P.config) && !flag('force')) die(`已迁移过（${P.config} 已存在）`);
  const oldCfgFile = path.join(from, 'config.json');
  const oldCfg = readJson(oldCfgFile, {});
  const oldRoot = from;
  const oldDb = path.resolve(oldRoot, oldCfg.dbFile || './data/yuduo.db');
  const oldData = path.dirname(oldDb);
  if (!fs.existsSync(oldDb)) die('找不到旧数据库：' + oldDb);
  fs.mkdirSync(P.shared, { recursive: true });
  // 1) 旧版本也做成一个可回退的 release（代码 + 当时的前台）
  const v = `legacy-${stamp()}`;
  const dst = path.join(P.releases, v);
  fs.mkdirSync(dst, { recursive: true });
  for (const item of PACK_ITEMS) {
    const src = path.join(from, item);
    if (fs.existsSync(src)) fs.cpSync(src, path.join(dst, item), { recursive: true });
  }
  if (fs.existsSync(web)) fs.cpSync(web, path.join(dst, 'web'), { recursive: true, filter: (s) => !/\.bak-/.test(s) && s !== path.join(web, 'cos') });
  const pkg = readJson(path.join(from, 'package.json'), {});
  fs.writeFileSync(path.join(dst, 'release.json'), JSON.stringify({ version: v, createdAt: now(), backend: pkg.version, migratedFrom: from, web: { build: (readJson(path.join(web, 'build-info.json'), {}) || {}).build || 'legacy' } }, null, 2) + '\n');
  writeSums(dst);
  // 2) 停服务 → 复制数据（数据库 + 上传文件 + 品牌图 …）→ 新配置
  const svc = releaseConfig().service;
  log(`… 迁移：停止旧服务，复制数据目录 ${oldData} → ${P.data}`);
  if (opt('old-pm2')) spawnSync('pm2', ['stop', opt('old-pm2')], { stdio: 'inherit' });
  fs.cpSync(oldData, P.data, { recursive: true, errorOnExist: false, force: false, filter: (s) => !/\/backup\//.test(s) });
  const upl = path.resolve(oldRoot, oldCfg.uploadDir || './data/uploads');
  if (!upl.startsWith(oldData)) fs.cpSync(upl, path.join(P.data, 'uploads'), { recursive: true });
  // 以前 mirror-cos.js 下载到前台目录里的素材图 → 数据目录（所有版本共用）；旧版本通过软链接继续使用
  if (fs.existsSync(path.join(web, 'cos'))) {
    fs.cpSync(path.join(web, 'cos'), path.join(P.data, 'cos'), { recursive: true, force: false, errorOnExist: false });
    fs.symlinkSync(path.join(P.data, 'cos'), path.join(dst, 'web', 'cos'));
  }
  const cfg = normalizeConfig({ ...oldCfg, dbFile: path.join(P.data, path.basename(oldDb)), uploadDir: path.join(P.data, 'uploads') });
  fs.writeFileSync(P.config, JSON.stringify(cfg, null, 2) + '\n');
  if (!fs.existsSync(P.releaseCfg)) fs.writeFileSync(P.releaseCfg, JSON.stringify({ service: svc, healthTimeout: 40 }, null, 2) + '\n');
  switchTo(v);
  writeEcosystem();
  log(`✅ 迁移完成：当前版本 ${v}。原目录 ${from}、${web} 未做任何修改，可随时退回。`);
  console.log(`\n下一步（切换到新的进程配置）：\n  pm2 delete ${opt('old-pm2') || 'yuduo-server'} ; pm2 start ${P.ecosystem} && pm2 save\n然后发布新版本：node ${path.join(P.current, 'tools', 'release.js')} deploy chengtu-<版本>.tar.gz`);
}

// ------------------------------------------------------------------ 状态
function status() {
  const cur = currentVersion();
  console.log(`目录：${HOME}\n当前版本：${cur || '（未设置）'}`);
  for (const { v, info } of releases()) console.log(`  ${v === cur ? '*' : ' '} ${v}  ${info.createdAt || ''}  前台 ${info.web && info.web.build}`);
}
function listBackups() {
  if (!fs.existsSync(P.backups)) return console.log('（无备份）');
  for (const b of fs.readdirSync(P.backups).sort()) console.log('  ' + b);
}

(async () => {
  try {
    switch (cmd) {
      case 'pack': await pack(); break;
      case 'install': install(positional[0]); break;
      case 'verify': if (!verify(positional[0] || currentVersion())) process.exitCode = 1; break;
      case 'activate': if (!(await activate(positional[0]))) process.exitCode = 1; break;
      case 'deploy': {
        const v = install(positional[0]);
        if (!verify(v)) { log(`✗ ${v} 未通过验证，未切换（当前仍是 ${currentVersion()}）`); process.exitCode = 1; break; }
        if (!(await activate(v))) process.exitCode = 1;
        break;
      }
      case 'rollback': await rollback(positional[0]); break;
      case 'status': case 'list': status(); break;
      case 'backups': listBackups(); break;
      case 'migrate': await migrate(); break;
      default:
        console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(2, 30).map((l) => l.replace(/^ \*\/?\s?/, '')).join('\n'));
        process.exitCode = cmd ? 1 : 0;
    }
  } catch (e) { console.error('❌ ' + (e && e.message || e)); process.exitCode = 1; }
})();
